<?php

$autoload['helper'] = array('markdown');