<?php 
echo table_torch_form_open(); 
echo table_torch_form( $desc, $row ); 
echo table_torch_form_close();
?>
