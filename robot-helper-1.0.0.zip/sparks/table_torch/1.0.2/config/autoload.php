<?php

$autoload['libraries'] = array( 'table_torch' );
$autoload['config'] = array( 'table_torch' );
$autoload['language'] = array( 'table_torch' );

$autoload['helper'] = array( 'table_torch', 'table_torch_form','url', 'inflector', 'form' );
$autoload['model'] = array( 'table_torch_model' );

