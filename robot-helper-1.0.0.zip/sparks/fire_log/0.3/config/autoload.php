<?php


$autoload[ 'libraries' ] = array( 'fire_log' );
$autoload[ 'config' ] = array( 'fire_log' );
$autoload[ 'language' ] = array( 'fire_log' );