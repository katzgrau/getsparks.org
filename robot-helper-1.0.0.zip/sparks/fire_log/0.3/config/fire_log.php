<?php


$config[ 'fire_log_version' ] = '0.3';
$config[ 'fire_log_strip_tags' ] = TRUE;