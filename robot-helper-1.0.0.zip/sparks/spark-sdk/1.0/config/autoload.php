<?php

# Load the spark spec and its dependencies
$autoload['libraries'] = array('yaml', 'spark_spec');
