<?php
/**
 * This file contains the bootstrap controller
 */

/**
 * This is a dummy controller for loading when bootstrapping CodeIgniter
 *  from the CLI. USed primarily for crons.
 */
class Bootstrap extends CI_Controller { function index() {} }