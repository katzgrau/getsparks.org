<?php $this->load->view('global/_new_header.php'); ?>

<div class="search-form">
	
</div>

<?php $this->load->view('global/_new_footer.php'); ?>