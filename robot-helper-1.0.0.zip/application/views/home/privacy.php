<?php $this->load->view('global/_new_header.php'); ?>

<h2>Privacy Policy</h2>

<?php $this->load->view('global/_new_footer.php'); ?>