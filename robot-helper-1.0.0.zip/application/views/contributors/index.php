<?php $this->load->view('global/_new_header.php'); ?>

<h2>Contributor Page</h2>

<?php $this->load->view('global/_new_footer.php'); ?>