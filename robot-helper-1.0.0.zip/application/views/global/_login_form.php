<form action="/login" method="post">
    <fieldset>
        <label for="email">Email Address:</label><br class="clear" />
        <input type="text" id="email" name="email" class="text-box" /><br class="clear" />
        <label for="password">Password:</label><br class="clear" />
        <input type="password" id="password" name="password" class="text-box" /><br class="clear" />
        <input type="submit" id="submit" class="submit" value="Login">
		<a href="/register" class="register">Register</a>
    </fieldset>
</form>