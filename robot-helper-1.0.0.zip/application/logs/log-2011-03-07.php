<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-07 09:56:29 --> Config Class Initialized
DEBUG - 2011-03-07 09:56:29 --> Hooks Class Initialized
DEBUG - 2011-03-07 09:56:29 --> Utf8 Class Initialized
DEBUG - 2011-03-07 09:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 09:56:29 --> URI Class Initialized
DEBUG - 2011-03-07 09:56:29 --> Router Class Initialized
ERROR - 2011-03-07 09:56:29 --> 404 Page Not Found --> sandbox
DEBUG - 2011-03-07 23:04:12 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:12 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:12 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:04:12 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:12 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:12 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:12 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:12 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:04:12 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:04:12 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:04:12 --> JSMin library initialized.
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
ERROR - 2011-03-07 23:04:12 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:12 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:04:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:04:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:04:12 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:04:12 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:12 --> Total execution time: 0.0570
DEBUG - 2011-03-07 23:04:13 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:13 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:13 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:13 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:13 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:13 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:13 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:13 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:13 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:13 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:13 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:13 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:04:13 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:13 --> Total execution time: 0.0321
DEBUG - 2011-03-07 23:04:21 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:21 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:21 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:04:21 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:21 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:21 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:21 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:21 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:04:21 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:04:21 --> JSMin library initialized.
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
ERROR - 2011-03-07 23:04:21 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:04:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:04:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:04:21 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:04:21 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:21 --> Total execution time: 0.0483
DEBUG - 2011-03-07 23:04:21 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:21 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:21 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:21 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:21 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:21 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:21 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:21 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:04:21 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:21 --> Total execution time: 0.0290
DEBUG - 2011-03-07 23:04:29 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:29 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:29 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:04:29 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:29 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:29 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:29 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:29 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:04:29 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:04:29 --> JSMin library initialized.
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
ERROR - 2011-03-07 23:04:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:04:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:04:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:04:29 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:04:29 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:29 --> Total execution time: 0.0442
DEBUG - 2011-03-07 23:04:29 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:29 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:29 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:29 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:29 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:29 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:29 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:29 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:04:29 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:29 --> Total execution time: 0.0369
DEBUG - 2011-03-07 23:04:35 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:35 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:35 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:04:35 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:35 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:35 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:35 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:35 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:04:35 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:04:35 --> JSMin library initialized.
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
ERROR - 2011-03-07 23:04:35 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:04:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:04:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:04:35 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:04:35 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:35 --> Total execution time: 0.0449
DEBUG - 2011-03-07 23:04:35 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:35 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:35 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:35 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:35 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:35 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:35 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:35 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:04:35 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:35 --> Total execution time: 0.0316
DEBUG - 2011-03-07 23:04:41 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:41 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:41 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:04:41 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:41 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:41 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:41 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:41 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:04:41 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:04:41 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:04:41 --> JSMin library initialized.
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
ERROR - 2011-03-07 23:04:41 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:41 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:04:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:04:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:04:41 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:04:41 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:41 --> Total execution time: 0.0462
DEBUG - 2011-03-07 23:04:42 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:42 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:42 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:42 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:42 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:42 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:42 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:42 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:42 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:42 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:42 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:42 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:04:42 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:42 --> Total execution time: 0.0311
DEBUG - 2011-03-07 23:04:46 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:46 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:46 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:04:46 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:46 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:46 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:46 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:46 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:04:46 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:04:46 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:04:46 --> JSMin library initialized.
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
ERROR - 2011-03-07 23:04:46 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:46 --> Model Class Initialized
DEBUG - 2011-03-07 23:04:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:04:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:04:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:04:46 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:04:46 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:46 --> Total execution time: 0.0479
DEBUG - 2011-03-07 23:04:47 --> Config Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:04:47 --> URI Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Router Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Output Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Input Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:04:47 --> Language Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Loader Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:04:47 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:04:47 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:04:47 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:04:47 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:04:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:04:47 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Session Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:04:47 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:04:47 --> Session routines successfully run
DEBUG - 2011-03-07 23:04:47 --> Controller Class Initialized
DEBUG - 2011-03-07 23:04:47 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:04:47 --> Final output sent to browser
DEBUG - 2011-03-07 23:04:47 --> Total execution time: 0.0260
DEBUG - 2011-03-07 23:05:03 --> Config Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:05:03 --> URI Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Router Class Initialized
DEBUG - 2011-03-07 23:05:03 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:05:03 --> Output Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Input Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:05:03 --> Language Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Loader Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:05:03 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Session Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:05:03 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Session routines successfully run
DEBUG - 2011-03-07 23:05:03 --> Controller Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:05:03 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:05:03 --> JSMin library initialized.
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:05:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:05:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:05:03 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:05:03 --> Final output sent to browser
DEBUG - 2011-03-07 23:05:03 --> Total execution time: 0.0474
DEBUG - 2011-03-07 23:05:03 --> Config Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:05:03 --> URI Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Router Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Output Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Input Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:05:03 --> Language Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Loader Class Initialized
DEBUG - 2011-03-07 23:05:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:05:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:05:04 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:05:04 --> Session Class Initialized
DEBUG - 2011-03-07 23:05:04 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:05:04 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:05:04 --> Session routines successfully run
DEBUG - 2011-03-07 23:05:04 --> Controller Class Initialized
DEBUG - 2011-03-07 23:05:04 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:05:04 --> Final output sent to browser
DEBUG - 2011-03-07 23:05:04 --> Total execution time: 0.0276
DEBUG - 2011-03-07 23:05:15 --> Config Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:05:15 --> URI Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Router Class Initialized
DEBUG - 2011-03-07 23:05:15 --> No URI present. Default controller set.
DEBUG - 2011-03-07 23:05:15 --> Output Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Input Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:05:15 --> Language Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Loader Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:05:15 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Session Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:05:15 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Session routines successfully run
DEBUG - 2011-03-07 23:05:15 --> Controller Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:05:15 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:05:15 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:05:15 --> JSMin library initialized.
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
ERROR - 2011-03-07 23:05:15 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:15 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:05:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:05:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:05:15 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-07 23:05:15 --> Final output sent to browser
DEBUG - 2011-03-07 23:05:15 --> Total execution time: 0.0521
DEBUG - 2011-03-07 23:05:16 --> Config Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:05:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:05:16 --> URI Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Router Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Output Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Input Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:05:16 --> Language Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Loader Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:05:16 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:05:16 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:05:16 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:05:16 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:05:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:05:16 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Session Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:05:16 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:05:16 --> Session routines successfully run
DEBUG - 2011-03-07 23:05:16 --> Controller Class Initialized
DEBUG - 2011-03-07 23:05:16 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:05:16 --> Final output sent to browser
DEBUG - 2011-03-07 23:05:16 --> Total execution time: 0.0285
DEBUG - 2011-03-07 23:05:25 --> Config Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:05:25 --> URI Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Router Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Output Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Input Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:05:25 --> Language Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Loader Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:05:25 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Session Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:05:25 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Session routines successfully run
DEBUG - 2011-03-07 23:05:25 --> Controller Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: file_helper
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: directory_helper
DEBUG - 2011-03-07 23:05:25 --> Helper loaded: assets_helper
DEBUG - 2011-03-07 23:05:25 --> CSSMin library initialized.
DEBUG - 2011-03-07 23:05:25 --> JSMin library initialized.
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> Model Class Initialized
DEBUG - 2011-03-07 23:05:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-07 23:05:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-07 23:05:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-07 23:05:25 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-07 23:05:25 --> Final output sent to browser
DEBUG - 2011-03-07 23:05:25 --> Total execution time: 0.0543
DEBUG - 2011-03-07 23:05:26 --> Config Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Hooks Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Utf8 Class Initialized
DEBUG - 2011-03-07 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-07 23:05:26 --> URI Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Router Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Output Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Input Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-07 23:05:26 --> Language Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Loader Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-07 23:05:26 --> Helper loaded: user_helper
DEBUG - 2011-03-07 23:05:26 --> Helper loaded: url_helper
DEBUG - 2011-03-07 23:05:26 --> Helper loaded: array_helper
DEBUG - 2011-03-07 23:05:26 --> Helper loaded: utility_helper
DEBUG - 2011-03-07 23:05:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-07 23:05:26 --> Database Driver Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Session Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Helper loaded: string_helper
DEBUG - 2011-03-07 23:05:26 --> Encrypt Class Initialized
DEBUG - 2011-03-07 23:05:26 --> Session routines successfully run
DEBUG - 2011-03-07 23:05:26 --> Controller Class Initialized
DEBUG - 2011-03-07 23:05:26 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-07 23:05:26 --> Final output sent to browser
DEBUG - 2011-03-07 23:05:26 --> Total execution time: 0.0223
