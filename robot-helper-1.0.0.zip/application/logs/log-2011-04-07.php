<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-07 20:38:21 --> Config Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Hooks Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Utf8 Class Initialized
DEBUG - 2011-04-07 20:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 20:38:21 --> URI Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Router Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Output Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Input Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 20:38:21 --> Language Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Loader Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: user_helper
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: url_helper
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: array_helper
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: utility_helper
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-07 20:38:21 --> Database Driver Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Session Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: string_helper
DEBUG - 2011-04-07 20:38:21 --> Encrypt Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Session routines successfully run
DEBUG - 2011-04-07 20:38:21 --> Controller Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: file_helper
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: directory_helper
DEBUG - 2011-04-07 20:38:21 --> Helper loaded: assets_helper
DEBUG - 2011-04-07 20:38:21 --> CSSMin library initialized.
DEBUG - 2011-04-07 20:38:21 --> JSMin library initialized.
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
ERROR - 2011-04-07 20:38:21 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
DEBUG - 2011-04-07 20:38:21 --> Model Class Initialized
DEBUG - 2011-04-07 20:38:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-07 20:38:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-07 20:38:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-07 20:38:21 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-04-07 20:38:21 --> Final output sent to browser
DEBUG - 2011-04-07 20:38:21 --> Total execution time: 0.0502
DEBUG - 2011-04-07 20:38:22 --> Config Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Hooks Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Utf8 Class Initialized
DEBUG - 2011-04-07 20:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-07 20:38:22 --> URI Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Router Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Output Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Input Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-07 20:38:22 --> Language Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Loader Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-07 20:38:22 --> Helper loaded: user_helper
DEBUG - 2011-04-07 20:38:22 --> Helper loaded: url_helper
DEBUG - 2011-04-07 20:38:22 --> Helper loaded: array_helper
DEBUG - 2011-04-07 20:38:22 --> Helper loaded: utility_helper
DEBUG - 2011-04-07 20:38:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-07 20:38:22 --> Database Driver Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Session Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Helper loaded: string_helper
DEBUG - 2011-04-07 20:38:22 --> Encrypt Class Initialized
DEBUG - 2011-04-07 20:38:22 --> Session routines successfully run
DEBUG - 2011-04-07 20:38:22 --> Controller Class Initialized
DEBUG - 2011-04-07 20:38:22 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-04-07 20:38:22 --> Final output sent to browser
DEBUG - 2011-04-07 20:38:22 --> Total execution time: 0.0297
