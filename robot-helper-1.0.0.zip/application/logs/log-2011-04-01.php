<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-01 19:26:55 --> Config Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Hooks Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Utf8 Class Initialized
DEBUG - 2011-04-01 19:26:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-01 19:26:55 --> URI Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Router Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Output Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Input Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-01 19:26:55 --> Language Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Loader Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: user_helper
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: url_helper
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: array_helper
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: utility_helper
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-01 19:26:55 --> Database Driver Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Session Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: string_helper
DEBUG - 2011-04-01 19:26:55 --> Encrypt Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Session routines successfully run
DEBUG - 2011-04-01 19:26:55 --> Controller Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: file_helper
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: directory_helper
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: assets_helper
DEBUG - 2011-04-01 19:26:55 --> CSSMin library initialized.
DEBUG - 2011-04-01 19:26:55 --> JSMin library initialized.
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-01 19:26:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-01 19:26:55 --> Helper loaded: rating_helper
DEBUG - 2011-04-01 19:26:55 --> Model Class Initialized
DEBUG - 2011-04-01 19:26:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-01 19:26:55 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-01 19:26:55 --> Final output sent to browser
DEBUG - 2011-04-01 19:26:55 --> Total execution time: 0.1065
DEBUG - 2011-04-01 19:26:57 --> Config Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Hooks Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Utf8 Class Initialized
DEBUG - 2011-04-01 19:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-01 19:26:57 --> URI Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Router Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Output Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Input Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-01 19:26:57 --> Language Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Loader Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-01 19:26:57 --> Helper loaded: user_helper
DEBUG - 2011-04-01 19:26:57 --> Helper loaded: url_helper
DEBUG - 2011-04-01 19:26:57 --> Helper loaded: array_helper
DEBUG - 2011-04-01 19:26:57 --> Helper loaded: utility_helper
DEBUG - 2011-04-01 19:26:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-01 19:26:57 --> Database Driver Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Session Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Helper loaded: string_helper
DEBUG - 2011-04-01 19:26:57 --> Encrypt Class Initialized
DEBUG - 2011-04-01 19:26:57 --> Session routines successfully run
DEBUG - 2011-04-01 19:26:57 --> Controller Class Initialized
DEBUG - 2011-04-01 19:26:57 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-04-01 19:26:57 --> Final output sent to browser
DEBUG - 2011-04-01 19:26:57 --> Total execution time: 0.0227
