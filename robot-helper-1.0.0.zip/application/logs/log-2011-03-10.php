<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-10 18:47:48 --> Config Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:47:48 --> URI Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Router Class Initialized
DEBUG - 2011-03-10 18:47:48 --> No URI present. Default controller set.
DEBUG - 2011-03-10 18:47:48 --> Output Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Input Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:47:48 --> Language Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Loader Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:47:48 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Session Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:47:48 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Session routines successfully run
DEBUG - 2011-03-10 18:47:48 --> Controller Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:47:48 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:47:48 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:47:48 --> JSMin library initialized.
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> Model Class Initialized
DEBUG - 2011-03-10 18:47:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:47:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:47:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:47:48 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-10 18:47:48 --> Final output sent to browser
DEBUG - 2011-03-10 18:47:48 --> Total execution time: 0.0562
DEBUG - 2011-03-10 18:47:49 --> Config Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:47:49 --> URI Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Router Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Output Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Input Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:47:49 --> Language Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Loader Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:47:49 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:47:49 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:47:49 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:47:49 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:47:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:47:49 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Session Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:47:49 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:47:49 --> Session routines successfully run
DEBUG - 2011-03-10 18:47:49 --> Controller Class Initialized
DEBUG - 2011-03-10 18:47:49 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:47:49 --> Final output sent to browser
DEBUG - 2011-03-10 18:47:49 --> Total execution time: 0.0318
DEBUG - 2011-03-10 18:54:47 --> Config Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:54:47 --> URI Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Router Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Output Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Input Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:54:47 --> Language Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Loader Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:54:47 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Session Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:54:47 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Session routines successfully run
DEBUG - 2011-03-10 18:54:47 --> Controller Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:54:47 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:54:47 --> JSMin library initialized.
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:54:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:54:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:54:47 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-10 18:54:47 --> Final output sent to browser
DEBUG - 2011-03-10 18:54:47 --> Total execution time: 0.0623
DEBUG - 2011-03-10 18:54:47 --> Config Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:54:47 --> URI Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Router Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Output Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Input Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:54:47 --> Language Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Loader Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:54:47 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Session Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:54:47 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:54:47 --> Session routines successfully run
DEBUG - 2011-03-10 18:54:47 --> Controller Class Initialized
DEBUG - 2011-03-10 18:54:47 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:54:47 --> Final output sent to browser
DEBUG - 2011-03-10 18:54:47 --> Total execution time: 0.0223
DEBUG - 2011-03-10 18:54:49 --> Config Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:54:49 --> URI Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Router Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Output Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Input Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:54:49 --> Language Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Loader Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:54:49 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Session Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:54:49 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Session routines successfully run
DEBUG - 2011-03-10 18:54:49 --> Controller Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:54:49 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:54:49 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:54:49 --> JSMin library initialized.
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:54:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:54:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:54:49 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-10 18:54:49 --> Final output sent to browser
DEBUG - 2011-03-10 18:54:49 --> Total execution time: 0.0444
DEBUG - 2011-03-10 18:54:50 --> Config Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:54:50 --> URI Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Router Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Output Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Input Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:54:50 --> Language Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Loader Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:54:50 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:54:50 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:54:50 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:54:50 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:54:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:54:50 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Session Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:54:50 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:54:50 --> Session routines successfully run
DEBUG - 2011-03-10 18:54:50 --> Controller Class Initialized
DEBUG - 2011-03-10 18:54:50 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:54:50 --> Final output sent to browser
DEBUG - 2011-03-10 18:54:50 --> Total execution time: 0.0236
DEBUG - 2011-03-10 18:54:53 --> Config Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:54:53 --> URI Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Router Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Output Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Input Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:54:53 --> Language Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Loader Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:54:53 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Session Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:54:53 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Session routines successfully run
DEBUG - 2011-03-10 18:54:53 --> Controller Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:54:53 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:54:53 --> JSMin library initialized.
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Model Class Initialized
DEBUG - 2011-03-10 18:54:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:54:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:54:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:54:53 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-10 18:54:53 --> Final output sent to browser
DEBUG - 2011-03-10 18:54:53 --> Total execution time: 0.0507
DEBUG - 2011-03-10 18:54:53 --> Config Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:54:53 --> URI Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Router Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Output Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Input Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:54:53 --> Language Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Loader Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:54:53 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Session Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:54:53 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:54:53 --> Session routines successfully run
DEBUG - 2011-03-10 18:54:53 --> Controller Class Initialized
DEBUG - 2011-03-10 18:54:53 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:54:53 --> Final output sent to browser
DEBUG - 2011-03-10 18:54:53 --> Total execution time: 0.0222
DEBUG - 2011-03-10 18:55:16 --> Config Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:55:16 --> URI Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Router Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Output Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Input Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:55:16 --> Language Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Loader Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:55:16 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Session Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:55:16 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Session routines successfully run
DEBUG - 2011-03-10 18:55:16 --> Controller Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:55:16 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:55:16 --> JSMin library initialized.
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:55:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:55:16 --> User Agent Class Initialized
DEBUG - 2011-03-10 18:55:16 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-10 18:55:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:55:16 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-10 18:55:16 --> Final output sent to browser
DEBUG - 2011-03-10 18:55:16 --> Total execution time: 0.0585
DEBUG - 2011-03-10 18:55:16 --> Config Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:55:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:55:16 --> URI Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Router Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Output Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Input Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:55:16 --> Language Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Loader Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:55:16 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Session Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:55:16 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:55:16 --> Session routines successfully run
DEBUG - 2011-03-10 18:55:16 --> Controller Class Initialized
DEBUG - 2011-03-10 18:55:16 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:55:16 --> Final output sent to browser
DEBUG - 2011-03-10 18:55:16 --> Total execution time: 0.0228
DEBUG - 2011-03-10 18:55:19 --> Config Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:55:19 --> URI Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Router Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Output Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Input Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:55:19 --> Language Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Loader Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:55:19 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:55:19 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:55:19 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:55:19 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:55:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:55:19 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Session Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:55:19 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:55:19 --> Session routines successfully run
DEBUG - 2011-03-10 18:55:19 --> Controller Class Initialized
DEBUG - 2011-03-10 18:55:19 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:55:19 --> Final output sent to browser
DEBUG - 2011-03-10 18:55:19 --> Total execution time: 0.0238
DEBUG - 2011-03-10 18:55:50 --> Config Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:55:50 --> URI Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Router Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Output Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Input Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:55:50 --> Language Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Loader Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:55:50 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Session Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:55:50 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Session routines successfully run
DEBUG - 2011-03-10 18:55:50 --> Controller Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:55:50 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:55:50 --> JSMin library initialized.
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Model Class Initialized
DEBUG - 2011-03-10 18:55:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:55:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:55:50 --> User Agent Class Initialized
DEBUG - 2011-03-10 18:55:50 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-10 18:55:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:55:50 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-10 18:55:50 --> Final output sent to browser
DEBUG - 2011-03-10 18:55:50 --> Total execution time: 0.0520
DEBUG - 2011-03-10 18:55:50 --> Config Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:55:50 --> URI Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Router Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Output Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Input Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:55:50 --> Language Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Loader Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:55:50 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Session Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:55:50 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:55:50 --> Session routines successfully run
DEBUG - 2011-03-10 18:55:50 --> Controller Class Initialized
DEBUG - 2011-03-10 18:55:50 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:55:50 --> Final output sent to browser
DEBUG - 2011-03-10 18:55:50 --> Total execution time: 0.0230
DEBUG - 2011-03-10 18:58:00 --> Config Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:58:00 --> URI Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Router Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Output Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Input Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:58:00 --> Language Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Loader Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:58:00 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Session Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:58:00 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Session routines successfully run
DEBUG - 2011-03-10 18:58:00 --> Controller Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:58:00 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:58:00 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:58:00 --> JSMin library initialized.
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> Model Class Initialized
DEBUG - 2011-03-10 18:58:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:58:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:58:00 --> User Agent Class Initialized
DEBUG - 2011-03-10 18:58:00 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-10 18:58:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:58:00 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-10 18:58:00 --> Final output sent to browser
DEBUG - 2011-03-10 18:58:00 --> Total execution time: 0.0561
DEBUG - 2011-03-10 18:58:26 --> Config Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:58:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:58:26 --> URI Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Router Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Output Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Input Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:58:26 --> Language Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Loader Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:58:26 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:58:26 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:58:26 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:58:26 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:58:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:58:26 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Session Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:58:26 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:58:26 --> Session routines successfully run
DEBUG - 2011-03-10 18:58:26 --> Controller Class Initialized
DEBUG - 2011-03-10 18:58:26 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:58:26 --> Final output sent to browser
DEBUG - 2011-03-10 18:58:26 --> Total execution time: 0.0285
DEBUG - 2011-03-10 18:59:12 --> Config Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:59:12 --> URI Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Router Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Output Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Input Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:59:12 --> Language Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Loader Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:59:12 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Session Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:59:12 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Session routines successfully run
DEBUG - 2011-03-10 18:59:12 --> Controller Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: file_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 18:59:12 --> CSSMin library initialized.
DEBUG - 2011-03-10 18:59:12 --> JSMin library initialized.
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Model Class Initialized
DEBUG - 2011-03-10 18:59:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 18:59:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 18:59:12 --> User Agent Class Initialized
DEBUG - 2011-03-10 18:59:12 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-10 18:59:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 18:59:12 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-10 18:59:12 --> Final output sent to browser
DEBUG - 2011-03-10 18:59:12 --> Total execution time: 0.0529
DEBUG - 2011-03-10 18:59:12 --> Config Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Hooks Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Utf8 Class Initialized
DEBUG - 2011-03-10 18:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 18:59:12 --> URI Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Router Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Output Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Input Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 18:59:12 --> Language Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Loader Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: user_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: url_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: array_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 18:59:12 --> Database Driver Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Session Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Helper loaded: string_helper
DEBUG - 2011-03-10 18:59:12 --> Encrypt Class Initialized
DEBUG - 2011-03-10 18:59:12 --> Session routines successfully run
DEBUG - 2011-03-10 18:59:12 --> Controller Class Initialized
DEBUG - 2011-03-10 18:59:12 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 18:59:12 --> Final output sent to browser
DEBUG - 2011-03-10 18:59:12 --> Total execution time: 0.0251
DEBUG - 2011-03-10 21:44:01 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:01 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:01 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:01 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:01 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:01 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:01 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:01 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:01 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:01 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-10 21:44:01 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:01 --> Total execution time: 0.0498
DEBUG - 2011-03-10 21:44:02 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:02 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:02 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:02 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:02 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:02 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:02 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:02 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:02 --> Total execution time: 0.0237
DEBUG - 2011-03-10 21:44:02 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:02 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:02 --> No URI present. Default controller set.
DEBUG - 2011-03-10 21:44:02 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:02 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:02 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:02 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:02 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:02 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:02 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:02 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-10 21:44:02 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:02 --> Total execution time: 0.0441
DEBUG - 2011-03-10 21:44:02 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:02 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:02 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:02 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:02 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:02 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:02 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:02 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:02 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:02 --> Total execution time: 0.0233
DEBUG - 2011-03-10 21:44:03 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:03 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:03 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:03 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:03 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:03 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:03 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:03 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:03 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:03 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-10 21:44:03 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:03 --> Total execution time: 0.0514
DEBUG - 2011-03-10 21:44:04 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:04 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:04 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:04 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:04 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:04 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:04 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:04 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:04 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:04 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:04 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:04 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:04 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:04 --> Total execution time: 0.0261
DEBUG - 2011-03-10 21:44:05 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:05 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:05 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:05 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:05 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:05 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:05 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:05 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:05 --> User Agent Class Initialized
DEBUG - 2011-03-10 21:44:05 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-10 21:44:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:05 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-10 21:44:05 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:05 --> Total execution time: 0.0503
DEBUG - 2011-03-10 21:44:05 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:05 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:05 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:05 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:05 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:05 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:05 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:05 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:05 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:05 --> Total execution time: 0.0251
DEBUG - 2011-03-10 21:44:07 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:07 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:07 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:07 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:07 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:07 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:07 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:07 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:08 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:08 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:08 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:08 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:08 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:08 --> User Agent Class Initialized
DEBUG - 2011-03-10 21:44:08 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-10 21:44:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:08 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-10 21:44:08 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:08 --> Total execution time: 0.0509
DEBUG - 2011-03-10 21:44:08 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:08 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:08 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:08 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:08 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:08 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:08 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:08 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:08 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:08 --> Total execution time: 0.0290
DEBUG - 2011-03-10 21:44:09 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:09 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:09 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:09 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:09 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:09 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:09 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:09 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:09 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-03-10 21:44:09 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:09 --> Total execution time: 0.0444
DEBUG - 2011-03-10 21:44:09 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:09 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:09 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:09 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:09 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:09 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:09 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:09 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:09 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:09 --> Total execution time: 0.0275
DEBUG - 2011-03-10 21:44:11 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:11 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:11 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:11 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:11 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:11 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: robot_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: form_helper
DEBUG - 2011-03-10 21:44:11 --> Form Validation Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:11 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:11 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:11 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-03-10 21:44:11 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:11 --> Total execution time: 0.0527
DEBUG - 2011-03-10 21:44:11 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:11 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:11 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:11 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:11 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:11 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:11 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:11 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:11 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:11 --> Total execution time: 0.0229
DEBUG - 2011-03-10 21:44:12 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:12 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:12 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:12 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:12 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:12 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: file_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: directory_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: assets_helper
DEBUG - 2011-03-10 21:44:12 --> CSSMin library initialized.
DEBUG - 2011-03-10 21:44:12 --> JSMin library initialized.
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Model Class Initialized
DEBUG - 2011-03-10 21:44:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-10 21:44:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-10 21:44:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-10 21:44:12 --> File loaded: application/views/home/contact.php
DEBUG - 2011-03-10 21:44:12 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:12 --> Total execution time: 0.0416
DEBUG - 2011-03-10 21:44:12 --> Config Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Hooks Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Utf8 Class Initialized
DEBUG - 2011-03-10 21:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-10 21:44:12 --> URI Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Router Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Output Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Input Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-10 21:44:12 --> Language Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Loader Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: user_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: url_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: array_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: utility_helper
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-10 21:44:12 --> Database Driver Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Session Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Helper loaded: string_helper
DEBUG - 2011-03-10 21:44:12 --> Encrypt Class Initialized
DEBUG - 2011-03-10 21:44:12 --> Session routines successfully run
DEBUG - 2011-03-10 21:44:12 --> Controller Class Initialized
DEBUG - 2011-03-10 21:44:12 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-10 21:44:12 --> Final output sent to browser
DEBUG - 2011-03-10 21:44:12 --> Total execution time: 0.0234
