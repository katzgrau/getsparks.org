<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-03 23:38:42 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:42 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Router Class Initialized
DEBUG - 2011-03-03 23:38:42 --> No URI present. Default controller set.
DEBUG - 2011-03-03 23:38:42 --> Output Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Input Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:38:42 --> Language Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Loader Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:38:42 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:38:42 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:38:42 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:38:42 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:38:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:38:42 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Session Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:38:42 --> A session cookie was not found.
DEBUG - 2011-03-03 23:38:42 --> Session routines successfully run
DEBUG - 2011-03-03 23:38:42 --> Controller Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Model Class Initialized
ERROR - 2011-03-03 23:38:42 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-03 23:38:42 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:42 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-03 23:38:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-03 23:38:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-03 23:38:42 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-03 23:38:42 --> Final output sent to browser
DEBUG - 2011-03-03 23:38:42 --> Total execution time: 0.0297
DEBUG - 2011-03-03 23:38:43 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:43 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Router Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Output Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Input Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:38:43 --> Language Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Loader Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:38:43 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:38:43 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:38:43 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:38:43 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:38:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:38:43 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Session Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:38:43 --> Session routines successfully run
DEBUG - 2011-03-03 23:38:43 --> Controller Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Final output sent to browser
DEBUG - 2011-03-03 23:38:43 --> Total execution time: 0.0203
DEBUG - 2011-03-03 23:38:43 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:43 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:43 --> Router Class Initialized
ERROR - 2011-03-03 23:38:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-03 23:38:44 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:44 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Router Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Output Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Input Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:38:44 --> Language Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Loader Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:38:44 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:38:44 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:38:44 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:38:44 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:38:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:38:44 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Session Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:38:44 --> Session routines successfully run
DEBUG - 2011-03-03 23:38:44 --> Controller Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> Model Class Initialized
DEBUG - 2011-03-03 23:38:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-03 23:38:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-03 23:38:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-03 23:38:44 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-03 23:38:44 --> Final output sent to browser
DEBUG - 2011-03-03 23:38:44 --> Total execution time: 0.0332
DEBUG - 2011-03-03 23:38:45 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:45 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Router Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Output Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Input Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:38:45 --> Language Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Loader Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:38:45 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:38:45 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:38:45 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:38:45 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:38:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:38:45 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Session Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:38:45 --> Session routines successfully run
DEBUG - 2011-03-03 23:38:45 --> Controller Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Final output sent to browser
DEBUG - 2011-03-03 23:38:45 --> Total execution time: 0.0191
DEBUG - 2011-03-03 23:38:45 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:45 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:45 --> Router Class Initialized
ERROR - 2011-03-03 23:38:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-03 23:38:46 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:46 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:46 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:46 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:46 --> Router Class Initialized
ERROR - 2011-03-03 23:38:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-03 23:38:46 --> Config Class Initialized
DEBUG - 2011-03-03 23:38:46 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:38:46 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:38:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:38:46 --> URI Class Initialized
DEBUG - 2011-03-03 23:38:46 --> Router Class Initialized
ERROR - 2011-03-03 23:38:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-03 23:41:08 --> Config Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:41:08 --> URI Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Router Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Output Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Input Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:41:08 --> Language Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Loader Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:41:08 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:41:08 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:41:08 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:41:08 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:41:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:41:08 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Session Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:41:08 --> Session routines successfully run
DEBUG - 2011-03-03 23:41:08 --> Controller Class Initialized
DEBUG - 2011-03-03 23:41:08 --> Config file loaded: sparks/fire_log/0.3/config/fire_log.php
DEBUG - 2011-03-03 23:41:08 --> Language file loaded: language/english/fire_log_lang.php
DEBUG - 2011-03-03 23:41:08 --> Helper loaded: file_helper
DEBUG - 2011-03-03 23:41:08 --> File loaded: sparks/fire_log/0.3/views/fire_log_view.php
DEBUG - 2011-03-03 23:41:08 --> Final output sent to browser
DEBUG - 2011-03-03 23:41:08 --> Total execution time: 0.0265
DEBUG - 2011-03-03 23:41:20 --> Config Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:41:20 --> URI Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Router Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Output Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Input Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:41:20 --> Language Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Loader Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:41:20 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:41:20 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:41:20 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:41:20 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:41:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:41:20 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Session Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:41:20 --> Session routines successfully run
DEBUG - 2011-03-03 23:41:20 --> Controller Class Initialized
DEBUG - 2011-03-03 23:41:20 --> Config file loaded: sparks/fire_log/0.3/config/fire_log.php
DEBUG - 2011-03-03 23:41:20 --> Language file loaded: language/english/fire_log_lang.php
DEBUG - 2011-03-03 23:41:20 --> Helper loaded: file_helper
DEBUG - 2011-03-03 23:41:21 --> File loaded: sparks/fire_log/0.3/views/fire_log_view.php
DEBUG - 2011-03-03 23:41:21 --> Final output sent to browser
DEBUG - 2011-03-03 23:41:21 --> Total execution time: 0.0346
DEBUG - 2011-03-03 23:41:25 --> Config Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:41:25 --> URI Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Router Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Output Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Input Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:41:25 --> Language Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Loader Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:41:25 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:41:25 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:41:25 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:41:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:41:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:41:25 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Session Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:41:25 --> Session routines successfully run
DEBUG - 2011-03-03 23:41:25 --> Controller Class Initialized
DEBUG - 2011-03-03 23:41:25 --> Config file loaded: sparks/fire_log/0.3/config/fire_log.php
DEBUG - 2011-03-03 23:41:25 --> Language file loaded: language/english/fire_log_lang.php
DEBUG - 2011-03-03 23:41:25 --> Helper loaded: file_helper
DEBUG - 2011-03-03 23:41:26 --> File loaded: sparks/fire_log/0.3/views/fire_log_view.php
DEBUG - 2011-03-03 23:41:26 --> Final output sent to browser
DEBUG - 2011-03-03 23:41:26 --> Total execution time: 0.0372
DEBUG - 2011-03-03 23:42:33 --> Config Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Hooks Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Utf8 Class Initialized
DEBUG - 2011-03-03 23:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-03 23:42:33 --> URI Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Router Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Output Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Input Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-03 23:42:33 --> Language Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Loader Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-03 23:42:33 --> Helper loaded: user_helper
DEBUG - 2011-03-03 23:42:33 --> Helper loaded: url_helper
DEBUG - 2011-03-03 23:42:33 --> Helper loaded: array_helper
DEBUG - 2011-03-03 23:42:33 --> Helper loaded: utility_helper
DEBUG - 2011-03-03 23:42:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-03 23:42:33 --> Database Driver Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Session Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Helper loaded: string_helper
DEBUG - 2011-03-03 23:42:33 --> Session routines successfully run
DEBUG - 2011-03-03 23:42:33 --> Controller Class Initialized
DEBUG - 2011-03-03 23:42:33 --> Config file loaded: sparks/fire_log/0.3/config/fire_log.php
DEBUG - 2011-03-03 23:42:33 --> Language file loaded: language/english/fire_log_lang.php
DEBUG - 2011-03-03 23:42:33 --> Helper loaded: file_helper
DEBUG - 2011-03-03 23:42:33 --> File loaded: sparks/fire_log/0.3/views/fire_log_view.php
DEBUG - 2011-03-03 23:42:33 --> Final output sent to browser
DEBUG - 2011-03-03 23:42:33 --> Total execution time: 0.0265
