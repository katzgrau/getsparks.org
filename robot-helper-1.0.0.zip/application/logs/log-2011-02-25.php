<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-25 08:54:46 --> Config Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:54:46 --> URI Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Router Class Initialized
DEBUG - 2011-02-25 08:54:46 --> No URI present. Default controller set.
DEBUG - 2011-02-25 08:54:46 --> Output Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Input Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:54:46 --> Language Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Loader Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:54:46 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:54:46 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:54:46 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:54:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:54:46 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Session Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:54:46 --> A session cookie was not found.
DEBUG - 2011-02-25 08:54:46 --> Session routines successfully run
DEBUG - 2011-02-25 08:54:46 --> Controller Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 08:54:46 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Model Class Initialized
ERROR - 2011-02-25 08:54:46 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-25 08:54:46 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:46 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 08:54:46 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 08:54:46 --> Severity: Notice  --> Undefined variable: featured_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 08:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 08:54:46 --> Severity: Notice  --> Undefined variable: top_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
ERROR - 2011-02-25 08:54:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
DEBUG - 2011-02-25 08:54:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 08:54:46 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 08:54:46 --> Final output sent to browser
DEBUG - 2011-02-25 08:54:46 --> Total execution time: 0.0316
DEBUG - 2011-02-25 08:54:48 --> Config Class Initialized
DEBUG - 2011-02-25 08:54:48 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:54:48 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:54:48 --> URI Class Initialized
DEBUG - 2011-02-25 08:54:48 --> Router Class Initialized
ERROR - 2011-02-25 08:54:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-25 08:54:53 --> Config Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:54:53 --> URI Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Router Class Initialized
DEBUG - 2011-02-25 08:54:53 --> No URI present. Default controller set.
DEBUG - 2011-02-25 08:54:53 --> Output Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Input Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:54:53 --> Language Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Loader Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:54:53 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:54:53 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:54:53 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:54:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:54:53 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Session Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:54:53 --> A session cookie was not found.
DEBUG - 2011-02-25 08:54:53 --> Session routines successfully run
DEBUG - 2011-02-25 08:54:53 --> Controller Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 08:54:53 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Model Class Initialized
ERROR - 2011-02-25 08:54:53 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-25 08:54:53 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:53 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 08:54:53 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 08:54:53 --> Severity: Notice  --> Undefined variable: featured_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 08:54:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 08:54:53 --> Severity: Notice  --> Undefined variable: top_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
ERROR - 2011-02-25 08:54:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
DEBUG - 2011-02-25 08:54:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 08:54:53 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 08:54:53 --> Final output sent to browser
DEBUG - 2011-02-25 08:54:53 --> Total execution time: 0.0388
DEBUG - 2011-02-25 08:54:56 --> Config Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:54:56 --> URI Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Router Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Output Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Input Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:54:56 --> Language Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Loader Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:54:56 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Session Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:54:56 --> Session routines successfully run
DEBUG - 2011-02-25 08:54:56 --> Controller Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Config Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:54:56 --> URI Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Router Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Output Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Input Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:54:56 --> Language Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Loader Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:54:56 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Session Class Initialized
DEBUG - 2011-02-25 08:54:56 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:54:56 --> Session routines successfully run
DEBUG - 2011-02-25 08:54:56 --> Controller Class Initialized
ERROR - 2011-02-25 08:54:56 --> 404 Page Not Found --> packages/example-spark
DEBUG - 2011-02-25 08:55:01 --> Config Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:55:01 --> URI Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Router Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Output Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Input Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:55:01 --> Language Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Loader Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:55:01 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Session Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:55:01 --> Session routines successfully run
DEBUG - 2011-02-25 08:55:01 --> Controller Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Config Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:55:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:55:01 --> URI Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Router Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Output Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Input Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:55:01 --> Language Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Loader Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:55:01 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Session Class Initialized
DEBUG - 2011-02-25 08:55:01 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:55:01 --> Session routines successfully run
DEBUG - 2011-02-25 08:55:01 --> Controller Class Initialized
ERROR - 2011-02-25 08:55:01 --> 404 Page Not Found --> packages/markdown
DEBUG - 2011-02-25 08:55:12 --> Config Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:55:12 --> URI Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Router Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Output Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Input Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:55:12 --> Language Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Loader Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:55:12 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Session Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:55:12 --> Session routines successfully run
DEBUG - 2011-02-25 08:55:12 --> Controller Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
ERROR - 2011-02-25 08:55:12 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Model Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Config Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:55:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:55:12 --> URI Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Router Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Output Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Input Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:55:12 --> Language Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Loader Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:55:12 --> Database Driver Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Session Class Initialized
DEBUG - 2011-02-25 08:55:12 --> Helper loaded: string_helper
DEBUG - 2011-02-25 08:55:12 --> Session routines successfully run
DEBUG - 2011-02-25 08:55:12 --> Controller Class Initialized
ERROR - 2011-02-25 08:55:12 --> 404 Page Not Found --> packages/example-spark
DEBUG - 2011-02-25 08:58:42 --> Config Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:58:42 --> URI Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Router Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Output Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Input Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:58:42 --> Language Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Loader Class Initialized
DEBUG - 2011-02-25 08:58:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:58:42 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:58:42 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:58:42 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:58:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 08:59:17 --> Config Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Hooks Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Utf8 Class Initialized
DEBUG - 2011-02-25 08:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 08:59:17 --> URI Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Router Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Output Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Input Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 08:59:17 --> Language Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Loader Class Initialized
DEBUG - 2011-02-25 08:59:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 08:59:17 --> Helper loaded: user_helper
DEBUG - 2011-02-25 08:59:17 --> Helper loaded: url_helper
DEBUG - 2011-02-25 08:59:17 --> Helper loaded: array_helper
DEBUG - 2011-02-25 08:59:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:00:03 --> Config Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:00:03 --> URI Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Router Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Output Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Input Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:00:03 --> Language Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Loader Class Initialized
DEBUG - 2011-02-25 09:00:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:00:03 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:00:03 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:00:03 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:00:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:00:04 --> Config Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:00:04 --> URI Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Router Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Output Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Input Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:00:04 --> Language Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Loader Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:00:04 --> Config Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:00:04 --> URI Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Router Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Output Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Input Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:00:04 --> Language Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Loader Class Initialized
DEBUG - 2011-02-25 09:00:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:00:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:00:56 --> Config Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:00:56 --> URI Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Router Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Output Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Input Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:00:56 --> Language Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Loader Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:00:56 --> Config Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:00:56 --> URI Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Router Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Output Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Input Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:00:56 --> Language Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Loader Class Initialized
DEBUG - 2011-02-25 09:00:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:00:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:01:07 --> Config Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:01:07 --> URI Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Router Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Output Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Input Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:01:07 --> Language Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Loader Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:01:07 --> Config Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:01:07 --> URI Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Router Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Output Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Input Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:01:07 --> Language Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Loader Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:01:07 --> Config Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:01:07 --> URI Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Router Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Output Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Input Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:01:07 --> Language Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Loader Class Initialized
DEBUG - 2011-02-25 09:01:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:01:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:01:42 --> Config Class Initialized
DEBUG - 2011-02-25 09:01:42 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:01:42 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:01:42 --> URI Class Initialized
DEBUG - 2011-02-25 09:01:42 --> Router Class Initialized
DEBUG - 2011-02-25 09:01:42 --> Output Class Initialized
DEBUG - 2011-02-25 09:01:42 --> Input Class Initialized
DEBUG - 2011-02-25 09:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:01:42 --> Language Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Config Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:02:09 --> URI Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Router Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Output Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Input Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:02:09 --> Language Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Loader Class Initialized
DEBUG - 2011-02-25 09:02:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:02:09 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:02:09 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:02:09 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:02:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:02:10 --> Config Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:02:10 --> URI Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Router Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Output Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Input Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:02:10 --> Language Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Loader Class Initialized
DEBUG - 2011-02-25 09:02:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:02:10 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:02:10 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:02:10 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:02:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:02:11 --> Config Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:02:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:02:11 --> URI Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Router Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Output Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Input Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:02:11 --> Language Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Loader Class Initialized
DEBUG - 2011-02-25 09:02:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:02:11 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:02:11 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:02:11 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:02:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:02:54 --> Config Class Initialized
DEBUG - 2011-02-25 09:02:54 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:02:54 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:02:54 --> URI Class Initialized
DEBUG - 2011-02-25 09:02:54 --> Router Class Initialized
DEBUG - 2011-02-25 09:02:54 --> Output Class Initialized
DEBUG - 2011-02-25 09:02:54 --> Input Class Initialized
DEBUG - 2011-02-25 09:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:02:54 --> Language Class Initialized
DEBUG - 2011-02-25 09:02:54 --> Loader Class Initialized
ERROR - 2011-02-25 09:02:54 --> Severity: Notice  --> Undefined variable: spark /Users/katzgrau/Dev/ci-sparks-repo/application/core/MY_Loader.php 123
DEBUG - 2011-02-25 09:03:00 --> Config Class Initialized
DEBUG - 2011-02-25 09:03:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:03:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:03:00 --> URI Class Initialized
DEBUG - 2011-02-25 09:03:00 --> Router Class Initialized
DEBUG - 2011-02-25 09:03:00 --> Output Class Initialized
DEBUG - 2011-02-25 09:03:00 --> Input Class Initialized
DEBUG - 2011-02-25 09:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:03:00 --> Language Class Initialized
DEBUG - 2011-02-25 09:03:00 --> Loader Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Config Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:03:11 --> URI Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Router Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Output Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Input Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:03:11 --> Language Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Loader Class Initialized
DEBUG - 2011-02-25 09:03:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:03:11 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:03:11 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:03:11 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:03:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:03:19 --> Config Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:03:19 --> URI Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Router Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Output Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Input Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:03:19 --> Language Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Loader Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:03:19 --> Config Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:03:19 --> URI Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Router Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Output Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Input Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:03:19 --> Language Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Loader Class Initialized
DEBUG - 2011-02-25 09:03:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:03:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:03:25 --> Config Class Initialized
DEBUG - 2011-02-25 09:03:25 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:03:25 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:03:25 --> URI Class Initialized
DEBUG - 2011-02-25 09:03:25 --> Router Class Initialized
DEBUG - 2011-02-25 09:03:25 --> Output Class Initialized
DEBUG - 2011-02-25 09:03:25 --> Input Class Initialized
DEBUG - 2011-02-25 09:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:03:25 --> Language Class Initialized
DEBUG - 2011-02-25 09:03:25 --> Loader Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Config Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:04:15 --> URI Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Router Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Output Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Input Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:04:15 --> Language Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Loader Class Initialized
DEBUG - 2011-02-25 09:04:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:04:15 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:04:15 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:04:15 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:04:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:04:31 --> Config Class Initialized
DEBUG - 2011-02-25 09:04:31 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:04:31 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:04:31 --> URI Class Initialized
DEBUG - 2011-02-25 09:04:31 --> Router Class Initialized
DEBUG - 2011-02-25 09:04:31 --> Output Class Initialized
DEBUG - 2011-02-25 09:04:31 --> Input Class Initialized
DEBUG - 2011-02-25 09:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:04:31 --> Language Class Initialized
DEBUG - 2011-02-25 09:04:31 --> Loader Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Config Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:04:37 --> URI Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Router Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Output Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Input Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:04:37 --> Language Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Loader Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Controller Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:04:37 --> Model Class Initialized
ERROR - 2011-02-25 09:04:37 --> Severity: Notice  --> Undefined property: Packages::$db /Users/katzgrau/Dev/ci-sparks-repo/application/models/spark.php 51
DEBUG - 2011-02-25 09:05:31 --> Config Class Initialized
DEBUG - 2011-02-25 09:05:31 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:05:31 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:05:31 --> URI Class Initialized
DEBUG - 2011-02-25 09:05:31 --> Router Class Initialized
DEBUG - 2011-02-25 09:05:31 --> Output Class Initialized
DEBUG - 2011-02-25 09:05:31 --> Input Class Initialized
DEBUG - 2011-02-25 09:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:05:31 --> Language Class Initialized
DEBUG - 2011-02-25 09:05:31 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:26 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:26 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:06:26 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:06:26 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:06:26 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:06:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:06:27 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:27 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:27 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:06:27 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:06:27 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:06:27 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:06:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:06:33 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:33 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:33 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:33 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:33 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:33 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:33 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:33 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:33 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:42 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:42 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:06:42 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:06:42 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:06:42 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:06:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:06:47 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:47 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:47 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:06:47 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:06:47 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:06:47 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:06:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:06:48 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:48 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:48 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:06:48 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:06:48 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:06:48 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:06:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:06:53 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:53 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:53 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:06:53 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:06:53 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:06:53 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:06:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:06:58 --> Config Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:06:58 --> URI Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Router Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Output Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Input Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:06:58 --> Language Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Loader Class Initialized
DEBUG - 2011-02-25 09:06:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:15:49 --> Config Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:15:49 --> URI Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Router Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Output Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Input Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:15:49 --> Language Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Loader Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Controller Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:15:49 --> Model Class Initialized
ERROR - 2011-02-25 09:15:49 --> Severity: Notice  --> Undefined property: Packages::$db /Users/katzgrau/Dev/ci-sparks-repo/application/models/spark.php 51
DEBUG - 2011-02-25 09:15:50 --> Config Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:15:50 --> URI Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Router Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Output Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Input Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:15:50 --> Language Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Loader Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Controller Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:15:50 --> Model Class Initialized
ERROR - 2011-02-25 09:15:50 --> Severity: Notice  --> Undefined property: Packages::$db /Users/katzgrau/Dev/ci-sparks-repo/application/models/spark.php 51
DEBUG - 2011-02-25 09:16:37 --> Config Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:16:37 --> URI Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Router Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Output Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Input Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:16:37 --> Language Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Loader Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Controller Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:16:37 --> Model Class Initialized
ERROR - 2011-02-25 09:16:37 --> Severity: Notice  --> Undefined property: Packages::$db /Users/katzgrau/Dev/ci-sparks-repo/application/models/spark.php 51
DEBUG - 2011-02-25 09:17:07 --> Config Class Initialized
DEBUG - 2011-02-25 09:17:07 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:17:07 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:17:07 --> URI Class Initialized
DEBUG - 2011-02-25 09:17:07 --> Router Class Initialized
DEBUG - 2011-02-25 09:17:07 --> Output Class Initialized
DEBUG - 2011-02-25 09:17:07 --> Input Class Initialized
DEBUG - 2011-02-25 09:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:17:07 --> Language Class Initialized
DEBUG - 2011-02-25 09:17:07 --> Loader Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Config Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:17:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:17:43 --> URI Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Router Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Output Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Input Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:17:43 --> Language Class Initialized
DEBUG - 2011-02-25 09:17:43 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:05 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:05 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:05 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:18 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:18 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:18:18 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:18:18 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:18:18 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:18:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:18:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:18:18 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Session Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:18:18 --> Session routines successfully run
DEBUG - 2011-02-25 09:18:18 --> Controller Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:18:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:18:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:18:18 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:18:18 --> Final output sent to browser
DEBUG - 2011-02-25 09:18:18 --> Total execution time: 0.1499
DEBUG - 2011-02-25 09:18:24 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:24 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:24 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:18:24 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:18:24 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:18:24 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:18:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:18:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:18:24 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Session Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:18:24 --> Session routines successfully run
DEBUG - 2011-02-25 09:18:24 --> Controller Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:18:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:18:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:18:24 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:18:24 --> Final output sent to browser
DEBUG - 2011-02-25 09:18:24 --> Total execution time: 0.0337
DEBUG - 2011-02-25 09:18:26 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:26 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:26 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:18:26 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:18:26 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:18:26 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:18:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:18:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:18:26 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Session Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:18:26 --> Session routines successfully run
DEBUG - 2011-02-25 09:18:26 --> Controller Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:18:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:18:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:18:26 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:18:26 --> Final output sent to browser
DEBUG - 2011-02-25 09:18:26 --> Total execution time: 0.0350
DEBUG - 2011-02-25 09:18:30 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:30 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:30 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:18:30 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:18:30 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:18:30 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:18:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:18:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:18:30 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Session Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:18:30 --> Session routines successfully run
DEBUG - 2011-02-25 09:18:30 --> Controller Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:18:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:18:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:18:30 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:18:30 --> Final output sent to browser
DEBUG - 2011-02-25 09:18:30 --> Total execution time: 0.0332
DEBUG - 2011-02-25 09:18:33 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:33 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:33 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:18:33 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:18:33 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:18:33 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:18:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:18:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:18:33 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Session Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:18:33 --> Session routines successfully run
DEBUG - 2011-02-25 09:18:33 --> Controller Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:18:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:18:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:18:33 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:18:33 --> Final output sent to browser
DEBUG - 2011-02-25 09:18:33 --> Total execution time: 0.0329
DEBUG - 2011-02-25 09:18:36 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:36 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:36 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:18:36 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:18:36 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:18:36 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:18:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:18:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:18:36 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Session Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:18:36 --> Session routines successfully run
DEBUG - 2011-02-25 09:18:36 --> Controller Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:18:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:18:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:18:36 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:18:36 --> Final output sent to browser
DEBUG - 2011-02-25 09:18:36 --> Total execution time: 0.0325
DEBUG - 2011-02-25 09:18:44 --> Config Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:18:44 --> URI Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Router Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Output Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Input Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:18:44 --> Language Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Loader Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:18:44 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:18:44 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:18:44 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:18:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:18:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:18:44 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Session Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:18:44 --> Session routines successfully run
DEBUG - 2011-02-25 09:18:44 --> Controller Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
ERROR - 2011-02-25 09:18:44 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:18:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:18:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:18:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:18:44 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:18:44 --> Final output sent to browser
DEBUG - 2011-02-25 09:18:44 --> Total execution time: 0.0345
DEBUG - 2011-02-25 09:21:36 --> Config Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:21:36 --> URI Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Router Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Output Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Input Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:21:36 --> Language Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Loader Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:21:36 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:21:36 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:21:36 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:21:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:21:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:21:36 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Session Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:21:36 --> Session routines successfully run
DEBUG - 2011-02-25 09:21:36 --> Controller Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:21:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:21:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:21:36 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:21:36 --> Final output sent to browser
DEBUG - 2011-02-25 09:21:36 --> Total execution time: 0.0351
DEBUG - 2011-02-25 09:21:37 --> Config Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:21:37 --> URI Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Router Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Output Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Input Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:21:37 --> Language Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Loader Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:21:37 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:21:37 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:21:37 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:21:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:21:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:21:37 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Session Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:21:37 --> Session routines successfully run
DEBUG - 2011-02-25 09:21:37 --> Controller Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
ERROR - 2011-02-25 09:21:37 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:21:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:21:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:21:37 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:21:37 --> Final output sent to browser
DEBUG - 2011-02-25 09:21:37 --> Total execution time: 0.0347
DEBUG - 2011-02-25 09:21:44 --> Config Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:21:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:21:44 --> URI Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Router Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Output Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Input Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:21:44 --> Language Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Loader Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:21:44 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:21:44 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:21:44 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:21:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:21:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:21:44 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Session Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:21:44 --> Session routines successfully run
DEBUG - 2011-02-25 09:21:44 --> Controller Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:21:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:21:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:21:44 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 09:21:44 --> Final output sent to browser
DEBUG - 2011-02-25 09:21:44 --> Total execution time: 0.0293
DEBUG - 2011-02-25 09:21:47 --> Config Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:21:47 --> URI Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Router Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Output Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Input Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:21:47 --> Language Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Loader Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:21:47 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:21:47 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:21:47 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:21:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:21:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:21:47 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Session Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:21:47 --> Session routines successfully run
DEBUG - 2011-02-25 09:21:47 --> Controller Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:21:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:21:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:21:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:21:47 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 09:21:47 --> Final output sent to browser
DEBUG - 2011-02-25 09:21:47 --> Total execution time: 0.0284
DEBUG - 2011-02-25 09:22:00 --> Config Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:22:00 --> URI Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Router Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Output Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Input Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:22:00 --> Language Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Loader Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:22:00 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:22:00 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:22:00 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:22:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:22:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:22:00 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Session Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:22:00 --> Session routines successfully run
DEBUG - 2011-02-25 09:22:00 --> Controller Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:22:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:22:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:22:00 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 09:22:00 --> Final output sent to browser
DEBUG - 2011-02-25 09:22:00 --> Total execution time: 0.0303
DEBUG - 2011-02-25 09:22:09 --> Config Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:22:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:22:09 --> URI Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Router Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Output Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Input Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:22:09 --> Language Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Loader Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:22:09 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:22:09 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:22:09 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:22:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:22:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:22:09 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Session Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:22:09 --> Session routines successfully run
DEBUG - 2011-02-25 09:22:09 --> Controller Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:22:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:22:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:22:09 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 09:22:09 --> Final output sent to browser
DEBUG - 2011-02-25 09:22:09 --> Total execution time: 0.0291
DEBUG - 2011-02-25 09:22:14 --> Config Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:22:14 --> URI Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Router Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Output Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Input Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:22:14 --> Language Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Loader Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:22:14 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:22:14 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:22:14 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:22:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:22:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:22:14 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Session Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:22:14 --> Session routines successfully run
DEBUG - 2011-02-25 09:22:14 --> Controller Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Model Class Initialized
ERROR - 2011-02-25 09:22:14 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-25 09:22:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:22:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:22:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:22:14 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 09:22:14 --> Final output sent to browser
DEBUG - 2011-02-25 09:22:14 --> Total execution time: 0.0296
DEBUG - 2011-02-25 09:22:19 --> Config Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:22:19 --> URI Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Router Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Output Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Input Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:22:19 --> Language Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Loader Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:22:19 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Session Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:22:19 --> Session routines successfully run
DEBUG - 2011-02-25 09:22:19 --> Controller Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Config Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:22:19 --> URI Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Router Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Output Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Input Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:22:19 --> Language Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Loader Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:22:19 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Session Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:22:19 --> Session routines successfully run
DEBUG - 2011-02-25 09:22:19 --> Controller Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:22:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:22:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:22:19 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:22:19 --> Final output sent to browser
DEBUG - 2011-02-25 09:22:19 --> Total execution time: 0.0378
DEBUG - 2011-02-25 09:22:40 --> Config Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:22:40 --> URI Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Router Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Output Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Input Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:22:40 --> Language Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Loader Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:22:40 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:22:40 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:22:40 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:22:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:22:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:22:40 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Session Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:22:40 --> Session routines successfully run
DEBUG - 2011-02-25 09:22:40 --> Controller Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:22:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:22:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:22:40 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:22:40 --> Final output sent to browser
DEBUG - 2011-02-25 09:22:40 --> Total execution time: 0.0348
DEBUG - 2011-02-25 09:22:50 --> Config Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:22:50 --> URI Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Router Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Output Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Input Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:22:50 --> Language Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Loader Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:22:50 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:22:50 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:22:50 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:22:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:22:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:22:50 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Session Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:22:50 --> Session routines successfully run
DEBUG - 2011-02-25 09:22:50 --> Controller Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:22:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Config Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:25:27 --> URI Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Router Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Output Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Input Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:25:27 --> Language Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Loader Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:25:27 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:25:27 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:25:27 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:25:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:25:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:25:27 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Session Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:25:27 --> Session routines successfully run
DEBUG - 2011-02-25 09:25:27 --> Controller Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:25:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:25:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:25:27 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:25:27 --> Final output sent to browser
DEBUG - 2011-02-25 09:25:27 --> Total execution time: 0.0302
DEBUG - 2011-02-25 09:25:30 --> Config Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:25:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:25:30 --> URI Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Router Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Output Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Input Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:25:30 --> Language Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Loader Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:25:30 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:25:30 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:25:30 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:25:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:25:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:25:30 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Session Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:25:30 --> Session routines successfully run
DEBUG - 2011-02-25 09:25:30 --> Controller Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:25:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:25:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:25:30 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:25:30 --> Final output sent to browser
DEBUG - 2011-02-25 09:25:30 --> Total execution time: 0.0327
DEBUG - 2011-02-25 09:25:34 --> Config Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:25:34 --> URI Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Router Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Output Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Input Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:25:34 --> Language Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Loader Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:25:34 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:25:34 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:25:34 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:25:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:25:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:25:34 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Session Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:25:34 --> Session routines successfully run
DEBUG - 2011-02-25 09:25:34 --> Controller Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:25:34 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:34 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:25:34 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:25:34 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:25:34 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:25:34 --> Final output sent to browser
DEBUG - 2011-02-25 09:25:34 --> Total execution time: 0.0352
DEBUG - 2011-02-25 09:25:38 --> Config Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:25:38 --> URI Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Router Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Output Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Input Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:25:38 --> Language Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Loader Class Initialized
DEBUG - 2011-02-25 09:25:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:25:38 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:25:38 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:25:38 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:25:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:25:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:25:38 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Session Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:25:39 --> Session routines successfully run
DEBUG - 2011-02-25 09:25:39 --> Controller Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:25:39 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:25:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:25:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:25:39 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-25 09:25:39 --> Final output sent to browser
DEBUG - 2011-02-25 09:25:39 --> Total execution time: 0.0319
DEBUG - 2011-02-25 09:25:46 --> Config Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:25:46 --> URI Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Router Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Output Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Input Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:25:46 --> Language Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Loader Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:25:46 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:25:46 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:25:46 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:25:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:25:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:25:46 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Session Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:25:46 --> Session routines successfully run
DEBUG - 2011-02-25 09:25:46 --> Controller Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:25:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:25:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:25:46 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:25:46 --> Final output sent to browser
DEBUG - 2011-02-25 09:25:46 --> Total execution time: 0.0324
DEBUG - 2011-02-25 09:25:49 --> Config Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:25:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:25:49 --> URI Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Router Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Output Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Input Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:25:49 --> Language Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Loader Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:25:49 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:25:49 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:25:49 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:25:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:25:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:25:49 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Session Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:25:49 --> Session routines successfully run
DEBUG - 2011-02-25 09:25:49 --> Controller Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:25:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:25:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:25:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:25:49 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:25:49 --> Final output sent to browser
DEBUG - 2011-02-25 09:25:49 --> Total execution time: 0.0338
DEBUG - 2011-02-25 09:26:02 --> Config Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:26:02 --> URI Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Router Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Output Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Input Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:26:02 --> Language Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Loader Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:26:02 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:26:02 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:26:02 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:26:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:26:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:26:02 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Session Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:26:02 --> Session routines successfully run
DEBUG - 2011-02-25 09:26:02 --> Controller Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Model Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Model Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Model Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Model Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Model Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Model Class Initialized
DEBUG - 2011-02-25 09:26:02 --> Final output sent to browser
DEBUG - 2011-02-25 09:26:02 --> Total execution time: 0.0283
DEBUG - 2011-02-25 09:27:36 --> Config Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:27:36 --> URI Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Router Class Initialized
DEBUG - 2011-02-25 09:27:36 --> No URI present. Default controller set.
DEBUG - 2011-02-25 09:27:36 --> Output Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Input Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:27:36 --> Language Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Loader Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:27:36 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:27:36 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:27:36 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:27:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:27:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:27:36 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Session Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:27:36 --> Session routines successfully run
DEBUG - 2011-02-25 09:27:36 --> Controller Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:27:36 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 09:27:36 --> Severity: Notice  --> Undefined variable: featured_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 09:27:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 09:27:36 --> Severity: Notice  --> Undefined variable: top_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
ERROR - 2011-02-25 09:27:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
DEBUG - 2011-02-25 09:27:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:27:36 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 09:27:36 --> Final output sent to browser
DEBUG - 2011-02-25 09:27:36 --> Total execution time: 0.0342
DEBUG - 2011-02-25 09:27:41 --> Config Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:27:41 --> URI Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Router Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Output Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Input Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:27:41 --> Language Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Loader Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:27:41 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:27:41 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:27:41 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:27:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:27:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:27:41 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Session Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:27:41 --> Session routines successfully run
DEBUG - 2011-02-25 09:27:41 --> Controller Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:27:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:27:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:27:41 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-25 09:27:41 --> Final output sent to browser
DEBUG - 2011-02-25 09:27:41 --> Total execution time: 0.0332
DEBUG - 2011-02-25 09:27:47 --> Config Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:27:47 --> URI Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Router Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Output Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Input Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:27:47 --> Language Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Loader Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:27:47 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:27:47 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:27:47 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:27:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:27:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:27:47 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Session Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:27:47 --> Session routines successfully run
DEBUG - 2011-02-25 09:27:47 --> Controller Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:27:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:27:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:27:47 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:27:47 --> Final output sent to browser
DEBUG - 2011-02-25 09:27:47 --> Total execution time: 0.0312
DEBUG - 2011-02-25 09:27:59 --> Config Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:27:59 --> URI Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Router Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Output Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Input Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:27:59 --> Language Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Loader Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:27:59 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:27:59 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:27:59 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:27:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:27:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:27:59 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Session Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:27:59 --> Session routines successfully run
DEBUG - 2011-02-25 09:27:59 --> Controller Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:27:59 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:27:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:27:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:27:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:27:59 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:27:59 --> Final output sent to browser
DEBUG - 2011-02-25 09:27:59 --> Total execution time: 0.0317
DEBUG - 2011-02-25 09:28:11 --> Config Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:28:11 --> URI Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Router Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Output Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Input Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:28:11 --> Language Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Loader Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:28:11 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:28:11 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:28:11 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:28:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:28:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:28:11 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Session Class Initialized
DEBUG - 2011-02-25 09:28:11 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:28:11 --> Session routines successfully run
DEBUG - 2011-02-25 09:28:11 --> Controller Class Initialized
ERROR - 2011-02-25 09:28:11 --> 404 Page Not Found --> contributors/%3C
DEBUG - 2011-02-25 09:33:25 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:25 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:25 --> No URI present. Default controller set.
DEBUG - 2011-02-25 09:33:25 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:25 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:25 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:25 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:25 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:25 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:25 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:25 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:25 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:25 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 09:33:25 --> Severity: Notice  --> Undefined variable: featured_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 09:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 09:33:25 --> Severity: Notice  --> Undefined variable: top_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
ERROR - 2011-02-25 09:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
DEBUG - 2011-02-25 09:33:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:25 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 09:33:25 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:25 --> Total execution time: 0.0397
DEBUG - 2011-02-25 09:33:26 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:26 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:26 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:26 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:26 --> Router Class Initialized
ERROR - 2011-02-25 09:33:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-25 09:33:29 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:29 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:29 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:29 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:29 --> Router Class Initialized
ERROR - 2011-02-25 09:33:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-25 09:33:31 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:31 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:31 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:31 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:31 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:31 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:31 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:31 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:31 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:33:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:31 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:33:31 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:31 --> Total execution time: 0.0395
DEBUG - 2011-02-25 09:33:34 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:34 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:34 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:34 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:34 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:34 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:34 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:34 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:34 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:33:34 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:34 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:34 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:33:34 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:34 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:33:34 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:34 --> Total execution time: 0.0343
DEBUG - 2011-02-25 09:33:40 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:40 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:40 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:40 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:40 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:40 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:40 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:40 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:40 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:33:40 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:33:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:40 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:33:40 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:40 --> Total execution time: 0.0387
DEBUG - 2011-02-25 09:33:49 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:49 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:49 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:49 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:49 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:49 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:49 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:49 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:49 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:33:49 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:33:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:49 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:33:49 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:49 --> Total execution time: 0.0396
DEBUG - 2011-02-25 09:33:53 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:53 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:53 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:53 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:53 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:53 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:53 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:53 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:53 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:33:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:53 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:33:53 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:53 --> Total execution time: 0.0316
DEBUG - 2011-02-25 09:33:56 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:56 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:56 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:56 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:56 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:56 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:56 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:56 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:56 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:33:56 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:33:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:56 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:33:56 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:56 --> Total execution time: 0.0346
DEBUG - 2011-02-25 09:33:58 --> Config Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:33:58 --> URI Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Router Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Output Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Input Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:33:58 --> Language Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Loader Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:33:58 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:33:58 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:33:58 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:33:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:33:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:33:58 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Session Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:33:58 --> Session routines successfully run
DEBUG - 2011-02-25 09:33:58 --> Controller Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> Model Class Initialized
DEBUG - 2011-02-25 09:33:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:33:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:33:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:33:58 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:33:58 --> Final output sent to browser
DEBUG - 2011-02-25 09:33:58 --> Total execution time: 0.0334
DEBUG - 2011-02-25 09:34:04 --> Config Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:34:04 --> URI Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Router Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Output Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Input Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:34:04 --> Language Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Loader Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:34:04 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:34:04 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:34:04 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:34:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:34:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:34:04 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Session Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:34:04 --> Session routines successfully run
DEBUG - 2011-02-25 09:34:04 --> Controller Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:34:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:34:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:34:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:34:04 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:34:04 --> Final output sent to browser
DEBUG - 2011-02-25 09:34:04 --> Total execution time: 0.0316
DEBUG - 2011-02-25 09:35:00 --> Config Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:35:00 --> URI Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Router Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Output Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Input Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:35:00 --> Language Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Loader Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:35:00 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:35:00 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:35:00 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:35:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:35:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:35:00 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Session Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:35:00 --> Session routines successfully run
DEBUG - 2011-02-25 09:35:00 --> Controller Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:35:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:35:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:35:00 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:35:00 --> Final output sent to browser
DEBUG - 2011-02-25 09:35:00 --> Total execution time: 0.0343
DEBUG - 2011-02-25 09:35:53 --> Config Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:35:53 --> URI Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Router Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Output Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Input Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:35:53 --> Language Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Loader Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:35:53 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:35:53 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:35:53 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:35:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:35:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:35:53 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Session Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:35:53 --> Session routines successfully run
DEBUG - 2011-02-25 09:35:53 --> Controller Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:35:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:35:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:35:53 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:35:53 --> Final output sent to browser
DEBUG - 2011-02-25 09:35:53 --> Total execution time: 0.0310
DEBUG - 2011-02-25 09:35:55 --> Config Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:35:55 --> URI Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Router Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Output Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Input Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:35:55 --> Language Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Loader Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:35:55 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:35:55 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:35:55 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:35:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:35:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:35:55 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Session Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:35:55 --> Session routines successfully run
DEBUG - 2011-02-25 09:35:55 --> Controller Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:35:55 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:35:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:35:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:35:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:35:55 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:35:55 --> Final output sent to browser
DEBUG - 2011-02-25 09:35:55 --> Total execution time: 0.0337
DEBUG - 2011-02-25 09:37:44 --> Config Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:37:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:37:44 --> URI Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Router Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Output Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Input Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:37:44 --> Language Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Loader Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:37:44 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:37:44 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:37:44 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:37:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:37:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:37:44 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Session Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:37:44 --> Session routines successfully run
DEBUG - 2011-02-25 09:37:44 --> Controller Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:37:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:37:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:37:44 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:37:44 --> Final output sent to browser
DEBUG - 2011-02-25 09:37:44 --> Total execution time: 0.0357
DEBUG - 2011-02-25 09:37:46 --> Config Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:37:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:37:46 --> URI Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Router Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Output Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Input Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:37:46 --> Language Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Loader Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:37:46 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:37:46 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:37:46 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:37:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:37:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:37:46 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Session Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:37:46 --> Session routines successfully run
DEBUG - 2011-02-25 09:37:46 --> Controller Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:37:46 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:37:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:37:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:37:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:37:46 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:37:46 --> Final output sent to browser
DEBUG - 2011-02-25 09:37:46 --> Total execution time: 0.0330
DEBUG - 2011-02-25 09:46:13 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:13 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:13 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:13 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:13 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:13 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:13 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:13 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:13 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:46:13 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:13 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:46:13 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:13 --> Total execution time: 0.0378
DEBUG - 2011-02-25 09:46:26 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:26 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:26 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:26 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:26 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:26 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:26 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:26 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:26 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:26 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:46:26 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:26 --> Total execution time: 0.0317
DEBUG - 2011-02-25 09:46:28 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:28 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:28 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:28 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:28 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:28 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:28 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:28 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:28 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:46:28 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:28 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:46:28 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:28 --> Total execution time: 0.0371
DEBUG - 2011-02-25 09:46:29 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:29 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:29 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:29 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:29 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:29 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:29 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:29 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:29 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:46:29 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:29 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:29 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-25 09:46:29 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:29 --> Total execution time: 0.0322
DEBUG - 2011-02-25 09:46:30 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:30 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:30 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:30 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:30 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:30 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:30 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:30 --> No URI present. Default controller set.
DEBUG - 2011-02-25 09:46:30 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:30 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:30 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:30 --> A session cookie was not found.
DEBUG - 2011-02-25 09:46:30 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:30 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:30 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:30 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 09:46:31 --> Severity: Notice  --> Undefined variable: featured_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 09:46:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 21
ERROR - 2011-02-25 09:46:31 --> Severity: Notice  --> Undefined variable: top_sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
ERROR - 2011-02-25 09:46:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /Users/katzgrau/Dev/ci-sparks-repo/application/views/home/index.php 39
DEBUG - 2011-02-25 09:46:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:31 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 09:46:31 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:31 --> Total execution time: 0.0276
DEBUG - 2011-02-25 09:46:35 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:35 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:35 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:35 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:35 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:35 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:35 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:35 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:36 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:36 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:36 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:36 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:36 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:36 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:36 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:46:36 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:36 --> Total execution time: 0.0346
DEBUG - 2011-02-25 09:46:41 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:41 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:41 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:41 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:41 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:41 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:41 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:41 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:41 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:41 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:46:41 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:41 --> Total execution time: 0.0328
DEBUG - 2011-02-25 09:46:43 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:43 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:43 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:43 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:43 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:43 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:43 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:43 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:43 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:43 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:46:43 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:43 --> Total execution time: 0.0325
DEBUG - 2011-02-25 09:46:48 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:48 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:48 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:48 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:48 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:48 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:48 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:48 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:48 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:48 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:48 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:48 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 09:46:48 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:48 --> Total execution time: 0.0350
DEBUG - 2011-02-25 09:46:50 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:50 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:50 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:50 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:50 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:50 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:50 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:50 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:50 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:50 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:46:50 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:50 --> Total execution time: 0.0323
DEBUG - 2011-02-25 09:46:53 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:53 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:53 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:53 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:53 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:53 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:53 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:53 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:53 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:54 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:54 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:54 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:54 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:54 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:54 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:46:54 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:54 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:54 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-25 09:46:54 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:54 --> Total execution time: 0.0339
DEBUG - 2011-02-25 09:46:55 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:55 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:55 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:55 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:55 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:55 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:55 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:55 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:55 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:46:55 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:55 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:46:55 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:55 --> Total execution time: 0.0322
DEBUG - 2011-02-25 09:46:57 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:57 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:57 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:57 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:57 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:57 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:57 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:57 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:57 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:57 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:46:57 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:57 --> Total execution time: 0.0320
DEBUG - 2011-02-25 09:46:59 --> Config Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:46:59 --> URI Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Router Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Output Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Input Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:46:59 --> Language Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Loader Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:46:59 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:46:59 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:46:59 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:46:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:46:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:46:59 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Session Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:46:59 --> Session routines successfully run
DEBUG - 2011-02-25 09:46:59 --> Controller Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:59 --> Model Class Initialized
DEBUG - 2011-02-25 09:46:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:46:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:46:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:46:59 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 09:46:59 --> Final output sent to browser
DEBUG - 2011-02-25 09:46:59 --> Total execution time: 0.0328
DEBUG - 2011-02-25 09:47:01 --> Config Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:47:01 --> URI Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Router Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Output Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Input Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:47:01 --> Language Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Loader Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:47:01 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:47:01 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:47:01 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:47:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:47:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:47:01 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Session Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:47:01 --> Session routines successfully run
DEBUG - 2011-02-25 09:47:01 --> Controller Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:47:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:47:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:47:01 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:47:01 --> Final output sent to browser
DEBUG - 2011-02-25 09:47:01 --> Total execution time: 0.0346
DEBUG - 2011-02-25 09:47:09 --> Config Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:47:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:47:09 --> URI Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Router Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Output Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Input Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:47:09 --> Language Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Loader Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:47:09 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:47:09 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:47:09 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:47:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:47:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:47:09 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Session Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:47:09 --> Session routines successfully run
DEBUG - 2011-02-25 09:47:09 --> Controller Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:47:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:47:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:47:09 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:47:09 --> Final output sent to browser
DEBUG - 2011-02-25 09:47:09 --> Total execution time: 0.0337
DEBUG - 2011-02-25 09:47:12 --> Config Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:47:12 --> URI Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Router Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Output Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Input Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:47:12 --> Language Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Loader Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:47:12 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:47:12 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:47:12 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:47:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:47:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:47:12 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Session Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:47:12 --> Session routines successfully run
DEBUG - 2011-02-25 09:47:12 --> Controller Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:47:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:47:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:47:12 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:47:12 --> Final output sent to browser
DEBUG - 2011-02-25 09:47:12 --> Total execution time: 0.0323
DEBUG - 2011-02-25 09:47:14 --> Config Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:47:14 --> URI Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Router Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Output Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Input Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:47:14 --> Language Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Loader Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:47:14 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:47:14 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:47:14 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:47:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:47:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:47:14 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Session Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:47:14 --> Session routines successfully run
DEBUG - 2011-02-25 09:47:14 --> Controller Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> Model Class Initialized
DEBUG - 2011-02-25 09:47:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:47:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:47:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:47:14 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:47:14 --> Final output sent to browser
DEBUG - 2011-02-25 09:47:14 --> Total execution time: 0.0335
DEBUG - 2011-02-25 09:51:00 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:00 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:00 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:00 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:00 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:00 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:00 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:00 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:00 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:00 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:00 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:00 --> Total execution time: 0.0327
DEBUG - 2011-02-25 09:51:04 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:04 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:04 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:04 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:04 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:04 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:04 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:04 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:04 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:04 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:04 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:04 --> Total execution time: 0.0319
DEBUG - 2011-02-25 09:51:07 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:07 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:07 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:07 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:07 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:07 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:07 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:07 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:07 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:51:07 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:07 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:51:07 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:07 --> Total execution time: 0.0339
DEBUG - 2011-02-25 09:51:09 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:09 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:09 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:09 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:09 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:09 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:09 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:09 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:09 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:09 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:09 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:09 --> Total execution time: 0.0335
DEBUG - 2011-02-25 09:51:12 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:12 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:12 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:12 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:12 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:12 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:12 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:12 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:12 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:12 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:12 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:12 --> Total execution time: 0.0323
DEBUG - 2011-02-25 09:51:13 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:13 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:13 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:13 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:13 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:13 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:13 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:13 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:13 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:13 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:13 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:13 --> Total execution time: 0.0320
DEBUG - 2011-02-25 09:51:20 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:20 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:20 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:20 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:20 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:20 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:20 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:20 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:20 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:51:20 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:20 --> File loaded: application/views/contributors/edit.php
DEBUG - 2011-02-25 09:51:20 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:20 --> Total execution time: 0.0357
DEBUG - 2011-02-25 09:51:22 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:22 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:22 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:22 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:22 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:22 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:22 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:22 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:22 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Helper loaded: form_helper
DEBUG - 2011-02-25 09:51:22 --> Form Validation Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:22 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:22 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-25 09:51:22 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:22 --> Total execution time: 0.0317
DEBUG - 2011-02-25 09:51:39 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:39 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:39 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:39 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:39 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:39 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:39 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:39 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:39 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:39 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:39 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:39 --> Total execution time: 0.0338
DEBUG - 2011-02-25 09:51:40 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:40 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:40 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:40 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:40 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:40 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:40 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:40 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:40 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:40 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:41 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:41 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:41 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:41 --> Total execution time: 0.0324
DEBUG - 2011-02-25 09:51:43 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:43 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:43 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:43 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:43 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:43 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:43 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:43 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:43 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:43 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:43 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:43 --> Total execution time: 0.0321
DEBUG - 2011-02-25 09:51:46 --> Config Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Hooks Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Utf8 Class Initialized
DEBUG - 2011-02-25 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 09:51:46 --> URI Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Router Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Output Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Input Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 09:51:46 --> Language Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Loader Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 09:51:46 --> Helper loaded: user_helper
DEBUG - 2011-02-25 09:51:46 --> Helper loaded: url_helper
DEBUG - 2011-02-25 09:51:46 --> Helper loaded: array_helper
DEBUG - 2011-02-25 09:51:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 09:51:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 09:51:46 --> Database Driver Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Session Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Helper loaded: string_helper
DEBUG - 2011-02-25 09:51:46 --> Session routines successfully run
DEBUG - 2011-02-25 09:51:46 --> Controller Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> Model Class Initialized
DEBUG - 2011-02-25 09:51:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 09:51:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 09:51:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 09:51:46 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 09:51:46 --> Final output sent to browser
DEBUG - 2011-02-25 09:51:46 --> Total execution time: 0.0332
DEBUG - 2011-02-25 18:15:59 --> Config Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:15:59 --> URI Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Router Class Initialized
DEBUG - 2011-02-25 18:15:59 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:15:59 --> Output Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Input Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:15:59 --> Language Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Loader Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:15:59 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:15:59 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:15:59 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:15:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:15:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:15:59 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Session Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:15:59 --> A session cookie was not found.
DEBUG - 2011-02-25 18:15:59 --> Session routines successfully run
DEBUG - 2011-02-25 18:15:59 --> Controller Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:15:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:15:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:15:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:15:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:15:59 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:15:59 --> Final output sent to browser
DEBUG - 2011-02-25 18:15:59 --> Total execution time: 0.0296
DEBUG - 2011-02-25 18:16:00 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:01 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:01 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:16:01 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:01 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:01 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:01 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:01 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:01 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:01 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:01 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:01 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:16:01 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:01 --> Total execution time: 0.0288
DEBUG - 2011-02-25 18:16:03 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:03 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:03 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:03 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:03 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:03 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:03 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:03 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:03 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:03 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:03 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:16:03 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:03 --> Total execution time: 0.0298
DEBUG - 2011-02-25 18:16:04 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:04 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:04 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:16:04 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:04 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:04 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:04 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:04 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:04 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:04 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:04 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:04 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:16:04 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:04 --> Total execution time: 0.0298
DEBUG - 2011-02-25 18:16:05 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:05 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:05 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:05 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:05 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:05 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:05 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:05 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:05 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:05 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:16:05 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:05 --> Total execution time: 0.0283
DEBUG - 2011-02-25 18:16:06 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:06 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:06 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:06 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:06 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:06 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:06 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:06 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:06 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:06 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-25 18:16:06 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:06 --> Total execution time: 0.0275
DEBUG - 2011-02-25 18:16:07 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:07 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:07 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:07 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:07 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:07 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:07 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:07 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:07 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:07 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:07 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:16:07 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:07 --> Total execution time: 0.0278
DEBUG - 2011-02-25 18:16:08 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:08 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:08 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:08 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:08 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:08 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:08 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:08 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:08 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:08 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:16:08 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:08 --> Total execution time: 0.0279
DEBUG - 2011-02-25 18:16:10 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:10 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:10 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:10 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:10 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:10 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:10 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:10 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:10 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:10 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:10 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:16:10 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:10 --> Total execution time: 0.0295
DEBUG - 2011-02-25 18:16:11 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:11 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:11 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:16:11 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:11 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:11 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:11 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:11 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:11 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:11 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:11 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:11 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:11 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:16:11 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:11 --> Total execution time: 0.0293
DEBUG - 2011-02-25 18:16:12 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:12 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:12 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:12 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:12 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:12 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:12 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:12 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:12 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:12 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:16:12 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:12 --> Total execution time: 0.0290
DEBUG - 2011-02-25 18:16:13 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:13 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:13 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:13 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:13 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:13 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:13 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:13 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:13 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:13 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:16:13 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:13 --> Total execution time: 0.0299
DEBUG - 2011-02-25 18:16:14 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:14 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:14 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:14 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:14 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:14 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:14 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:14 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:14 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:14 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-25 18:16:14 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:14 --> Total execution time: 0.0285
DEBUG - 2011-02-25 18:16:15 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:15 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:15 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:15 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:15 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:15 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:15 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:15 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:15 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:15 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:16:15 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:15 --> Total execution time: 0.0288
DEBUG - 2011-02-25 18:16:16 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:16 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:16 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:16 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:16 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:16 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:16 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:16 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:16 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:16 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:16 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:16:16 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:16 --> Total execution time: 0.0279
DEBUG - 2011-02-25 18:16:17 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:17 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:17 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:17 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:17 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:17 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:17 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:17 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:17 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:17 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:17 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:16:17 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:17 --> Total execution time: 0.0317
DEBUG - 2011-02-25 18:16:18 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:18 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:18 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:18 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:18 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:18 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:18 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:18 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:18 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:18 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:16:18 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:18 --> Total execution time: 0.0275
DEBUG - 2011-02-25 18:16:19 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:19 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:19 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:19 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:19 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:19 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:19 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:19 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:19 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:19 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:16:19 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:19 --> Total execution time: 0.0291
DEBUG - 2011-02-25 18:16:24 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:24 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:24 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:16:24 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:24 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:24 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:24 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:24 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:24 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:24 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:24 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:24 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:16:24 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:24 --> Total execution time: 0.0289
DEBUG - 2011-02-25 18:16:28 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:28 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Router Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Output Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Input Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:16:28 --> Language Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Loader Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:16:28 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:16:28 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:16:28 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:16:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:16:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:16:28 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Session Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:16:28 --> Session routines successfully run
DEBUG - 2011-02-25 18:16:28 --> Controller Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:16:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:16:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:16:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:16:28 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:16:28 --> Final output sent to browser
DEBUG - 2011-02-25 18:16:28 --> Total execution time: 0.0280
DEBUG - 2011-02-25 18:16:38 --> Config Class Initialized
DEBUG - 2011-02-25 18:16:38 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:16:38 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:16:38 --> URI Class Initialized
DEBUG - 2011-02-25 18:16:38 --> Router Class Initialized
ERROR - 2011-02-25 18:16:38 --> 404 Page Not Found --> official
DEBUG - 2011-02-25 18:17:08 --> Config Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:17:08 --> URI Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Router Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Output Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Input Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:17:08 --> Language Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Loader Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:17:08 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:17:08 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:17:08 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:17:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:17:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:17:08 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Session Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:17:08 --> Session routines successfully run
DEBUG - 2011-02-25 18:17:08 --> Controller Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:17:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Config Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:17:09 --> URI Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Router Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Output Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Input Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:17:09 --> Language Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Loader Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:17:09 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:17:09 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:17:09 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:17:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:17:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:17:09 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Session Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:17:09 --> Session routines successfully run
DEBUG - 2011-02-25 18:17:09 --> Controller Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:17:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Config Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:18:34 --> URI Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Router Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Output Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Input Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:18:34 --> Language Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Loader Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:18:34 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:18:34 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:18:34 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:18:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:18:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:18:34 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Session Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:18:34 --> Session routines successfully run
DEBUG - 2011-02-25 18:18:34 --> Controller Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:18:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Config Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:22:58 --> URI Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Router Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Output Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Input Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:22:58 --> Language Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Loader Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:22:58 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:22:58 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:22:58 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:22:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:22:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:22:58 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Session Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:22:58 --> Session routines successfully run
DEBUG - 2011-02-25 18:22:58 --> Controller Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:22:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:22:58 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 18:22:58 --> Severity: Notice  --> Undefined variable: sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 8
ERROR - 2011-02-25 18:22:58 --> Severity: Notice  --> Undefined variable: spark /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 21
ERROR - 2011-02-25 18:22:58 --> Severity: Notice  --> Trying to get property of non-object /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 21
DEBUG - 2011-02-25 18:22:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:22:58 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:22:58 --> Final output sent to browser
DEBUG - 2011-02-25 18:22:58 --> Total execution time: 0.0336
DEBUG - 2011-02-25 18:23:14 --> Config Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:23:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:23:14 --> URI Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Router Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Output Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Input Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:23:14 --> Language Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Loader Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:23:14 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:23:14 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:23:14 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:23:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:23:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:23:14 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Session Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:23:14 --> Session routines successfully run
DEBUG - 2011-02-25 18:23:14 --> Controller Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:14 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:23:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:23:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:23:14 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:23:14 --> Final output sent to browser
DEBUG - 2011-02-25 18:23:14 --> Total execution time: 0.0311
DEBUG - 2011-02-25 18:23:24 --> Config Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:23:24 --> URI Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Router Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Output Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Input Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:23:24 --> Language Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Loader Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:23:24 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:23:24 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:23:24 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:23:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:23:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:23:24 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Session Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:23:24 --> Session routines successfully run
DEBUG - 2011-02-25 18:23:24 --> Controller Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:23:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:23:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:23:24 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:23:24 --> Final output sent to browser
DEBUG - 2011-02-25 18:23:24 --> Total execution time: 0.0351
DEBUG - 2011-02-25 18:23:41 --> Config Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:23:41 --> URI Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Router Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Output Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Input Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:23:41 --> Language Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Loader Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:23:41 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:23:41 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:23:41 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:23:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:23:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:23:41 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Session Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:23:41 --> Session routines successfully run
DEBUG - 2011-02-25 18:23:41 --> Controller Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:23:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:23:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:23:41 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:23:41 --> Final output sent to browser
DEBUG - 2011-02-25 18:23:41 --> Total execution time: 0.0309
DEBUG - 2011-02-25 18:23:55 --> Config Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:23:55 --> URI Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Router Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Output Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Input Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:23:55 --> Language Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Loader Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:23:55 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:23:55 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:23:55 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:23:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:23:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:23:55 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Session Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:23:55 --> Session routines successfully run
DEBUG - 2011-02-25 18:23:55 --> Controller Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:23:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:23:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:23:55 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:23:55 --> Final output sent to browser
DEBUG - 2011-02-25 18:23:55 --> Total execution time: 0.0312
DEBUG - 2011-02-25 18:23:58 --> Config Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:23:58 --> URI Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Router Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Output Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Input Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:23:58 --> Language Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Loader Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:23:58 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:23:58 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:23:58 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:23:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:23:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:23:58 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Session Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:23:58 --> Session routines successfully run
DEBUG - 2011-02-25 18:23:58 --> Controller Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:23:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:23:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:23:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:23:58 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:23:58 --> Final output sent to browser
DEBUG - 2011-02-25 18:23:58 --> Total execution time: 0.0320
DEBUG - 2011-02-25 18:24:01 --> Config Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:24:01 --> URI Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Router Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Output Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Input Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:24:01 --> Language Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Loader Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:24:01 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:24:01 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:24:01 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:24:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:24:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:24:01 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Session Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:24:01 --> Session routines successfully run
DEBUG - 2011-02-25 18:24:01 --> Controller Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:24:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:24:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:24:01 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:24:01 --> Final output sent to browser
DEBUG - 2011-02-25 18:24:01 --> Total execution time: 0.0339
DEBUG - 2011-02-25 18:24:45 --> Config Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:24:45 --> URI Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Router Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Output Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Input Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:24:45 --> Language Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Loader Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:24:45 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:24:45 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:24:45 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:24:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:24:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:24:45 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Session Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:24:45 --> Session routines successfully run
DEBUG - 2011-02-25 18:24:45 --> Controller Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:24:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:24:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:24:45 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:24:45 --> Final output sent to browser
DEBUG - 2011-02-25 18:24:45 --> Total execution time: 0.0314
DEBUG - 2011-02-25 18:24:46 --> Config Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:24:46 --> URI Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Router Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Output Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Input Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:24:46 --> Language Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Loader Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:24:46 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:24:46 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:24:46 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:24:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:24:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:24:46 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Session Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:24:46 --> Session routines successfully run
DEBUG - 2011-02-25 18:24:46 --> Controller Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:46 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:24:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:24:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:24:46 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:24:46 --> Final output sent to browser
DEBUG - 2011-02-25 18:24:46 --> Total execution time: 0.0284
DEBUG - 2011-02-25 18:24:48 --> Config Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:24:48 --> URI Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Router Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Output Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Input Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:24:48 --> Language Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Loader Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:24:48 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:24:48 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:24:48 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:24:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:24:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:24:48 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Session Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:24:48 --> Session routines successfully run
DEBUG - 2011-02-25 18:24:48 --> Controller Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:24:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:24:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:24:48 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:24:48 --> Final output sent to browser
DEBUG - 2011-02-25 18:24:48 --> Total execution time: 0.0267
DEBUG - 2011-02-25 18:24:50 --> Config Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:24:50 --> URI Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Router Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Output Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Input Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:24:50 --> Language Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Loader Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:24:50 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:24:50 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:24:50 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:24:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:24:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:24:50 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Session Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:24:50 --> Session routines successfully run
DEBUG - 2011-02-25 18:24:50 --> Controller Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:24:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:24:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:24:50 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-25 18:24:50 --> Final output sent to browser
DEBUG - 2011-02-25 18:24:50 --> Total execution time: 0.0287
DEBUG - 2011-02-25 18:24:57 --> Config Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:24:57 --> URI Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Router Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Output Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Input Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:24:57 --> Language Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Loader Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:24:57 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:24:57 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:24:57 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:24:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:24:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:24:57 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Session Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:24:57 --> Session routines successfully run
DEBUG - 2011-02-25 18:24:57 --> Controller Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:24:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:24:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:24:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:24:57 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-25 18:24:57 --> Final output sent to browser
DEBUG - 2011-02-25 18:24:57 --> Total execution time: 0.0308
DEBUG - 2011-02-25 18:25:04 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:04 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:04 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:25:04 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:04 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:04 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:04 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:04 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:04 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:04 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:04 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:04 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:25:04 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:04 --> Total execution time: 0.0286
DEBUG - 2011-02-25 18:25:06 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:06 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:06 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:06 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:06 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:06 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:06 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:06 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:06 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:06 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:25:06 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:06 --> Total execution time: 0.0329
DEBUG - 2011-02-25 18:25:08 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:08 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:08 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:08 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:08 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:08 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:08 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:08 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:08 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:08 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:08 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:25:08 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:08 --> Total execution time: 0.0288
DEBUG - 2011-02-25 18:25:09 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:09 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:09 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:09 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:09 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:09 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:09 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:09 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:09 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:09 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:25:09 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:09 --> Total execution time: 0.0268
DEBUG - 2011-02-25 18:25:23 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:23 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:23 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:25:23 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:23 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:23 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:23 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:23 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:23 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:23 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:23 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:23 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:25:23 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:23 --> Total execution time: 0.0287
DEBUG - 2011-02-25 18:25:25 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:25 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:25 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:25 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:25 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:25 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:25 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:25 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:25 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:25 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:25:25 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:25 --> Total execution time: 0.0304
DEBUG - 2011-02-25 18:25:26 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:26 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:26 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:26 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:26 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:26 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:26 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:26 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:26 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:26 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:25:26 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:26 --> Total execution time: 0.0287
DEBUG - 2011-02-25 18:25:27 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:27 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:27 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:27 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:27 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:27 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:27 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:27 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:27 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:27 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:27 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:25:27 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:27 --> Total execution time: 0.0283
DEBUG - 2011-02-25 18:25:28 --> Config Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:25:28 --> URI Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Router Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Output Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Input Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:25:28 --> Language Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Loader Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:25:28 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:25:28 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:25:28 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:25:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:25:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:25:28 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Session Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:25:28 --> Session routines successfully run
DEBUG - 2011-02-25 18:25:28 --> Controller Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:25:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:25:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:25:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:25:28 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-25 18:25:28 --> Final output sent to browser
DEBUG - 2011-02-25 18:25:28 --> Total execution time: 0.0292
DEBUG - 2011-02-25 18:26:36 --> Config Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:26:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:26:36 --> URI Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Router Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Output Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Input Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:26:36 --> Language Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Loader Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:26:36 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:26:36 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:26:36 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:26:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:26:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:26:36 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Session Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:26:36 --> Session routines successfully run
DEBUG - 2011-02-25 18:26:36 --> Controller Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:26:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:26:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:26:36 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-25 18:26:36 --> Final output sent to browser
DEBUG - 2011-02-25 18:26:36 --> Total execution time: 0.0367
DEBUG - 2011-02-25 18:26:38 --> Config Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:26:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:26:38 --> URI Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Router Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Output Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Input Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:26:38 --> Language Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Loader Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:26:38 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:26:38 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:26:38 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:26:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:26:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:26:38 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Session Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:26:38 --> Session routines successfully run
DEBUG - 2011-02-25 18:26:38 --> Controller Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:26:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:26:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:26:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:26:38 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:26:38 --> Final output sent to browser
DEBUG - 2011-02-25 18:26:38 --> Total execution time: 0.0316
DEBUG - 2011-02-25 18:34:52 --> Config Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:34:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:34:52 --> URI Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Router Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Output Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Input Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:34:52 --> Language Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Loader Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:34:52 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:34:52 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:34:52 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:34:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:34:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:34:52 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Session Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:34:52 --> Session routines successfully run
DEBUG - 2011-02-25 18:34:52 --> Controller Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:34:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:34:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:34:52 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:34:52 --> Final output sent to browser
DEBUG - 2011-02-25 18:34:52 --> Total execution time: 0.0324
DEBUG - 2011-02-25 18:34:57 --> Config Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:34:57 --> URI Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Router Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Output Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Input Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:34:57 --> Language Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Loader Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:34:57 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:34:57 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:34:57 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:34:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:34:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:34:57 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Session Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:34:57 --> Session routines successfully run
DEBUG - 2011-02-25 18:34:57 --> Controller Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:34:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:34:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:34:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:34:57 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:34:57 --> Final output sent to browser
DEBUG - 2011-02-25 18:34:57 --> Total execution time: 0.0362
DEBUG - 2011-02-25 18:35:01 --> Config Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:35:01 --> URI Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Router Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Output Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Input Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:35:01 --> Language Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Loader Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:35:01 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:35:01 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:35:01 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:35:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:35:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:35:01 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Session Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:35:01 --> Session routines successfully run
DEBUG - 2011-02-25 18:35:01 --> Controller Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:35:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:35:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:35:01 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:35:01 --> Final output sent to browser
DEBUG - 2011-02-25 18:35:01 --> Total execution time: 0.0348
DEBUG - 2011-02-25 18:35:05 --> Config Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:35:05 --> URI Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Router Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Output Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Input Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:35:05 --> Language Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Loader Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:35:05 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:35:05 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:35:05 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:35:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:35:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:35:05 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Session Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:35:05 --> Session routines successfully run
DEBUG - 2011-02-25 18:35:05 --> Controller Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:35:05 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 18:35:05 --> Severity: Notice  --> Undefined variable: browse_type /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 3
ERROR - 2011-02-25 18:35:05 --> Severity: Notice  --> Undefined variable: spark /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 19
ERROR - 2011-02-25 18:35:05 --> Severity: Notice  --> Trying to get property of non-object /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 19
DEBUG - 2011-02-25 18:35:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:35:05 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:35:05 --> Final output sent to browser
DEBUG - 2011-02-25 18:35:05 --> Total execution time: 0.0392
DEBUG - 2011-02-25 18:35:31 --> Config Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:35:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:35:31 --> URI Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Router Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Output Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Input Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:35:31 --> Language Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Loader Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:35:31 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:35:31 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:35:31 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:35:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:35:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:35:31 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Session Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:35:31 --> Session routines successfully run
DEBUG - 2011-02-25 18:35:31 --> Controller Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:35:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:35:31 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 18:35:31 --> Severity: Notice  --> Undefined variable: spark /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 19
ERROR - 2011-02-25 18:35:31 --> Severity: Notice  --> Trying to get property of non-object /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 19
DEBUG - 2011-02-25 18:35:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:35:31 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:35:31 --> Final output sent to browser
DEBUG - 2011-02-25 18:35:31 --> Total execution time: 0.0331
DEBUG - 2011-02-25 18:37:12 --> Config Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:37:12 --> URI Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Router Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Output Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Input Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:37:12 --> Language Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Loader Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:37:12 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:37:12 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:37:12 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:37:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:37:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:37:12 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Session Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:37:12 --> Session routines successfully run
DEBUG - 2011-02-25 18:37:12 --> Controller Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:37:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:37:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:37:12 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:37:12 --> Final output sent to browser
DEBUG - 2011-02-25 18:37:12 --> Total execution time: 0.0291
DEBUG - 2011-02-25 18:37:25 --> Config Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:37:25 --> URI Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Router Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Output Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Input Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:37:25 --> Language Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Loader Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:37:25 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:37:25 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:37:25 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:37:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:37:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:37:25 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Session Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:37:25 --> Session routines successfully run
DEBUG - 2011-02-25 18:37:25 --> Controller Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:37:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:37:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:37:25 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:37:25 --> Final output sent to browser
DEBUG - 2011-02-25 18:37:25 --> Total execution time: 0.0290
DEBUG - 2011-02-25 18:37:38 --> Config Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:37:38 --> URI Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Router Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Output Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Input Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:37:38 --> Language Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Loader Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:37:38 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:37:38 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:37:38 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:37:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:37:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:37:38 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Session Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:37:38 --> Session routines successfully run
DEBUG - 2011-02-25 18:37:38 --> Controller Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:37:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:37:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:37:38 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:37:38 --> Final output sent to browser
DEBUG - 2011-02-25 18:37:38 --> Total execution time: 0.0292
DEBUG - 2011-02-25 18:37:40 --> Config Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:37:40 --> URI Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Router Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Output Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Input Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:37:40 --> Language Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Loader Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:37:40 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:37:40 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:37:40 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:37:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:37:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:37:40 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Session Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:37:40 --> Session routines successfully run
DEBUG - 2011-02-25 18:37:40 --> Controller Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:40 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:37:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:37:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:37:40 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:37:40 --> Final output sent to browser
DEBUG - 2011-02-25 18:37:40 --> Total execution time: 0.0297
DEBUG - 2011-02-25 18:37:42 --> Config Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:37:42 --> URI Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Router Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Output Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Input Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:37:42 --> Language Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Loader Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:37:42 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:37:42 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:37:42 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:37:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:37:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:37:42 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Session Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:37:42 --> Session routines successfully run
DEBUG - 2011-02-25 18:37:42 --> Controller Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:37:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:37:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:37:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:37:43 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:37:43 --> Final output sent to browser
DEBUG - 2011-02-25 18:37:43 --> Total execution time: 0.0313
DEBUG - 2011-02-25 18:38:13 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:13 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:13 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:13 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:13 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:13 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:13 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:13 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:13 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:13 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:38:13 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:13 --> Total execution time: 0.0320
DEBUG - 2011-02-25 18:38:15 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:15 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:15 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:15 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:15 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:15 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:15 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:15 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:15 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:15 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:38:15 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:15 --> Total execution time: 0.0316
DEBUG - 2011-02-25 18:38:18 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:18 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:18 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:18 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:18 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:18 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:18 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:18 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:18 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:18 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:38:18 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:18 --> Total execution time: 0.0317
DEBUG - 2011-02-25 18:38:20 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:20 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:20 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:20 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:20 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:20 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:20 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:20 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:20 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:20 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:38:20 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:20 --> Total execution time: 0.0302
DEBUG - 2011-02-25 18:38:34 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:34 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:34 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:34 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:34 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:34 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:34 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:34 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:34 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:34 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:34 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:34 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:34 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:38:34 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:34 --> Total execution time: 0.0321
DEBUG - 2011-02-25 18:38:49 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:49 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:49 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:49 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:49 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:49 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:49 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:49 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:49 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:49 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:38:49 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:49 --> Total execution time: 0.0326
DEBUG - 2011-02-25 18:38:53 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:53 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:53 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:53 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:53 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:53 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:53 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:53 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:53 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:53 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:38:53 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:53 --> Total execution time: 0.0338
DEBUG - 2011-02-25 18:38:55 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:55 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:55 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:55 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:55 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:55 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:55 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:55 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:55 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:55 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:38:55 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:55 --> Total execution time: 0.0407
DEBUG - 2011-02-25 18:38:59 --> Config Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:38:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:38:59 --> URI Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Router Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Output Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Input Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:38:59 --> Language Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Loader Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:38:59 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:38:59 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:38:59 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:38:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:38:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:38:59 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Session Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:38:59 --> Session routines successfully run
DEBUG - 2011-02-25 18:38:59 --> Controller Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:59 --> Model Class Initialized
DEBUG - 2011-02-25 18:38:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:38:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:38:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:38:59 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:38:59 --> Final output sent to browser
DEBUG - 2011-02-25 18:38:59 --> Total execution time: 0.0274
DEBUG - 2011-02-25 18:39:00 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:00 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:00 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:00 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:00 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:00 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:00 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:00 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:00 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:00 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:39:00 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:00 --> Total execution time: 0.0281
DEBUG - 2011-02-25 18:39:01 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:01 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:01 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:01 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:01 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:01 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:01 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:01 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:01 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:01 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:01 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:39:01 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:01 --> Total execution time: 0.0292
DEBUG - 2011-02-25 18:39:04 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:04 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:04 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:39:04 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:04 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:04 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:04 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:04 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:04 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:04 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:04 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:04 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:04 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:39:04 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:04 --> Total execution time: 0.0285
DEBUG - 2011-02-25 18:39:29 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:29 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:29 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:29 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:29 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:29 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:29 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:29 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:29 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:29 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:39:29 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:29 --> Total execution time: 0.0305
DEBUG - 2011-02-25 18:39:33 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:33 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:33 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:33 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:33 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:33 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:33 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:33 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:33 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:33 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:33 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:39:33 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:33 --> Total execution time: 0.0283
DEBUG - 2011-02-25 18:39:38 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:38 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:38 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:38 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:38 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:38 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:38 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:38 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:38 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:38 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:38 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-25 18:39:38 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:38 --> Total execution time: 0.0290
DEBUG - 2011-02-25 18:39:41 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:41 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:41 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:39:41 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:41 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:41 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:41 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:41 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:41 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:41 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:41 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:41 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:41 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:39:41 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:41 --> Total execution time: 0.0294
DEBUG - 2011-02-25 18:39:43 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:43 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:43 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:43 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:43 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:43 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:43 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:43 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:43 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:43 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:43 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-25 18:39:43 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:43 --> Total execution time: 0.0289
DEBUG - 2011-02-25 18:39:48 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:48 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:48 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:48 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:48 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:48 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:48 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:48 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:48 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:48 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:39:48 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:48 --> Total execution time: 0.0281
DEBUG - 2011-02-25 18:39:49 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:49 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:49 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:49 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:49 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:49 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:49 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:49 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:49 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:49 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:39:49 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:49 --> Total execution time: 0.0286
DEBUG - 2011-02-25 18:39:50 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:50 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:50 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:50 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:50 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:50 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:50 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:50 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:50 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:50 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:50 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:39:50 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:50 --> Total execution time: 0.0278
DEBUG - 2011-02-25 18:39:51 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:51 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:51 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:39:51 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:51 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:51 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:51 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:51 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:51 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:51 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:51 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:51 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:39:51 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:51 --> Total execution time: 0.0278
DEBUG - 2011-02-25 18:39:58 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:58 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:58 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:58 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:58 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:58 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Config Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:39:58 --> URI Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Router Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Output Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Input Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:39:58 --> Language Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Loader Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:39:58 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Session Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:39:58 --> Session routines successfully run
DEBUG - 2011-02-25 18:39:58 --> Controller Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:39:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:39:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:39:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:39:58 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 18:39:58 --> Final output sent to browser
DEBUG - 2011-02-25 18:39:58 --> Total execution time: 0.0341
DEBUG - 2011-02-25 18:40:13 --> Config Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:40:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:40:13 --> URI Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Router Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Output Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Input Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:40:13 --> Language Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Loader Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:40:13 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:40:13 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:40:13 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:40:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:40:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:40:13 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Session Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:40:13 --> Session routines successfully run
DEBUG - 2011-02-25 18:40:13 --> Controller Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:40:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:40:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:40:13 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:40:13 --> Final output sent to browser
DEBUG - 2011-02-25 18:40:13 --> Total execution time: 0.0324
DEBUG - 2011-02-25 18:40:22 --> Config Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:40:22 --> URI Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Router Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Output Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Input Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:40:22 --> Language Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Loader Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:40:22 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:40:22 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:40:22 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:40:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:40:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:40:22 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Session Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:40:22 --> Session routines successfully run
DEBUG - 2011-02-25 18:40:22 --> Controller Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:40:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:40:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:40:22 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:40:22 --> Final output sent to browser
DEBUG - 2011-02-25 18:40:22 --> Total execution time: 0.0323
DEBUG - 2011-02-25 18:40:29 --> Config Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:40:29 --> URI Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Router Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Output Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Input Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:40:29 --> Language Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Loader Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:40:29 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:40:29 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:40:29 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:40:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:40:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:40:29 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Session Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:40:29 --> Session routines successfully run
DEBUG - 2011-02-25 18:40:29 --> Controller Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:29 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:40:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:40:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:40:29 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:40:29 --> Final output sent to browser
DEBUG - 2011-02-25 18:40:29 --> Total execution time: 0.0497
DEBUG - 2011-02-25 18:40:30 --> Config Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:40:30 --> URI Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Router Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Output Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Input Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:40:30 --> Language Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Loader Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:40:30 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:40:30 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:40:30 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:40:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:40:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:40:30 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Session Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:40:30 --> Session routines successfully run
DEBUG - 2011-02-25 18:40:30 --> Controller Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:30 --> Model Class Initialized
DEBUG - 2011-02-25 18:40:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:40:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:40:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:40:30 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:40:30 --> Final output sent to browser
DEBUG - 2011-02-25 18:40:30 --> Total execution time: 0.0280
DEBUG - 2011-02-25 18:41:05 --> Config Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:41:05 --> URI Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Router Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Output Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Input Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:41:05 --> Language Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Loader Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:41:05 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:41:05 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:41:05 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:41:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:41:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:41:05 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Session Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:41:05 --> Session routines successfully run
DEBUG - 2011-02-25 18:41:05 --> Controller Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:41:05 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Config Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:42:36 --> URI Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Router Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Output Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Input Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:42:36 --> Language Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Loader Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:42:36 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Session Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:42:36 --> Session routines successfully run
DEBUG - 2011-02-25 18:42:36 --> Controller Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Config Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:42:36 --> URI Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Router Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Output Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Input Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:42:36 --> Language Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Loader Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:42:36 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Session Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:42:36 --> Session routines successfully run
DEBUG - 2011-02-25 18:42:36 --> Controller Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:36 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Config Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:42:42 --> URI Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Router Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Output Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Input Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:42:42 --> Language Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Loader Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:42:42 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:42:42 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:42:42 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:42:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:42:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:42:42 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Session Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:42:42 --> Session routines successfully run
DEBUG - 2011-02-25 18:42:42 --> Controller Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:42 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Config Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:42:49 --> URI Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Router Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Output Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Input Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:42:49 --> Language Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Loader Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:42:49 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:42:49 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:42:49 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:42:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:42:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:42:49 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Session Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:42:49 --> Session routines successfully run
DEBUG - 2011-02-25 18:42:49 --> Controller Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:42:49 --> Model Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Config Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:45:39 --> URI Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Router Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Output Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Input Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:45:39 --> Language Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Loader Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:45:39 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:45:39 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:45:39 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:45:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:45:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:45:39 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Session Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:45:39 --> Session routines successfully run
DEBUG - 2011-02-25 18:45:39 --> Controller Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Model Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Model Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Model Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Model Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Model Class Initialized
DEBUG - 2011-02-25 18:45:39 --> Model Class Initialized
DEBUG - 2011-02-25 18:45:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:45:39 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-02-25 18:45:39 --> Severity: Notice  --> Undefined variable: sparks /Users/katzgrau/Dev/ci-sparks-repo/application/views/packages/listing.php 6
DEBUG - 2011-02-25 18:45:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:45:39 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:45:39 --> Final output sent to browser
DEBUG - 2011-02-25 18:45:39 --> Total execution time: 0.0367
DEBUG - 2011-02-25 18:46:02 --> Config Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:46:02 --> URI Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Router Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Output Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Input Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:46:02 --> Language Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Loader Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:46:02 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:46:02 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:46:02 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:46:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:46:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:46:02 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Session Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:46:02 --> Session routines successfully run
DEBUG - 2011-02-25 18:46:02 --> Controller Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:02 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:46:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:46:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:46:02 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:46:02 --> Final output sent to browser
DEBUG - 2011-02-25 18:46:02 --> Total execution time: 0.0291
DEBUG - 2011-02-25 18:46:13 --> Config Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:46:13 --> URI Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Router Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Output Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Input Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:46:13 --> Language Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Loader Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:46:13 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:46:13 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:46:13 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:46:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:46:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:46:13 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Session Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:46:13 --> Session routines successfully run
DEBUG - 2011-02-25 18:46:13 --> Controller Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:13 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:46:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:46:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:46:13 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:46:13 --> Final output sent to browser
DEBUG - 2011-02-25 18:46:13 --> Total execution time: 0.0326
DEBUG - 2011-02-25 18:46:44 --> Config Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:46:44 --> URI Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Router Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Output Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Input Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:46:44 --> Language Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Loader Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:46:44 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:46:44 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:46:44 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:46:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:46:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:46:44 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Session Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:46:44 --> Session routines successfully run
DEBUG - 2011-02-25 18:46:44 --> Controller Class Initialized
DEBUG - 2011-02-25 18:46:44 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:45 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:46:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:46:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:46:45 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:46:45 --> Final output sent to browser
DEBUG - 2011-02-25 18:46:45 --> Total execution time: 0.0315
DEBUG - 2011-02-25 18:46:51 --> Config Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:46:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:46:51 --> URI Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Router Class Initialized
DEBUG - 2011-02-25 18:46:51 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:46:51 --> Output Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Input Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:46:51 --> Language Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Loader Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:46:51 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:46:51 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:46:51 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:46:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:46:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:46:51 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Session Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:46:51 --> Session routines successfully run
DEBUG - 2011-02-25 18:46:51 --> Controller Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:51 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:46:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:46:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:46:51 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:46:51 --> Final output sent to browser
DEBUG - 2011-02-25 18:46:51 --> Total execution time: 0.0304
DEBUG - 2011-02-25 18:46:57 --> Config Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:46:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:46:57 --> URI Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Router Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Output Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Input Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:46:57 --> Language Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Loader Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:46:57 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:46:57 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:46:57 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:46:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:46:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:46:57 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Session Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:46:57 --> Session routines successfully run
DEBUG - 2011-02-25 18:46:57 --> Controller Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> Model Class Initialized
DEBUG - 2011-02-25 18:46:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:46:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:46:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:46:57 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:46:57 --> Final output sent to browser
DEBUG - 2011-02-25 18:46:57 --> Total execution time: 0.0361
DEBUG - 2011-02-25 18:47:00 --> Config Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:47:00 --> URI Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Router Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Output Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Input Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:47:00 --> Language Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Loader Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:47:00 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:47:00 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:47:00 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:47:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:47:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:47:00 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Session Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:47:00 --> Session routines successfully run
DEBUG - 2011-02-25 18:47:00 --> Controller Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:47:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:47:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:47:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:47:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:47:00 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:47:00 --> Final output sent to browser
DEBUG - 2011-02-25 18:47:00 --> Total execution time: 0.0321
DEBUG - 2011-02-25 18:48:31 --> Config Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:48:31 --> URI Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Router Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Output Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Input Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:48:31 --> Language Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Loader Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:48:31 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:48:31 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:48:31 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:48:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:48:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:48:31 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Session Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:48:31 --> Session routines successfully run
DEBUG - 2011-02-25 18:48:31 --> Controller Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:48:31 --> Model Class Initialized
DEBUG - 2011-02-25 18:48:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:48:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:48:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:48:31 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:48:31 --> Final output sent to browser
DEBUG - 2011-02-25 18:48:31 --> Total execution time: 0.0308
DEBUG - 2011-02-25 18:49:26 --> Config Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:49:26 --> URI Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Router Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Output Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Input Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:49:26 --> Language Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Loader Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:49:26 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:49:26 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:49:26 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:49:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:49:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:49:26 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Session Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:49:26 --> Session routines successfully run
DEBUG - 2011-02-25 18:49:26 --> Controller Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:49:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:49:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:49:26 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:49:26 --> Final output sent to browser
DEBUG - 2011-02-25 18:49:26 --> Total execution time: 0.0324
DEBUG - 2011-02-25 18:49:32 --> Config Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:49:32 --> URI Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Router Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Output Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Input Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:49:32 --> Language Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Loader Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:49:32 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:49:32 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:49:32 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:49:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:49:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:49:32 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Session Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:49:32 --> Session routines successfully run
DEBUG - 2011-02-25 18:49:32 --> Controller Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:32 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:49:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:49:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:49:32 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:49:32 --> Final output sent to browser
DEBUG - 2011-02-25 18:49:32 --> Total execution time: 0.0313
DEBUG - 2011-02-25 18:49:43 --> Config Class Initialized
DEBUG - 2011-02-25 18:49:43 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:49:43 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:49:43 --> URI Class Initialized
DEBUG - 2011-02-25 18:49:43 --> Router Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Output Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Input Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:49:44 --> Language Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Loader Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:49:44 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:49:44 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:49:44 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:49:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:49:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:49:44 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Session Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:49:44 --> Session routines successfully run
DEBUG - 2011-02-25 18:49:44 --> Controller Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:44 --> Model Class Initialized
DEBUG - 2011-02-25 18:49:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:49:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:49:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:49:44 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:49:44 --> Final output sent to browser
DEBUG - 2011-02-25 18:49:44 --> Total execution time: 0.0357
DEBUG - 2011-02-25 18:50:06 --> Config Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:50:06 --> URI Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Router Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Output Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Input Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:50:06 --> Language Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Loader Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:50:06 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:50:06 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:50:06 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:50:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:50:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:50:06 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Session Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:50:06 --> Session routines successfully run
DEBUG - 2011-02-25 18:50:06 --> Controller Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:06 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:50:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:50:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:50:06 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:50:06 --> Final output sent to browser
DEBUG - 2011-02-25 18:50:06 --> Total execution time: 0.0293
DEBUG - 2011-02-25 18:50:12 --> Config Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:50:12 --> URI Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Router Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Output Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Input Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:50:12 --> Language Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Loader Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:50:12 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:50:12 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:50:12 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:50:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:50:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:50:12 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Session Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:50:12 --> Session routines successfully run
DEBUG - 2011-02-25 18:50:12 --> Controller Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:12 --> Model Class Initialized
DEBUG - 2011-02-25 18:50:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:50:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:50:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:50:12 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:50:12 --> Final output sent to browser
DEBUG - 2011-02-25 18:50:12 --> Total execution time: 0.0334
DEBUG - 2011-02-25 18:54:00 --> Config Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:54:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:54:00 --> URI Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Router Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Output Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Input Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:54:00 --> Language Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Loader Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:54:00 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:54:00 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:54:00 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:54:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:54:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:54:00 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Session Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:54:00 --> Session routines successfully run
DEBUG - 2011-02-25 18:54:00 --> Controller Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:00 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:54:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:54:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:54:00 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:54:00 --> Final output sent to browser
DEBUG - 2011-02-25 18:54:00 --> Total execution time: 0.0304
DEBUG - 2011-02-25 18:54:24 --> Config Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:54:24 --> URI Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Router Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Output Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Input Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:54:24 --> Language Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Loader Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:54:24 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:54:24 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:54:24 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:54:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:54:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:54:24 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Session Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:54:24 --> Session routines successfully run
DEBUG - 2011-02-25 18:54:24 --> Controller Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:24 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:54:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:54:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:54:24 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:54:24 --> Final output sent to browser
DEBUG - 2011-02-25 18:54:24 --> Total execution time: 0.0286
DEBUG - 2011-02-25 18:54:37 --> Config Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:54:37 --> URI Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Router Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Output Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Input Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:54:37 --> Language Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Loader Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:54:37 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:54:37 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:54:37 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:54:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:54:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:54:37 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Session Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:54:37 --> Session routines successfully run
DEBUG - 2011-02-25 18:54:37 --> Controller Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:37 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:54:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:54:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:54:37 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:54:37 --> Final output sent to browser
DEBUG - 2011-02-25 18:54:37 --> Total execution time: 0.0350
DEBUG - 2011-02-25 18:54:48 --> Config Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:54:48 --> URI Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Router Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Output Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Input Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:54:48 --> Language Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Loader Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:54:48 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:54:48 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:54:48 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:54:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:54:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:54:48 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Session Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:54:48 --> Session routines successfully run
DEBUG - 2011-02-25 18:54:48 --> Controller Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:54:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:54:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:54:48 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-25 18:54:48 --> Final output sent to browser
DEBUG - 2011-02-25 18:54:48 --> Total execution time: 0.0347
DEBUG - 2011-02-25 18:54:56 --> Config Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:54:56 --> URI Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Router Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Output Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Input Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:54:56 --> Language Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Loader Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:54:56 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:54:56 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:54:56 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:54:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:54:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:54:56 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Session Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:54:56 --> Session routines successfully run
DEBUG - 2011-02-25 18:54:56 --> Controller Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:56 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:54:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:54:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:54:56 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:54:56 --> Final output sent to browser
DEBUG - 2011-02-25 18:54:56 --> Total execution time: 0.0317
DEBUG - 2011-02-25 18:54:58 --> Config Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:54:58 --> URI Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Router Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Output Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Input Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:54:58 --> Language Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Loader Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:54:58 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:54:58 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:54:58 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:54:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:54:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:54:58 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Session Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:54:58 --> Session routines successfully run
DEBUG - 2011-02-25 18:54:58 --> Controller Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:58 --> Model Class Initialized
DEBUG - 2011-02-25 18:54:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:54:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:54:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:54:58 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:54:58 --> Final output sent to browser
DEBUG - 2011-02-25 18:54:58 --> Total execution time: 0.0287
DEBUG - 2011-02-25 18:55:09 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:09 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:09 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:55:09 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:09 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:09 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:09 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:09 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:09 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:09 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:09 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:09 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:09 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:55:09 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:09 --> Total execution time: 0.0325
DEBUG - 2011-02-25 18:55:15 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:15 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:15 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:15 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:15 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:15 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:15 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:15 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:15 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:15 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 18:55:15 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:15 --> Total execution time: 0.0309
DEBUG - 2011-02-25 18:55:18 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:18 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:18 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:18 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:18 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:18 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:18 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:18 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:18 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:18 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:55:18 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:18 --> Total execution time: 0.0295
DEBUG - 2011-02-25 18:55:19 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:19 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:19 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:19 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:19 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:19 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:19 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:19 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:19 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:19 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:19 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:55:19 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:19 --> Total execution time: 0.0313
DEBUG - 2011-02-25 18:55:20 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:20 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:20 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:20 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:20 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:20 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:20 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:20 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:20 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:20 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:20 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-25 18:55:20 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:20 --> Total execution time: 0.0282
DEBUG - 2011-02-25 18:55:21 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:21 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:21 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:21 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:21 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:21 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:21 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:21 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:21 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:21 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:21 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:21 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-25 18:55:21 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:21 --> Total execution time: 0.0474
DEBUG - 2011-02-25 18:55:23 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:23 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:23 --> No URI present. Default controller set.
DEBUG - 2011-02-25 18:55:23 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:23 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:23 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:23 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:23 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:23 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:23 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:23 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:23 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:23 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-25 18:55:23 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:23 --> Total execution time: 0.0283
DEBUG - 2011-02-25 18:55:25 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:25 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:25 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:25 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:25 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:25 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:25 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:25 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:25 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:25 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:25 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-25 18:55:25 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:25 --> Total execution time: 0.0287
DEBUG - 2011-02-25 18:55:26 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:26 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:26 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:26 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:26 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:26 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:26 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:26 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:26 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:26 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:26 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-25 18:55:26 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:26 --> Total execution time: 0.0288
DEBUG - 2011-02-25 18:55:28 --> Config Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:55:28 --> URI Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Router Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Output Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Input Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:55:28 --> Language Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Loader Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:55:28 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:55:28 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:55:28 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:55:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:55:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:55:28 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Session Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:55:28 --> Session routines successfully run
DEBUG - 2011-02-25 18:55:28 --> Controller Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> Model Class Initialized
DEBUG - 2011-02-25 18:55:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:55:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:55:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:55:28 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-25 18:55:28 --> Final output sent to browser
DEBUG - 2011-02-25 18:55:28 --> Total execution time: 0.0326
DEBUG - 2011-02-25 18:57:18 --> Config Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Hooks Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Utf8 Class Initialized
DEBUG - 2011-02-25 18:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-25 18:57:18 --> URI Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Router Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Output Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Input Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-25 18:57:18 --> Language Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Loader Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-25 18:57:18 --> Helper loaded: user_helper
DEBUG - 2011-02-25 18:57:18 --> Helper loaded: url_helper
DEBUG - 2011-02-25 18:57:18 --> Helper loaded: array_helper
DEBUG - 2011-02-25 18:57:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-25 18:57:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-25 18:57:18 --> Database Driver Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Session Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Helper loaded: string_helper
DEBUG - 2011-02-25 18:57:18 --> Session routines successfully run
DEBUG - 2011-02-25 18:57:18 --> Controller Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:57:18 --> Model Class Initialized
DEBUG - 2011-02-25 18:57:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-25 18:57:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-25 18:57:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-25 18:57:18 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-25 18:57:18 --> Final output sent to browser
DEBUG - 2011-02-25 18:57:18 --> Total execution time: 0.0353
