<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-12 22:07:59 --> Config Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:07:59 --> URI Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Router Class Initialized
DEBUG - 2011-03-12 22:07:59 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:07:59 --> Output Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Input Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:07:59 --> Language Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Loader Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:07:59 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Session Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:07:59 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Session routines successfully run
DEBUG - 2011-03-12 22:07:59 --> Controller Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:07:59 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:07:59 --> JSMin library initialized.
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:07:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:07:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:07:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:07:59 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:07:59 --> Final output sent to browser
DEBUG - 2011-03-12 22:07:59 --> Total execution time: 0.0913
DEBUG - 2011-03-12 22:07:59 --> Config Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:07:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:07:59 --> URI Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Router Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Output Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Input Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:07:59 --> Language Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Loader Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:07:59 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Session Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:07:59 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:07:59 --> Session routines successfully run
DEBUG - 2011-03-12 22:07:59 --> Controller Class Initialized
DEBUG - 2011-03-12 22:07:59 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:07:59 --> Final output sent to browser
DEBUG - 2011-03-12 22:07:59 --> Total execution time: 0.0251
DEBUG - 2011-03-12 22:10:06 --> Config Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:10:06 --> URI Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Router Class Initialized
DEBUG - 2011-03-12 22:10:06 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:10:06 --> Output Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Input Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:10:06 --> Language Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Loader Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:10:06 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Session Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:10:06 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Session routines successfully run
DEBUG - 2011-03-12 22:10:06 --> Controller Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:10:06 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:10:06 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:10:06 --> JSMin library initialized.
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:10:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:10:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:10:06 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:10:06 --> Final output sent to browser
DEBUG - 2011-03-12 22:10:06 --> Total execution time: 0.0531
DEBUG - 2011-03-12 22:10:07 --> Config Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:10:07 --> URI Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Router Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Output Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Input Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:10:07 --> Language Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Loader Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:10:07 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:10:07 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:10:07 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:10:07 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:10:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:10:07 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Session Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:10:07 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:10:07 --> Session routines successfully run
DEBUG - 2011-03-12 22:10:07 --> Controller Class Initialized
DEBUG - 2011-03-12 22:10:07 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:10:07 --> Final output sent to browser
DEBUG - 2011-03-12 22:10:07 --> Total execution time: 0.0276
DEBUG - 2011-03-12 22:10:31 --> Config Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:10:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:10:31 --> URI Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Router Class Initialized
DEBUG - 2011-03-12 22:10:31 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:10:31 --> Output Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Input Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:10:31 --> Language Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Loader Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:10:31 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Session Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:10:31 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Session routines successfully run
DEBUG - 2011-03-12 22:10:31 --> Controller Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:10:31 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:10:31 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:10:31 --> JSMin library initialized.
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> Model Class Initialized
DEBUG - 2011-03-12 22:10:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:10:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:10:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:10:31 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:10:31 --> Final output sent to browser
DEBUG - 2011-03-12 22:10:31 --> Total execution time: 0.0508
DEBUG - 2011-03-12 22:10:32 --> Config Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:10:32 --> URI Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Router Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Output Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Input Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:10:32 --> Language Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Loader Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:10:32 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:10:32 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:10:32 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:10:32 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:10:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:10:32 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Session Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:10:32 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:10:32 --> Session routines successfully run
DEBUG - 2011-03-12 22:10:32 --> Controller Class Initialized
DEBUG - 2011-03-12 22:10:32 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:10:32 --> Final output sent to browser
DEBUG - 2011-03-12 22:10:32 --> Total execution time: 0.1315
DEBUG - 2011-03-12 22:12:32 --> Config Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:12:32 --> URI Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Router Class Initialized
DEBUG - 2011-03-12 22:12:32 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:12:32 --> Output Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Input Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:12:32 --> Language Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Loader Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:12:32 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Session Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:12:32 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Session routines successfully run
DEBUG - 2011-03-12 22:12:32 --> Controller Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:12:32 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:12:32 --> JSMin library initialized.
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:12:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:12:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:12:32 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:12:32 --> Final output sent to browser
DEBUG - 2011-03-12 22:12:32 --> Total execution time: 0.0542
DEBUG - 2011-03-12 22:12:32 --> Config Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:12:32 --> URI Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Router Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Output Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Input Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:12:32 --> Language Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Loader Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:12:32 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Session Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:12:32 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:12:32 --> Session routines successfully run
DEBUG - 2011-03-12 22:12:32 --> Controller Class Initialized
DEBUG - 2011-03-12 22:12:32 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:12:32 --> Final output sent to browser
DEBUG - 2011-03-12 22:12:32 --> Total execution time: 0.0258
DEBUG - 2011-03-12 22:12:44 --> Config Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:12:44 --> URI Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Router Class Initialized
DEBUG - 2011-03-12 22:12:44 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:12:44 --> Output Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Input Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:12:44 --> Language Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Loader Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:12:44 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Session Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:12:44 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Session routines successfully run
DEBUG - 2011-03-12 22:12:44 --> Controller Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:12:44 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:12:44 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:12:44 --> JSMin library initialized.
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> Model Class Initialized
DEBUG - 2011-03-12 22:12:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:12:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:12:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:12:44 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:12:44 --> Final output sent to browser
DEBUG - 2011-03-12 22:12:44 --> Total execution time: 0.0631
DEBUG - 2011-03-12 22:12:45 --> Config Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:12:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:12:45 --> URI Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Router Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Output Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Input Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:12:45 --> Language Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Loader Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:12:45 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:12:45 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:12:45 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:12:45 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:12:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:12:45 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Session Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:12:45 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:12:45 --> Session routines successfully run
DEBUG - 2011-03-12 22:12:45 --> Controller Class Initialized
DEBUG - 2011-03-12 22:12:45 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:12:45 --> Final output sent to browser
DEBUG - 2011-03-12 22:12:45 --> Total execution time: 0.0335
DEBUG - 2011-03-12 22:13:24 --> Config Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:13:24 --> URI Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Router Class Initialized
DEBUG - 2011-03-12 22:13:24 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:13:24 --> Output Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Input Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:13:24 --> Language Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Loader Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:13:24 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Session Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:13:24 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Session routines successfully run
DEBUG - 2011-03-12 22:13:24 --> Controller Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:13:24 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:13:24 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:13:24 --> JSMin library initialized.
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:13:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:13:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:13:24 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:13:24 --> Final output sent to browser
DEBUG - 2011-03-12 22:13:24 --> Total execution time: 0.0683
DEBUG - 2011-03-12 22:13:25 --> Config Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:13:25 --> URI Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Router Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Output Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Input Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:13:25 --> Language Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Loader Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:13:25 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:13:25 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:13:25 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:13:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:13:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:13:25 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Session Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:13:25 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:13:25 --> Session routines successfully run
DEBUG - 2011-03-12 22:13:25 --> Controller Class Initialized
DEBUG - 2011-03-12 22:13:25 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:13:25 --> Final output sent to browser
DEBUG - 2011-03-12 22:13:25 --> Total execution time: 0.0326
DEBUG - 2011-03-12 22:13:51 --> Config Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:13:51 --> URI Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Router Class Initialized
DEBUG - 2011-03-12 22:13:51 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:13:51 --> Output Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Input Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:13:51 --> Language Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Loader Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:13:51 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Session Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:13:51 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Session routines successfully run
DEBUG - 2011-03-12 22:13:51 --> Controller Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:13:51 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:13:51 --> JSMin library initialized.
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:13:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:13:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:13:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:13:51 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:13:51 --> Final output sent to browser
DEBUG - 2011-03-12 22:13:51 --> Total execution time: 0.0466
DEBUG - 2011-03-12 22:13:51 --> Config Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:13:51 --> URI Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Router Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Output Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Input Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:13:51 --> Language Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Loader Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:13:51 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Session Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:13:51 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:13:51 --> Session routines successfully run
DEBUG - 2011-03-12 22:13:51 --> Controller Class Initialized
DEBUG - 2011-03-12 22:13:51 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:13:51 --> Final output sent to browser
DEBUG - 2011-03-12 22:13:51 --> Total execution time: 0.0349
DEBUG - 2011-03-12 22:14:27 --> Config Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:14:27 --> URI Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Router Class Initialized
DEBUG - 2011-03-12 22:14:27 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:14:27 --> Output Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Input Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:14:27 --> Language Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Loader Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:14:27 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Session Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:14:27 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Session routines successfully run
DEBUG - 2011-03-12 22:14:27 --> Controller Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:14:27 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:14:27 --> JSMin library initialized.
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Model Class Initialized
DEBUG - 2011-03-12 22:14:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:14:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:14:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:14:27 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:14:27 --> Final output sent to browser
DEBUG - 2011-03-12 22:14:27 --> Total execution time: 0.0477
DEBUG - 2011-03-12 22:14:27 --> Config Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:14:27 --> URI Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Router Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Output Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Input Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:14:27 --> Language Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Loader Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:14:27 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Session Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:14:27 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:14:27 --> Session routines successfully run
DEBUG - 2011-03-12 22:14:27 --> Controller Class Initialized
DEBUG - 2011-03-12 22:14:27 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:14:27 --> Final output sent to browser
DEBUG - 2011-03-12 22:14:27 --> Total execution time: 0.0330
DEBUG - 2011-03-12 22:16:29 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:29 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:29 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:16:29 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:29 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:29 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:29 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:29 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:29 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:29 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:29 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:16:29 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:29 --> Total execution time: 0.0514
DEBUG - 2011-03-12 22:16:29 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:29 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:29 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:29 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:29 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:29 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:29 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:29 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:29 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:29 --> Total execution time: 0.0322
DEBUG - 2011-03-12 22:16:30 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:30 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:30 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:30 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:30 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:30 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:30 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:30 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:30 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:30 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-12 22:16:30 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:30 --> Total execution time: 0.0909
DEBUG - 2011-03-12 22:16:31 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:31 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:31 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:31 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:31 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:31 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:31 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:31 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:31 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:31 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:31 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:31 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:31 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:31 --> Total execution time: 0.0248
DEBUG - 2011-03-12 22:16:37 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:37 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:37 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:37 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:37 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:37 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:37 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:37 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:37 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:16:37 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:37 --> Total execution time: 0.0466
DEBUG - 2011-03-12 22:16:37 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:37 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:37 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:37 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:37 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:37 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:37 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:37 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:37 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:37 --> Total execution time: 0.0323
DEBUG - 2011-03-12 22:16:38 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:38 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:38 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:38 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:38 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:38 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:38 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:38 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:38 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-03-12 22:16:38 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:38 --> Total execution time: 0.0442
DEBUG - 2011-03-12 22:16:38 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:38 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:38 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:38 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:38 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:38 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:38 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:38 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:38 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:38 --> Total execution time: 0.0315
DEBUG - 2011-03-12 22:16:39 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:39 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:39 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:39 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:39 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:39 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:39 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:39 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:39 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-12 22:16:39 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:39 --> Total execution time: 0.0647
DEBUG - 2011-03-12 22:16:39 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:39 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:39 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:39 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:39 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:39 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:39 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:39 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:39 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:39 --> Total execution time: 0.0270
DEBUG - 2011-03-12 22:16:40 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:40 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:40 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:40 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:40 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:40 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:40 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:40 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:40 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:16:40 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:40 --> Total execution time: 0.0419
DEBUG - 2011-03-12 22:16:40 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:40 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:40 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:40 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:40 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:40 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:40 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:40 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:40 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:40 --> Total execution time: 0.0317
DEBUG - 2011-03-12 22:16:41 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:41 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:41 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:41 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:41 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:41 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:41 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:41 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:41 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-03-12 22:16:41 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:41 --> Total execution time: 0.0437
DEBUG - 2011-03-12 22:16:41 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:41 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:41 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:41 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:41 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:41 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:41 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:41 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:41 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:41 --> Total execution time: 0.0313
DEBUG - 2011-03-12 22:16:42 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:42 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:42 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:42 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:42 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:42 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:42 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:42 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:42 --> File loaded: application/views/home/contact.php
DEBUG - 2011-03-12 22:16:42 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:42 --> Total execution time: 0.0447
DEBUG - 2011-03-12 22:16:42 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:42 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:42 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:42 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:42 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:42 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:42 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:42 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:42 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:42 --> Total execution time: 0.0258
DEBUG - 2011-03-12 22:16:45 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:45 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:45 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:16:45 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:45 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:45 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:45 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:45 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:45 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:45 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:45 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:16:45 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:45 --> Total execution time: 0.0443
DEBUG - 2011-03-12 22:16:45 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:45 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:45 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:45 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:45 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:45 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:45 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:45 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:45 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:45 --> Total execution time: 0.0366
DEBUG - 2011-03-12 22:16:47 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:47 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:47 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:16:47 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:47 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:47 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:47 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:47 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:47 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:47 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:47 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:47 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:16:47 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:47 --> Total execution time: 0.0468
DEBUG - 2011-03-12 22:16:48 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:48 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:48 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:48 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:48 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:48 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:48 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:48 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:48 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:48 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:48 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:48 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:48 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:48 --> Total execution time: 0.0297
DEBUG - 2011-03-12 22:16:49 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:49 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:49 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:49 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:49 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:49 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:49 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:49 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:49 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-12 22:16:49 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:49 --> Total execution time: 0.0632
DEBUG - 2011-03-12 22:16:49 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:49 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:49 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:49 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:49 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:49 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:49 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:49 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:49 --> Total execution time: 0.0312
DEBUG - 2011-03-12 22:16:49 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:49 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:49 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:16:49 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:49 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:49 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:50 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:50 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:50 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:50 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:50 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:16:50 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:50 --> Total execution time: 0.0427
DEBUG - 2011-03-12 22:16:50 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:50 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:50 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:50 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:50 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:50 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:50 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:50 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:50 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:50 --> Total execution time: 0.0320
DEBUG - 2011-03-12 22:16:51 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:51 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:51 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:51 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:51 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:51 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:51 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:51 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:51 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-03-12 22:16:51 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:51 --> Total execution time: 0.0453
DEBUG - 2011-03-12 22:16:51 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:51 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:51 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:51 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:51 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:51 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:51 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:51 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:51 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:51 --> Total execution time: 0.0281
DEBUG - 2011-03-12 22:16:52 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:52 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:52 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:52 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:52 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:52 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:52 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:52 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:52 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-03-12 22:16:52 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:52 --> Total execution time: 0.0435
DEBUG - 2011-03-12 22:16:52 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:52 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:52 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:52 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:52 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:52 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:52 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:52 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:52 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:52 --> Total execution time: 0.0324
DEBUG - 2011-03-12 22:16:53 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:53 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:53 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:16:53 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:53 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:53 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:53 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:53 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:16:53 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:16:53 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:16:53 --> JSMin library initialized.
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> Model Class Initialized
DEBUG - 2011-03-12 22:16:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:16:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:16:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:16:53 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:16:53 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:53 --> Total execution time: 0.0444
DEBUG - 2011-03-12 22:16:54 --> Config Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:16:54 --> URI Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Router Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Output Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Input Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:16:54 --> Language Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Loader Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:16:54 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:16:54 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:16:54 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:16:54 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:16:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:16:54 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Session Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:16:54 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:16:54 --> Session routines successfully run
DEBUG - 2011-03-12 22:16:54 --> Controller Class Initialized
DEBUG - 2011-03-12 22:16:54 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:16:54 --> Final output sent to browser
DEBUG - 2011-03-12 22:16:54 --> Total execution time: 0.0279
DEBUG - 2011-03-12 22:18:07 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:07 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:07 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:07 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:07 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:07 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:18:07 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:07 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:07 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:07 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:07 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:08 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:08 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:08 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:08 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:08 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:08 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:18:08 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:08 --> Total execution time: 0.0464
DEBUG - 2011-03-12 22:18:08 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:08 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:08 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:08 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:08 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:08 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:08 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:08 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:08 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:08 --> Total execution time: 0.0315
DEBUG - 2011-03-12 22:18:09 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:09 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:09 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:18:09 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:09 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:09 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:09 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:09 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:09 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:09 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:09 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:18:09 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:09 --> Total execution time: 0.0503
DEBUG - 2011-03-12 22:18:09 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:09 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:09 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:09 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:09 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:09 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:09 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:09 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:09 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:09 --> Total execution time: 0.0272
DEBUG - 2011-03-12 22:18:10 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:10 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:10 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:10 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:10 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:10 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:10 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:10 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:10 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:10 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-12 22:18:10 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:10 --> Total execution time: 0.0509
DEBUG - 2011-03-12 22:18:11 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:11 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:11 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:11 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:11 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:11 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:11 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:11 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:11 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:11 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:11 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:11 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:11 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:11 --> Total execution time: 0.0250
DEBUG - 2011-03-12 22:18:12 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:12 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:12 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:12 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:12 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:12 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:12 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:12 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:12 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:18:12 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:12 --> Total execution time: 0.0454
DEBUG - 2011-03-12 22:18:12 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:12 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:12 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:12 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:12 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:12 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:12 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:12 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:12 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:12 --> Total execution time: 0.0305
DEBUG - 2011-03-12 22:18:14 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:14 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:14 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:14 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:14 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:14 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:14 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:14 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:14 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:14 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-03-12 22:18:14 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:14 --> Total execution time: 0.0455
DEBUG - 2011-03-12 22:18:15 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:15 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:15 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:15 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:15 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:15 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:15 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:15 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:15 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:15 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:15 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:15 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:15 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:15 --> Total execution time: 0.0254
DEBUG - 2011-03-12 22:18:17 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:17 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:17 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:17 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:17 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:17 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:17 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:17 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:17 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-12 22:18:17 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:17 --> Total execution time: 0.0505
DEBUG - 2011-03-12 22:18:17 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:17 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:17 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:17 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:17 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:17 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:17 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:17 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:17 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:17 --> Total execution time: 0.0328
DEBUG - 2011-03-12 22:18:18 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:18 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:18 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:18 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:18 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:18 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: robot_helper
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: form_helper
DEBUG - 2011-03-12 22:18:18 --> Form Validation Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:18 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:18 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:18 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:18 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-03-12 22:18:18 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:18 --> Total execution time: 0.0573
DEBUG - 2011-03-12 22:18:19 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:19 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:19 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:19 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:19 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:19 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:19 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:19 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:19 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:19 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:19 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:19 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:19 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:19 --> Total execution time: 0.0320
DEBUG - 2011-03-12 22:18:20 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:20 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:20 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:20 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:20 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:20 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:20 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:20 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:20 --> File loaded: application/views/home/contact.php
DEBUG - 2011-03-12 22:18:20 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:20 --> Total execution time: 0.0453
DEBUG - 2011-03-12 22:18:20 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:20 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:20 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:20 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:20 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:20 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:20 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:20 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:20 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:20 --> Total execution time: 0.0312
DEBUG - 2011-03-12 22:18:35 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:35 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:35 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:35 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:35 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:35 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:35 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:35 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:35 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:35 --> File loaded: application/views/home/contact.php
DEBUG - 2011-03-12 22:18:35 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:35 --> Total execution time: 0.0519
DEBUG - 2011-03-12 22:18:36 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:36 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:36 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:36 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:36 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:36 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:36 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:36 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:36 --> Total execution time: 0.0453
DEBUG - 2011-03-12 22:18:36 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:36 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:36 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:36 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:36 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:36 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:36 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:36 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:36 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:36 --> File loaded: application/views/home/contact.php
DEBUG - 2011-03-12 22:18:36 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:36 --> Total execution time: 0.0494
DEBUG - 2011-03-12 22:18:37 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:37 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:37 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:37 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:37 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:37 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:37 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:37 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:37 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:37 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:37 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:37 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:37 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:37 --> Total execution time: 0.0264
DEBUG - 2011-03-12 22:18:40 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:40 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:40 --> No URI present. Default controller set.
DEBUG - 2011-03-12 22:18:40 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:40 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:40 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:40 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:40 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:40 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:40 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:40 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-12 22:18:40 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:40 --> Total execution time: 0.0464
DEBUG - 2011-03-12 22:18:40 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:40 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:40 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:40 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:40 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:40 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:40 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:40 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:40 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:40 --> Total execution time: 0.0282
DEBUG - 2011-03-12 22:18:41 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:41 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:41 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:41 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:41 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:41 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:18:41 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:18:41 --> JSMin library initialized.
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Model Class Initialized
DEBUG - 2011-03-12 22:18:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:18:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:18:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:18:41 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:18:41 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:41 --> Total execution time: 0.0448
DEBUG - 2011-03-12 22:18:41 --> Config Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:18:41 --> URI Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Router Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Output Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Input Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:18:41 --> Language Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Loader Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:18:41 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Session Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:18:41 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:18:41 --> Session routines successfully run
DEBUG - 2011-03-12 22:18:41 --> Controller Class Initialized
DEBUG - 2011-03-12 22:18:41 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:18:41 --> Final output sent to browser
DEBUG - 2011-03-12 22:18:41 --> Total execution time: 0.0302
DEBUG - 2011-03-12 22:19:54 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:54 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:54 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:54 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:54 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:54 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:19:54 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:19:54 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:19:54 --> JSMin library initialized.
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:19:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:19:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:19:54 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:19:54 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:54 --> Total execution time: 0.0493
DEBUG - 2011-03-12 22:19:55 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:55 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:55 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:55 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:55 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:55 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:55 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:55 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:55 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:55 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:55 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:55 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:19:55 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:55 --> Total execution time: 0.0260
DEBUG - 2011-03-12 22:19:56 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:56 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:56 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:56 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:56 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:56 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:19:56 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:19:56 --> JSMin library initialized.
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:19:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:19:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:19:56 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:19:56 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:56 --> Total execution time: 0.0487
DEBUG - 2011-03-12 22:19:56 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:56 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:56 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:56 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:56 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:56 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:56 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:56 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:19:56 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:56 --> Total execution time: 0.0248
DEBUG - 2011-03-12 22:19:57 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:57 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:57 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:57 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:57 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:57 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:19:57 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:19:57 --> JSMin library initialized.
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:19:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:19:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:19:57 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-12 22:19:57 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:57 --> Total execution time: 0.0630
DEBUG - 2011-03-12 22:19:57 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:57 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:57 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:57 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:57 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:57 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:57 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:57 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:19:57 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:57 --> Total execution time: 0.0407
DEBUG - 2011-03-12 22:19:58 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:58 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:58 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:58 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:58 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:58 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:19:58 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:19:58 --> JSMin library initialized.
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:19:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:19:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:19:58 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:19:58 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:58 --> Total execution time: 0.0431
DEBUG - 2011-03-12 22:19:58 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:58 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:58 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:58 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:58 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:58 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:58 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:58 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:19:58 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:58 --> Total execution time: 0.0285
DEBUG - 2011-03-12 22:19:59 --> Config Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:19:59 --> URI Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Router Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Output Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Input Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:19:59 --> Language Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Loader Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:19:59 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Session Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:19:59 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Session routines successfully run
DEBUG - 2011-03-12 22:19:59 --> Controller Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:19:59 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:19:59 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:19:59 --> JSMin library initialized.
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> Model Class Initialized
DEBUG - 2011-03-12 22:19:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:19:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:19:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:19:59 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-03-12 22:19:59 --> Final output sent to browser
DEBUG - 2011-03-12 22:19:59 --> Total execution time: 0.0461
DEBUG - 2011-03-12 22:20:00 --> Config Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:20:00 --> URI Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Router Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Output Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Input Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:20:00 --> Language Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Loader Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:20:00 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:20:00 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:20:00 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:20:00 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:20:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:20:00 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Session Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:20:00 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:20:00 --> Session routines successfully run
DEBUG - 2011-03-12 22:20:00 --> Controller Class Initialized
DEBUG - 2011-03-12 22:20:00 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:20:00 --> Final output sent to browser
DEBUG - 2011-03-12 22:20:00 --> Total execution time: 0.0368
DEBUG - 2011-03-12 22:20:13 --> Config Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:20:13 --> URI Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Router Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Output Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Input Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:20:13 --> Language Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Loader Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:20:13 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Session Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:20:13 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Session routines successfully run
DEBUG - 2011-03-12 22:20:13 --> Controller Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:20:13 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:20:13 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:20:13 --> JSMin library initialized.
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:20:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:20:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:20:13 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:20:13 --> Final output sent to browser
DEBUG - 2011-03-12 22:20:13 --> Total execution time: 0.0462
DEBUG - 2011-03-12 22:20:14 --> Config Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:20:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:20:14 --> URI Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Router Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Output Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Input Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:20:14 --> Language Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Loader Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:20:14 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:20:14 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:20:14 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:20:14 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:20:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:20:14 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Session Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:20:14 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:20:14 --> Session routines successfully run
DEBUG - 2011-03-12 22:20:14 --> Controller Class Initialized
DEBUG - 2011-03-12 22:20:14 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:20:14 --> Final output sent to browser
DEBUG - 2011-03-12 22:20:14 --> Total execution time: 0.0259
DEBUG - 2011-03-12 22:20:55 --> Config Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:20:55 --> URI Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Router Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Output Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Input Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:20:55 --> Language Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Loader Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:20:55 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Session Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:20:55 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Session routines successfully run
DEBUG - 2011-03-12 22:20:55 --> Controller Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:20:55 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:20:55 --> JSMin library initialized.
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:20:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:20:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:20:55 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:20:55 --> Final output sent to browser
DEBUG - 2011-03-12 22:20:55 --> Total execution time: 0.0491
DEBUG - 2011-03-12 22:20:55 --> Config Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:20:55 --> URI Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Router Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Output Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Input Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:20:55 --> Language Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Loader Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:20:55 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Session Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:20:55 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:20:55 --> Session routines successfully run
DEBUG - 2011-03-12 22:20:55 --> Controller Class Initialized
DEBUG - 2011-03-12 22:20:55 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:20:55 --> Final output sent to browser
DEBUG - 2011-03-12 22:20:55 --> Total execution time: 0.0244
DEBUG - 2011-03-12 22:20:56 --> Config Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:20:56 --> URI Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Router Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Output Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Input Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:20:56 --> Language Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Loader Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:20:56 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Session Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:20:56 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Session routines successfully run
DEBUG - 2011-03-12 22:20:56 --> Controller Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: file_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 22:20:56 --> CSSMin library initialized.
DEBUG - 2011-03-12 22:20:56 --> JSMin library initialized.
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Model Class Initialized
DEBUG - 2011-03-12 22:20:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 22:20:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 22:20:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 22:20:56 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 22:20:56 --> Final output sent to browser
DEBUG - 2011-03-12 22:20:56 --> Total execution time: 0.0439
DEBUG - 2011-03-12 22:20:56 --> Config Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Hooks Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Utf8 Class Initialized
DEBUG - 2011-03-12 22:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 22:20:56 --> URI Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Router Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Output Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Input Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 22:20:56 --> Language Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Loader Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: user_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: url_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: array_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 22:20:56 --> Database Driver Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Session Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Helper loaded: string_helper
DEBUG - 2011-03-12 22:20:56 --> Encrypt Class Initialized
DEBUG - 2011-03-12 22:20:56 --> Session routines successfully run
DEBUG - 2011-03-12 22:20:56 --> Controller Class Initialized
DEBUG - 2011-03-12 22:20:56 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 22:20:56 --> Final output sent to browser
DEBUG - 2011-03-12 22:20:56 --> Total execution time: 0.0252
DEBUG - 2011-03-12 23:23:19 --> Config Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Hooks Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Utf8 Class Initialized
DEBUG - 2011-03-12 23:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 23:23:19 --> URI Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Router Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Output Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Input Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 23:23:19 --> Language Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Loader Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: user_helper
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: url_helper
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: array_helper
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 23:23:19 --> Database Driver Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Session Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: string_helper
DEBUG - 2011-03-12 23:23:19 --> Encrypt Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Session routines successfully run
DEBUG - 2011-03-12 23:23:19 --> Controller Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: file_helper
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: directory_helper
DEBUG - 2011-03-12 23:23:19 --> Helper loaded: assets_helper
DEBUG - 2011-03-12 23:23:19 --> CSSMin library initialized.
DEBUG - 2011-03-12 23:23:19 --> JSMin library initialized.
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> Model Class Initialized
DEBUG - 2011-03-12 23:23:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-12 23:23:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-12 23:23:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-12 23:23:19 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-12 23:23:19 --> Final output sent to browser
DEBUG - 2011-03-12 23:23:19 --> Total execution time: 0.0628
DEBUG - 2011-03-12 23:23:20 --> Config Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Hooks Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Utf8 Class Initialized
DEBUG - 2011-03-12 23:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-12 23:23:20 --> URI Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Router Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Output Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Input Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-12 23:23:20 --> Language Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Loader Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-12 23:23:20 --> Helper loaded: user_helper
DEBUG - 2011-03-12 23:23:20 --> Helper loaded: url_helper
DEBUG - 2011-03-12 23:23:20 --> Helper loaded: array_helper
DEBUG - 2011-03-12 23:23:20 --> Helper loaded: utility_helper
DEBUG - 2011-03-12 23:23:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-12 23:23:20 --> Database Driver Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Session Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Helper loaded: string_helper
DEBUG - 2011-03-12 23:23:20 --> Encrypt Class Initialized
DEBUG - 2011-03-12 23:23:20 --> Session routines successfully run
DEBUG - 2011-03-12 23:23:20 --> Controller Class Initialized
DEBUG - 2011-03-12 23:23:20 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-12 23:23:20 --> Final output sent to browser
DEBUG - 2011-03-12 23:23:20 --> Total execution time: 0.0321
