<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-31 20:41:15 --> Config Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:41:15 --> URI Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Router Class Initialized
DEBUG - 2011-03-31 20:41:15 --> No URI present. Default controller set.
DEBUG - 2011-03-31 20:41:15 --> Output Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Input Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:41:15 --> Language Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Loader Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: user_helper
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: array_helper
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: utility_helper
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-31 20:41:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Session Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: string_helper
DEBUG - 2011-03-31 20:41:15 --> Encrypt Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Session routines successfully run
DEBUG - 2011-03-31 20:41:15 --> Controller Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: file_helper
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: directory_helper
DEBUG - 2011-03-31 20:41:15 --> Helper loaded: assets_helper
DEBUG - 2011-03-31 20:41:15 --> CSSMin library initialized.
DEBUG - 2011-03-31 20:41:15 --> JSMin library initialized.
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-31 20:41:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-31 20:41:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-31 20:41:15 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-31 20:41:15 --> Final output sent to browser
DEBUG - 2011-03-31 20:41:15 --> Total execution time: 0.0918
DEBUG - 2011-03-31 20:41:17 --> Config Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:41:17 --> URI Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Router Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Output Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Input Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:41:17 --> Language Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Loader Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-31 20:41:17 --> Helper loaded: user_helper
DEBUG - 2011-03-31 20:41:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:41:17 --> Helper loaded: array_helper
DEBUG - 2011-03-31 20:41:17 --> Helper loaded: utility_helper
DEBUG - 2011-03-31 20:41:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-31 20:41:17 --> Database Driver Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Session Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Helper loaded: string_helper
DEBUG - 2011-03-31 20:41:17 --> Encrypt Class Initialized
DEBUG - 2011-03-31 20:41:17 --> Session routines successfully run
DEBUG - 2011-03-31 20:41:17 --> Controller Class Initialized
DEBUG - 2011-03-31 20:41:17 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-31 20:41:17 --> Final output sent to browser
DEBUG - 2011-03-31 20:41:17 --> Total execution time: 0.0329
DEBUG - 2011-03-31 20:41:19 --> Config Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:41:19 --> URI Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Router Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Output Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Input Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:41:19 --> Language Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Loader Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: user_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: array_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: utility_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-31 20:41:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Session Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: string_helper
DEBUG - 2011-03-31 20:41:19 --> Encrypt Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Session routines successfully run
DEBUG - 2011-03-31 20:41:19 --> Controller Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: file_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: directory_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: assets_helper
DEBUG - 2011-03-31 20:41:19 --> CSSMin library initialized.
DEBUG - 2011-03-31 20:41:19 --> JSMin library initialized.
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-31 20:41:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: rating_helper
DEBUG - 2011-03-31 20:41:19 --> Model Class Initialized
DEBUG - 2011-03-31 20:41:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-31 20:41:19 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-31 20:41:19 --> Final output sent to browser
DEBUG - 2011-03-31 20:41:19 --> Total execution time: 0.0883
DEBUG - 2011-03-31 20:41:19 --> Config Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:41:19 --> URI Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Router Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Output Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Input Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:41:19 --> Language Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Loader Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: user_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: array_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: utility_helper
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-31 20:41:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Session Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Helper loaded: string_helper
DEBUG - 2011-03-31 20:41:19 --> Encrypt Class Initialized
DEBUG - 2011-03-31 20:41:19 --> Session routines successfully run
DEBUG - 2011-03-31 20:41:19 --> Controller Class Initialized
DEBUG - 2011-03-31 20:41:19 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-31 20:41:19 --> Final output sent to browser
DEBUG - 2011-03-31 20:41:19 --> Total execution time: 0.0264
DEBUG - 2011-03-31 21:11:35 --> Config Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:11:35 --> URI Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Router Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Output Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Input Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:11:35 --> Language Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Loader Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: user_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: array_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-31 21:11:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Session Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: string_helper
DEBUG - 2011-03-31 21:11:35 --> Encrypt Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Session routines successfully run
DEBUG - 2011-03-31 21:11:35 --> Controller Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: file_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: directory_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: assets_helper
DEBUG - 2011-03-31 21:11:35 --> CSSMin library initialized.
DEBUG - 2011-03-31 21:11:35 --> JSMin library initialized.
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Model Class Initialized
DEBUG - 2011-03-31 21:11:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-31 21:11:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-31 21:11:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-31 21:11:35 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-03-31 21:11:35 --> Final output sent to browser
DEBUG - 2011-03-31 21:11:35 --> Total execution time: 0.0575
DEBUG - 2011-03-31 21:11:35 --> Config Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:11:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:11:35 --> URI Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Router Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Output Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Input Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:11:35 --> Language Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Loader Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: user_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: array_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-31 21:11:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Session Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Helper loaded: string_helper
DEBUG - 2011-03-31 21:11:35 --> Encrypt Class Initialized
DEBUG - 2011-03-31 21:11:35 --> Session routines successfully run
DEBUG - 2011-03-31 21:11:35 --> Controller Class Initialized
DEBUG - 2011-03-31 21:11:35 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-31 21:11:35 --> Final output sent to browser
DEBUG - 2011-03-31 21:11:35 --> Total execution time: 0.0255
