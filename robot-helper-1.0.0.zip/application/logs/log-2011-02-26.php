<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-26 10:53:18 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:18 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:18 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:18 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:18 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:18 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:18 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:18 --> A session cookie was not found.
DEBUG - 2011-02-26 10:53:18 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:18 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:18 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:18 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:53:18 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:18 --> Total execution time: 0.0286
DEBUG - 2011-02-26 10:53:19 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:19 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:19 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:19 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:19 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:19 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:19 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:19 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:19 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:19 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:19 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:53:19 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:19 --> Total execution time: 0.0271
DEBUG - 2011-02-26 10:53:21 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:21 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:21 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:21 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:21 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:21 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:21 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:21 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:21 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:21 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:21 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:21 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 10:53:21 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:21 --> Total execution time: 0.0283
DEBUG - 2011-02-26 10:53:23 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:23 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:23 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:23 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:23 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:23 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:23 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:23 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:23 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:23 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:23 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:53:23 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:23 --> Total execution time: 0.0287
DEBUG - 2011-02-26 10:53:25 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:25 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:25 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:25 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:25 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:25 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:25 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:25 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:25 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:25 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:25 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:53:25 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:25 --> Total execution time: 0.0285
DEBUG - 2011-02-26 10:53:27 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:27 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:27 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:27 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:27 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:27 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:27 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:27 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:27 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:27 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:27 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:53:27 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:27 --> Total execution time: 0.0289
DEBUG - 2011-02-26 10:53:28 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:28 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:28 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:28 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:28 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:28 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:28 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:28 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:28 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:28 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:29 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:29 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:29 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:29 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:29 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:29 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:29 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 10:53:29 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:29 --> Total execution time: 0.0285
DEBUG - 2011-02-26 10:53:30 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:30 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:30 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:31 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:31 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:31 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:31 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:31 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:31 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:31 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:31 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:31 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:31 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:53:31 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:31 --> Total execution time: 0.0287
DEBUG - 2011-02-26 10:53:32 --> Config Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:53:32 --> URI Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Router Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Output Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Input Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:53:32 --> Language Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Loader Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:53:32 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:53:32 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:53:32 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:53:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:53:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:53:32 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Session Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:53:32 --> Session routines successfully run
DEBUG - 2011-02-26 10:53:32 --> Controller Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:32 --> Model Class Initialized
DEBUG - 2011-02-26 10:53:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:53:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:53:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:53:32 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:53:32 --> Final output sent to browser
DEBUG - 2011-02-26 10:53:32 --> Total execution time: 0.0290
DEBUG - 2011-02-26 10:54:14 --> Config Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:54:14 --> URI Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Router Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Output Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Input Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:54:14 --> Language Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Loader Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:54:14 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:54:14 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:54:14 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:54:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:54:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:54:14 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Session Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:54:14 --> Session routines successfully run
DEBUG - 2011-02-26 10:54:14 --> Controller Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:14 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:54:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:54:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:54:14 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:54:14 --> Final output sent to browser
DEBUG - 2011-02-26 10:54:14 --> Total execution time: 0.0304
DEBUG - 2011-02-26 10:54:16 --> Config Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:54:16 --> URI Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Router Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Output Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Input Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:54:16 --> Language Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Loader Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:54:16 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:54:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:54:16 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:54:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:54:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:54:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Session Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:54:16 --> Session routines successfully run
DEBUG - 2011-02-26 10:54:16 --> Controller Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:16 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:54:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:54:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:54:16 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:54:16 --> Final output sent to browser
DEBUG - 2011-02-26 10:54:16 --> Total execution time: 0.0273
DEBUG - 2011-02-26 10:54:17 --> Config Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:54:17 --> URI Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Router Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Output Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Input Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:54:17 --> Language Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Loader Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:54:17 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:54:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:54:17 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:54:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:54:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:54:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Session Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:54:17 --> Session routines successfully run
DEBUG - 2011-02-26 10:54:17 --> Controller Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:17 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:54:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:54:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:54:17 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:54:17 --> Final output sent to browser
DEBUG - 2011-02-26 10:54:17 --> Total execution time: 0.0290
DEBUG - 2011-02-26 10:54:26 --> Config Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:54:26 --> URI Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Router Class Initialized
DEBUG - 2011-02-26 10:54:26 --> No URI present. Default controller set.
DEBUG - 2011-02-26 10:54:26 --> Output Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Input Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:54:26 --> Language Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Loader Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:54:26 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:54:26 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:54:26 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:54:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:54:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:54:26 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Session Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:54:26 --> Session routines successfully run
DEBUG - 2011-02-26 10:54:26 --> Controller Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:26 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:54:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:54:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:54:26 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 10:54:26 --> Final output sent to browser
DEBUG - 2011-02-26 10:54:26 --> Total execution time: 0.0292
DEBUG - 2011-02-26 10:54:36 --> Config Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:54:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:54:36 --> URI Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Router Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Output Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Input Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:54:36 --> Language Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Loader Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:54:36 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:54:36 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:54:36 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:54:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:54:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:54:36 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Session Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:54:36 --> Session routines successfully run
DEBUG - 2011-02-26 10:54:36 --> Controller Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:36 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:54:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:54:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:54:36 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:54:36 --> Final output sent to browser
DEBUG - 2011-02-26 10:54:36 --> Total execution time: 0.0304
DEBUG - 2011-02-26 10:54:37 --> Config Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:54:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:54:37 --> URI Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Router Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Output Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Input Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:54:37 --> Language Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Loader Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:54:37 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:54:37 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:54:37 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:54:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:54:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:54:37 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Session Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:54:37 --> Session routines successfully run
DEBUG - 2011-02-26 10:54:37 --> Controller Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:37 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:54:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:54:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:54:37 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:54:37 --> Final output sent to browser
DEBUG - 2011-02-26 10:54:37 --> Total execution time: 0.0283
DEBUG - 2011-02-26 10:54:44 --> Config Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:54:44 --> URI Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Router Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Output Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Input Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:54:44 --> Language Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Loader Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:54:44 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:54:44 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:54:44 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:54:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:54:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:54:44 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Session Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:54:44 --> Session routines successfully run
DEBUG - 2011-02-26 10:54:44 --> Controller Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:44 --> Model Class Initialized
DEBUG - 2011-02-26 10:54:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:54:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:54:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:54:44 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 10:54:44 --> Final output sent to browser
DEBUG - 2011-02-26 10:54:44 --> Total execution time: 0.0294
DEBUG - 2011-02-26 10:55:48 --> Config Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:55:48 --> URI Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Router Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Output Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Input Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:55:48 --> Language Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Loader Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:55:48 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:55:48 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:55:48 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:55:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:55:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:55:48 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Session Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:55:48 --> Session routines successfully run
DEBUG - 2011-02-26 10:55:48 --> Controller Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:55:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:55:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:55:48 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:55:48 --> Final output sent to browser
DEBUG - 2011-02-26 10:55:48 --> Total execution time: 0.0308
DEBUG - 2011-02-26 10:55:50 --> Config Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:55:50 --> URI Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Router Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Output Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Input Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:55:50 --> Language Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Loader Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:55:50 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:55:50 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:55:50 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:55:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:55:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:55:50 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Session Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:55:50 --> Session routines successfully run
DEBUG - 2011-02-26 10:55:50 --> Controller Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:55:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:55:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:55:50 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 10:55:50 --> Final output sent to browser
DEBUG - 2011-02-26 10:55:50 --> Total execution time: 0.0290
DEBUG - 2011-02-26 10:55:51 --> Config Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:55:51 --> URI Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Router Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Output Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Input Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:55:51 --> Language Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Loader Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:55:51 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:55:51 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:55:51 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:55:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:55:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:55:51 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Session Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:55:51 --> Session routines successfully run
DEBUG - 2011-02-26 10:55:51 --> Controller Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:55:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:55:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:55:51 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:55:51 --> Final output sent to browser
DEBUG - 2011-02-26 10:55:51 --> Total execution time: 0.0280
DEBUG - 2011-02-26 10:55:52 --> Config Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:55:52 --> URI Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Router Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Output Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Input Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:55:52 --> Language Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Loader Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:55:52 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:55:52 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:55:52 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:55:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:55:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:55:52 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Session Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:55:52 --> Session routines successfully run
DEBUG - 2011-02-26 10:55:52 --> Controller Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:55:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:55:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:55:52 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 10:55:52 --> Final output sent to browser
DEBUG - 2011-02-26 10:55:52 --> Total execution time: 0.0299
DEBUG - 2011-02-26 10:55:54 --> Config Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:55:54 --> URI Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Router Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Output Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Input Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:55:54 --> Language Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Loader Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:55:54 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:55:54 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:55:54 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:55:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:55:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:55:54 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Session Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:55:54 --> Session routines successfully run
DEBUG - 2011-02-26 10:55:54 --> Controller Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:54 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:55:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:55:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:55:54 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 10:55:54 --> Final output sent to browser
DEBUG - 2011-02-26 10:55:54 --> Total execution time: 0.0285
DEBUG - 2011-02-26 10:55:56 --> Config Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:55:56 --> URI Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Router Class Initialized
DEBUG - 2011-02-26 10:55:56 --> No URI present. Default controller set.
DEBUG - 2011-02-26 10:55:56 --> Output Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Input Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:55:56 --> Language Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Loader Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:55:56 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:55:56 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:55:56 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:55:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:55:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:55:56 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Session Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:55:56 --> Session routines successfully run
DEBUG - 2011-02-26 10:55:56 --> Controller Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:56 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:55:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:55:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:55:56 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 10:55:56 --> Final output sent to browser
DEBUG - 2011-02-26 10:55:56 --> Total execution time: 0.0290
DEBUG - 2011-02-26 10:55:58 --> Config Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:55:58 --> URI Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Router Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Output Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Input Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:55:58 --> Language Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Loader Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:55:58 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:55:58 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:55:58 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:55:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:55:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:55:58 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Session Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:55:58 --> Session routines successfully run
DEBUG - 2011-02-26 10:55:58 --> Controller Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:58 --> Model Class Initialized
DEBUG - 2011-02-26 10:55:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:55:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:55:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:55:58 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 10:55:58 --> Final output sent to browser
DEBUG - 2011-02-26 10:55:58 --> Total execution time: 0.0298
DEBUG - 2011-02-26 10:58:43 --> Config Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:58:43 --> URI Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Router Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Output Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Input Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:58:43 --> Language Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Loader Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:58:43 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:58:43 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:58:43 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:58:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:58:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:58:43 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Session Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:58:43 --> Session routines successfully run
DEBUG - 2011-02-26 10:58:43 --> Controller Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:43 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:58:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:58:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:58:43 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-26 10:58:43 --> Final output sent to browser
DEBUG - 2011-02-26 10:58:43 --> Total execution time: 0.0336
DEBUG - 2011-02-26 10:58:57 --> Config Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:58:57 --> URI Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Router Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Output Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Input Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:58:57 --> Language Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Loader Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:58:57 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Session Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:58:57 --> Session routines successfully run
DEBUG - 2011-02-26 10:58:57 --> Controller Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Config Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:58:57 --> URI Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Router Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Output Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Input Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:58:57 --> Language Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Loader Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:58:57 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Session Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:58:57 --> Session routines successfully run
DEBUG - 2011-02-26 10:58:57 --> Controller Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> Model Class Initialized
DEBUG - 2011-02-26 10:58:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:58:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:58:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:58:57 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-26 10:58:57 --> Final output sent to browser
DEBUG - 2011-02-26 10:58:57 --> Total execution time: 0.0342
DEBUG - 2011-02-26 10:59:35 --> Config Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:59:35 --> URI Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Router Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Output Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Input Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:59:35 --> Language Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Loader Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:59:35 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:59:35 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:59:35 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:59:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:59:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:59:35 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Session Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:59:35 --> Session routines successfully run
DEBUG - 2011-02-26 10:59:35 --> Controller Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:59:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:59:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:59:35 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-26 10:59:35 --> Final output sent to browser
DEBUG - 2011-02-26 10:59:35 --> Total execution time: 0.0363
DEBUG - 2011-02-26 10:59:48 --> Config Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:59:48 --> URI Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Router Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Output Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Input Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:59:48 --> Language Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Loader Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:59:48 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:59:48 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:59:48 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:59:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:59:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:59:48 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Session Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:59:48 --> Session routines successfully run
DEBUG - 2011-02-26 10:59:48 --> Controller Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:48 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:59:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:59:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:59:48 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 10:59:48 --> Final output sent to browser
DEBUG - 2011-02-26 10:59:48 --> Total execution time: 0.0313
DEBUG - 2011-02-26 10:59:50 --> Config Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:59:50 --> URI Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Router Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Output Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Input Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:59:50 --> Language Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Loader Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:59:50 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:59:50 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:59:50 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:59:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:59:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:59:50 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Session Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:59:50 --> Session routines successfully run
DEBUG - 2011-02-26 10:59:50 --> Controller Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:50 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:59:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:59:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:59:50 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 10:59:50 --> Final output sent to browser
DEBUG - 2011-02-26 10:59:50 --> Total execution time: 0.0293
DEBUG - 2011-02-26 10:59:51 --> Config Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:59:51 --> URI Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Router Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Output Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Input Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:59:51 --> Language Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Loader Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:59:51 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Session Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:59:51 --> Session routines successfully run
DEBUG - 2011-02-26 10:59:51 --> Controller Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Config Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:59:51 --> URI Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Router Class Initialized
DEBUG - 2011-02-26 10:59:51 --> No URI present. Default controller set.
DEBUG - 2011-02-26 10:59:51 --> Output Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Input Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:59:51 --> Language Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Loader Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:59:51 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Session Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:59:51 --> A session cookie was not found.
DEBUG - 2011-02-26 10:59:51 --> Session routines successfully run
DEBUG - 2011-02-26 10:59:51 --> Controller Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:51 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:59:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:59:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:59:51 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 10:59:51 --> Final output sent to browser
DEBUG - 2011-02-26 10:59:51 --> Total execution time: 0.0276
DEBUG - 2011-02-26 10:59:52 --> Config Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Hooks Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Utf8 Class Initialized
DEBUG - 2011-02-26 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 10:59:52 --> URI Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Router Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Output Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Input Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 10:59:52 --> Language Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Loader Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: user_helper
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: url_helper
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: array_helper
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 10:59:52 --> Database Driver Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Session Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: string_helper
DEBUG - 2011-02-26 10:59:52 --> Session routines successfully run
DEBUG - 2011-02-26 10:59:52 --> Controller Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: robot_helper
DEBUG - 2011-02-26 10:59:52 --> Helper loaded: form_helper
DEBUG - 2011-02-26 10:59:52 --> Form Validation Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:52 --> Model Class Initialized
DEBUG - 2011-02-26 10:59:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 10:59:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 10:59:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 10:59:52 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-26 10:59:52 --> Final output sent to browser
DEBUG - 2011-02-26 10:59:52 --> Total execution time: 0.0327
DEBUG - 2011-02-26 11:19:09 --> Config Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:19:09 --> URI Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Router Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Output Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Input Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:19:09 --> Language Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Loader Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:19:09 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Session Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:19:09 --> Session routines successfully run
DEBUG - 2011-02-26 11:19:09 --> Controller Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: robot_helper
DEBUG - 2011-02-26 11:19:09 --> Helper loaded: form_helper
DEBUG - 2011-02-26 11:19:09 --> Form Validation Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Model Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Model Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Model Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Model Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Model Class Initialized
DEBUG - 2011-02-26 11:19:09 --> Model Class Initialized
DEBUG - 2011-02-26 11:19:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:19:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:19:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:19:09 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-26 11:19:09 --> Final output sent to browser
DEBUG - 2011-02-26 11:19:09 --> Total execution time: 0.0335
DEBUG - 2011-02-26 11:25:46 --> Config Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:25:46 --> URI Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Router Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Output Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Input Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:25:46 --> Language Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Loader Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:25:46 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Session Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:25:46 --> Session routines successfully run
DEBUG - 2011-02-26 11:25:46 --> Controller Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: robot_helper
DEBUG - 2011-02-26 11:25:46 --> Helper loaded: form_helper
DEBUG - 2011-02-26 11:25:46 --> Form Validation Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Model Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Model Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Model Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Model Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Model Class Initialized
DEBUG - 2011-02-26 11:25:46 --> Model Class Initialized
DEBUG - 2011-02-26 11:25:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:25:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:25:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:25:46 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-26 11:25:46 --> Final output sent to browser
DEBUG - 2011-02-26 11:25:46 --> Total execution time: 0.0355
DEBUG - 2011-02-26 11:26:08 --> Config Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:26:08 --> URI Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Router Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Output Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Input Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:26:08 --> Language Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Loader Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:26:08 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:26:08 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:26:08 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:26:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:26:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:26:08 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Session Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:26:08 --> Session routines successfully run
DEBUG - 2011-02-26 11:26:08 --> Controller Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:08 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:26:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:26:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:26:08 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 11:26:08 --> Final output sent to browser
DEBUG - 2011-02-26 11:26:08 --> Total execution time: 0.0298
DEBUG - 2011-02-26 11:26:12 --> Config Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:26:12 --> URI Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Router Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Output Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Input Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:26:12 --> Language Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Loader Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:26:12 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:26:12 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:26:12 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:26:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:26:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:26:12 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Session Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:26:12 --> Session routines successfully run
DEBUG - 2011-02-26 11:26:12 --> Controller Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:12 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:26:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:26:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:26:12 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 11:26:12 --> Final output sent to browser
DEBUG - 2011-02-26 11:26:12 --> Total execution time: 0.0288
DEBUG - 2011-02-26 11:26:15 --> Config Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:26:15 --> URI Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Router Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Output Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Input Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:26:15 --> Language Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Loader Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:26:15 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:26:15 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:26:15 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:26:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:26:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:26:15 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Session Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:26:15 --> Session routines successfully run
DEBUG - 2011-02-26 11:26:15 --> Controller Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:15 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:26:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:26:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:26:15 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 11:26:15 --> Final output sent to browser
DEBUG - 2011-02-26 11:26:15 --> Total execution time: 0.0271
DEBUG - 2011-02-26 11:26:17 --> Config Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:26:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:26:17 --> URI Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Router Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Output Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Input Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:26:17 --> Language Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Loader Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:26:17 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:26:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:26:17 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:26:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:26:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:26:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Session Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:26:17 --> Session routines successfully run
DEBUG - 2011-02-26 11:26:17 --> Controller Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:26:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:26:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:26:17 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 11:26:17 --> Final output sent to browser
DEBUG - 2011-02-26 11:26:17 --> Total execution time: 0.0275
DEBUG - 2011-02-26 11:26:43 --> Config Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:26:43 --> URI Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Router Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Output Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Input Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:26:43 --> Language Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Loader Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:26:43 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:26:43 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:26:43 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:26:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:26:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:26:43 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Session Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:26:43 --> Session routines successfully run
DEBUG - 2011-02-26 11:26:43 --> Controller Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:43 --> Model Class Initialized
DEBUG - 2011-02-26 11:26:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:26:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:26:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:26:43 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 11:26:43 --> Final output sent to browser
DEBUG - 2011-02-26 11:26:43 --> Total execution time: 0.0297
DEBUG - 2011-02-26 11:38:02 --> Config Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:38:02 --> URI Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Router Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Output Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Input Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:38:02 --> Language Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Loader Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:38:02 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:38:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:38:02 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:38:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:38:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:38:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Session Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:38:02 --> Session routines successfully run
DEBUG - 2011-02-26 11:38:02 --> Controller Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:02 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:38:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:38:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:38:02 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 11:38:02 --> Final output sent to browser
DEBUG - 2011-02-26 11:38:02 --> Total execution time: 0.0417
DEBUG - 2011-02-26 11:38:05 --> Config Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:38:05 --> URI Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Router Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Output Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Input Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:38:05 --> Language Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Loader Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:38:05 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:38:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:38:05 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:38:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:38:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:38:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Session Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:38:05 --> Session routines successfully run
DEBUG - 2011-02-26 11:38:05 --> Controller Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:38:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:38:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:38:05 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 11:38:05 --> Final output sent to browser
DEBUG - 2011-02-26 11:38:05 --> Total execution time: 0.0294
DEBUG - 2011-02-26 11:38:17 --> Config Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:38:17 --> URI Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Router Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Output Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Input Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:38:17 --> Language Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Loader Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:38:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Session Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:38:17 --> Session routines successfully run
DEBUG - 2011-02-26 11:38:17 --> Controller Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Config Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 11:38:17 --> URI Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Router Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Output Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Input Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 11:38:17 --> Language Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Loader Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: user_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: array_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 11:38:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Session Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 11:38:17 --> Session routines successfully run
DEBUG - 2011-02-26 11:38:17 --> Controller Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:17 --> Model Class Initialized
DEBUG - 2011-02-26 11:38:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 11:38:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 11:38:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 11:38:17 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-26 11:38:17 --> Final output sent to browser
DEBUG - 2011-02-26 11:38:17 --> Total execution time: 0.0275
DEBUG - 2011-02-26 12:02:32 --> Config Class Initialized
DEBUG - 2011-02-26 12:02:32 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:02:32 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:02:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:02:32 --> URI Class Initialized
DEBUG - 2011-02-26 12:02:32 --> Router Class Initialized
DEBUG - 2011-02-26 12:02:32 --> No URI present. Default controller set.
DEBUG - 2011-02-26 12:02:33 --> Output Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Input Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:02:33 --> Language Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Loader Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:02:33 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:02:33 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:02:33 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:02:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:02:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:02:33 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Session Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:02:33 --> Session routines successfully run
DEBUG - 2011-02-26 12:02:33 --> Controller Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Model Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Model Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Model Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Model Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Model Class Initialized
DEBUG - 2011-02-26 12:02:33 --> Model Class Initialized
DEBUG - 2011-02-26 12:02:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:02:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:02:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:02:33 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 12:02:33 --> Final output sent to browser
DEBUG - 2011-02-26 12:02:33 --> Total execution time: 0.0439
DEBUG - 2011-02-26 12:04:01 --> Config Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:04:01 --> URI Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Router Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Output Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Input Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:04:01 --> Language Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Loader Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:04:01 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:04:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:04:01 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:04:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:04:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:04:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Session Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:04:01 --> Session routines successfully run
DEBUG - 2011-02-26 12:04:01 --> Controller Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:01 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:04:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:04:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:04:01 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 12:04:01 --> Final output sent to browser
DEBUG - 2011-02-26 12:04:01 --> Total execution time: 0.0566
DEBUG - 2011-02-26 12:04:02 --> Config Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:04:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:04:02 --> URI Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Router Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Output Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Input Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:04:02 --> Language Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Loader Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:04:02 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:04:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:04:02 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:04:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:04:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:04:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Session Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:04:02 --> Session routines successfully run
DEBUG - 2011-02-26 12:04:02 --> Controller Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:02 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:03 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:03 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:03 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:03 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:04:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:04:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:04:03 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 12:04:03 --> Final output sent to browser
DEBUG - 2011-02-26 12:04:03 --> Total execution time: 0.0314
DEBUG - 2011-02-26 12:04:06 --> Config Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:04:06 --> URI Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Router Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Output Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Input Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:04:06 --> Language Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Loader Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:04:06 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:04:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:04:06 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:04:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:04:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:04:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Session Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:04:06 --> Session routines successfully run
DEBUG - 2011-02-26 12:04:06 --> Controller Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:06 --> Model Class Initialized
DEBUG - 2011-02-26 12:04:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:04:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:04:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:04:06 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 12:04:06 --> Final output sent to browser
DEBUG - 2011-02-26 12:04:06 --> Total execution time: 0.0472
DEBUG - 2011-02-26 12:10:08 --> Config Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:10:08 --> URI Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Router Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Output Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Input Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:10:08 --> Language Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Loader Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:10:08 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:10:08 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:10:08 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:10:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:10:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:10:08 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Session Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:10:08 --> Session routines successfully run
DEBUG - 2011-02-26 12:10:08 --> Controller Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:08 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:10:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:10:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:10:08 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 12:10:08 --> Final output sent to browser
DEBUG - 2011-02-26 12:10:08 --> Total execution time: 0.0357
DEBUG - 2011-02-26 12:10:09 --> Config Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:10:09 --> URI Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Router Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Output Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Input Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:10:09 --> Language Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Loader Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:10:09 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:10:09 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:10:09 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:10:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:10:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:10:09 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Session Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:10:09 --> Session routines successfully run
DEBUG - 2011-02-26 12:10:09 --> Controller Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:09 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:10:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:10:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:10:09 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 12:10:09 --> Final output sent to browser
DEBUG - 2011-02-26 12:10:09 --> Total execution time: 0.0332
DEBUG - 2011-02-26 12:10:11 --> Config Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:10:11 --> URI Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Router Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Output Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Input Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:10:11 --> Language Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Loader Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:10:11 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:10:11 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:10:11 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:10:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:10:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:10:11 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Session Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:10:11 --> Session routines successfully run
DEBUG - 2011-02-26 12:10:11 --> Controller Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:11 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:10:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:10:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:10:11 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 12:10:11 --> Final output sent to browser
DEBUG - 2011-02-26 12:10:11 --> Total execution time: 0.0302
DEBUG - 2011-02-26 12:10:16 --> Config Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:10:16 --> URI Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Router Class Initialized
DEBUG - 2011-02-26 12:10:16 --> No URI present. Default controller set.
DEBUG - 2011-02-26 12:10:16 --> Output Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Input Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:10:16 --> Language Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Loader Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:10:16 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:10:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:10:16 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:10:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:10:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:10:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Session Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:10:16 --> Session routines successfully run
DEBUG - 2011-02-26 12:10:16 --> Controller Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:16 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:10:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:10:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:10:16 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 12:10:16 --> Final output sent to browser
DEBUG - 2011-02-26 12:10:16 --> Total execution time: 0.0291
DEBUG - 2011-02-26 12:10:18 --> Config Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:10:18 --> URI Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Router Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Output Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Input Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:10:18 --> Language Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Loader Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:10:18 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:10:18 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:10:18 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:10:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:10:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:10:18 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Session Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:10:18 --> Session routines successfully run
DEBUG - 2011-02-26 12:10:18 --> Controller Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:18 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:10:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:10:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:10:18 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 12:10:18 --> Final output sent to browser
DEBUG - 2011-02-26 12:10:18 --> Total execution time: 0.0317
DEBUG - 2011-02-26 12:10:25 --> Config Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Hooks Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Utf8 Class Initialized
DEBUG - 2011-02-26 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 12:10:25 --> URI Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Router Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Output Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Input Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 12:10:25 --> Language Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Loader Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 12:10:25 --> Helper loaded: user_helper
DEBUG - 2011-02-26 12:10:25 --> Helper loaded: url_helper
DEBUG - 2011-02-26 12:10:25 --> Helper loaded: array_helper
DEBUG - 2011-02-26 12:10:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 12:10:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 12:10:25 --> Database Driver Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Session Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Helper loaded: string_helper
DEBUG - 2011-02-26 12:10:25 --> Session routines successfully run
DEBUG - 2011-02-26 12:10:25 --> Controller Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:25 --> Model Class Initialized
DEBUG - 2011-02-26 12:10:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 12:10:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 12:10:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 12:10:25 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 12:10:25 --> Final output sent to browser
DEBUG - 2011-02-26 12:10:25 --> Total execution time: 0.0291
DEBUG - 2011-02-26 13:19:12 --> Config Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:19:12 --> URI Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Router Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Output Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Input Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:19:12 --> Language Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Loader Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:19:12 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:19:12 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:19:12 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:19:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:19:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:19:12 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Session Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:19:12 --> Session routines successfully run
DEBUG - 2011-02-26 13:19:12 --> Controller Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:13 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:13 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:13 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:13 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:19:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:19:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:19:13 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 13:19:13 --> Final output sent to browser
DEBUG - 2011-02-26 13:19:13 --> Total execution time: 0.0348
DEBUG - 2011-02-26 13:19:16 --> Config Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:19:16 --> URI Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Router Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Output Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Input Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:19:16 --> Language Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Loader Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:19:16 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:19:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:19:16 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:19:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:19:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:19:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Session Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:19:16 --> Session routines successfully run
DEBUG - 2011-02-26 13:19:16 --> Controller Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:19:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:19:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:19:16 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:19:16 --> Final output sent to browser
DEBUG - 2011-02-26 13:19:16 --> Total execution time: 0.0285
DEBUG - 2011-02-26 13:19:54 --> Config Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:19:54 --> URI Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Router Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Output Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Input Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:19:54 --> Language Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Loader Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:19:54 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:19:54 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:19:54 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:19:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:19:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:19:54 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Session Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:19:54 --> Session routines successfully run
DEBUG - 2011-02-26 13:19:54 --> Controller Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:19:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:19:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:19:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:19:54 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:19:54 --> Final output sent to browser
DEBUG - 2011-02-26 13:19:54 --> Total execution time: 0.0292
DEBUG - 2011-02-26 13:22:27 --> Config Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:22:27 --> URI Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Router Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Output Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Input Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:22:27 --> Language Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Loader Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:22:27 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:22:27 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:22:27 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:22:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:22:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:22:27 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Session Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:22:27 --> Session routines successfully run
DEBUG - 2011-02-26 13:22:27 --> Controller Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:27 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:22:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:22:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:22:27 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:22:27 --> Final output sent to browser
DEBUG - 2011-02-26 13:22:27 --> Total execution time: 0.0339
DEBUG - 2011-02-26 13:22:43 --> Config Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:22:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:22:43 --> URI Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Router Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Output Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Input Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:22:43 --> Language Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Loader Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:22:43 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:22:43 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:22:43 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:22:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:22:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:22:43 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Session Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:22:43 --> Session routines successfully run
DEBUG - 2011-02-26 13:22:43 --> Controller Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:43 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:22:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:22:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:22:43 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:22:43 --> Final output sent to browser
DEBUG - 2011-02-26 13:22:43 --> Total execution time: 0.0319
DEBUG - 2011-02-26 13:22:53 --> Config Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:22:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:22:53 --> URI Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Router Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Output Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Input Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:22:53 --> Language Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Loader Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:22:53 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:22:53 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:22:53 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:22:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:22:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:22:53 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Session Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:22:53 --> Session routines successfully run
DEBUG - 2011-02-26 13:22:53 --> Controller Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:53 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:54 --> Model Class Initialized
DEBUG - 2011-02-26 13:22:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:22:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:22:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:22:54 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:22:54 --> Final output sent to browser
DEBUG - 2011-02-26 13:22:54 --> Total execution time: 0.0282
DEBUG - 2011-02-26 13:23:06 --> Config Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:23:06 --> URI Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Router Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Output Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Input Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:23:06 --> Language Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Loader Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:23:06 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:23:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:23:06 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:23:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:23:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:23:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Session Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:23:06 --> Session routines successfully run
DEBUG - 2011-02-26 13:23:06 --> Controller Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:06 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:23:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:23:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:23:06 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:23:06 --> Final output sent to browser
DEBUG - 2011-02-26 13:23:06 --> Total execution time: 0.0287
DEBUG - 2011-02-26 13:23:12 --> Config Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:23:12 --> URI Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Router Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Output Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Input Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:23:12 --> Language Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Loader Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:23:12 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:23:12 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:23:12 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:23:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:23:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:23:12 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Session Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:23:12 --> Session routines successfully run
DEBUG - 2011-02-26 13:23:12 --> Controller Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:12 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:23:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:23:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:23:12 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:23:12 --> Final output sent to browser
DEBUG - 2011-02-26 13:23:12 --> Total execution time: 0.0271
DEBUG - 2011-02-26 13:23:25 --> Config Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:23:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:23:25 --> URI Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Router Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Output Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Input Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:23:25 --> Language Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Loader Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:23:25 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:23:25 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:23:25 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:23:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:23:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:23:25 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Session Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:23:25 --> Session routines successfully run
DEBUG - 2011-02-26 13:23:25 --> Controller Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:25 --> Model Class Initialized
DEBUG - 2011-02-26 13:23:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:23:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:23:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:23:25 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:23:25 --> Final output sent to browser
DEBUG - 2011-02-26 13:23:25 --> Total execution time: 0.0295
DEBUG - 2011-02-26 13:55:02 --> Config Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:55:02 --> URI Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Router Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Output Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Input Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:55:02 --> Language Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Loader Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:55:02 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:55:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:55:02 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:55:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:55:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:55:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Session Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:55:02 --> Session routines successfully run
DEBUG - 2011-02-26 13:55:02 --> Controller Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Model Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Model Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Model Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Model Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Model Class Initialized
DEBUG - 2011-02-26 13:55:02 --> Model Class Initialized
DEBUG - 2011-02-26 13:55:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:55:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:55:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:55:02 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 13:55:02 --> Final output sent to browser
DEBUG - 2011-02-26 13:55:02 --> Total execution time: 0.0360
DEBUG - 2011-02-26 13:56:55 --> Config Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:56:55 --> URI Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Router Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Output Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Input Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:56:55 --> Language Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Loader Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:56:55 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:56:55 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:56:55 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:56:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:56:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:56:55 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Session Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:56:55 --> Session routines successfully run
DEBUG - 2011-02-26 13:56:55 --> Controller Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Model Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Model Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Model Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Model Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Model Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Model Class Initialized
DEBUG - 2011-02-26 13:56:55 --> Model Class Initialized
DEBUG - 2011-02-26 13:56:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:56:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:56:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:56:55 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-26 13:56:55 --> Final output sent to browser
DEBUG - 2011-02-26 13:56:55 --> Total execution time: 0.0363
DEBUG - 2011-02-26 13:57:01 --> Config Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:57:01 --> URI Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Router Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Output Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Input Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:57:01 --> Language Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Loader Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:57:01 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:57:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:57:01 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:57:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:57:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:57:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Session Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:57:01 --> Session routines successfully run
DEBUG - 2011-02-26 13:57:01 --> Controller Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:01 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:57:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:57:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:57:01 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-26 13:57:01 --> Final output sent to browser
DEBUG - 2011-02-26 13:57:01 --> Total execution time: 0.0324
DEBUG - 2011-02-26 13:57:16 --> Config Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:57:16 --> URI Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Router Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Output Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Input Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:57:16 --> Language Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Loader Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:57:16 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:57:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:57:16 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:57:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:57:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:57:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Session Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:57:16 --> Session routines successfully run
DEBUG - 2011-02-26 13:57:16 --> Controller Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:16 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:57:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:57:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:57:16 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-26 13:57:16 --> Final output sent to browser
DEBUG - 2011-02-26 13:57:16 --> Total execution time: 0.0332
DEBUG - 2011-02-26 13:57:22 --> Config Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Hooks Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Utf8 Class Initialized
DEBUG - 2011-02-26 13:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 13:57:22 --> URI Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Router Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Output Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Input Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 13:57:22 --> Language Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Loader Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 13:57:22 --> Helper loaded: user_helper
DEBUG - 2011-02-26 13:57:22 --> Helper loaded: url_helper
DEBUG - 2011-02-26 13:57:22 --> Helper loaded: array_helper
DEBUG - 2011-02-26 13:57:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 13:57:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 13:57:22 --> Database Driver Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Session Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Helper loaded: string_helper
DEBUG - 2011-02-26 13:57:22 --> Session routines successfully run
DEBUG - 2011-02-26 13:57:22 --> Controller Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:22 --> Model Class Initialized
DEBUG - 2011-02-26 13:57:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 13:57:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 13:57:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 13:57:22 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-26 13:57:22 --> Final output sent to browser
DEBUG - 2011-02-26 13:57:22 --> Total execution time: 0.0325
DEBUG - 2011-02-26 14:18:12 --> Config Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Hooks Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Utf8 Class Initialized
DEBUG - 2011-02-26 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 14:18:12 --> URI Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Router Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Output Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Input Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 14:18:12 --> Language Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Loader Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 14:18:12 --> Helper loaded: user_helper
DEBUG - 2011-02-26 14:18:12 --> Helper loaded: url_helper
DEBUG - 2011-02-26 14:18:12 --> Helper loaded: array_helper
DEBUG - 2011-02-26 14:18:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 14:18:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 14:18:12 --> Database Driver Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Session Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Helper loaded: string_helper
DEBUG - 2011-02-26 14:18:12 --> Session routines successfully run
DEBUG - 2011-02-26 14:18:12 --> Controller Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Model Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Model Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Model Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Model Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Model Class Initialized
DEBUG - 2011-02-26 14:18:12 --> Model Class Initialized
DEBUG - 2011-02-26 14:18:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 14:18:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 14:18:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 14:18:12 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 14:18:12 --> Final output sent to browser
DEBUG - 2011-02-26 14:18:12 --> Total execution time: 0.0359
DEBUG - 2011-02-26 17:07:04 --> Config Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:07:04 --> URI Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Router Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Output Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Input Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:07:04 --> Language Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Loader Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:07:04 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:07:04 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:07:04 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:07:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:07:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:07:04 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Session Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:07:04 --> A session cookie was not found.
DEBUG - 2011-02-26 17:07:04 --> Session routines successfully run
DEBUG - 2011-02-26 17:07:04 --> Controller Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:04 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:07:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:07:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:07:04 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 17:07:04 --> Final output sent to browser
DEBUG - 2011-02-26 17:07:04 --> Total execution time: 0.0323
DEBUG - 2011-02-26 17:07:05 --> Config Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:07:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:07:05 --> URI Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Router Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Output Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Input Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:07:05 --> Language Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Loader Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:07:05 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:07:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:07:05 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:07:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:07:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:07:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Session Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:07:05 --> Session routines successfully run
DEBUG - 2011-02-26 17:07:05 --> Controller Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:05 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:07:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:07:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:07:05 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 17:07:05 --> Final output sent to browser
DEBUG - 2011-02-26 17:07:05 --> Total execution time: 0.0277
DEBUG - 2011-02-26 17:07:08 --> Config Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:07:08 --> URI Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Router Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Output Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Input Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:07:08 --> Language Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Loader Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:07:08 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:07:08 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:07:08 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:07:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:07:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:07:08 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Session Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:07:08 --> Session routines successfully run
DEBUG - 2011-02-26 17:07:08 --> Controller Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:07:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:07:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:07:08 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 17:07:08 --> Final output sent to browser
DEBUG - 2011-02-26 17:07:08 --> Total execution time: 0.0299
DEBUG - 2011-02-26 17:07:11 --> Config Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:07:11 --> URI Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Router Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Output Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Input Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:07:11 --> Language Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Loader Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:07:11 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:07:11 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:07:11 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:07:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:07:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:07:11 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Session Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:07:11 --> Session routines successfully run
DEBUG - 2011-02-26 17:07:11 --> Controller Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:11 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:07:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:07:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:07:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 17:07:11 --> Final output sent to browser
DEBUG - 2011-02-26 17:07:11 --> Total execution time: 0.0285
DEBUG - 2011-02-26 17:07:33 --> Config Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:07:33 --> URI Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Router Class Initialized
DEBUG - 2011-02-26 17:07:33 --> No URI present. Default controller set.
DEBUG - 2011-02-26 17:07:33 --> Output Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Input Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:07:33 --> Language Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Loader Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:07:33 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:07:33 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:07:33 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:07:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:07:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:07:33 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Session Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:07:33 --> Session routines successfully run
DEBUG - 2011-02-26 17:07:33 --> Controller Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:07:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:07:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:07:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:07:33 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 17:07:33 --> Final output sent to browser
DEBUG - 2011-02-26 17:07:33 --> Total execution time: 0.0318
DEBUG - 2011-02-26 17:08:28 --> Config Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:08:28 --> URI Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Router Class Initialized
DEBUG - 2011-02-26 17:08:28 --> No URI present. Default controller set.
DEBUG - 2011-02-26 17:08:28 --> Output Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Input Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:08:28 --> Language Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Loader Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:08:28 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:08:28 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:08:28 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:08:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:08:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:08:28 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Session Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:08:28 --> Session routines successfully run
DEBUG - 2011-02-26 17:08:28 --> Controller Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 17:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 17:08:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:08:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:08:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:08:28 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 17:08:28 --> Final output sent to browser
DEBUG - 2011-02-26 17:08:28 --> Total execution time: 0.0275
DEBUG - 2011-02-26 17:09:15 --> Config Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:09:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:09:15 --> URI Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Router Class Initialized
DEBUG - 2011-02-26 17:09:15 --> No URI present. Default controller set.
DEBUG - 2011-02-26 17:09:15 --> Output Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Input Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:09:15 --> Language Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Loader Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:09:15 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:09:15 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:09:15 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:09:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:09:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:09:15 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Session Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:09:15 --> Session routines successfully run
DEBUG - 2011-02-26 17:09:15 --> Controller Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:15 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:09:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:09:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:09:15 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 17:09:15 --> Final output sent to browser
DEBUG - 2011-02-26 17:09:15 --> Total execution time: 0.0285
DEBUG - 2011-02-26 17:09:30 --> Config Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:09:30 --> URI Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Router Class Initialized
DEBUG - 2011-02-26 17:09:30 --> No URI present. Default controller set.
DEBUG - 2011-02-26 17:09:30 --> Output Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Input Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:09:30 --> Language Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Loader Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:09:30 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:09:30 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:09:30 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:09:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:09:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:09:30 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Session Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:09:30 --> Session routines successfully run
DEBUG - 2011-02-26 17:09:30 --> Controller Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 17:09:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:09:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:09:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:09:30 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 17:09:30 --> Final output sent to browser
DEBUG - 2011-02-26 17:09:30 --> Total execution time: 0.0282
DEBUG - 2011-02-26 17:10:33 --> Config Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:10:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:10:33 --> URI Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Router Class Initialized
DEBUG - 2011-02-26 17:10:33 --> No URI present. Default controller set.
DEBUG - 2011-02-26 17:10:33 --> Output Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Input Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:10:33 --> Language Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Loader Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:10:33 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:10:33 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:10:33 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:10:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:10:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:10:33 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Session Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:10:33 --> Session routines successfully run
DEBUG - 2011-02-26 17:10:33 --> Controller Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:33 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:10:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:10:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:10:33 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 17:10:33 --> Final output sent to browser
DEBUG - 2011-02-26 17:10:33 --> Total execution time: 0.0301
DEBUG - 2011-02-26 17:10:39 --> Config Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:10:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:10:39 --> URI Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Router Class Initialized
DEBUG - 2011-02-26 17:10:39 --> No URI present. Default controller set.
DEBUG - 2011-02-26 17:10:39 --> Output Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Input Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:10:39 --> Language Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Loader Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:10:39 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:10:39 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:10:39 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:10:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:10:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:10:39 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Session Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:10:39 --> Session routines successfully run
DEBUG - 2011-02-26 17:10:39 --> Controller Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:39 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:10:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:10:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:10:39 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 17:10:39 --> Final output sent to browser
DEBUG - 2011-02-26 17:10:39 --> Total execution time: 0.0291
DEBUG - 2011-02-26 17:10:52 --> Config Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Hooks Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Utf8 Class Initialized
DEBUG - 2011-02-26 17:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 17:10:52 --> URI Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Router Class Initialized
DEBUG - 2011-02-26 17:10:52 --> No URI present. Default controller set.
DEBUG - 2011-02-26 17:10:52 --> Output Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Input Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 17:10:52 --> Language Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Loader Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 17:10:52 --> Helper loaded: user_helper
DEBUG - 2011-02-26 17:10:52 --> Helper loaded: url_helper
DEBUG - 2011-02-26 17:10:52 --> Helper loaded: array_helper
DEBUG - 2011-02-26 17:10:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 17:10:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 17:10:52 --> Database Driver Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Session Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Helper loaded: string_helper
DEBUG - 2011-02-26 17:10:52 --> Session routines successfully run
DEBUG - 2011-02-26 17:10:52 --> Controller Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:52 --> Model Class Initialized
DEBUG - 2011-02-26 17:10:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 17:10:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 17:10:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 17:10:52 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 17:10:52 --> Final output sent to browser
DEBUG - 2011-02-26 17:10:52 --> Total execution time: 0.0276
DEBUG - 2011-02-26 20:12:24 --> Config Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:12:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:12:24 --> URI Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Router Class Initialized
DEBUG - 2011-02-26 20:12:24 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:12:24 --> Output Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Input Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:12:24 --> Language Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Loader Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:12:24 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:12:24 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:12:24 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:12:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:12:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:12:24 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Session Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:12:24 --> A session cookie was not found.
DEBUG - 2011-02-26 20:12:24 --> Session routines successfully run
DEBUG - 2011-02-26 20:12:24 --> Controller Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Model Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Model Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Model Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Model Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Model Class Initialized
DEBUG - 2011-02-26 20:12:24 --> Model Class Initialized
DEBUG - 2011-02-26 20:12:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:12:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:12:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:12:24 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:12:24 --> Final output sent to browser
DEBUG - 2011-02-26 20:12:24 --> Total execution time: 0.0285
DEBUG - 2011-02-26 20:14:09 --> Config Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:14:09 --> URI Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Router Class Initialized
DEBUG - 2011-02-26 20:14:09 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:14:09 --> Output Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Input Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:14:09 --> Language Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Loader Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:14:09 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:14:09 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:14:09 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:14:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:14:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:14:09 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Session Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:14:09 --> Session routines successfully run
DEBUG - 2011-02-26 20:14:09 --> Controller Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:09 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:14:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:14:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:14:09 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:14:09 --> Final output sent to browser
DEBUG - 2011-02-26 20:14:09 --> Total execution time: 0.0290
DEBUG - 2011-02-26 20:14:10 --> Config Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:14:10 --> URI Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Router Class Initialized
DEBUG - 2011-02-26 20:14:10 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:14:10 --> Output Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Input Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:14:10 --> Language Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Loader Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:14:10 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:14:10 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:14:10 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:14:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:14:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:14:10 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Session Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:14:10 --> Session routines successfully run
DEBUG - 2011-02-26 20:14:10 --> Controller Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:10 --> Model Class Initialized
DEBUG - 2011-02-26 20:14:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:14:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:14:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:14:10 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:14:10 --> Final output sent to browser
DEBUG - 2011-02-26 20:14:10 --> Total execution time: 0.0293
DEBUG - 2011-02-26 20:15:01 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:01 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:01 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:15:01 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:01 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:01 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:01 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:01 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:01 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:01 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:15:01 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:01 --> Total execution time: 0.0278
DEBUG - 2011-02-26 20:15:19 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:19 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:19 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:15:19 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:19 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:19 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:19 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:19 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:19 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:19 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:19 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:19 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:19 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:15:19 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:19 --> Total execution time: 0.0363
DEBUG - 2011-02-26 20:15:32 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:32 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:32 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:15:32 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:32 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:32 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:32 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:32 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:32 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:32 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:32 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:32 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:32 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:15:32 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:32 --> Total execution time: 0.0300
DEBUG - 2011-02-26 20:15:35 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:35 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:35 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:35 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:35 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:35 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:35 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:35 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:35 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:35 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:35 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 20:15:35 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:35 --> Total execution time: 0.0356
DEBUG - 2011-02-26 20:15:37 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:37 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:37 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:15:37 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:37 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:37 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:37 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:37 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:37 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:37 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:37 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:37 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:37 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:15:37 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:37 --> Total execution time: 0.0288
DEBUG - 2011-02-26 20:15:39 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:39 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:39 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:39 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:39 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:39 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:39 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:39 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:39 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:39 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:39 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 20:15:39 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:39 --> Total execution time: 0.0291
DEBUG - 2011-02-26 20:15:41 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:41 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:41 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:41 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:41 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:41 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:41 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:41 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:41 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:41 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:41 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 20:15:41 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:41 --> Total execution time: 0.0289
DEBUG - 2011-02-26 20:15:42 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:42 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:42 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:42 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:42 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:42 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:42 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:42 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:42 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:42 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:42 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 20:15:42 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:42 --> Total execution time: 0.0280
DEBUG - 2011-02-26 20:15:44 --> Config Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:15:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:15:44 --> URI Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Router Class Initialized
DEBUG - 2011-02-26 20:15:44 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:15:44 --> Output Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Input Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:15:44 --> Language Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Loader Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:15:44 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:15:44 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:15:44 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:15:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:15:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:15:44 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Session Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:15:44 --> Session routines successfully run
DEBUG - 2011-02-26 20:15:44 --> Controller Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:44 --> Model Class Initialized
DEBUG - 2011-02-26 20:15:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:15:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:15:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:15:44 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:15:44 --> Final output sent to browser
DEBUG - 2011-02-26 20:15:44 --> Total execution time: 0.0293
DEBUG - 2011-02-26 20:16:01 --> Config Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:16:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:16:01 --> URI Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Router Class Initialized
DEBUG - 2011-02-26 20:16:01 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:16:01 --> Output Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Input Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:16:01 --> Language Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Loader Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:16:01 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:16:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:16:01 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:16:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:16:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:16:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Session Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:16:01 --> Session routines successfully run
DEBUG - 2011-02-26 20:16:01 --> Controller Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:16:01 --> Model Class Initialized
DEBUG - 2011-02-26 20:16:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:16:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:16:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:16:01 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:16:01 --> Final output sent to browser
DEBUG - 2011-02-26 20:16:01 --> Total execution time: 0.0326
DEBUG - 2011-02-26 20:17:16 --> Config Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 20:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 20:17:16 --> URI Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Router Class Initialized
DEBUG - 2011-02-26 20:17:16 --> No URI present. Default controller set.
DEBUG - 2011-02-26 20:17:16 --> Output Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Input Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 20:17:16 --> Language Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Loader Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 20:17:16 --> Helper loaded: user_helper
DEBUG - 2011-02-26 20:17:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 20:17:16 --> Helper loaded: array_helper
DEBUG - 2011-02-26 20:17:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 20:17:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 20:17:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Session Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 20:17:16 --> Session routines successfully run
DEBUG - 2011-02-26 20:17:16 --> Controller Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Model Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Model Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Model Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Model Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Model Class Initialized
DEBUG - 2011-02-26 20:17:16 --> Model Class Initialized
DEBUG - 2011-02-26 20:17:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 20:17:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 20:17:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 20:17:16 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 20:17:16 --> Final output sent to browser
DEBUG - 2011-02-26 20:17:16 --> Total execution time: 0.0266
DEBUG - 2011-02-26 22:58:10 --> Config Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Hooks Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Utf8 Class Initialized
DEBUG - 2011-02-26 22:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 22:58:10 --> URI Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Router Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Output Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Input Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 22:58:10 --> Language Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Loader Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 22:58:10 --> Helper loaded: user_helper
DEBUG - 2011-02-26 22:58:10 --> Helper loaded: url_helper
DEBUG - 2011-02-26 22:58:10 --> Helper loaded: array_helper
DEBUG - 2011-02-26 22:58:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 22:58:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 22:58:10 --> Database Driver Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Session Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Helper loaded: string_helper
DEBUG - 2011-02-26 22:58:10 --> A session cookie was not found.
DEBUG - 2011-02-26 22:58:10 --> Session routines successfully run
DEBUG - 2011-02-26 22:58:10 --> Controller Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:10 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 22:58:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 22:58:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 22:58:10 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 22:58:10 --> Final output sent to browser
DEBUG - 2011-02-26 22:58:10 --> Total execution time: 0.0324
DEBUG - 2011-02-26 22:58:14 --> Config Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 22:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 22:58:14 --> URI Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Router Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Output Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Input Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 22:58:14 --> Language Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Loader Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 22:58:14 --> Helper loaded: user_helper
DEBUG - 2011-02-26 22:58:14 --> Helper loaded: url_helper
DEBUG - 2011-02-26 22:58:14 --> Helper loaded: array_helper
DEBUG - 2011-02-26 22:58:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 22:58:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 22:58:14 --> Database Driver Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Session Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Helper loaded: string_helper
DEBUG - 2011-02-26 22:58:14 --> Session routines successfully run
DEBUG - 2011-02-26 22:58:14 --> Controller Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:14 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 22:58:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 22:58:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 22:58:14 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 22:58:14 --> Final output sent to browser
DEBUG - 2011-02-26 22:58:14 --> Total execution time: 0.0285
DEBUG - 2011-02-26 22:58:50 --> Config Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Hooks Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Utf8 Class Initialized
DEBUG - 2011-02-26 22:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 22:58:50 --> URI Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Router Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Output Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Input Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 22:58:50 --> Language Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Loader Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 22:58:50 --> Helper loaded: user_helper
DEBUG - 2011-02-26 22:58:50 --> Helper loaded: url_helper
DEBUG - 2011-02-26 22:58:50 --> Helper loaded: array_helper
DEBUG - 2011-02-26 22:58:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 22:58:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 22:58:50 --> Database Driver Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Session Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Helper loaded: string_helper
DEBUG - 2011-02-26 22:58:50 --> Session routines successfully run
DEBUG - 2011-02-26 22:58:50 --> Controller Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:50 --> Model Class Initialized
DEBUG - 2011-02-26 22:58:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 22:58:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 22:58:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 22:58:50 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 22:58:50 --> Final output sent to browser
DEBUG - 2011-02-26 22:58:50 --> Total execution time: 0.0285
DEBUG - 2011-02-26 22:59:37 --> Config Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Hooks Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Utf8 Class Initialized
DEBUG - 2011-02-26 22:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 22:59:37 --> URI Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Router Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Output Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Input Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 22:59:37 --> Language Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Loader Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 22:59:37 --> Helper loaded: user_helper
DEBUG - 2011-02-26 22:59:37 --> Helper loaded: url_helper
DEBUG - 2011-02-26 22:59:37 --> Helper loaded: array_helper
DEBUG - 2011-02-26 22:59:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 22:59:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 22:59:37 --> Database Driver Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Session Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Helper loaded: string_helper
DEBUG - 2011-02-26 22:59:37 --> Session routines successfully run
DEBUG - 2011-02-26 22:59:37 --> Controller Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Model Class Initialized
DEBUG - 2011-02-26 22:59:37 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Config Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:00:06 --> URI Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Router Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Output Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Input Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:00:06 --> Language Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Loader Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:00:06 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:00:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:00:06 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:00:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:00:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:00:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Session Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:00:06 --> Session routines successfully run
DEBUG - 2011-02-26 23:00:06 --> Controller Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:00:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:00:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:00:06 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 23:00:06 --> Final output sent to browser
DEBUG - 2011-02-26 23:00:06 --> Total execution time: 0.0339
DEBUG - 2011-02-26 23:00:26 --> Config Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:00:26 --> URI Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Router Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Output Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Input Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:00:26 --> Language Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Loader Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:00:26 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:00:26 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:00:26 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:00:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:00:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:00:26 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Session Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:00:26 --> Session routines successfully run
DEBUG - 2011-02-26 23:00:26 --> Controller Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:26 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:00:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:00:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:00:26 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 23:00:26 --> Final output sent to browser
DEBUG - 2011-02-26 23:00:26 --> Total execution time: 0.0294
DEBUG - 2011-02-26 23:00:47 --> Config Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:00:47 --> URI Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Router Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Output Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Input Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:00:47 --> Language Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Loader Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:00:47 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:00:47 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:00:47 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:00:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:00:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:00:47 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Session Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:00:47 --> Session routines successfully run
DEBUG - 2011-02-26 23:00:47 --> Controller Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:00:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:00:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:00:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:00:47 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 23:00:47 --> Final output sent to browser
DEBUG - 2011-02-26 23:00:47 --> Total execution time: 0.0322
DEBUG - 2011-02-26 23:02:48 --> Config Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:02:48 --> URI Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Router Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Output Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Input Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:02:48 --> Language Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Loader Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:02:48 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:02:48 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:02:48 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:02:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:02:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:02:48 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Session Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:02:48 --> Session routines successfully run
DEBUG - 2011-02-26 23:02:48 --> Controller Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:02:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:02:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:02:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:02:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:02:48 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 23:02:48 --> Final output sent to browser
DEBUG - 2011-02-26 23:02:48 --> Total execution time: 0.0312
DEBUG - 2011-02-26 23:03:14 --> Config Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:03:14 --> URI Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Router Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Output Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Input Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:03:14 --> Language Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Loader Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:03:14 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:03:14 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:03:14 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:03:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:03:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:03:14 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Session Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:03:14 --> Session routines successfully run
DEBUG - 2011-02-26 23:03:14 --> Controller Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:03:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:03:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:03:14 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:03:14 --> Final output sent to browser
DEBUG - 2011-02-26 23:03:14 --> Total execution time: 0.0369
DEBUG - 2011-02-26 23:03:18 --> Config Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:03:18 --> URI Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Router Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Output Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Input Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:03:18 --> Language Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Loader Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:03:18 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:03:18 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:03:18 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:03:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:03:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:03:18 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Session Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:03:18 --> Session routines successfully run
DEBUG - 2011-02-26 23:03:18 --> Controller Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:03:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:03:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:03:18 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:03:18 --> Final output sent to browser
DEBUG - 2011-02-26 23:03:18 --> Total execution time: 0.0285
DEBUG - 2011-02-26 23:03:44 --> Config Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:03:44 --> URI Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Router Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Output Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Input Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:03:44 --> Language Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Loader Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:03:44 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:03:44 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:03:44 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:03:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:03:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:03:44 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Session Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:03:44 --> Session routines successfully run
DEBUG - 2011-02-26 23:03:44 --> Controller Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:03:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:03:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:03:44 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:03:44 --> Final output sent to browser
DEBUG - 2011-02-26 23:03:44 --> Total execution time: 0.0287
DEBUG - 2011-02-26 23:03:45 --> Config Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:03:45 --> URI Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Router Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Output Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Input Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:03:45 --> Language Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Loader Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:03:45 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:03:45 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:03:45 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:03:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:03:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:03:45 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Session Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:03:45 --> Session routines successfully run
DEBUG - 2011-02-26 23:03:45 --> Controller Class Initialized
DEBUG - 2011-02-26 23:03:45 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:46 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:46 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:46 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:46 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:46 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:03:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:03:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:03:46 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:03:46 --> Final output sent to browser
DEBUG - 2011-02-26 23:03:46 --> Total execution time: 0.0321
DEBUG - 2011-02-26 23:03:56 --> Config Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:03:56 --> URI Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Router Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Output Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Input Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:03:56 --> Language Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Loader Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:03:56 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:03:56 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:03:56 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:03:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:03:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:03:56 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Session Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:03:56 --> Session routines successfully run
DEBUG - 2011-02-26 23:03:56 --> Controller Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:56 --> Model Class Initialized
DEBUG - 2011-02-26 23:03:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:03:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:03:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:03:56 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:03:56 --> Final output sent to browser
DEBUG - 2011-02-26 23:03:56 --> Total execution time: 0.0304
DEBUG - 2011-02-26 23:04:24 --> Config Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:04:24 --> URI Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Router Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Output Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Input Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:04:24 --> Language Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Loader Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:04:24 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:04:24 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:04:24 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:04:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:04:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:04:24 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Session Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:04:24 --> Session routines successfully run
DEBUG - 2011-02-26 23:04:24 --> Controller Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:24 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:04:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:04:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:04:24 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:04:24 --> Final output sent to browser
DEBUG - 2011-02-26 23:04:24 --> Total execution time: 0.0309
DEBUG - 2011-02-26 23:04:40 --> Config Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:04:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:04:40 --> URI Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Router Class Initialized
DEBUG - 2011-02-26 23:04:40 --> No URI present. Default controller set.
DEBUG - 2011-02-26 23:04:40 --> Output Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Input Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:04:40 --> Language Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Loader Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:04:40 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:04:40 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:04:40 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:04:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:04:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:04:40 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Session Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:04:40 --> Session routines successfully run
DEBUG - 2011-02-26 23:04:40 --> Controller Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:04:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:04:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:04:40 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 23:04:40 --> Final output sent to browser
DEBUG - 2011-02-26 23:04:40 --> Total execution time: 0.0296
DEBUG - 2011-02-26 23:04:43 --> Config Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:04:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:04:43 --> URI Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Router Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Output Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Input Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:04:43 --> Language Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Loader Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:04:43 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:04:43 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:04:43 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:04:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:04:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:04:43 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Session Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:04:43 --> Session routines successfully run
DEBUG - 2011-02-26 23:04:43 --> Controller Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:43 --> Model Class Initialized
DEBUG - 2011-02-26 23:04:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:04:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:04:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:04:43 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:04:43 --> Final output sent to browser
DEBUG - 2011-02-26 23:04:43 --> Total execution time: 0.0302
DEBUG - 2011-02-26 23:05:00 --> Config Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:05:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:05:00 --> URI Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Router Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Output Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Input Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:05:00 --> Language Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Loader Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:05:00 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:05:00 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:05:00 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:05:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:05:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:05:00 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Session Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:05:00 --> Session routines successfully run
DEBUG - 2011-02-26 23:05:00 --> Controller Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:05:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:05:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:05:00 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 23:05:00 --> Final output sent to browser
DEBUG - 2011-02-26 23:05:00 --> Total execution time: 0.0310
DEBUG - 2011-02-26 23:05:05 --> Config Class Initialized
DEBUG - 2011-02-26 23:05:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:05:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:05:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:05:05 --> URI Class Initialized
DEBUG - 2011-02-26 23:05:05 --> Router Class Initialized
DEBUG - 2011-02-26 23:05:05 --> Output Class Initialized
DEBUG - 2011-02-26 23:05:05 --> Input Class Initialized
DEBUG - 2011-02-26 23:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:05:05 --> Language Class Initialized
DEBUG - 2011-02-26 23:05:05 --> Loader Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:05:06 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:05:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:05:06 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:05:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:05:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:05:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Session Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:05:06 --> Session routines successfully run
DEBUG - 2011-02-26 23:05:06 --> Controller Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:06 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:05:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:05:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:05:06 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 23:05:06 --> Final output sent to browser
DEBUG - 2011-02-26 23:05:06 --> Total execution time: 0.0314
DEBUG - 2011-02-26 23:05:09 --> Config Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:05:09 --> URI Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Router Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Output Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Input Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:05:09 --> Language Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Loader Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:05:09 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:05:09 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:05:09 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:05:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:05:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:05:09 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Session Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:05:09 --> Session routines successfully run
DEBUG - 2011-02-26 23:05:09 --> Controller Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:05:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:05:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:05:09 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 23:05:09 --> Final output sent to browser
DEBUG - 2011-02-26 23:05:09 --> Total execution time: 0.0312
DEBUG - 2011-02-26 23:05:18 --> Config Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:05:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:05:18 --> URI Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Router Class Initialized
DEBUG - 2011-02-26 23:05:18 --> No URI present. Default controller set.
DEBUG - 2011-02-26 23:05:18 --> Output Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Input Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:05:18 --> Language Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Loader Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:05:18 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:05:18 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:05:18 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:05:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:05:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:05:18 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Session Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:05:18 --> Session routines successfully run
DEBUG - 2011-02-26 23:05:18 --> Controller Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:05:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:05:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:05:18 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 23:05:18 --> Final output sent to browser
DEBUG - 2011-02-26 23:05:18 --> Total execution time: 0.0307
DEBUG - 2011-02-26 23:05:27 --> Config Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:05:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:05:27 --> URI Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Router Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Output Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Input Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:05:27 --> Language Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Loader Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:05:27 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:05:27 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:05:27 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:05:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:05:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:05:27 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Session Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:05:27 --> Session routines successfully run
DEBUG - 2011-02-26 23:05:27 --> Controller Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:05:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:05:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:05:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:05:27 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-26 23:05:27 --> Final output sent to browser
DEBUG - 2011-02-26 23:05:27 --> Total execution time: 0.0361
DEBUG - 2011-02-26 23:07:08 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:08 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:08 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:08 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:08 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:08 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:08 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:08 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:08 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:08 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-26 23:07:08 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:08 --> Total execution time: 0.0362
DEBUG - 2011-02-26 23:07:09 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:09 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:09 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:09 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:09 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:09 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:09 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:09 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:09 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:09 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-26 23:07:09 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:09 --> Total execution time: 0.0327
DEBUG - 2011-02-26 23:07:10 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:10 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:10 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:10 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:10 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:10 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:10 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:10 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:10 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:10 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-26 23:07:10 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:10 --> Total execution time: 0.0388
DEBUG - 2011-02-26 23:07:28 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:28 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:28 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:28 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:28 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:28 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:28 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:28 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:28 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:28 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:07:28 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:28 --> Total execution time: 0.0303
DEBUG - 2011-02-26 23:07:30 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:30 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:30 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:30 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:30 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:30 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:30 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:30 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:30 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:30 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-26 23:07:30 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:30 --> Total execution time: 0.0318
DEBUG - 2011-02-26 23:07:33 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:33 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:33 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:33 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:33 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:33 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:33 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:33 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:33 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:33 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-26 23:07:33 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:33 --> Total execution time: 0.1334
DEBUG - 2011-02-26 23:07:34 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:34 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:34 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:34 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:34 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:34 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:34 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:34 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:34 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:34 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:34 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:34 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:34 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-26 23:07:34 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:34 --> Total execution time: 0.0326
DEBUG - 2011-02-26 23:07:35 --> Config Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:07:35 --> URI Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Router Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Output Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Input Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:07:35 --> Language Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Loader Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:07:35 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:07:35 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:07:35 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:07:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:07:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:07:35 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Session Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:07:35 --> Session routines successfully run
DEBUG - 2011-02-26 23:07:35 --> Controller Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> Model Class Initialized
DEBUG - 2011-02-26 23:07:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:07:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:07:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:07:35 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-26 23:07:35 --> Final output sent to browser
DEBUG - 2011-02-26 23:07:35 --> Total execution time: 0.0351
DEBUG - 2011-02-26 23:08:05 --> Config Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:08:05 --> URI Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Router Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Output Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Input Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:08:05 --> Language Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Loader Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:08:05 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:08:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:08:05 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:08:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:08:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:08:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Session Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:08:05 --> Session routines successfully run
DEBUG - 2011-02-26 23:08:05 --> Controller Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:08:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:08:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:08:05 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-26 23:08:05 --> Final output sent to browser
DEBUG - 2011-02-26 23:08:05 --> Total execution time: 0.0324
DEBUG - 2011-02-26 23:08:28 --> Config Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:08:28 --> URI Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Router Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Output Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Input Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:08:28 --> Language Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Loader Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:08:28 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Session Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:08:28 --> Session routines successfully run
DEBUG - 2011-02-26 23:08:28 --> Controller Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: robot_helper
DEBUG - 2011-02-26 23:08:28 --> Helper loaded: form_helper
DEBUG - 2011-02-26 23:08:28 --> Form Validation Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:28 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:08:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:08:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:08:28 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-26 23:08:28 --> Final output sent to browser
DEBUG - 2011-02-26 23:08:28 --> Total execution time: 0.0393
DEBUG - 2011-02-26 23:08:36 --> Config Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:08:36 --> URI Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Router Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Output Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Input Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:08:36 --> Language Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Loader Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:08:36 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:08:36 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:08:36 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:08:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:08:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:08:36 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Session Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:08:36 --> Session routines successfully run
DEBUG - 2011-02-26 23:08:36 --> Controller Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:08:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:08:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:08:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:08:36 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:08:36 --> Final output sent to browser
DEBUG - 2011-02-26 23:08:36 --> Total execution time: 0.0303
DEBUG - 2011-02-26 23:09:05 --> Config Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:09:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:09:05 --> URI Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Router Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Output Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Input Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:09:05 --> Language Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Loader Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:09:05 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:09:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:09:05 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:09:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:09:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:09:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Session Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:09:05 --> Session routines successfully run
DEBUG - 2011-02-26 23:09:05 --> Controller Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:09:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:09:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:09:05 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:09:05 --> Final output sent to browser
DEBUG - 2011-02-26 23:09:05 --> Total execution time: 0.0296
DEBUG - 2011-02-26 23:09:25 --> Config Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:09:25 --> URI Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Router Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Output Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Input Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:09:25 --> Language Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Loader Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:09:25 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:09:25 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:09:25 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:09:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:09:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:09:25 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Session Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:09:25 --> Session routines successfully run
DEBUG - 2011-02-26 23:09:25 --> Controller Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:25 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:09:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:09:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:09:25 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:09:25 --> Final output sent to browser
DEBUG - 2011-02-26 23:09:25 --> Total execution time: 0.0287
DEBUG - 2011-02-26 23:09:30 --> Config Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:09:30 --> URI Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Router Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Output Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Input Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:09:30 --> Language Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Loader Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:09:30 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:09:30 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:09:30 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:09:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:09:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:09:30 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Session Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:09:30 --> Session routines successfully run
DEBUG - 2011-02-26 23:09:30 --> Controller Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:09:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:09:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:09:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:09:30 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:09:30 --> Final output sent to browser
DEBUG - 2011-02-26 23:09:30 --> Total execution time: 0.0305
DEBUG - 2011-02-26 23:17:02 --> Config Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:17:02 --> URI Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Router Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Output Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Input Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:17:02 --> Language Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Loader Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:17:02 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:17:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:17:02 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:17:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:17:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:17:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Session Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:17:02 --> Session routines successfully run
DEBUG - 2011-02-26 23:17:02 --> Controller Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:17:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:17:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:17:02 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:17:02 --> Final output sent to browser
DEBUG - 2011-02-26 23:17:02 --> Total execution time: 0.0353
DEBUG - 2011-02-26 23:17:42 --> Config Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:17:42 --> URI Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Router Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Output Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Input Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:17:42 --> Language Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Loader Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:17:42 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:17:42 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:17:42 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:17:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:17:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:17:42 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Session Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:17:42 --> Session routines successfully run
DEBUG - 2011-02-26 23:17:42 --> Controller Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:17:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:17:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:17:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:17:42 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:17:42 --> Final output sent to browser
DEBUG - 2011-02-26 23:17:42 --> Total execution time: 0.0322
DEBUG - 2011-02-26 23:26:04 --> Config Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:26:04 --> URI Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Router Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Output Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Input Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:26:04 --> Language Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Loader Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:26:04 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:26:04 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:26:04 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:26:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:26:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:26:04 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Session Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:26:04 --> Session routines successfully run
DEBUG - 2011-02-26 23:26:04 --> Controller Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:04 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:26:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:26:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:26:04 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:26:04 --> Final output sent to browser
DEBUG - 2011-02-26 23:26:04 --> Total execution time: 0.0333
DEBUG - 2011-02-26 23:26:18 --> Config Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:26:18 --> URI Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Router Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Output Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Input Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:26:18 --> Language Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Loader Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:26:18 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:26:18 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:26:18 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:26:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:26:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:26:18 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Session Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:26:18 --> Session routines successfully run
DEBUG - 2011-02-26 23:26:18 --> Controller Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:18 --> Model Class Initialized
DEBUG - 2011-02-26 23:26:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:26:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:26:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:26:18 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:26:18 --> Final output sent to browser
DEBUG - 2011-02-26 23:26:18 --> Total execution time: 0.0285
DEBUG - 2011-02-26 23:27:00 --> Config Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:27:00 --> URI Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Router Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Output Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Input Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:27:00 --> Language Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Loader Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:27:00 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:27:00 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:27:00 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:27:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:27:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:27:00 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Session Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:27:00 --> Session routines successfully run
DEBUG - 2011-02-26 23:27:00 --> Controller Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:27:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:27:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:27:00 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:27:00 --> Final output sent to browser
DEBUG - 2011-02-26 23:27:00 --> Total execution time: 0.0298
DEBUG - 2011-02-26 23:27:40 --> Config Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:27:40 --> URI Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Router Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Output Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Input Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:27:40 --> Language Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Loader Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:27:40 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:27:40 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:27:40 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:27:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:27:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:27:40 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Session Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:27:40 --> Session routines successfully run
DEBUG - 2011-02-26 23:27:40 --> Controller Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:40 --> Model Class Initialized
DEBUG - 2011-02-26 23:27:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:27:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:27:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:27:40 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:27:40 --> Final output sent to browser
DEBUG - 2011-02-26 23:27:40 --> Total execution time: 0.0363
DEBUG - 2011-02-26 23:28:53 --> Config Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:28:53 --> URI Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Router Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Output Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Input Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:28:53 --> Language Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Loader Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:28:53 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:28:53 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:28:53 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:28:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:28:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:28:53 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Session Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:28:53 --> Session routines successfully run
DEBUG - 2011-02-26 23:28:53 --> Controller Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:28:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:28:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:28:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:28:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:28:53 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:28:53 --> Final output sent to browser
DEBUG - 2011-02-26 23:28:53 --> Total execution time: 0.0267
DEBUG - 2011-02-26 23:29:07 --> Config Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:29:07 --> URI Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Router Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Output Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Input Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:29:07 --> Language Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Loader Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:29:07 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:29:07 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:29:07 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:29:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:29:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:29:07 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Session Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:29:07 --> Session routines successfully run
DEBUG - 2011-02-26 23:29:07 --> Controller Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:29:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:29:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:29:07 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:29:07 --> Final output sent to browser
DEBUG - 2011-02-26 23:29:07 --> Total execution time: 0.0285
DEBUG - 2011-02-26 23:29:20 --> Config Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:29:20 --> URI Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Router Class Initialized
DEBUG - 2011-02-26 23:29:20 --> No URI present. Default controller set.
DEBUG - 2011-02-26 23:29:20 --> Output Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Input Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:29:20 --> Language Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Loader Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:29:20 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:29:20 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:29:20 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:29:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:29:20 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:29:20 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Session Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:29:20 --> Session routines successfully run
DEBUG - 2011-02-26 23:29:20 --> Controller Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:20 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:29:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:29:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:29:20 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 23:29:20 --> Final output sent to browser
DEBUG - 2011-02-26 23:29:20 --> Total execution time: 0.0301
DEBUG - 2011-02-26 23:29:21 --> Config Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:29:21 --> URI Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Router Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Output Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Input Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:29:21 --> Language Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Loader Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:29:21 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:29:21 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:29:21 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:29:21 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:29:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:29:21 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Session Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:29:21 --> Session routines successfully run
DEBUG - 2011-02-26 23:29:21 --> Controller Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:21 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:29:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:29:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:29:21 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:29:21 --> Final output sent to browser
DEBUG - 2011-02-26 23:29:21 --> Total execution time: 0.0307
DEBUG - 2011-02-26 23:29:23 --> Config Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:29:23 --> URI Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Router Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Output Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Input Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:29:23 --> Language Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Loader Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:29:23 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:29:23 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:29:23 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:29:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:29:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:29:23 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Session Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:29:23 --> Session routines successfully run
DEBUG - 2011-02-26 23:29:23 --> Controller Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:23 --> Model Class Initialized
DEBUG - 2011-02-26 23:29:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:29:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:29:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:29:23 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:29:23 --> Final output sent to browser
DEBUG - 2011-02-26 23:29:23 --> Total execution time: 0.0289
DEBUG - 2011-02-26 23:30:16 --> Config Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:30:16 --> URI Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Router Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Output Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Input Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:30:16 --> Language Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Loader Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:30:16 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:30:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:30:16 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:30:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:30:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:30:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Session Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:30:16 --> Session routines successfully run
DEBUG - 2011-02-26 23:30:16 --> Controller Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:30:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:30:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:30:16 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:30:16 --> Final output sent to browser
DEBUG - 2011-02-26 23:30:16 --> Total execution time: 0.0282
DEBUG - 2011-02-26 23:30:29 --> Config Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:30:29 --> URI Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Router Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Output Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Input Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:30:29 --> Language Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Loader Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:30:29 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:30:29 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:30:29 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:30:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:30:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:30:29 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Session Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:30:29 --> Session routines successfully run
DEBUG - 2011-02-26 23:30:29 --> Controller Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:29 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:30 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:30:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:30:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:30:30 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:30:30 --> Final output sent to browser
DEBUG - 2011-02-26 23:30:30 --> Total execution time: 0.0287
DEBUG - 2011-02-26 23:30:44 --> Config Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:30:44 --> URI Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Router Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Output Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Input Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:30:44 --> Language Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Loader Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:30:44 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:30:44 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:30:44 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:30:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:30:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:30:44 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Session Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:30:44 --> Session routines successfully run
DEBUG - 2011-02-26 23:30:44 --> Controller Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:30:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:30:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:30:44 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:30:44 --> Final output sent to browser
DEBUG - 2011-02-26 23:30:44 --> Total execution time: 0.0301
DEBUG - 2011-02-26 23:30:53 --> Config Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:30:53 --> URI Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Router Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Output Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Input Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:30:53 --> Language Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Loader Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:30:53 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:30:53 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:30:53 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:30:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:30:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:30:53 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Session Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:30:53 --> Session routines successfully run
DEBUG - 2011-02-26 23:30:53 --> Controller Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:30:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:30:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:30:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:30:53 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:30:53 --> Final output sent to browser
DEBUG - 2011-02-26 23:30:53 --> Total execution time: 0.0272
DEBUG - 2011-02-26 23:31:36 --> Config Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:31:36 --> URI Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Router Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Output Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Input Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:31:36 --> Language Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Loader Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:31:36 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:31:36 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:31:36 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:31:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:31:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:31:36 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Session Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:31:36 --> Session routines successfully run
DEBUG - 2011-02-26 23:31:36 --> Controller Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:31:36 --> Model Class Initialized
DEBUG - 2011-02-26 23:31:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:31:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:31:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:31:36 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:31:36 --> Final output sent to browser
DEBUG - 2011-02-26 23:31:36 --> Total execution time: 0.0287
DEBUG - 2011-02-26 23:32:01 --> Config Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:32:01 --> URI Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Router Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Output Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Input Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:32:01 --> Language Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Loader Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:32:01 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:32:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:32:01 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:32:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:32:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:32:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Session Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:32:01 --> Session routines successfully run
DEBUG - 2011-02-26 23:32:01 --> Controller Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:32:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:32:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:32:01 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:32:01 --> Final output sent to browser
DEBUG - 2011-02-26 23:32:01 --> Total execution time: 0.0281
DEBUG - 2011-02-26 23:32:47 --> Config Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:32:47 --> URI Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Router Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Output Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Input Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:32:47 --> Language Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Loader Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:32:47 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:32:47 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:32:47 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:32:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:32:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:32:47 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Session Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:32:47 --> Session routines successfully run
DEBUG - 2011-02-26 23:32:47 --> Controller Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:32:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:32:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:32:47 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:32:47 --> Final output sent to browser
DEBUG - 2011-02-26 23:32:47 --> Total execution time: 0.0288
DEBUG - 2011-02-26 23:32:52 --> Config Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:32:52 --> URI Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Router Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Output Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Input Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:32:52 --> Language Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Loader Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:32:52 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:32:52 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:32:52 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:32:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:32:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:32:52 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Session Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:32:52 --> Session routines successfully run
DEBUG - 2011-02-26 23:32:52 --> Controller Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:52 --> Model Class Initialized
DEBUG - 2011-02-26 23:32:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:32:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:32:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:32:52 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:32:52 --> Final output sent to browser
DEBUG - 2011-02-26 23:32:52 --> Total execution time: 0.0288
DEBUG - 2011-02-26 23:33:02 --> Config Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:33:02 --> URI Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Router Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Output Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Input Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:33:02 --> Language Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Loader Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:33:02 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:33:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:33:02 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:33:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:33:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:33:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Session Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:33:02 --> Session routines successfully run
DEBUG - 2011-02-26 23:33:02 --> Controller Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:33:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:33:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:33:02 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:33:02 --> Final output sent to browser
DEBUG - 2011-02-26 23:33:02 --> Total execution time: 0.0278
DEBUG - 2011-02-26 23:33:15 --> Config Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:33:15 --> URI Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Router Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Output Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Input Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:33:15 --> Language Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Loader Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:33:15 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:33:15 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:33:15 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:33:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:33:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:33:15 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Session Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:33:15 --> Session routines successfully run
DEBUG - 2011-02-26 23:33:15 --> Controller Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:15 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:33:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:33:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:33:15 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:33:15 --> Final output sent to browser
DEBUG - 2011-02-26 23:33:15 --> Total execution time: 0.0294
DEBUG - 2011-02-26 23:33:22 --> Config Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:33:22 --> URI Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Router Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Output Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Input Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:33:22 --> Language Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Loader Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:33:22 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:33:22 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:33:22 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:33:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:33:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:33:22 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Session Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:33:22 --> Session routines successfully run
DEBUG - 2011-02-26 23:33:22 --> Controller Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:22 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:33:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:33:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:33:22 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:33:22 --> Final output sent to browser
DEBUG - 2011-02-26 23:33:22 --> Total execution time: 0.0318
DEBUG - 2011-02-26 23:33:44 --> Config Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:33:44 --> URI Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Router Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Output Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Input Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:33:44 --> Language Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Loader Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:33:44 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:33:44 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:33:44 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:33:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:33:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:33:44 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Session Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:33:44 --> Session routines successfully run
DEBUG - 2011-02-26 23:33:44 --> Controller Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:44 --> Model Class Initialized
DEBUG - 2011-02-26 23:33:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:33:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:33:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:33:44 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:33:44 --> Final output sent to browser
DEBUG - 2011-02-26 23:33:44 --> Total execution time: 0.0278
DEBUG - 2011-02-26 23:34:01 --> Config Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:34:01 --> URI Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Router Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Output Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Input Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:34:01 --> Language Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Loader Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:34:01 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:34:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:34:01 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:34:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:34:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:34:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Session Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:34:01 --> Session routines successfully run
DEBUG - 2011-02-26 23:34:01 --> Controller Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:01 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:34:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:34:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:34:01 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:34:01 --> Final output sent to browser
DEBUG - 2011-02-26 23:34:01 --> Total execution time: 0.0273
DEBUG - 2011-02-26 23:34:14 --> Config Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:34:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:34:14 --> URI Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Router Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Output Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Input Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:34:14 --> Language Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Loader Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:34:14 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:34:14 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:34:14 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:34:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:34:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:34:14 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Session Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:34:14 --> Session routines successfully run
DEBUG - 2011-02-26 23:34:14 --> Controller Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:14 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:34:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:34:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:34:14 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:34:14 --> Final output sent to browser
DEBUG - 2011-02-26 23:34:14 --> Total execution time: 0.0294
DEBUG - 2011-02-26 23:34:27 --> Config Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:34:27 --> URI Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Router Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Output Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Input Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:34:27 --> Language Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Loader Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:34:27 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:34:27 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:34:27 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:34:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:34:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:34:27 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Session Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:34:27 --> Session routines successfully run
DEBUG - 2011-02-26 23:34:27 --> Controller Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:27 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:34:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:34:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:34:27 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:34:27 --> Final output sent to browser
DEBUG - 2011-02-26 23:34:27 --> Total execution time: 0.0284
DEBUG - 2011-02-26 23:34:41 --> Config Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:34:41 --> URI Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Router Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Output Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Input Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:34:41 --> Language Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Loader Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:34:41 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:34:41 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:34:41 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:34:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:34:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:34:41 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Session Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:34:41 --> Session routines successfully run
DEBUG - 2011-02-26 23:34:41 --> Controller Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:41 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:42 --> Model Class Initialized
DEBUG - 2011-02-26 23:34:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:34:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:34:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:34:42 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:34:42 --> Final output sent to browser
DEBUG - 2011-02-26 23:34:42 --> Total execution time: 0.0276
DEBUG - 2011-02-26 23:36:08 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:08 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:08 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:08 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:08 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:08 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:08 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:08 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:08 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:08 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:08 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:36:08 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:08 --> Total execution time: 0.0283
DEBUG - 2011-02-26 23:36:16 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:16 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:16 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:16 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:16 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:16 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:16 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:16 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:16 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:36:16 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:16 --> Total execution time: 0.0291
DEBUG - 2011-02-26 23:36:45 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:45 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:45 --> No URI present. Default controller set.
DEBUG - 2011-02-26 23:36:45 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:45 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:45 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:45 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:45 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:45 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:45 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:45 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:45 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:45 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 23:36:45 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:45 --> Total execution time: 0.0305
DEBUG - 2011-02-26 23:36:47 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:47 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:47 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:47 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:47 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:47 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:47 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:47 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:47 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:47 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:47 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:36:47 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:47 --> Total execution time: 0.0300
DEBUG - 2011-02-26 23:36:48 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:48 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:48 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:48 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:48 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:48 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:48 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:48 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:48 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:48 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:48 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 23:36:48 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:48 --> Total execution time: 0.0277
DEBUG - 2011-02-26 23:36:50 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:50 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:50 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:50 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:50 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:50 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:50 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:50 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:50 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:50 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:50 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 23:36:50 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:50 --> Total execution time: 0.0282
DEBUG - 2011-02-26 23:36:51 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:51 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:51 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:51 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:51 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:51 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:51 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:51 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:51 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:51 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:51 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-26 23:36:51 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:51 --> Total execution time: 0.0285
DEBUG - 2011-02-26 23:36:53 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:53 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:53 --> No URI present. Default controller set.
DEBUG - 2011-02-26 23:36:53 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:53 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:53 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:53 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:53 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:53 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:53 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:53 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:53 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:53 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 23:36:53 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:53 --> Total execution time: 0.0294
DEBUG - 2011-02-26 23:36:55 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:55 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:55 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:55 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:55 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:55 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: robot_helper
DEBUG - 2011-02-26 23:36:55 --> Helper loaded: form_helper
DEBUG - 2011-02-26 23:36:55 --> Form Validation Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:55 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:55 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-26 23:36:55 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:55 --> Total execution time: 0.0334
DEBUG - 2011-02-26 23:36:57 --> Config Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:36:57 --> URI Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Router Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Output Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Input Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:36:57 --> Language Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Loader Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:36:57 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:36:57 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:36:57 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:36:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:36:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:36:57 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Session Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:36:57 --> Session routines successfully run
DEBUG - 2011-02-26 23:36:57 --> Controller Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:57 --> Model Class Initialized
DEBUG - 2011-02-26 23:36:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:36:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:36:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:36:57 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-26 23:36:57 --> Final output sent to browser
DEBUG - 2011-02-26 23:36:57 --> Total execution time: 0.0289
DEBUG - 2011-02-26 23:37:00 --> Config Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:37:00 --> URI Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Router Class Initialized
DEBUG - 2011-02-26 23:37:00 --> No URI present. Default controller set.
DEBUG - 2011-02-26 23:37:00 --> Output Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Input Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:37:00 --> Language Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Loader Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:37:00 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:37:00 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:37:00 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:37:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:37:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:37:00 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Session Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:37:00 --> Session routines successfully run
DEBUG - 2011-02-26 23:37:00 --> Controller Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:00 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:37:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:37:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:37:00 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-26 23:37:00 --> Final output sent to browser
DEBUG - 2011-02-26 23:37:00 --> Total execution time: 0.0294
DEBUG - 2011-02-26 23:37:02 --> Config Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:37:02 --> URI Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Router Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Output Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Input Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:37:02 --> Language Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Loader Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:37:02 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:37:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:37:02 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:37:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:37:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:37:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Session Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:37:02 --> Session routines successfully run
DEBUG - 2011-02-26 23:37:02 --> Controller Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:02 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:37:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:37:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:37:02 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-26 23:37:02 --> Final output sent to browser
DEBUG - 2011-02-26 23:37:02 --> Total execution time: 0.0287
DEBUG - 2011-02-26 23:37:05 --> Config Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:37:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:37:05 --> URI Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Router Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Output Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Input Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:37:05 --> Language Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Loader Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:37:05 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:37:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:37:05 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:37:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:37:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:37:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Session Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:37:05 --> Session routines successfully run
DEBUG - 2011-02-26 23:37:05 --> Controller Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:05 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:37:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:37:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:37:05 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-26 23:37:05 --> Final output sent to browser
DEBUG - 2011-02-26 23:37:05 --> Total execution time: 0.0383
DEBUG - 2011-02-26 23:37:07 --> Config Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Hooks Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Utf8 Class Initialized
DEBUG - 2011-02-26 23:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 23:37:07 --> URI Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Router Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Output Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Input Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 23:37:07 --> Language Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Loader Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-26 23:37:07 --> Helper loaded: user_helper
DEBUG - 2011-02-26 23:37:07 --> Helper loaded: url_helper
DEBUG - 2011-02-26 23:37:07 --> Helper loaded: array_helper
DEBUG - 2011-02-26 23:37:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-26 23:37:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-26 23:37:07 --> Database Driver Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Session Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Helper loaded: string_helper
DEBUG - 2011-02-26 23:37:07 --> Session routines successfully run
DEBUG - 2011-02-26 23:37:07 --> Controller Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:07 --> Model Class Initialized
DEBUG - 2011-02-26 23:37:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-26 23:37:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-26 23:37:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-26 23:37:07 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-26 23:37:07 --> Final output sent to browser
DEBUG - 2011-02-26 23:37:07 --> Total execution time: 0.0272
