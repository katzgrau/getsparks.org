<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-24 00:37:03 --> Config Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Hooks Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Utf8 Class Initialized
DEBUG - 2011-02-24 00:37:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 00:37:03 --> URI Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Router Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Output Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Input Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 00:37:03 --> Language Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Loader Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 00:37:03 --> Helper loaded: user_helper
DEBUG - 2011-02-24 00:37:03 --> Helper loaded: url_helper
DEBUG - 2011-02-24 00:37:03 --> Helper loaded: array_helper
DEBUG - 2011-02-24 00:37:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 00:37:03 --> Database Driver Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Session Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Helper loaded: string_helper
DEBUG - 2011-02-24 00:37:03 --> Session routines successfully run
DEBUG - 2011-02-24 00:37:03 --> Controller Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:03 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 00:37:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 00:37:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 00:37:03 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-24 00:37:03 --> Final output sent to browser
DEBUG - 2011-02-24 00:37:03 --> Total execution time: 0.0324
DEBUG - 2011-02-24 00:37:07 --> Config Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Hooks Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Utf8 Class Initialized
DEBUG - 2011-02-24 00:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 00:37:07 --> URI Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Router Class Initialized
DEBUG - 2011-02-24 00:37:07 --> No URI present. Default controller set.
DEBUG - 2011-02-24 00:37:07 --> Output Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Input Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 00:37:07 --> Language Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Loader Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 00:37:07 --> Helper loaded: user_helper
DEBUG - 2011-02-24 00:37:07 --> Helper loaded: url_helper
DEBUG - 2011-02-24 00:37:07 --> Helper loaded: array_helper
DEBUG - 2011-02-24 00:37:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 00:37:07 --> Database Driver Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Session Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Helper loaded: string_helper
DEBUG - 2011-02-24 00:37:07 --> Session routines successfully run
DEBUG - 2011-02-24 00:37:07 --> Controller Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 00:37:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 00:37:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 00:37:07 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-24 00:37:07 --> Final output sent to browser
DEBUG - 2011-02-24 00:37:07 --> Total execution time: 0.0441
DEBUG - 2011-02-24 00:37:14 --> Config Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Hooks Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Utf8 Class Initialized
DEBUG - 2011-02-24 00:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 00:37:14 --> URI Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Router Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Output Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Input Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 00:37:14 --> Language Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Loader Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 00:37:14 --> Helper loaded: user_helper
DEBUG - 2011-02-24 00:37:14 --> Helper loaded: url_helper
DEBUG - 2011-02-24 00:37:14 --> Helper loaded: array_helper
DEBUG - 2011-02-24 00:37:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 00:37:14 --> Database Driver Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Session Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Helper loaded: string_helper
DEBUG - 2011-02-24 00:37:14 --> Session routines successfully run
DEBUG - 2011-02-24 00:37:14 --> Controller Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:14 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 00:37:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 00:37:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 00:37:14 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-24 00:37:14 --> Final output sent to browser
DEBUG - 2011-02-24 00:37:14 --> Total execution time: 0.0283
DEBUG - 2011-02-24 00:37:23 --> Config Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Hooks Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Utf8 Class Initialized
DEBUG - 2011-02-24 00:37:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 00:37:23 --> URI Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Router Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Output Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Input Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 00:37:23 --> Language Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Loader Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 00:37:23 --> Helper loaded: user_helper
DEBUG - 2011-02-24 00:37:23 --> Helper loaded: url_helper
DEBUG - 2011-02-24 00:37:23 --> Helper loaded: array_helper
DEBUG - 2011-02-24 00:37:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 00:37:23 --> Database Driver Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Session Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Helper loaded: string_helper
DEBUG - 2011-02-24 00:37:23 --> Session routines successfully run
DEBUG - 2011-02-24 00:37:23 --> Controller Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:23 --> Model Class Initialized
DEBUG - 2011-02-24 00:37:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 00:37:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 00:37:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 00:37:23 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-24 00:37:23 --> Final output sent to browser
DEBUG - 2011-02-24 00:37:23 --> Total execution time: 0.0296
DEBUG - 2011-02-24 00:37:30 --> Config Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Hooks Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Utf8 Class Initialized
DEBUG - 2011-02-24 00:37:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 00:37:30 --> URI Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Router Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Output Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Input Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 00:37:30 --> Language Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Loader Class Initialized
DEBUG - 2011-02-24 00:37:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 00:37:30 --> Helper loaded: user_helper
DEBUG - 2011-02-24 00:37:30 --> Helper loaded: url_helper
DEBUG - 2011-02-24 00:37:30 --> Helper loaded: array_helper
DEBUG - 2011-02-24 00:37:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 00:37:31 --> Database Driver Class Initialized
DEBUG - 2011-02-24 00:37:31 --> Session Class Initialized
DEBUG - 2011-02-24 00:37:31 --> Helper loaded: string_helper
DEBUG - 2011-02-24 00:37:31 --> Session routines successfully run
DEBUG - 2011-02-24 00:37:31 --> Controller Class Initialized
DEBUG - 2011-02-24 00:37:31 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-24 00:37:31 --> Final output sent to browser
DEBUG - 2011-02-24 00:37:31 --> Total execution time: 0.0257
DEBUG - 2011-02-24 01:11:13 --> Config Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Hooks Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Utf8 Class Initialized
DEBUG - 2011-02-24 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 01:11:13 --> URI Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Router Class Initialized
DEBUG - 2011-02-24 01:11:13 --> No URI present. Default controller set.
DEBUG - 2011-02-24 01:11:13 --> Output Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Input Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 01:11:13 --> Language Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Loader Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 01:11:13 --> Helper loaded: user_helper
DEBUG - 2011-02-24 01:11:13 --> Helper loaded: url_helper
DEBUG - 2011-02-24 01:11:13 --> Helper loaded: array_helper
DEBUG - 2011-02-24 01:11:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 01:11:13 --> Database Driver Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Session Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Helper loaded: string_helper
DEBUG - 2011-02-24 01:11:13 --> Session routines successfully run
DEBUG - 2011-02-24 01:11:13 --> Controller Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> Model Class Initialized
DEBUG - 2011-02-24 01:11:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 01:11:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 01:11:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 01:11:13 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-24 01:11:13 --> Final output sent to browser
DEBUG - 2011-02-24 01:11:13 --> Total execution time: 0.0307
DEBUG - 2011-02-24 01:12:38 --> Config Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Hooks Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Utf8 Class Initialized
DEBUG - 2011-02-24 01:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 01:12:38 --> URI Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Router Class Initialized
DEBUG - 2011-02-24 01:12:38 --> No URI present. Default controller set.
DEBUG - 2011-02-24 01:12:38 --> Output Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Input Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 01:12:38 --> Language Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Loader Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 01:12:38 --> Helper loaded: user_helper
DEBUG - 2011-02-24 01:12:38 --> Helper loaded: url_helper
DEBUG - 2011-02-24 01:12:38 --> Helper loaded: array_helper
DEBUG - 2011-02-24 01:12:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 01:12:38 --> Database Driver Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Session Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Helper loaded: string_helper
DEBUG - 2011-02-24 01:12:38 --> Session routines successfully run
DEBUG - 2011-02-24 01:12:38 --> Controller Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> Model Class Initialized
DEBUG - 2011-02-24 01:12:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 01:12:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 01:12:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 01:12:38 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-24 01:12:38 --> Final output sent to browser
DEBUG - 2011-02-24 01:12:38 --> Total execution time: 0.0358
DEBUG - 2011-02-24 09:00:09 --> Config Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:00:09 --> URI Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Router Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Output Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Input Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:00:09 --> Language Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Loader Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:00:09 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:00:09 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:00:09 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:00:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:00:09 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Session Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:00:09 --> A session cookie was not found.
DEBUG - 2011-02-24 09:00:09 --> Session routines successfully run
DEBUG - 2011-02-24 09:00:09 --> Controller Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Model Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Model Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Model Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Model Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Model Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Model Class Initialized
DEBUG - 2011-02-24 09:00:09 --> Model Class Initialized
DEBUG - 2011-02-24 09:00:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:00:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:00:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:00:09 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-24 09:00:09 --> Final output sent to browser
DEBUG - 2011-02-24 09:00:09 --> Total execution time: 0.0288
DEBUG - 2011-02-24 09:01:15 --> Config Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:01:15 --> URI Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Router Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Output Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Input Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:01:15 --> Language Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Loader Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:01:15 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:01:15 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:01:15 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:01:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:01:15 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Session Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:01:15 --> Session routines successfully run
DEBUG - 2011-02-24 09:01:15 --> Controller Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Model Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Model Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Model Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Model Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Model Class Initialized
DEBUG - 2011-02-24 09:01:15 --> Model Class Initialized
DEBUG - 2011-02-24 09:01:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:01:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:01:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:01:15 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-24 09:01:15 --> Final output sent to browser
DEBUG - 2011-02-24 09:01:15 --> Total execution time: 0.0300
DEBUG - 2011-02-24 09:03:20 --> Config Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:03:20 --> URI Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Router Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Output Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Input Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:03:20 --> Language Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Loader Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:03:20 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:03:20 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:03:20 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:03:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:03:20 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Session Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:03:20 --> Session routines successfully run
DEBUG - 2011-02-24 09:03:20 --> Controller Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:03:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:03:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:03:20 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-24 09:03:20 --> Final output sent to browser
DEBUG - 2011-02-24 09:03:20 --> Total execution time: 0.0275
DEBUG - 2011-02-24 09:03:26 --> Config Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:03:26 --> URI Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Router Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Output Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Input Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:03:26 --> Language Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Loader Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:03:26 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:03:26 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:03:26 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:03:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:03:26 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Session Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:03:26 --> Session routines successfully run
DEBUG - 2011-02-24 09:03:26 --> Controller Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:26 --> Model Class Initialized
DEBUG - 2011-02-24 09:03:26 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-24 09:03:26 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-24 09:03:26 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-24 09:03:26 --> Final output sent to browser
DEBUG - 2011-02-24 09:03:26 --> Total execution time: 0.0268
DEBUG - 2011-02-24 09:11:21 --> Config Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:11:21 --> URI Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Router Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Output Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Input Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:11:21 --> Language Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Loader Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:11:21 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:11:21 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:11:21 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:11:21 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:11:21 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Session Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:11:21 --> Session routines successfully run
DEBUG - 2011-02-24 09:11:21 --> Controller Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-24 09:11:21 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:21 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:11:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:11:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:11:21 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-24 09:11:21 --> Final output sent to browser
DEBUG - 2011-02-24 09:11:21 --> Total execution time: 0.0256
DEBUG - 2011-02-24 09:11:24 --> Config Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:11:24 --> URI Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Router Class Initialized
DEBUG - 2011-02-24 09:11:24 --> No URI present. Default controller set.
DEBUG - 2011-02-24 09:11:24 --> Output Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Input Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:11:24 --> Language Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Loader Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:11:24 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:11:24 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:11:24 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:11:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:11:24 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Session Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:11:24 --> Session routines successfully run
DEBUG - 2011-02-24 09:11:24 --> Controller Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> Model Class Initialized
DEBUG - 2011-02-24 09:11:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:11:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:11:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:11:24 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-24 09:11:24 --> Final output sent to browser
DEBUG - 2011-02-24 09:11:24 --> Total execution time: 0.0347
DEBUG - 2011-02-24 09:44:02 --> Config Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:44:02 --> URI Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Router Class Initialized
DEBUG - 2011-02-24 09:44:02 --> No URI present. Default controller set.
DEBUG - 2011-02-24 09:44:02 --> Output Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Input Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:44:02 --> Language Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Loader Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:44:02 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:44:02 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:44:02 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:44:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:44:02 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Session Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:44:02 --> Session routines successfully run
DEBUG - 2011-02-24 09:44:02 --> Controller Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:44:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:44:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:44:02 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-24 09:44:02 --> Final output sent to browser
DEBUG - 2011-02-24 09:44:02 --> Total execution time: 0.0333
DEBUG - 2011-02-24 09:44:07 --> Config Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:44:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:44:07 --> URI Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Router Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Output Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Input Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:44:07 --> Language Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Loader Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:44:07 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:44:07 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:44:07 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:44:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:44:07 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Session Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:44:07 --> Session routines successfully run
DEBUG - 2011-02-24 09:44:07 --> Controller Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:07 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:44:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:44:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:44:07 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-24 09:44:07 --> Final output sent to browser
DEBUG - 2011-02-24 09:44:07 --> Total execution time: 0.0288
DEBUG - 2011-02-24 09:44:43 --> Config Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:44:43 --> URI Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Router Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Output Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Input Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:44:43 --> Language Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Loader Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:44:43 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:44:43 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:44:43 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:44:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:44:43 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Session Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:44:43 --> Session routines successfully run
DEBUG - 2011-02-24 09:44:43 --> Controller Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:43 --> Model Class Initialized
DEBUG - 2011-02-24 09:44:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:44:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:44:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:44:43 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-24 09:44:43 --> Final output sent to browser
DEBUG - 2011-02-24 09:44:43 --> Total execution time: 0.0243
DEBUG - 2011-02-24 09:47:44 --> Config Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Hooks Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Utf8 Class Initialized
DEBUG - 2011-02-24 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 09:47:44 --> URI Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Router Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Output Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Input Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 09:47:44 --> Language Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Loader Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 09:47:44 --> Helper loaded: user_helper
DEBUG - 2011-02-24 09:47:44 --> Helper loaded: url_helper
DEBUG - 2011-02-24 09:47:44 --> Helper loaded: array_helper
DEBUG - 2011-02-24 09:47:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 09:47:44 --> Database Driver Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Session Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Helper loaded: string_helper
DEBUG - 2011-02-24 09:47:44 --> Session routines successfully run
DEBUG - 2011-02-24 09:47:44 --> Controller Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-24 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-24 09:47:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 09:47:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 09:47:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 09:47:44 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-24 09:47:44 --> Final output sent to browser
DEBUG - 2011-02-24 09:47:44 --> Total execution time: 0.0241
DEBUG - 2011-02-24 23:30:38 --> Config Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Hooks Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Utf8 Class Initialized
DEBUG - 2011-02-24 23:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-24 23:30:38 --> URI Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Router Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Output Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Input Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-24 23:30:38 --> Language Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Loader Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-24 23:30:38 --> Helper loaded: user_helper
DEBUG - 2011-02-24 23:30:38 --> Helper loaded: url_helper
DEBUG - 2011-02-24 23:30:38 --> Helper loaded: array_helper
DEBUG - 2011-02-24 23:30:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-24 23:30:38 --> Database Driver Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Session Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Helper loaded: string_helper
DEBUG - 2011-02-24 23:30:38 --> A session cookie was not found.
DEBUG - 2011-02-24 23:30:38 --> Session routines successfully run
DEBUG - 2011-02-24 23:30:38 --> Controller Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Model Class Initialized
DEBUG - 2011-02-24 23:30:38 --> Model Class Initialized
DEBUG - 2011-02-24 23:30:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-24 23:30:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-24 23:30:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-24 23:30:38 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-24 23:30:38 --> Final output sent to browser
DEBUG - 2011-02-24 23:30:38 --> Total execution time: 0.0272
