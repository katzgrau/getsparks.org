<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-23 22:55:56 --> Config Class Initialized
DEBUG - 2011-03-23 22:55:56 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:55:56 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:55:56 --> URI Class Initialized
DEBUG - 2011-03-23 22:55:56 --> Router Class Initialized
ERROR - 2011-03-23 22:55:56 --> 404 Page Not Found --> api/1.0
DEBUG - 2011-03-23 22:56:09 --> Config Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:56:09 --> URI Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Router Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Output Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Input Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:56:09 --> Language Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Loader Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:56:09 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:56:09 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:56:09 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:56:09 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:56:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:56:09 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Session Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:56:09 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Session routines successfully run
DEBUG - 2011-03-23 22:56:09 --> Controller Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Model Class Initialized
ERROR - 2011-03-23 22:56:09 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-23 22:56:09 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:09 --> Model Class Initialized
ERROR - 2011-03-23 22:56:09 --> Severity: Notice  --> Undefined variable: CI /Users/katzgrau/Dev/ci-sparks-repo/application/models/spark.php 206
ERROR - 2011-03-23 22:56:09 --> Severity: Notice  --> Trying to get property of non-object /Users/katzgrau/Dev/ci-sparks-repo/application/models/spark.php 206
DEBUG - 2011-03-23 22:56:23 --> Config Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:56:23 --> URI Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Router Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Output Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Input Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:56:23 --> Language Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Loader Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:56:23 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:56:23 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:56:23 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:56:23 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:56:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:56:23 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Session Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:56:23 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Session routines successfully run
DEBUG - 2011-03-23 22:56:23 --> Controller Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Model Class Initialized
ERROR - 2011-03-23 22:56:23 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-23 22:56:23 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:23 --> Final output sent to browser
DEBUG - 2011-03-23 22:56:23 --> Total execution time: 0.0346
DEBUG - 2011-03-23 22:56:42 --> Config Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:56:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:56:42 --> URI Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Router Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Output Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Input Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:56:42 --> Language Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Loader Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:56:42 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:56:42 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:56:42 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:56:42 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:56:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:56:42 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Session Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:56:42 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:56:42 --> Session routines successfully run
DEBUG - 2011-03-23 22:56:42 --> Controller Class Initialized
ERROR - 2011-03-23 22:56:42 --> 404 Page Not Found --> packages/spark-sdk
DEBUG - 2011-03-23 22:56:54 --> Config Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:56:54 --> URI Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Router Class Initialized
DEBUG - 2011-03-23 22:56:54 --> No URI present. Default controller set.
DEBUG - 2011-03-23 22:56:54 --> Output Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Input Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:56:54 --> Language Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Loader Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:56:54 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Session Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:56:54 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Session routines successfully run
DEBUG - 2011-03-23 22:56:54 --> Controller Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: file_helper
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: directory_helper
DEBUG - 2011-03-23 22:56:54 --> Helper loaded: assets_helper
DEBUG - 2011-03-23 22:56:54 --> CSSMin library initialized.
DEBUG - 2011-03-23 22:56:54 --> JSMin library initialized.
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
ERROR - 2011-03-23 22:56:54 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:54 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-23 22:56:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-23 22:56:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-23 22:56:54 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-23 22:56:54 --> Final output sent to browser
DEBUG - 2011-03-23 22:56:54 --> Total execution time: 0.0509
DEBUG - 2011-03-23 22:56:56 --> Config Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:56:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:56:56 --> URI Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Router Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Output Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Input Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:56:56 --> Language Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Loader Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:56:56 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:56:56 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:56:56 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:56:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:56:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:56:56 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Session Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:56:56 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:56:56 --> Session routines successfully run
DEBUG - 2011-03-23 22:56:56 --> Controller Class Initialized
DEBUG - 2011-03-23 22:56:56 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-23 22:56:56 --> Final output sent to browser
DEBUG - 2011-03-23 22:56:56 --> Total execution time: 0.0260
DEBUG - 2011-03-23 22:56:57 --> Config Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:56:57 --> URI Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Router Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Output Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Input Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:56:57 --> Language Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Loader Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:56:57 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Session Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:56:57 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Session routines successfully run
DEBUG - 2011-03-23 22:56:57 --> Controller Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
ERROR - 2011-03-23 22:56:57 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: file_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: directory_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: assets_helper
DEBUG - 2011-03-23 22:56:57 --> CSSMin library initialized.
DEBUG - 2011-03-23 22:56:57 --> JSMin library initialized.
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-23 22:56:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: rating_helper
DEBUG - 2011-03-23 22:56:57 --> Model Class Initialized
DEBUG - 2011-03-23 22:56:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-23 22:56:57 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-23 22:56:57 --> Final output sent to browser
DEBUG - 2011-03-23 22:56:57 --> Total execution time: 0.0744
DEBUG - 2011-03-23 22:56:57 --> Config Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:56:57 --> URI Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Router Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Output Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Input Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:56:57 --> Language Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Loader Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:56:57 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Session Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:56:57 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:56:57 --> Session routines successfully run
DEBUG - 2011-03-23 22:56:57 --> Controller Class Initialized
DEBUG - 2011-03-23 22:56:57 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-23 22:56:57 --> Final output sent to browser
DEBUG - 2011-03-23 22:56:57 --> Total execution time: 0.0241
DEBUG - 2011-03-23 22:57:01 --> Config Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:57:01 --> URI Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Router Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Output Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Input Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:57:01 --> Language Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Loader Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:57:01 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Session Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:57:01 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Session routines successfully run
DEBUG - 2011-03-23 22:57:01 --> Controller Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: file_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: directory_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: assets_helper
DEBUG - 2011-03-23 22:57:01 --> CSSMin library initialized.
DEBUG - 2011-03-23 22:57:01 --> JSMin library initialized.
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-23 22:57:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-23 22:57:01 --> User Agent Class Initialized
DEBUG - 2011-03-23 22:57:01 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-23 22:57:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-23 22:57:01 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-23 22:57:01 --> Final output sent to browser
DEBUG - 2011-03-23 22:57:01 --> Total execution time: 0.0500
DEBUG - 2011-03-23 22:57:01 --> Config Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:57:01 --> URI Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Router Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Output Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Input Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:57:01 --> Language Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Loader Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:57:01 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Session Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:57:01 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:57:01 --> Session routines successfully run
DEBUG - 2011-03-23 22:57:01 --> Controller Class Initialized
DEBUG - 2011-03-23 22:57:01 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-23 22:57:01 --> Final output sent to browser
DEBUG - 2011-03-23 22:57:01 --> Total execution time: 0.0221
DEBUG - 2011-03-23 22:57:11 --> Config Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:57:11 --> URI Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Router Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Output Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Input Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:57:11 --> Language Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Loader Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:57:11 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:57:11 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:57:11 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:57:11 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:57:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:57:11 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Session Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:57:11 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Session routines successfully run
DEBUG - 2011-03-23 22:57:11 --> Controller Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Model Class Initialized
DEBUG - 2011-03-23 22:57:11 --> Final output sent to browser
DEBUG - 2011-03-23 22:57:11 --> Total execution time: 0.0342
DEBUG - 2011-03-23 22:59:59 --> Config Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Hooks Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Utf8 Class Initialized
DEBUG - 2011-03-23 22:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 22:59:59 --> URI Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Router Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Output Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Input Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 22:59:59 --> Language Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Loader Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 22:59:59 --> Helper loaded: user_helper
DEBUG - 2011-03-23 22:59:59 --> Helper loaded: url_helper
DEBUG - 2011-03-23 22:59:59 --> Helper loaded: array_helper
DEBUG - 2011-03-23 22:59:59 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 22:59:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 22:59:59 --> Database Driver Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Session Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Helper loaded: string_helper
DEBUG - 2011-03-23 22:59:59 --> Encrypt Class Initialized
DEBUG - 2011-03-23 22:59:59 --> Session routines successfully run
DEBUG - 2011-03-23 22:59:59 --> Controller Class Initialized
DEBUG - 2011-03-23 22:59:59 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-23 22:59:59 --> Final output sent to browser
DEBUG - 2011-03-23 22:59:59 --> Total execution time: 0.0244
DEBUG - 2011-03-23 23:00:06 --> Config Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Hooks Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Utf8 Class Initialized
DEBUG - 2011-03-23 23:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 23:00:06 --> URI Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Router Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Output Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Input Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 23:00:06 --> Language Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Loader Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: user_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: url_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: array_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 23:00:06 --> Database Driver Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Session Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: string_helper
DEBUG - 2011-03-23 23:00:06 --> Encrypt Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Session routines successfully run
DEBUG - 2011-03-23 23:00:06 --> Controller Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
ERROR - 2011-03-23 23:00:06 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: file_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: directory_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: assets_helper
DEBUG - 2011-03-23 23:00:06 --> CSSMin library initialized.
DEBUG - 2011-03-23 23:00:06 --> JSMin library initialized.
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-23 23:00:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-23 23:00:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-23 23:00:06 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-03-23 23:00:06 --> Final output sent to browser
DEBUG - 2011-03-23 23:00:06 --> Total execution time: 0.0463
DEBUG - 2011-03-23 23:00:06 --> Config Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Hooks Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Utf8 Class Initialized
DEBUG - 2011-03-23 23:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 23:00:06 --> URI Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Router Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Output Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Input Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 23:00:06 --> Language Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Loader Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: user_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: url_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: array_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 23:00:06 --> Database Driver Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Session Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Helper loaded: string_helper
DEBUG - 2011-03-23 23:00:06 --> Encrypt Class Initialized
DEBUG - 2011-03-23 23:00:06 --> Session routines successfully run
DEBUG - 2011-03-23 23:00:06 --> Controller Class Initialized
DEBUG - 2011-03-23 23:00:06 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-23 23:00:06 --> Final output sent to browser
DEBUG - 2011-03-23 23:00:06 --> Total execution time: 0.0238
DEBUG - 2011-03-23 23:00:10 --> Config Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Hooks Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Utf8 Class Initialized
DEBUG - 2011-03-23 23:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 23:00:10 --> URI Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Router Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Output Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Input Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 23:00:10 --> Language Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Loader Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: user_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: url_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: array_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 23:00:10 --> Database Driver Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Session Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: string_helper
DEBUG - 2011-03-23 23:00:10 --> Encrypt Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Session routines successfully run
DEBUG - 2011-03-23 23:00:10 --> Controller Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: file_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: directory_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: assets_helper
DEBUG - 2011-03-23 23:00:10 --> CSSMin library initialized.
DEBUG - 2011-03-23 23:00:10 --> JSMin library initialized.
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-23 23:00:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-23 23:00:10 --> User Agent Class Initialized
DEBUG - 2011-03-23 23:00:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-03-23 23:00:10 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-03-23 23:00:10 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-23 23:00:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-23 23:00:10 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-23 23:00:10 --> Final output sent to browser
DEBUG - 2011-03-23 23:00:10 --> Total execution time: 0.0505
DEBUG - 2011-03-23 23:00:10 --> Config Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Hooks Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Utf8 Class Initialized
DEBUG - 2011-03-23 23:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 23:00:10 --> URI Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Router Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Output Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Input Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 23:00:10 --> Language Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Loader Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: user_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: url_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: array_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 23:00:10 --> Database Driver Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Session Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Helper loaded: string_helper
DEBUG - 2011-03-23 23:00:10 --> Encrypt Class Initialized
DEBUG - 2011-03-23 23:00:10 --> Session routines successfully run
DEBUG - 2011-03-23 23:00:10 --> Controller Class Initialized
DEBUG - 2011-03-23 23:00:10 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-23 23:00:10 --> Final output sent to browser
DEBUG - 2011-03-23 23:00:10 --> Total execution time: 0.0222
DEBUG - 2011-03-23 23:00:22 --> Config Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Hooks Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Utf8 Class Initialized
DEBUG - 2011-03-23 23:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 23:00:22 --> URI Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Router Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Output Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Input Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 23:00:22 --> Language Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Loader Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 23:00:22 --> Helper loaded: user_helper
DEBUG - 2011-03-23 23:00:22 --> Helper loaded: url_helper
DEBUG - 2011-03-23 23:00:22 --> Helper loaded: array_helper
DEBUG - 2011-03-23 23:00:22 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 23:00:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 23:00:22 --> Database Driver Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Session Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Helper loaded: string_helper
DEBUG - 2011-03-23 23:00:22 --> Encrypt Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Session routines successfully run
DEBUG - 2011-03-23 23:00:22 --> Controller Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Model Class Initialized
ERROR - 2011-03-23 23:00:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-23 23:00:22 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Model Class Initialized
DEBUG - 2011-03-23 23:00:22 --> Final output sent to browser
DEBUG - 2011-03-23 23:00:22 --> Total execution time: 0.0404
DEBUG - 2011-03-23 23:01:23 --> Config Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Hooks Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Utf8 Class Initialized
DEBUG - 2011-03-23 23:01:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-23 23:01:23 --> URI Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Router Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Output Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Input Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-23 23:01:23 --> Language Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Loader Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-23 23:01:23 --> Helper loaded: user_helper
DEBUG - 2011-03-23 23:01:23 --> Helper loaded: url_helper
DEBUG - 2011-03-23 23:01:23 --> Helper loaded: array_helper
DEBUG - 2011-03-23 23:01:23 --> Helper loaded: utility_helper
DEBUG - 2011-03-23 23:01:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-23 23:01:23 --> Database Driver Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Session Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Helper loaded: string_helper
DEBUG - 2011-03-23 23:01:23 --> Encrypt Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Session routines successfully run
DEBUG - 2011-03-23 23:01:23 --> Controller Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Model Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Model Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Model Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Model Class Initialized
ERROR - 2011-03-23 23:01:23 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-23 23:01:23 --> Model Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Model Class Initialized
DEBUG - 2011-03-23 23:01:23 --> Final output sent to browser
DEBUG - 2011-03-23 23:01:23 --> Total execution time: 0.0375
