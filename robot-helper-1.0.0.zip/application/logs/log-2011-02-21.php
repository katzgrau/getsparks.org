<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-21 11:37:25 --> Config Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:37:25 --> URI Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Router Class Initialized
DEBUG - 2011-02-21 11:37:25 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:37:25 --> Output Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Input Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:37:25 --> Language Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Loader Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:37:25 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:37:25 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:37:25 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:37:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:37:25 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Session Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:37:25 --> Session routines successfully run
DEBUG - 2011-02-21 11:37:25 --> Controller Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:25 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:37:25 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:37:25 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:37:25 --> Final output sent to browser
DEBUG - 2011-02-21 11:37:25 --> Total execution time: 0.0392
DEBUG - 2011-02-21 11:37:47 --> Config Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:37:47 --> URI Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Router Class Initialized
DEBUG - 2011-02-21 11:37:47 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:37:47 --> Output Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Input Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:37:47 --> Language Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Loader Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:37:47 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:37:47 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:37:47 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:37:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:37:47 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Session Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:37:47 --> Session routines successfully run
DEBUG - 2011-02-21 11:37:47 --> Controller Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> Model Class Initialized
DEBUG - 2011-02-21 11:37:47 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:37:47 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:37:47 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:37:47 --> Final output sent to browser
DEBUG - 2011-02-21 11:37:47 --> Total execution time: 0.0380
DEBUG - 2011-02-21 11:38:04 --> Config Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:38:04 --> URI Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Router Class Initialized
DEBUG - 2011-02-21 11:38:04 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:38:04 --> Output Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Input Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:38:04 --> Language Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Loader Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:38:04 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:38:04 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:38:04 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:38:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:38:04 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Session Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:38:04 --> Session routines successfully run
DEBUG - 2011-02-21 11:38:04 --> Controller Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:04 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:38:04 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:38:04 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:38:04 --> Final output sent to browser
DEBUG - 2011-02-21 11:38:04 --> Total execution time: 0.0442
DEBUG - 2011-02-21 11:38:05 --> Config Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:38:05 --> URI Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Router Class Initialized
DEBUG - 2011-02-21 11:38:05 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:38:05 --> Output Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Input Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:38:05 --> Language Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Loader Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:38:05 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:38:05 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:38:05 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:38:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:38:05 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Session Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:38:05 --> Session routines successfully run
DEBUG - 2011-02-21 11:38:05 --> Controller Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:05 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:38:05 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:38:05 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:38:05 --> Final output sent to browser
DEBUG - 2011-02-21 11:38:05 --> Total execution time: 0.0393
DEBUG - 2011-02-21 11:38:06 --> Config Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:38:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:38:06 --> URI Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Router Class Initialized
DEBUG - 2011-02-21 11:38:06 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:38:06 --> Output Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Input Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:38:06 --> Language Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Loader Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:38:06 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:38:06 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:38:06 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:38:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:38:06 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Session Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:38:06 --> Session routines successfully run
DEBUG - 2011-02-21 11:38:06 --> Controller Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:06 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:38:06 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:38:06 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:38:06 --> Final output sent to browser
DEBUG - 2011-02-21 11:38:06 --> Total execution time: 0.0621
DEBUG - 2011-02-21 11:38:37 --> Config Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:38:37 --> URI Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Router Class Initialized
DEBUG - 2011-02-21 11:38:37 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:38:37 --> Output Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Input Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:38:37 --> Language Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Loader Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:38:37 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:38:37 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:38:37 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:38:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:38:37 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Session Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:38:37 --> Session routines successfully run
DEBUG - 2011-02-21 11:38:37 --> Controller Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> Model Class Initialized
DEBUG - 2011-02-21 11:38:37 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:38:37 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:38:37 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:38:37 --> Cache file written: application/cache/52c4fa29145d5d48615fa3599fa99231
DEBUG - 2011-02-21 11:38:37 --> Final output sent to browser
DEBUG - 2011-02-21 11:38:37 --> Total execution time: 0.0458
DEBUG - 2011-02-21 11:38:38 --> Config Class Initialized
DEBUG - 2011-02-21 11:38:38 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:38:38 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:38:38 --> URI Class Initialized
DEBUG - 2011-02-21 11:38:38 --> Router Class Initialized
DEBUG - 2011-02-21 11:38:38 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:38:38 --> Output Class Initialized
DEBUG - 2011-02-21 11:38:38 --> Final output sent to browser
DEBUG - 2011-02-21 11:38:38 --> Total execution time: 0.0082
DEBUG - 2011-02-21 11:38:38 --> Cache file is current. Sending it to browser.
DEBUG - 2011-02-21 11:39:29 --> Config Class Initialized
DEBUG - 2011-02-21 11:39:29 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:39:29 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:39:29 --> URI Class Initialized
DEBUG - 2011-02-21 11:39:29 --> Router Class Initialized
DEBUG - 2011-02-21 11:39:29 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:39:29 --> Output Class Initialized
DEBUG - 2011-02-21 11:39:29 --> Final output sent to browser
DEBUG - 2011-02-21 11:39:29 --> Total execution time: 0.0069
DEBUG - 2011-02-21 11:39:29 --> Cache file is current. Sending it to browser.
DEBUG - 2011-02-21 11:43:52 --> Config Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:43:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:43:52 --> URI Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Router Class Initialized
DEBUG - 2011-02-21 11:43:52 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:43:52 --> Output Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Cache file has expired. File deleted
DEBUG - 2011-02-21 11:43:52 --> Input Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:43:52 --> Language Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Loader Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:43:52 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:43:52 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:43:52 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:43:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:43:52 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Session Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:43:52 --> Session routines successfully run
DEBUG - 2011-02-21 11:43:52 --> Controller Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> Model Class Initialized
DEBUG - 2011-02-21 11:43:52 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:43:52 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:43:52 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:43:52 --> Final output sent to browser
DEBUG - 2011-02-21 11:43:52 --> Total execution time: 0.0408
DEBUG - 2011-02-21 11:56:22 --> Config Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:56:22 --> URI Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Router Class Initialized
DEBUG - 2011-02-21 11:56:22 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:56:22 --> Output Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Input Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:56:22 --> Language Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Loader Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:56:22 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:56:22 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:56:22 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:56:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:56:22 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Session Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:56:22 --> Session routines successfully run
DEBUG - 2011-02-21 11:56:22 --> Controller Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:22 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:56:22 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:56:22 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:56:22 --> Final output sent to browser
DEBUG - 2011-02-21 11:56:22 --> Total execution time: 0.0347
DEBUG - 2011-02-21 11:56:24 --> Config Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:56:24 --> URI Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Router Class Initialized
DEBUG - 2011-02-21 11:56:24 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:56:24 --> Output Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Input Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:56:24 --> Language Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Loader Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:56:24 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:56:24 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:56:24 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:56:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:56:24 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Session Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:56:24 --> Session routines successfully run
DEBUG - 2011-02-21 11:56:24 --> Controller Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:24 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:56:24 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:56:24 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:56:24 --> Final output sent to browser
DEBUG - 2011-02-21 11:56:24 --> Total execution time: 0.0396
DEBUG - 2011-02-21 11:56:25 --> Config Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Hooks Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Utf8 Class Initialized
DEBUG - 2011-02-21 11:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 11:56:25 --> URI Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Router Class Initialized
DEBUG - 2011-02-21 11:56:25 --> No URI present. Default controller set.
DEBUG - 2011-02-21 11:56:25 --> Output Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Input Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 11:56:25 --> Language Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Loader Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 11:56:25 --> Helper loaded: user_helper
DEBUG - 2011-02-21 11:56:25 --> Helper loaded: url_helper
DEBUG - 2011-02-21 11:56:25 --> Helper loaded: array_helper
DEBUG - 2011-02-21 11:56:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 11:56:25 --> Database Driver Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Session Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Helper loaded: string_helper
DEBUG - 2011-02-21 11:56:25 --> Session routines successfully run
DEBUG - 2011-02-21 11:56:25 --> Controller Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> Model Class Initialized
DEBUG - 2011-02-21 11:56:25 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 11:56:25 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 11:56:25 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 11:56:25 --> Final output sent to browser
DEBUG - 2011-02-21 11:56:25 --> Total execution time: 0.0392
DEBUG - 2011-02-21 23:49:13 --> Config Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Hooks Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Utf8 Class Initialized
DEBUG - 2011-02-21 23:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 23:49:13 --> URI Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Router Class Initialized
DEBUG - 2011-02-21 23:49:13 --> No URI present. Default controller set.
DEBUG - 2011-02-21 23:49:13 --> Output Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Input Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 23:49:13 --> Language Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Loader Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 23:49:13 --> Helper loaded: user_helper
DEBUG - 2011-02-21 23:49:13 --> Helper loaded: url_helper
DEBUG - 2011-02-21 23:49:13 --> Helper loaded: array_helper
DEBUG - 2011-02-21 23:49:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 23:49:13 --> Database Driver Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Session Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Helper loaded: string_helper
DEBUG - 2011-02-21 23:49:13 --> A session cookie was not found.
DEBUG - 2011-02-21 23:49:13 --> Session routines successfully run
DEBUG - 2011-02-21 23:49:13 --> Controller Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Helper loaded: gravatar_helper
ERROR - 2011-02-21 23:49:13 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:13 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 23:49:13 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 23:49:13 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-21 23:49:13 --> Final output sent to browser
DEBUG - 2011-02-21 23:49:13 --> Total execution time: 0.0367
DEBUG - 2011-02-21 23:49:13 --> Config Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Hooks Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Utf8 Class Initialized
DEBUG - 2011-02-21 23:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 23:49:13 --> URI Class Initialized
DEBUG - 2011-02-21 23:49:13 --> Router Class Initialized
ERROR - 2011-02-21 23:49:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 23:49:14 --> Config Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Hooks Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Utf8 Class Initialized
DEBUG - 2011-02-21 23:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 23:49:14 --> URI Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Router Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Output Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Input Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 23:49:14 --> Language Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Loader Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-21 23:49:14 --> Helper loaded: user_helper
DEBUG - 2011-02-21 23:49:14 --> Helper loaded: url_helper
DEBUG - 2011-02-21 23:49:14 --> Helper loaded: array_helper
DEBUG - 2011-02-21 23:49:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-21 23:49:14 --> Database Driver Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Session Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Helper loaded: string_helper
DEBUG - 2011-02-21 23:49:14 --> Session routines successfully run
DEBUG - 2011-02-21 23:49:14 --> Controller Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Model Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Model Class Initialized
ERROR - 2011-02-21 23:49:14 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-21 23:49:14 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-21 23:49:14 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-21 23:49:14 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-21 23:49:14 --> Final output sent to browser
DEBUG - 2011-02-21 23:49:14 --> Total execution time: 0.0265
DEBUG - 2011-02-21 23:49:14 --> Config Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Hooks Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Utf8 Class Initialized
DEBUG - 2011-02-21 23:49:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 23:49:14 --> URI Class Initialized
DEBUG - 2011-02-21 23:49:14 --> Router Class Initialized
ERROR - 2011-02-21 23:49:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 23:49:16 --> Config Class Initialized
DEBUG - 2011-02-21 23:49:16 --> Hooks Class Initialized
DEBUG - 2011-02-21 23:49:16 --> Utf8 Class Initialized
DEBUG - 2011-02-21 23:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 23:49:16 --> URI Class Initialized
DEBUG - 2011-02-21 23:49:16 --> Router Class Initialized
ERROR - 2011-02-21 23:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 23:49:16 --> Config Class Initialized
DEBUG - 2011-02-21 23:49:16 --> Hooks Class Initialized
DEBUG - 2011-02-21 23:49:16 --> Utf8 Class Initialized
DEBUG - 2011-02-21 23:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 23:49:16 --> URI Class Initialized
DEBUG - 2011-02-21 23:49:16 --> Router Class Initialized
ERROR - 2011-02-21 23:49:16 --> 404 Page Not Found --> favicon.ico
