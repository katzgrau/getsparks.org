<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-30 12:26:02 --> Config Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:26:02 --> URI Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Router Class Initialized
DEBUG - 2011-04-30 12:26:02 --> No URI present. Default controller set.
DEBUG - 2011-04-30 12:26:02 --> Output Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Input Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:26:02 --> Language Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Loader Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:26:02 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Session Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:26:02 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:26:02 --> A session cookie was not found.
DEBUG - 2011-04-30 12:26:02 --> Session routines successfully run
DEBUG - 2011-04-30 12:26:02 --> Controller Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:26:02 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:26:02 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:26:02 --> JSMin library initialized.
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:26:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:26:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:26:02 --> File loaded: application/views/home/index.php
DEBUG - 2011-04-30 12:26:02 --> Final output sent to browser
DEBUG - 2011-04-30 12:26:02 --> Total execution time: 0.1048
DEBUG - 2011-04-30 12:26:04 --> Config Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:26:04 --> URI Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Router Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Output Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Input Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:26:04 --> Language Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Loader Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:26:04 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:26:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:26:04 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:26:04 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:26:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:26:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Session Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:26:04 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:26:04 --> Session routines successfully run
DEBUG - 2011-04-30 12:26:04 --> Controller Class Initialized
DEBUG - 2011-04-30 12:26:04 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:26:04 --> Final output sent to browser
DEBUG - 2011-04-30 12:26:04 --> Total execution time: 0.0267
DEBUG - 2011-04-30 12:26:07 --> Config Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:26:07 --> URI Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Router Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Output Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Input Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:26:07 --> Language Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Loader Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:26:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Session Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:26:07 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Session routines successfully run
DEBUG - 2011-04-30 12:26:07 --> Controller Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:26:07 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:26:07 --> JSMin library initialized.
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Model Class Initialized
DEBUG - 2011-04-30 12:26:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:26:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:26:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:26:07 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-04-30 12:26:07 --> Final output sent to browser
DEBUG - 2011-04-30 12:26:07 --> Total execution time: 0.0465
DEBUG - 2011-04-30 12:26:07 --> Config Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:26:07 --> URI Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Router Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Output Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Input Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:26:07 --> Language Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Loader Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:26:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Session Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:26:07 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:26:07 --> Session routines successfully run
DEBUG - 2011-04-30 12:26:07 --> Controller Class Initialized
DEBUG - 2011-04-30 12:26:07 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:26:07 --> Final output sent to browser
DEBUG - 2011-04-30 12:26:07 --> Total execution time: 0.0253
DEBUG - 2011-04-30 12:28:49 --> Config Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:28:49 --> URI Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Router Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Output Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Input Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:28:49 --> Language Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Loader Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:28:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Session Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:28:49 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Session routines successfully run
DEBUG - 2011-04-30 12:28:49 --> Controller Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:28:49 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:28:49 --> JSMin library initialized.
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:28:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:28:49 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 12:28:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:28:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:28:49 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 12:28:49 --> Final output sent to browser
DEBUG - 2011-04-30 12:28:49 --> Total execution time: 0.0958
DEBUG - 2011-04-30 12:28:50 --> Config Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:28:50 --> URI Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Router Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Output Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Input Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:28:50 --> Language Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Loader Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:28:50 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:28:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:28:50 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:28:50 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:28:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:28:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Session Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:28:50 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:28:50 --> Session routines successfully run
DEBUG - 2011-04-30 12:28:50 --> Controller Class Initialized
DEBUG - 2011-04-30 12:28:50 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:28:50 --> Final output sent to browser
DEBUG - 2011-04-30 12:28:50 --> Total execution time: 0.0243
DEBUG - 2011-04-30 12:30:09 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:09 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:09 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:09 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:09 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:30:09 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:30:09 --> JSMin library initialized.
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:30:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 12:30:09 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:30:09 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 12:30:09 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:09 --> Total execution time: 0.0747
DEBUG - 2011-04-30 12:30:09 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:09 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:09 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:09 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:09 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:09 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:09 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:30:09 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:09 --> Total execution time: 0.0284
DEBUG - 2011-04-30 12:30:49 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:49 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:49 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:49 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:49 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:30:49 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:30:49 --> JSMin library initialized.
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:30:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 12:30:49 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:30:49 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 12:30:49 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:49 --> Total execution time: 0.0762
DEBUG - 2011-04-30 12:30:49 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:49 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:49 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:49 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:49 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:49 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:49 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:30:49 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:49 --> Total execution time: 0.0278
DEBUG - 2011-04-30 12:30:50 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:50 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:50 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:50 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:50 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:30:50 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:30:50 --> JSMin library initialized.
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:30:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:30:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:30:50 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-04-30 12:30:50 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:50 --> Total execution time: 0.0384
DEBUG - 2011-04-30 12:30:50 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:50 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:50 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:50 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:50 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:50 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:50 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:30:50 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:50 --> Total execution time: 0.0207
DEBUG - 2011-04-30 12:30:51 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:51 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:51 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:51 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:51 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:30:51 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:30:51 --> JSMin library initialized.
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:30:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:30:51 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 12:30:51 --> Model Class Initialized
DEBUG - 2011-04-30 12:30:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:30:51 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 12:30:51 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:51 --> Total execution time: 0.0664
DEBUG - 2011-04-30 12:30:52 --> Config Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:30:52 --> URI Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Router Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Output Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Input Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:30:52 --> Language Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Loader Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:30:52 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:30:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:30:52 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:30:52 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:30:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:30:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Session Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:30:52 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:30:52 --> Session routines successfully run
DEBUG - 2011-04-30 12:30:52 --> Controller Class Initialized
DEBUG - 2011-04-30 12:30:52 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:30:52 --> Final output sent to browser
DEBUG - 2011-04-30 12:30:52 --> Total execution time: 0.0274
DEBUG - 2011-04-30 12:35:52 --> Config Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:35:52 --> URI Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Router Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Output Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Input Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:35:52 --> Language Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Loader Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:35:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Session Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:35:52 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Session routines successfully run
DEBUG - 2011-04-30 12:35:52 --> Controller Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: file_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 12:35:52 --> CSSMin library initialized.
DEBUG - 2011-04-30 12:35:52 --> JSMin library initialized.
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 12:35:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 12:35:52 --> Model Class Initialized
DEBUG - 2011-04-30 12:35:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 12:35:52 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 12:35:52 --> Final output sent to browser
DEBUG - 2011-04-30 12:35:52 --> Total execution time: 0.0718
DEBUG - 2011-04-30 12:35:52 --> Config Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 12:35:52 --> URI Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Router Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Output Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Input Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 12:35:52 --> Language Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Loader Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: user_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: array_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 12:35:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Session Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Helper loaded: string_helper
DEBUG - 2011-04-30 12:35:52 --> Encrypt Class Initialized
DEBUG - 2011-04-30 12:35:52 --> Session routines successfully run
DEBUG - 2011-04-30 12:35:52 --> Controller Class Initialized
DEBUG - 2011-04-30 12:35:52 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 12:35:52 --> Final output sent to browser
DEBUG - 2011-04-30 12:35:52 --> Total execution time: 0.0272
DEBUG - 2011-04-30 13:35:44 --> Config Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:35:44 --> URI Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Router Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Output Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Input Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:35:44 --> Language Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Loader Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:35:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Session Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:35:44 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Session routines successfully run
DEBUG - 2011-04-30 13:35:44 --> Controller Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: file_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 13:35:44 --> CSSMin library initialized.
DEBUG - 2011-04-30 13:35:44 --> JSMin library initialized.
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 13:35:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 13:35:44 --> User Agent Class Initialized
DEBUG - 2011-04-30 13:35:44 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-04-30 13:35:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 13:35:44 --> File loaded: application/views/packages/show.php
DEBUG - 2011-04-30 13:35:44 --> Final output sent to browser
DEBUG - 2011-04-30 13:35:44 --> Total execution time: 0.0563
DEBUG - 2011-04-30 13:35:44 --> Config Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:35:44 --> URI Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Router Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Output Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Input Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:35:44 --> Language Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Loader Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:35:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Session Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:35:44 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:35:44 --> Session routines successfully run
DEBUG - 2011-04-30 13:35:44 --> Controller Class Initialized
DEBUG - 2011-04-30 13:35:44 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 13:35:44 --> Final output sent to browser
DEBUG - 2011-04-30 13:35:44 --> Total execution time: 0.0216
DEBUG - 2011-04-30 13:35:53 --> Config Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:35:53 --> URI Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Router Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Output Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Input Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:35:53 --> Language Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Loader Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:35:53 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:35:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:35:53 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:35:53 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:35:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:35:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Session Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:35:53 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Session routines successfully run
DEBUG - 2011-04-30 13:35:53 --> Controller Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Model Class Initialized
DEBUG - 2011-04-30 13:35:53 --> Final output sent to browser
DEBUG - 2011-04-30 13:35:53 --> Total execution time: 0.0378
DEBUG - 2011-04-30 13:37:40 --> Config Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:37:40 --> URI Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Router Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Output Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Input Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:37:40 --> Language Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Loader Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:37:40 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:37:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:37:40 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:37:40 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:37:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:37:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Session Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:37:40 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Session routines successfully run
DEBUG - 2011-04-30 13:37:40 --> Controller Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Model Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Model Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Model Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Model Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Model Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Model Class Initialized
DEBUG - 2011-04-30 13:37:40 --> Final output sent to browser
DEBUG - 2011-04-30 13:37:40 --> Total execution time: 0.0378
DEBUG - 2011-04-30 13:47:51 --> Config Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:47:51 --> URI Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Router Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Output Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Input Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:47:51 --> Language Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Loader Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:47:51 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:47:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:47:51 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:47:51 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:47:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:47:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Session Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:47:51 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Session routines successfully run
DEBUG - 2011-04-30 13:47:51 --> Controller Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:51 --> Final output sent to browser
DEBUG - 2011-04-30 13:47:51 --> Total execution time: 0.0327
DEBUG - 2011-04-30 13:47:52 --> Config Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:47:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:47:52 --> URI Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Router Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Output Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Input Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:47:52 --> Language Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Loader Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:47:52 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:47:52 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:47:52 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:47:52 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:47:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:47:52 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Session Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:47:52 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Session routines successfully run
DEBUG - 2011-04-30 13:47:52 --> Controller Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Model Class Initialized
DEBUG - 2011-04-30 13:47:52 --> Final output sent to browser
DEBUG - 2011-04-30 13:47:52 --> Total execution time: 0.0340
DEBUG - 2011-04-30 13:48:03 --> Config Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:48:03 --> URI Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Router Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Output Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Input Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:48:03 --> Language Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Loader Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:48:03 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:48:03 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:48:03 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:48:03 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:48:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:48:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Session Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:48:03 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Session routines successfully run
DEBUG - 2011-04-30 13:48:03 --> Controller Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:03 --> Final output sent to browser
DEBUG - 2011-04-30 13:48:03 --> Total execution time: 0.0368
DEBUG - 2011-04-30 13:48:38 --> Config Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Hooks Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Utf8 Class Initialized
DEBUG - 2011-04-30 13:48:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 13:48:38 --> URI Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Router Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Output Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Input Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 13:48:38 --> Language Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Loader Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 13:48:38 --> Helper loaded: user_helper
DEBUG - 2011-04-30 13:48:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 13:48:38 --> Helper loaded: array_helper
DEBUG - 2011-04-30 13:48:38 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 13:48:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 13:48:38 --> Database Driver Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Session Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Helper loaded: string_helper
DEBUG - 2011-04-30 13:48:38 --> Encrypt Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Session routines successfully run
DEBUG - 2011-04-30 13:48:38 --> Controller Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Model Class Initialized
DEBUG - 2011-04-30 13:48:38 --> Final output sent to browser
DEBUG - 2011-04-30 13:48:38 --> Total execution time: 0.0385
DEBUG - 2011-04-30 14:14:40 --> Config Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:14:40 --> URI Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Router Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Output Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Input Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:14:40 --> Language Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Loader Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:14:40 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:14:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:14:40 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:14:40 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:14:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:14:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Session Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:14:40 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Session routines successfully run
DEBUG - 2011-04-30 14:14:40 --> Controller Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:40 --> Final output sent to browser
DEBUG - 2011-04-30 14:14:40 --> Total execution time: 0.0351
DEBUG - 2011-04-30 14:14:44 --> Config Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:14:44 --> URI Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Router Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Output Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Input Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:14:44 --> Language Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Loader Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:14:44 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:14:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:14:44 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:14:44 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:14:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:14:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Session Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:14:44 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Session routines successfully run
DEBUG - 2011-04-30 14:14:44 --> Controller Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:44 --> Final output sent to browser
DEBUG - 2011-04-30 14:14:44 --> Total execution time: 0.0334
DEBUG - 2011-04-30 14:14:45 --> Config Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:14:45 --> URI Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Router Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Output Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Input Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:14:45 --> Language Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Loader Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:14:45 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:14:45 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:14:45 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:14:45 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:14:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:14:45 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Session Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:14:45 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Session routines successfully run
DEBUG - 2011-04-30 14:14:45 --> Controller Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Model Class Initialized
DEBUG - 2011-04-30 14:14:45 --> Final output sent to browser
DEBUG - 2011-04-30 14:14:45 --> Total execution time: 0.0325
DEBUG - 2011-04-30 14:15:08 --> Config Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:15:08 --> URI Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Router Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Output Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Input Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:15:08 --> Language Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Loader Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:15:08 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:15:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:15:08 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:15:08 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:15:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:15:08 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Session Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:15:08 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:15:08 --> A session cookie was not found.
DEBUG - 2011-04-30 14:15:08 --> Session routines successfully run
DEBUG - 2011-04-30 14:15:08 --> Controller Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Model Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Model Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Model Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Model Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Model Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Model Class Initialized
DEBUG - 2011-04-30 14:15:08 --> Final output sent to browser
DEBUG - 2011-04-30 14:15:08 --> Total execution time: 0.0316
DEBUG - 2011-04-30 14:17:21 --> Config Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:17:21 --> URI Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Router Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Output Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Input Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:17:21 --> Language Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Loader Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:17:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Session Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:17:21 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Session routines successfully run
DEBUG - 2011-04-30 14:17:21 --> Controller Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
ERROR - 2011-04-30 14:17:21 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: file_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 14:17:21 --> CSSMin library initialized.
DEBUG - 2011-04-30 14:17:21 --> JSMin library initialized.
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Model Class Initialized
DEBUG - 2011-04-30 14:17:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 14:17:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 14:17:21 --> User Agent Class Initialized
DEBUG - 2011-04-30 14:17:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-04-30 14:17:21 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-04-30 14:17:21 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-04-30 14:17:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 14:17:21 --> File loaded: application/views/packages/show.php
DEBUG - 2011-04-30 14:17:21 --> Final output sent to browser
DEBUG - 2011-04-30 14:17:21 --> Total execution time: 0.0555
DEBUG - 2011-04-30 14:17:21 --> Config Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:17:21 --> URI Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Router Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Output Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Input Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:17:21 --> Language Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Loader Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:17:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Session Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:17:21 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:17:21 --> Session routines successfully run
DEBUG - 2011-04-30 14:17:21 --> Controller Class Initialized
DEBUG - 2011-04-30 14:17:21 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 14:17:21 --> Final output sent to browser
DEBUG - 2011-04-30 14:17:21 --> Total execution time: 0.0205
DEBUG - 2011-04-30 14:20:04 --> Config Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:20:04 --> URI Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Router Class Initialized
DEBUG - 2011-04-30 14:20:04 --> No URI present. Default controller set.
DEBUG - 2011-04-30 14:20:04 --> Output Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Input Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:20:04 --> Language Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Loader Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:20:04 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:20:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:20:04 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:20:04 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:20:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:20:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Session Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:20:04 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:20:04 --> A session cookie was not found.
DEBUG - 2011-04-30 14:20:04 --> Session routines successfully run
DEBUG - 2011-04-30 14:20:04 --> Controller Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Final output sent to browser
DEBUG - 2011-04-30 14:20:04 --> Total execution time: 0.0264
DEBUG - 2011-04-30 14:20:04 --> Model Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Model Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Model Class Initialized
DEBUG - 2011-04-30 14:20:04 --> Helper loaded: markdown_helper
DEBUG - 2011-04-30 14:20:06 --> Config Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 14:20:06 --> URI Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Router Class Initialized
DEBUG - 2011-04-30 14:20:06 --> No URI present. Default controller set.
DEBUG - 2011-04-30 14:20:06 --> Output Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Input Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 14:20:06 --> Language Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Loader Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 14:20:06 --> Helper loaded: user_helper
DEBUG - 2011-04-30 14:20:06 --> Helper loaded: url_helper
DEBUG - 2011-04-30 14:20:06 --> Helper loaded: array_helper
DEBUG - 2011-04-30 14:20:06 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 14:20:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 14:20:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Session Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Helper loaded: string_helper
DEBUG - 2011-04-30 14:20:06 --> Encrypt Class Initialized
DEBUG - 2011-04-30 14:20:06 --> A session cookie was not found.
DEBUG - 2011-04-30 14:20:06 --> Session routines successfully run
DEBUG - 2011-04-30 14:20:06 --> Controller Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Final output sent to browser
DEBUG - 2011-04-30 14:20:06 --> Total execution time: 0.0237
DEBUG - 2011-04-30 14:20:06 --> Model Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Model Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Model Class Initialized
DEBUG - 2011-04-30 14:20:06 --> Helper loaded: markdown_helper
DEBUG - 2011-04-30 15:32:39 --> Config Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Hooks Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Utf8 Class Initialized
DEBUG - 2011-04-30 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 15:32:39 --> URI Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Router Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Output Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Input Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 15:32:39 --> Language Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Loader Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 15:32:39 --> Helper loaded: user_helper
DEBUG - 2011-04-30 15:32:39 --> Helper loaded: url_helper
DEBUG - 2011-04-30 15:32:39 --> Helper loaded: array_helper
DEBUG - 2011-04-30 15:32:39 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 15:32:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 15:32:39 --> Database Driver Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Session Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Helper loaded: string_helper
DEBUG - 2011-04-30 15:32:39 --> Encrypt Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Session routines successfully run
DEBUG - 2011-04-30 15:32:39 --> Controller Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Model Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Model Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Model Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Model Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Model Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Model Class Initialized
DEBUG - 2011-04-30 15:32:39 --> Final output sent to browser
DEBUG - 2011-04-30 15:32:39 --> Total execution time: 0.0312
DEBUG - 2011-04-30 16:17:35 --> Config Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:17:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:17:35 --> URI Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Router Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Output Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Input Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:17:35 --> Language Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Loader Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:17:35 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:17:35 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:17:35 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:17:35 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:17:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:17:35 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Session Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:17:35 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Session routines successfully run
DEBUG - 2011-04-30 16:17:35 --> Controller Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Model Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Model Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Model Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Model Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Model Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Model Class Initialized
DEBUG - 2011-04-30 16:17:35 --> Final output sent to browser
DEBUG - 2011-04-30 16:17:35 --> Total execution time: 0.0379
DEBUG - 2011-04-30 16:19:05 --> Config Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:19:05 --> URI Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Router Class Initialized
DEBUG - 2011-04-30 16:19:05 --> No URI present. Default controller set.
DEBUG - 2011-04-30 16:19:05 --> Output Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Input Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:19:05 --> Language Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Loader Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:19:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Session Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:19:05 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Session routines successfully run
DEBUG - 2011-04-30 16:19:05 --> Controller Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:19:05 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:19:05 --> JSMin library initialized.
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:19:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:19:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:19:05 --> File loaded: application/views/home/index.php
DEBUG - 2011-04-30 16:19:05 --> Final output sent to browser
DEBUG - 2011-04-30 16:19:05 --> Total execution time: 0.0459
DEBUG - 2011-04-30 16:19:05 --> Config Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:19:05 --> URI Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Router Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Output Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Input Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:19:05 --> Language Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Loader Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:19:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Session Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:19:05 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:19:05 --> Session routines successfully run
DEBUG - 2011-04-30 16:19:05 --> Controller Class Initialized
DEBUG - 2011-04-30 16:19:05 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:19:05 --> Final output sent to browser
DEBUG - 2011-04-30 16:19:05 --> Total execution time: 0.0214
DEBUG - 2011-04-30 16:19:07 --> Config Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:19:07 --> URI Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Router Class Initialized
DEBUG - 2011-04-30 16:19:07 --> No URI present. Default controller set.
DEBUG - 2011-04-30 16:19:07 --> Output Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Input Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:19:07 --> Language Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Loader Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:19:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Session Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:19:07 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Session routines successfully run
DEBUG - 2011-04-30 16:19:07 --> Controller Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:19:07 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:19:07 --> JSMin library initialized.
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:19:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:19:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:19:07 --> File loaded: application/views/home/index.php
DEBUG - 2011-04-30 16:19:07 --> Final output sent to browser
DEBUG - 2011-04-30 16:19:07 --> Total execution time: 0.0409
DEBUG - 2011-04-30 16:19:07 --> Config Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:19:07 --> URI Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Router Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Output Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Input Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:19:07 --> Language Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Loader Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:19:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Session Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:19:07 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:19:07 --> Session routines successfully run
DEBUG - 2011-04-30 16:19:07 --> Controller Class Initialized
DEBUG - 2011-04-30 16:19:07 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:19:07 --> Final output sent to browser
DEBUG - 2011-04-30 16:19:07 --> Total execution time: 0.0317
DEBUG - 2011-04-30 16:19:08 --> Config Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:19:08 --> URI Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Router Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Output Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Input Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:19:08 --> Language Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Loader Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:19:08 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Session Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:19:08 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Session routines successfully run
DEBUG - 2011-04-30 16:19:08 --> Controller Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:19:08 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:19:08 --> JSMin library initialized.
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:19:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:19:08 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 16:19:08 --> Model Class Initialized
DEBUG - 2011-04-30 16:19:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:19:08 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 16:19:08 --> Final output sent to browser
DEBUG - 2011-04-30 16:19:08 --> Total execution time: 0.0738
DEBUG - 2011-04-30 16:19:09 --> Config Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:19:09 --> URI Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Router Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Output Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Input Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:19:09 --> Language Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Loader Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:19:09 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:19:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:19:09 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:19:09 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:19:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:19:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Session Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:19:09 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:19:09 --> Session routines successfully run
DEBUG - 2011-04-30 16:19:09 --> Controller Class Initialized
DEBUG - 2011-04-30 16:19:09 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:19:09 --> Final output sent to browser
DEBUG - 2011-04-30 16:19:09 --> Total execution time: 0.0208
DEBUG - 2011-04-30 16:20:19 --> Config Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:20:19 --> URI Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Router Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Output Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Input Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:20:19 --> Language Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Loader Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:20:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Session Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:20:19 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Session routines successfully run
DEBUG - 2011-04-30 16:20:19 --> Controller Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:20:19 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:20:19 --> JSMin library initialized.
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:20:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 16:20:19 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:20:19 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 16:20:19 --> Final output sent to browser
DEBUG - 2011-04-30 16:20:19 --> Total execution time: 0.0720
DEBUG - 2011-04-30 16:20:19 --> Config Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:20:19 --> URI Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Router Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Output Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Input Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:20:19 --> Language Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Loader Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:20:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Session Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:20:19 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:20:19 --> Session routines successfully run
DEBUG - 2011-04-30 16:20:19 --> Controller Class Initialized
DEBUG - 2011-04-30 16:20:19 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:20:19 --> Final output sent to browser
DEBUG - 2011-04-30 16:20:19 --> Total execution time: 0.0246
DEBUG - 2011-04-30 16:20:21 --> Config Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:20:21 --> URI Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Router Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Output Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Input Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:20:21 --> Language Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Loader Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:20:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Session Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:20:21 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Session routines successfully run
DEBUG - 2011-04-30 16:20:21 --> Controller Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:20:21 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:20:21 --> JSMin library initialized.
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Model Class Initialized
DEBUG - 2011-04-30 16:20:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:20:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:20:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:20:21 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-04-30 16:20:21 --> Final output sent to browser
DEBUG - 2011-04-30 16:20:21 --> Total execution time: 0.0403
DEBUG - 2011-04-30 16:20:21 --> Config Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:20:21 --> URI Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Router Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Output Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Input Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:20:21 --> Language Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Loader Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:20:21 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Session Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:20:21 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:20:21 --> Session routines successfully run
DEBUG - 2011-04-30 16:20:21 --> Controller Class Initialized
DEBUG - 2011-04-30 16:20:21 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:20:21 --> Final output sent to browser
DEBUG - 2011-04-30 16:20:21 --> Total execution time: 0.0223
DEBUG - 2011-04-30 16:21:49 --> Config Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:21:49 --> URI Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Router Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Output Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Input Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:21:49 --> Language Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Loader Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:21:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Session Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:21:49 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Session routines successfully run
DEBUG - 2011-04-30 16:21:49 --> Controller Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:21:49 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:21:49 --> JSMin library initialized.
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:21:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 16:21:49 --> Model Class Initialized
DEBUG - 2011-04-30 16:21:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:21:49 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 16:21:49 --> Final output sent to browser
DEBUG - 2011-04-30 16:21:49 --> Total execution time: 0.0722
DEBUG - 2011-04-30 16:21:49 --> Config Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:21:49 --> URI Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Router Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Output Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Input Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:21:49 --> Language Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Loader Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:21:49 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Session Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:21:49 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:21:49 --> Session routines successfully run
DEBUG - 2011-04-30 16:21:49 --> Controller Class Initialized
DEBUG - 2011-04-30 16:21:49 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:21:49 --> Final output sent to browser
DEBUG - 2011-04-30 16:21:49 --> Total execution time: 0.0267
DEBUG - 2011-04-30 16:22:02 --> Config Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:22:02 --> URI Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Router Class Initialized
DEBUG - 2011-04-30 16:22:02 --> No URI present. Default controller set.
DEBUG - 2011-04-30 16:22:02 --> Output Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Input Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:22:02 --> Language Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Loader Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:22:02 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Session Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:22:02 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Session routines successfully run
DEBUG - 2011-04-30 16:22:02 --> Controller Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:22:02 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:22:02 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:22:02 --> JSMin library initialized.
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> Model Class Initialized
DEBUG - 2011-04-30 16:22:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:22:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:22:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:22:02 --> File loaded: application/views/home/index.php
DEBUG - 2011-04-30 16:22:02 --> Final output sent to browser
DEBUG - 2011-04-30 16:22:02 --> Total execution time: 0.0430
DEBUG - 2011-04-30 16:22:03 --> Config Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:22:03 --> URI Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Router Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Output Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Input Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:22:03 --> Language Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Loader Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:22:03 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:22:03 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:22:03 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:22:03 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:22:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:22:03 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Session Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:22:03 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:22:03 --> Session routines successfully run
DEBUG - 2011-04-30 16:22:03 --> Controller Class Initialized
DEBUG - 2011-04-30 16:22:03 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:22:03 --> Final output sent to browser
DEBUG - 2011-04-30 16:22:03 --> Total execution time: 0.0280
DEBUG - 2011-04-30 16:27:46 --> Config Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:27:46 --> URI Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Router Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Output Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Input Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:27:46 --> Language Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Loader Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:27:46 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Session Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:27:46 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Session routines successfully run
DEBUG - 2011-04-30 16:27:46 --> Controller Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:27:46 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:27:46 --> JSMin library initialized.
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:27:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 16:27:46 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:27:46 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 16:27:46 --> Final output sent to browser
DEBUG - 2011-04-30 16:27:46 --> Total execution time: 0.0712
DEBUG - 2011-04-30 16:27:46 --> Config Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:27:46 --> URI Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Router Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Output Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Input Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:27:46 --> Language Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Loader Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:27:46 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Session Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:27:46 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:27:46 --> Session routines successfully run
DEBUG - 2011-04-30 16:27:46 --> Controller Class Initialized
DEBUG - 2011-04-30 16:27:46 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:27:46 --> Final output sent to browser
DEBUG - 2011-04-30 16:27:46 --> Total execution time: 0.0217
DEBUG - 2011-04-30 16:27:54 --> Config Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:27:54 --> URI Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Router Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Output Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Input Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:27:54 --> Language Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Loader Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:27:54 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Session Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:27:54 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Session routines successfully run
DEBUG - 2011-04-30 16:27:54 --> Controller Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: file_helper
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 16:27:54 --> CSSMin library initialized.
DEBUG - 2011-04-30 16:27:54 --> JSMin library initialized.
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 16:27:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 16:27:54 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 16:27:54 --> Model Class Initialized
DEBUG - 2011-04-30 16:27:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 16:27:54 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 16:27:54 --> Final output sent to browser
DEBUG - 2011-04-30 16:27:54 --> Total execution time: 0.0700
DEBUG - 2011-04-30 16:27:55 --> Config Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Hooks Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Utf8 Class Initialized
DEBUG - 2011-04-30 16:27:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 16:27:55 --> URI Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Router Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Output Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Input Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 16:27:55 --> Language Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Loader Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 16:27:55 --> Helper loaded: user_helper
DEBUG - 2011-04-30 16:27:55 --> Helper loaded: url_helper
DEBUG - 2011-04-30 16:27:55 --> Helper loaded: array_helper
DEBUG - 2011-04-30 16:27:55 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 16:27:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 16:27:55 --> Database Driver Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Session Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Helper loaded: string_helper
DEBUG - 2011-04-30 16:27:55 --> Encrypt Class Initialized
DEBUG - 2011-04-30 16:27:55 --> Session routines successfully run
DEBUG - 2011-04-30 16:27:55 --> Controller Class Initialized
DEBUG - 2011-04-30 16:27:55 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 16:27:55 --> Final output sent to browser
DEBUG - 2011-04-30 16:27:55 --> Total execution time: 0.0269
DEBUG - 2011-04-30 17:08:22 --> Config Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:08:22 --> URI Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Router Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Output Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Input Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:08:22 --> Language Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Loader Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:08:22 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:08:22 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:08:22 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:08:22 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:08:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:08:22 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Session Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:08:22 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Session routines successfully run
DEBUG - 2011-04-30 17:08:22 --> Controller Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:22 --> Final output sent to browser
DEBUG - 2011-04-30 17:08:22 --> Total execution time: 0.0324
DEBUG - 2011-04-30 17:08:28 --> Config Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:08:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:08:28 --> URI Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Router Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Output Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Input Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:08:28 --> Language Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Loader Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:08:28 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Session Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:08:28 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Session routines successfully run
DEBUG - 2011-04-30 17:08:28 --> Controller Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:08:28 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:08:28 --> JSMin library initialized.
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:08:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:08:28 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 17:08:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:08:28 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 17:08:28 --> Final output sent to browser
DEBUG - 2011-04-30 17:08:28 --> Total execution time: 0.0758
DEBUG - 2011-04-30 17:08:29 --> Config Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:08:29 --> URI Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Router Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Output Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Input Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:08:29 --> Language Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Loader Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:08:29 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:08:29 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:08:29 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:08:29 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:08:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:08:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Session Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:08:29 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:08:29 --> Session routines successfully run
DEBUG - 2011-04-30 17:08:29 --> Controller Class Initialized
DEBUG - 2011-04-30 17:08:29 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:08:29 --> Final output sent to browser
DEBUG - 2011-04-30 17:08:29 --> Total execution time: 0.0267
DEBUG - 2011-04-30 17:08:37 --> Config Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:08:37 --> URI Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Router Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Output Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Input Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:08:37 --> Language Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Loader Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:08:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Session Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:08:37 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Session routines successfully run
DEBUG - 2011-04-30 17:08:37 --> Controller Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:08:37 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:08:37 --> JSMin library initialized.
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:08:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:08:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:08:37 --> User Agent Class Initialized
DEBUG - 2011-04-30 17:08:37 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-04-30 17:08:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:08:37 --> File loaded: application/views/packages/show.php
DEBUG - 2011-04-30 17:08:37 --> Final output sent to browser
DEBUG - 2011-04-30 17:08:37 --> Total execution time: 0.0488
DEBUG - 2011-04-30 17:08:37 --> Config Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:08:37 --> URI Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Router Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Output Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Input Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:08:37 --> Language Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Loader Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:08:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Session Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:08:37 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:08:37 --> Session routines successfully run
DEBUG - 2011-04-30 17:08:37 --> Controller Class Initialized
DEBUG - 2011-04-30 17:08:37 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:08:37 --> Final output sent to browser
DEBUG - 2011-04-30 17:08:37 --> Total execution time: 0.0204
DEBUG - 2011-04-30 17:09:30 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:30 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:30 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:30 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:30 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:30 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:09:30 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:09:30 --> JSMin library initialized.
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:09:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 17:09:30 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:09:30 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 17:09:30 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:30 --> Total execution time: 0.0699
DEBUG - 2011-04-30 17:09:30 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:30 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:30 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:30 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:30 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:30 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:30 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:30 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:09:30 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:30 --> Total execution time: 0.0262
DEBUG - 2011-04-30 17:09:40 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:40 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:40 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:40 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:40 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:09:40 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:09:40 --> JSMin library initialized.
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:09:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:09:40 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 17:09:40 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:09:40 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 17:09:40 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:40 --> Total execution time: 0.0754
DEBUG - 2011-04-30 17:09:41 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:41 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:41 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:41 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:41 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:41 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:41 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:41 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:41 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:41 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:41 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:41 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:09:41 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:41 --> Total execution time: 0.0233
DEBUG - 2011-04-30 17:09:42 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:42 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:42 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:42 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:42 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:09:42 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:09:42 --> JSMin library initialized.
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:09:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:09:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:09:42 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-04-30 17:09:42 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:42 --> Total execution time: 0.0395
DEBUG - 2011-04-30 17:09:42 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:42 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:42 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:42 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:42 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:42 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:42 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:42 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:09:42 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:42 --> Total execution time: 0.0207
DEBUG - 2011-04-30 17:09:53 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:53 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:53 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:53 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:53 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:53 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:53 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:53 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:53 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:53 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:53 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:09:54 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:09:54 --> JSMin library initialized.
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:09:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 17:09:54 --> Model Class Initialized
DEBUG - 2011-04-30 17:09:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:09:54 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 17:09:54 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:54 --> Total execution time: 0.0712
DEBUG - 2011-04-30 17:09:54 --> Config Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:09:54 --> URI Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Router Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Output Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Input Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:09:54 --> Language Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Loader Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:09:54 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Session Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:09:54 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:09:54 --> Session routines successfully run
DEBUG - 2011-04-30 17:09:54 --> Controller Class Initialized
DEBUG - 2011-04-30 17:09:54 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:09:54 --> Final output sent to browser
DEBUG - 2011-04-30 17:09:54 --> Total execution time: 0.0246
DEBUG - 2011-04-30 17:10:05 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:05 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:05 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:05 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:05 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:05 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:05 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:05 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-04-30 17:10:05 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:05 --> Total execution time: 0.0500
DEBUG - 2011-04-30 17:10:05 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:05 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:05 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:05 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:05 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:05 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:05 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:05 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:05 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:05 --> Total execution time: 0.0334
DEBUG - 2011-04-30 17:10:06 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:06 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:06 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:06 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:06 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:06 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:06 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 17:10:06 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:06 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 17:10:06 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:06 --> Total execution time: 0.0697
DEBUG - 2011-04-30 17:10:06 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:06 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:06 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:06 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:06 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:06 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:06 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:06 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:06 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:06 --> Total execution time: 0.0276
DEBUG - 2011-04-30 17:10:07 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:07 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:07 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:07 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:07 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:07 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:07 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:07 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:07 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:07 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-04-30 17:10:07 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:07 --> Total execution time: 0.0414
DEBUG - 2011-04-30 17:10:08 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:08 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:08 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:08 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:08 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:08 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:08 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:08 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:08 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:08 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:08 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:08 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:08 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:08 --> Total execution time: 0.0206
DEBUG - 2011-04-30 17:10:09 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:09 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:09 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:09 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:09 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:09 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:09 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 17:10:09 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:09 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 17:10:09 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:09 --> Total execution time: 0.0709
DEBUG - 2011-04-30 17:10:09 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:09 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:09 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:09 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:09 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:09 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:09 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:09 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:09 --> Total execution time: 0.0257
DEBUG - 2011-04-30 17:10:28 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:28 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:28 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:28 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:28 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:28 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:28 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:28 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:28 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-04-30 17:10:28 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:28 --> Total execution time: 0.0440
DEBUG - 2011-04-30 17:10:28 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:28 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:28 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:28 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:28 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:28 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:28 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:28 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:28 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:28 --> Total execution time: 0.0248
DEBUG - 2011-04-30 17:10:29 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:29 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:29 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:29 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:29 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:29 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:29 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:29 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-04-30 17:10:29 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:29 --> Total execution time: 0.0395
DEBUG - 2011-04-30 17:10:29 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:29 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:29 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:29 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:29 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:29 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:29 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:29 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:29 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:29 --> Total execution time: 0.0206
DEBUG - 2011-04-30 17:10:36 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:36 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:36 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:36 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:36 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:36 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:37 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:37 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:37 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:37 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:37 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-04-30 17:10:37 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:37 --> Total execution time: 0.0399
DEBUG - 2011-04-30 17:10:37 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:37 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:37 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:37 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:37 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:37 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:37 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:37 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:37 --> Total execution time: 0.0263
DEBUG - 2011-04-30 17:10:38 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:38 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:38 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:38 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:38 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:38 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: file_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 17:10:38 --> CSSMin library initialized.
DEBUG - 2011-04-30 17:10:38 --> JSMin library initialized.
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Model Class Initialized
DEBUG - 2011-04-30 17:10:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 17:10:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 17:10:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 17:10:38 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-04-30 17:10:38 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:38 --> Total execution time: 0.0399
DEBUG - 2011-04-30 17:10:38 --> Config Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:10:38 --> URI Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Router Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Output Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Input Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:10:38 --> Language Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Loader Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:10:38 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Session Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:10:38 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:10:38 --> Session routines successfully run
DEBUG - 2011-04-30 17:10:38 --> Controller Class Initialized
DEBUG - 2011-04-30 17:10:38 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 17:10:38 --> Final output sent to browser
DEBUG - 2011-04-30 17:10:38 --> Total execution time: 0.0244
DEBUG - 2011-04-30 17:37:18 --> Config Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 17:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 17:37:18 --> URI Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Router Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Output Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Input Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 17:37:18 --> Language Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Loader Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 17:37:18 --> Helper loaded: user_helper
DEBUG - 2011-04-30 17:37:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 17:37:18 --> Helper loaded: array_helper
DEBUG - 2011-04-30 17:37:18 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 17:37:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 17:37:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Session Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Helper loaded: string_helper
DEBUG - 2011-04-30 17:37:18 --> Encrypt Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Session routines successfully run
DEBUG - 2011-04-30 17:37:18 --> Controller Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Model Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Model Class Initialized
DEBUG - 2011-04-30 17:37:18 --> Model Class Initialized
ERROR - 2011-04-30 17:37:18 --> Severity: Notice  --> Undefined variable: sparks /Users/katzgrau/Dev/ci-sparks-repo/application/controllers/api/rss.php 23
ERROR - 2011-04-30 17:37:18 --> 404 Page Not Found --> 
DEBUG - 2011-04-30 18:01:57 --> Config Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Hooks Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Utf8 Class Initialized
DEBUG - 2011-04-30 18:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 18:01:57 --> URI Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Router Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Output Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Input Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 18:01:57 --> Language Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Loader Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: user_helper
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: url_helper
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: array_helper
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 18:01:57 --> Database Driver Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Session Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: string_helper
DEBUG - 2011-04-30 18:01:57 --> Encrypt Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Session routines successfully run
DEBUG - 2011-04-30 18:01:57 --> Controller Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: file_helper
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 18:01:57 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 18:01:57 --> CSSMin library initialized.
DEBUG - 2011-04-30 18:01:57 --> JSMin library initialized.
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> Model Class Initialized
DEBUG - 2011-04-30 18:01:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 18:01:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 18:01:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 18:01:57 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-04-30 18:01:57 --> Final output sent to browser
DEBUG - 2011-04-30 18:01:57 --> Total execution time: 0.0433
DEBUG - 2011-04-30 18:01:58 --> Config Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 18:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 18:01:58 --> URI Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Router Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Output Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Input Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 18:01:58 --> Language Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Loader Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 18:01:58 --> Helper loaded: user_helper
DEBUG - 2011-04-30 18:01:58 --> Helper loaded: url_helper
DEBUG - 2011-04-30 18:01:58 --> Helper loaded: array_helper
DEBUG - 2011-04-30 18:01:58 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 18:01:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 18:01:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Session Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Helper loaded: string_helper
DEBUG - 2011-04-30 18:01:58 --> Encrypt Class Initialized
DEBUG - 2011-04-30 18:01:58 --> Session routines successfully run
DEBUG - 2011-04-30 18:01:58 --> Controller Class Initialized
DEBUG - 2011-04-30 18:01:58 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 18:01:58 --> Final output sent to browser
DEBUG - 2011-04-30 18:01:58 --> Total execution time: 0.0272
DEBUG - 2011-04-30 18:02:40 --> Config Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 18:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 18:02:40 --> URI Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Router Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Output Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Input Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 18:02:40 --> Language Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Loader Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: user_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: array_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 18:02:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Session Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: string_helper
DEBUG - 2011-04-30 18:02:40 --> Encrypt Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Session routines successfully run
DEBUG - 2011-04-30 18:02:40 --> Controller Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: file_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 18:02:40 --> CSSMin library initialized.
DEBUG - 2011-04-30 18:02:40 --> JSMin library initialized.
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 18:02:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 18:02:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 18:02:40 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-04-30 18:02:40 --> Final output sent to browser
DEBUG - 2011-04-30 18:02:40 --> Total execution time: 0.0384
DEBUG - 2011-04-30 18:02:40 --> Config Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 18:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 18:02:40 --> URI Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Router Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Output Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Input Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 18:02:40 --> Language Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Loader Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: user_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: array_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 18:02:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Session Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Helper loaded: string_helper
DEBUG - 2011-04-30 18:02:40 --> Encrypt Class Initialized
DEBUG - 2011-04-30 18:02:40 --> Session routines successfully run
DEBUG - 2011-04-30 18:02:40 --> Controller Class Initialized
DEBUG - 2011-04-30 18:02:40 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 18:02:40 --> Final output sent to browser
DEBUG - 2011-04-30 18:02:40 --> Total execution time: 0.0414
DEBUG - 2011-04-30 18:02:50 --> Config Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 18:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 18:02:50 --> URI Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Router Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Output Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Input Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 18:02:50 --> Language Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Loader Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: user_helper
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: array_helper
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 18:02:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Session Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: string_helper
DEBUG - 2011-04-30 18:02:50 --> Encrypt Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Session routines successfully run
DEBUG - 2011-04-30 18:02:50 --> Controller Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: file_helper
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 18:02:50 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 18:02:50 --> CSSMin library initialized.
DEBUG - 2011-04-30 18:02:50 --> JSMin library initialized.
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> Model Class Initialized
DEBUG - 2011-04-30 18:02:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 18:02:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 18:02:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 18:02:50 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-04-30 18:02:50 --> Final output sent to browser
DEBUG - 2011-04-30 18:02:50 --> Total execution time: 0.0413
DEBUG - 2011-04-30 18:02:51 --> Config Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 18:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 18:02:51 --> URI Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Router Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Output Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Input Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 18:02:51 --> Language Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Loader Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 18:02:51 --> Helper loaded: user_helper
DEBUG - 2011-04-30 18:02:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 18:02:51 --> Helper loaded: array_helper
DEBUG - 2011-04-30 18:02:51 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 18:02:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 18:02:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Session Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Helper loaded: string_helper
DEBUG - 2011-04-30 18:02:51 --> Encrypt Class Initialized
DEBUG - 2011-04-30 18:02:51 --> Session routines successfully run
DEBUG - 2011-04-30 18:02:51 --> Controller Class Initialized
DEBUG - 2011-04-30 18:02:51 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 18:02:51 --> Final output sent to browser
DEBUG - 2011-04-30 18:02:51 --> Total execution time: 0.0306
DEBUG - 2011-04-30 19:00:09 --> Config Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 19:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 19:00:09 --> URI Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Router Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Output Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Input Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 19:00:09 --> Language Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Loader Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: user_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: array_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 19:00:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Session Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: string_helper
DEBUG - 2011-04-30 19:00:09 --> Encrypt Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Session routines successfully run
DEBUG - 2011-04-30 19:00:09 --> Controller Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: file_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 19:00:09 --> CSSMin library initialized.
DEBUG - 2011-04-30 19:00:09 --> JSMin library initialized.
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Model Class Initialized
DEBUG - 2011-04-30 19:00:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 19:00:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 19:00:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 19:00:09 --> File loaded: application/views/home/spec_format.php
DEBUG - 2011-04-30 19:00:09 --> Final output sent to browser
DEBUG - 2011-04-30 19:00:09 --> Total execution time: 0.0452
DEBUG - 2011-04-30 19:00:09 --> Config Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Hooks Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Utf8 Class Initialized
DEBUG - 2011-04-30 19:00:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 19:00:09 --> URI Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Router Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Output Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Input Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 19:00:09 --> Language Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Loader Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: user_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: url_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: array_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 19:00:09 --> Database Driver Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Session Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Helper loaded: string_helper
DEBUG - 2011-04-30 19:00:09 --> Encrypt Class Initialized
DEBUG - 2011-04-30 19:00:09 --> Session routines successfully run
DEBUG - 2011-04-30 19:00:09 --> Controller Class Initialized
DEBUG - 2011-04-30 19:00:09 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 19:00:09 --> Final output sent to browser
DEBUG - 2011-04-30 19:00:09 --> Total execution time: 0.0211
DEBUG - 2011-04-30 19:03:58 --> Config Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 19:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 19:03:58 --> URI Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Router Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Output Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Input Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 19:03:58 --> Language Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Loader Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: user_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: url_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: array_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 19:03:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Session Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: string_helper
DEBUG - 2011-04-30 19:03:58 --> Encrypt Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Session routines successfully run
DEBUG - 2011-04-30 19:03:58 --> Controller Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: form_helper
DEBUG - 2011-04-30 19:03:58 --> Form Validation Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2011-04-30 19:03:58 --> Security Class Initialized
DEBUG - 2011-04-30 19:03:58 --> XSS Filtering completed
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: file_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 19:03:58 --> CSSMin library initialized.
DEBUG - 2011-04-30 19:03:58 --> JSMin library initialized.
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Model Class Initialized
DEBUG - 2011-04-30 19:03:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 19:03:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 19:03:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 19:03:58 --> File loaded: application/views/search/listing.php
DEBUG - 2011-04-30 19:03:58 --> Final output sent to browser
DEBUG - 2011-04-30 19:03:58 --> Total execution time: 0.0569
DEBUG - 2011-04-30 19:03:58 --> Config Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Hooks Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Utf8 Class Initialized
DEBUG - 2011-04-30 19:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 19:03:58 --> URI Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Router Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Output Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Input Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 19:03:58 --> Language Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Loader Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: user_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: url_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: array_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 19:03:58 --> Database Driver Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Session Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Helper loaded: string_helper
DEBUG - 2011-04-30 19:03:58 --> Encrypt Class Initialized
DEBUG - 2011-04-30 19:03:58 --> Session routines successfully run
DEBUG - 2011-04-30 19:03:58 --> Controller Class Initialized
DEBUG - 2011-04-30 19:03:58 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 19:03:58 --> Final output sent to browser
DEBUG - 2011-04-30 19:03:58 --> Total execution time: 0.0264
DEBUG - 2011-04-30 23:04:23 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:23 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:23 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:23 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:23 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:23 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:04:23 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:04:23 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:04:23 --> JSMin library initialized.
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:04:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:04:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:04:23 --> File loaded: application/views/home/spec_format.php
DEBUG - 2011-04-30 23:04:23 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:23 --> Total execution time: 0.0386
DEBUG - 2011-04-30 23:04:24 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:24 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:24 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:24 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:24 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:24 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:24 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:24 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:24 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:24 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:24 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:24 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:04:24 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:24 --> Total execution time: 0.0251
DEBUG - 2011-04-30 23:04:26 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:26 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:26 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:26 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:26 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:26 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: form_helper
DEBUG - 2011-04-30 23:04:26 --> Form Validation Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2011-04-30 23:04:26 --> Security Class Initialized
DEBUG - 2011-04-30 23:04:26 --> XSS Filtering completed
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:04:26 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:04:26 --> JSMin library initialized.
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:04:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:26 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:04:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:04:26 --> File loaded: application/views/search/listing.php
DEBUG - 2011-04-30 23:04:26 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:26 --> Total execution time: 0.0844
DEBUG - 2011-04-30 23:04:26 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:26 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:26 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:26 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:26 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:26 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:26 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:26 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:04:26 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:26 --> Total execution time: 0.0255
DEBUG - 2011-04-30 23:04:46 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:46 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:46 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:46 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:46 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:46 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:04:46 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:04:46 --> JSMin library initialized.
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:04:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:04:46 --> User Agent Class Initialized
DEBUG - 2011-04-30 23:04:46 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-04-30 23:04:46 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-04-30 23:04:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:04:46 --> File loaded: application/views/packages/show.php
DEBUG - 2011-04-30 23:04:46 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:46 --> Total execution time: 0.0495
DEBUG - 2011-04-30 23:04:46 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:46 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:46 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:46 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:46 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:46 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:46 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:46 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:04:46 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:46 --> Total execution time: 0.0205
DEBUG - 2011-04-30 23:04:51 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:51 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:51 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:51 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:51 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:04:51 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:04:51 --> JSMin library initialized.
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Model Class Initialized
DEBUG - 2011-04-30 23:04:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:04:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:04:51 --> User Agent Class Initialized
DEBUG - 2011-04-30 23:04:51 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-04-30 23:04:51 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-04-30 23:04:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:04:51 --> File loaded: application/views/packages/show.php
DEBUG - 2011-04-30 23:04:51 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:51 --> Total execution time: 0.0532
DEBUG - 2011-04-30 23:04:51 --> Config Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:04:51 --> URI Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Router Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Output Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Input Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:04:51 --> Language Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Loader Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:04:51 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Session Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:04:51 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:04:51 --> Session routines successfully run
DEBUG - 2011-04-30 23:04:51 --> Controller Class Initialized
DEBUG - 2011-04-30 23:04:51 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:04:51 --> Final output sent to browser
DEBUG - 2011-04-30 23:04:51 --> Total execution time: 0.0253
DEBUG - 2011-04-30 23:08:18 --> Config Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:08:18 --> URI Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Router Class Initialized
DEBUG - 2011-04-30 23:08:18 --> No URI present. Default controller set.
DEBUG - 2011-04-30 23:08:18 --> Output Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Input Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:08:18 --> Language Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Loader Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:08:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Session Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:08:18 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Session routines successfully run
DEBUG - 2011-04-30 23:08:18 --> Controller Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:08:18 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:08:18 --> JSMin library initialized.
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:08:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:08:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:08:18 --> File loaded: application/views/home/index.php
DEBUG - 2011-04-30 23:08:18 --> Final output sent to browser
DEBUG - 2011-04-30 23:08:18 --> Total execution time: 0.0455
DEBUG - 2011-04-30 23:08:18 --> Config Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:08:18 --> URI Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Router Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Output Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Input Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:08:18 --> Language Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Loader Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:08:18 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Session Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:08:18 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:08:18 --> Session routines successfully run
DEBUG - 2011-04-30 23:08:18 --> Controller Class Initialized
DEBUG - 2011-04-30 23:08:18 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:08:18 --> Final output sent to browser
DEBUG - 2011-04-30 23:08:18 --> Total execution time: 0.0252
DEBUG - 2011-04-30 23:08:44 --> Config Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:08:44 --> URI Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Router Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Output Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Input Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:08:44 --> Language Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Loader Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:08:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Session Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:08:44 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Session routines successfully run
DEBUG - 2011-04-30 23:08:44 --> Controller Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:08:44 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:08:44 --> JSMin library initialized.
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:08:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:08:44 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:44 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:08:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:08:44 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:08:44 --> Final output sent to browser
DEBUG - 2011-04-30 23:08:44 --> Total execution time: 0.0707
DEBUG - 2011-04-30 23:08:44 --> Config Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:08:44 --> URI Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Router Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Output Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Input Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:08:44 --> Language Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Loader Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:08:44 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Session Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:08:44 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:08:44 --> Session routines successfully run
DEBUG - 2011-04-30 23:08:44 --> Controller Class Initialized
DEBUG - 2011-04-30 23:08:44 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:08:44 --> Final output sent to browser
DEBUG - 2011-04-30 23:08:44 --> Total execution time: 0.0200
DEBUG - 2011-04-30 23:08:59 --> Config Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:08:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:08:59 --> URI Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Router Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Output Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Input Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:08:59 --> Language Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Loader Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:08:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Session Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:08:59 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Session routines successfully run
DEBUG - 2011-04-30 23:08:59 --> Controller Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:08:59 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:08:59 --> JSMin library initialized.
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:08:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:08:59 --> Model Class Initialized
DEBUG - 2011-04-30 23:08:59 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:08:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:08:59 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:08:59 --> Final output sent to browser
DEBUG - 2011-04-30 23:08:59 --> Total execution time: 0.0847
DEBUG - 2011-04-30 23:08:59 --> Config Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:08:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:08:59 --> URI Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Router Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Output Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Input Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:08:59 --> Language Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Loader Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:08:59 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Session Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:08:59 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:08:59 --> Session routines successfully run
DEBUG - 2011-04-30 23:08:59 --> Controller Class Initialized
DEBUG - 2011-04-30 23:08:59 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:08:59 --> Final output sent to browser
DEBUG - 2011-04-30 23:08:59 --> Total execution time: 0.0259
DEBUG - 2011-04-30 23:09:13 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:13 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:13 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:13 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:13 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:09:13 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:09:13 --> JSMin library initialized.
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:09:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:09:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:13 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:09:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:09:13 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:09:13 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:13 --> Total execution time: 0.0706
DEBUG - 2011-04-30 23:09:13 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:13 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:13 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:13 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:13 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:13 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:13 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:09:13 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:13 --> Total execution time: 0.0302
DEBUG - 2011-04-30 23:09:16 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:16 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:16 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:16 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:16 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:16 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:09:16 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:09:16 --> JSMin library initialized.
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:09:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:09:16 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:16 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:09:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:09:16 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:09:16 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:16 --> Total execution time: 0.0709
DEBUG - 2011-04-30 23:09:16 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:16 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:16 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:16 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:16 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:16 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:16 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:16 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:09:16 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:16 --> Total execution time: 0.0258
DEBUG - 2011-04-30 23:09:17 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:17 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:17 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:17 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:17 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:09:17 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:09:17 --> JSMin library initialized.
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:09:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:09:17 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:17 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:09:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:09:17 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:09:17 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:17 --> Total execution time: 0.0715
DEBUG - 2011-04-30 23:09:17 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:17 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:17 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:17 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:17 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:17 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:17 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:17 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:09:17 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:17 --> Total execution time: 0.0254
DEBUG - 2011-04-30 23:09:19 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:19 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:19 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:19 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:19 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:09:19 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:09:19 --> JSMin library initialized.
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:09:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:09:19 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:19 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:09:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:09:19 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:09:19 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:19 --> Total execution time: 0.0685
DEBUG - 2011-04-30 23:09:19 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:19 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:19 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:19 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:19 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:19 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:19 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:19 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:09:19 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:19 --> Total execution time: 0.0276
DEBUG - 2011-04-30 23:09:35 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:35 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:35 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:35 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:35 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:35 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:09:35 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:09:35 --> JSMin library initialized.
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:09:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:09:35 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:09:35 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:35 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:09:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:09:35 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:09:35 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:35 --> Total execution time: 0.0752
DEBUG - 2011-04-30 23:09:36 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:36 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:36 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:36 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:36 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:36 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:09:36 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:36 --> Total execution time: 0.0247
DEBUG - 2011-04-30 23:09:36 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:36 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:36 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:36 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:36 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:36 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:09:36 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:09:36 --> JSMin library initialized.
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:09:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:09:36 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:09:36 --> Model Class Initialized
DEBUG - 2011-04-30 23:09:36 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:09:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:09:36 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:09:36 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:36 --> Total execution time: 0.0770
DEBUG - 2011-04-30 23:09:37 --> Config Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:09:37 --> URI Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Router Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Output Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Input Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:09:37 --> Language Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Loader Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:09:37 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:09:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:09:37 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:09:37 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:09:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:09:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Session Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:09:37 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:09:37 --> Session routines successfully run
DEBUG - 2011-04-30 23:09:37 --> Controller Class Initialized
DEBUG - 2011-04-30 23:09:37 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:09:37 --> Final output sent to browser
DEBUG - 2011-04-30 23:09:37 --> Total execution time: 0.0256
DEBUG - 2011-04-30 23:10:10 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:10 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:10 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:10 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:10 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:10 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:10 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:10 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:10 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:11 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:11 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:10:11 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:10:11 --> JSMin library initialized.
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:10:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:10:11 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:11 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:10:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:10:11 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:10:11 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:11 --> Total execution time: 0.0756
DEBUG - 2011-04-30 23:10:11 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:11 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:11 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:11 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:11 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:11 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:11 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:11 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:10:11 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:11 --> Total execution time: 0.0206
DEBUG - 2011-04-30 23:10:12 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:12 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:12 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:12 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:12 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:12 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:10:12 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:10:12 --> JSMin library initialized.
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:10:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:10:12 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:12 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:10:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:10:12 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:10:12 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:12 --> Total execution time: 0.0730
DEBUG - 2011-04-30 23:10:12 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:12 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:12 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:12 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:12 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:12 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:12 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:12 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:10:12 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:12 --> Total execution time: 0.0239
DEBUG - 2011-04-30 23:10:13 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:13 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:13 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:13 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:13 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:10:13 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:10:13 --> JSMin library initialized.
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:10:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:10:13 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:13 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:10:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:10:13 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:10:13 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:13 --> Total execution time: 0.0707
DEBUG - 2011-04-30 23:10:13 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:13 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:13 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:13 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:13 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:13 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:13 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:13 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:10:13 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:13 --> Total execution time: 0.0269
DEBUG - 2011-04-30 23:10:15 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:15 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:15 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:15 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:15 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:15 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:10:15 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:10:15 --> JSMin library initialized.
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:10:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: rating_helper
DEBUG - 2011-04-30 23:10:15 --> Model Class Initialized
DEBUG - 2011-04-30 23:10:15 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-04-30 23:10:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:10:15 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-04-30 23:10:15 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:15 --> Total execution time: 0.0724
DEBUG - 2011-04-30 23:10:15 --> Config Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:10:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:10:15 --> URI Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Router Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Output Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Input Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:10:15 --> Language Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Loader Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:10:15 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Session Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:10:15 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:10:15 --> Session routines successfully run
DEBUG - 2011-04-30 23:10:15 --> Controller Class Initialized
DEBUG - 2011-04-30 23:10:15 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:10:15 --> Final output sent to browser
DEBUG - 2011-04-30 23:10:15 --> Total execution time: 0.0279
DEBUG - 2011-04-30 23:12:04 --> Config Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:12:04 --> URI Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Router Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Output Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Input Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:12:04 --> Language Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Loader Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:12:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Session Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:12:04 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Session routines successfully run
DEBUG - 2011-04-30 23:12:04 --> Controller Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:12:04 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:12:04 --> JSMin library initialized.
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Model Class Initialized
DEBUG - 2011-04-30 23:12:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:12:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:12:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:12:04 --> File loaded: application/views/home/spec_format.php
DEBUG - 2011-04-30 23:12:04 --> Final output sent to browser
DEBUG - 2011-04-30 23:12:04 --> Total execution time: 0.0483
DEBUG - 2011-04-30 23:12:04 --> Config Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:12:04 --> URI Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Router Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Output Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Input Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:12:04 --> Language Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Loader Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:12:04 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Session Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:12:04 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:12:04 --> Session routines successfully run
DEBUG - 2011-04-30 23:12:04 --> Controller Class Initialized
DEBUG - 2011-04-30 23:12:04 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:12:04 --> Final output sent to browser
DEBUG - 2011-04-30 23:12:04 --> Total execution time: 0.0294
DEBUG - 2011-04-30 23:13:37 --> Config Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:13:37 --> URI Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Router Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Output Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Input Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:13:37 --> Language Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Loader Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:13:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Session Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:13:37 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Session routines successfully run
DEBUG - 2011-04-30 23:13:37 --> Controller Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:13:37 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:13:37 --> JSMin library initialized.
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:13:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:13:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:13:37 --> File loaded: application/views/home/spec_format.php
DEBUG - 2011-04-30 23:13:37 --> Final output sent to browser
DEBUG - 2011-04-30 23:13:37 --> Total execution time: 0.0440
DEBUG - 2011-04-30 23:13:37 --> Config Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:13:37 --> URI Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Router Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Output Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Input Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:13:37 --> Language Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Loader Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:13:37 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Session Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:13:37 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:13:37 --> Session routines successfully run
DEBUG - 2011-04-30 23:13:37 --> Controller Class Initialized
DEBUG - 2011-04-30 23:13:37 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:13:37 --> Final output sent to browser
DEBUG - 2011-04-30 23:13:37 --> Total execution time: 0.0235
DEBUG - 2011-04-30 23:13:40 --> Config Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:13:40 --> URI Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Router Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Output Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Input Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:13:40 --> Language Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Loader Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:13:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Session Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:13:40 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Session routines successfully run
DEBUG - 2011-04-30 23:13:40 --> Controller Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:13:40 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:13:40 --> JSMin library initialized.
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:13:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:13:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:13:40 --> File loaded: application/views/home/spec_format.php
DEBUG - 2011-04-30 23:13:40 --> Final output sent to browser
DEBUG - 2011-04-30 23:13:40 --> Total execution time: 0.0412
DEBUG - 2011-04-30 23:13:40 --> Config Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:13:40 --> URI Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Router Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Output Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Input Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:13:40 --> Language Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Loader Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:13:40 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Session Class Initialized
DEBUG - 2011-04-30 23:13:40 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:13:41 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:13:41 --> Session routines successfully run
DEBUG - 2011-04-30 23:13:41 --> Controller Class Initialized
DEBUG - 2011-04-30 23:13:41 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:13:41 --> Final output sent to browser
DEBUG - 2011-04-30 23:13:41 --> Total execution time: 0.0274
DEBUG - 2011-04-30 23:13:50 --> Config Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:13:50 --> URI Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Router Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Output Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Input Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:13:50 --> Language Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Loader Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:13:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Session Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:13:50 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Session routines successfully run
DEBUG - 2011-04-30 23:13:50 --> Controller Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: file_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: directory_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: assets_helper
DEBUG - 2011-04-30 23:13:50 --> CSSMin library initialized.
DEBUG - 2011-04-30 23:13:50 --> JSMin library initialized.
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Model Class Initialized
DEBUG - 2011-04-30 23:13:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-04-30 23:13:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-04-30 23:13:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-04-30 23:13:50 --> File loaded: application/views/home/spec_format.php
DEBUG - 2011-04-30 23:13:50 --> Final output sent to browser
DEBUG - 2011-04-30 23:13:50 --> Total execution time: 0.0390
DEBUG - 2011-04-30 23:13:50 --> Config Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Hooks Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Utf8 Class Initialized
DEBUG - 2011-04-30 23:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-30 23:13:50 --> URI Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Router Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Output Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Input Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-30 23:13:50 --> Language Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Loader Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: user_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: url_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: array_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: utility_helper
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-04-30 23:13:50 --> Database Driver Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Session Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Helper loaded: string_helper
DEBUG - 2011-04-30 23:13:50 --> Encrypt Class Initialized
DEBUG - 2011-04-30 23:13:50 --> Session routines successfully run
DEBUG - 2011-04-30 23:13:50 --> Controller Class Initialized
DEBUG - 2011-04-30 23:13:50 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-04-30 23:13:50 --> Final output sent to browser
DEBUG - 2011-04-30 23:13:50 --> Total execution time: 0.0260
