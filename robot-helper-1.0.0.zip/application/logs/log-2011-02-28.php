<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-28 09:07:31 --> Config Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:07:31 --> URI Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Router Class Initialized
DEBUG - 2011-02-28 09:07:31 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:07:31 --> Output Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Input Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:07:31 --> Language Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Loader Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:07:31 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:07:31 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:07:31 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:07:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:07:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:07:31 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Session Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:07:31 --> A session cookie was not found.
DEBUG - 2011-02-28 09:07:31 --> Session routines successfully run
DEBUG - 2011-02-28 09:07:31 --> Controller Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:07:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:07:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:07:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:07:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:07:31 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:07:31 --> Final output sent to browser
DEBUG - 2011-02-28 09:07:31 --> Total execution time: 0.0640
DEBUG - 2011-02-28 09:07:34 --> Config Class Initialized
DEBUG - 2011-02-28 09:07:34 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:07:34 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:07:34 --> URI Class Initialized
DEBUG - 2011-02-28 09:07:34 --> Router Class Initialized
ERROR - 2011-02-28 09:07:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-28 09:07:37 --> Config Class Initialized
DEBUG - 2011-02-28 09:07:37 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:07:37 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:07:37 --> URI Class Initialized
DEBUG - 2011-02-28 09:07:37 --> Router Class Initialized
ERROR - 2011-02-28 09:07:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-28 09:13:29 --> Config Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:13:29 --> URI Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Router Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Output Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Input Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:13:29 --> Language Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Loader Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:13:29 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Session Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:13:29 --> Session routines successfully run
DEBUG - 2011-02-28 09:13:29 --> Controller Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Config Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> URI Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Router Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Output Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Input Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Language Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Loader Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:13:29 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Session Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:13:29 --> Session routines successfully run
DEBUG - 2011-02-28 09:13:29 --> Controller Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:13:29 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:13:29 --> Final output sent to browser
DEBUG - 2011-02-28 09:13:29 --> Total execution time: 0.0467
DEBUG - 2011-02-28 09:13:29 --> Final output sent to browser
DEBUG - 2011-02-28 09:13:29 --> Total execution time: 0.0438
DEBUG - 2011-02-28 09:13:39 --> Config Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:13:39 --> URI Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Router Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Output Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Input Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:13:39 --> Language Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Loader Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:13:39 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:13:39 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:13:39 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:13:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:13:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:13:39 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Session Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:13:39 --> Session routines successfully run
DEBUG - 2011-02-28 09:13:39 --> Controller Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:13:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:13:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:13:39 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:13:39 --> Final output sent to browser
DEBUG - 2011-02-28 09:13:39 --> Total execution time: 0.0388
DEBUG - 2011-02-28 09:13:44 --> Config Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:13:44 --> URI Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Router Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Output Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Input Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:13:44 --> Language Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Loader Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:13:44 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:13:44 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:13:44 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:13:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:13:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:13:44 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Session Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:13:44 --> Session routines successfully run
DEBUG - 2011-02-28 09:13:44 --> Controller Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:13:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:13:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:13:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:13:44 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:13:44 --> Final output sent to browser
DEBUG - 2011-02-28 09:13:44 --> Total execution time: 0.0354
DEBUG - 2011-02-28 09:17:04 --> Config Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:17:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:17:04 --> URI Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Router Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Output Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Input Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:17:04 --> Language Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Loader Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:17:04 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:17:04 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:17:04 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:17:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:17:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:17:04 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Session Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:17:04 --> Session routines successfully run
DEBUG - 2011-02-28 09:17:04 --> Controller Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:17:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:17:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:17:04 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:17:04 --> Final output sent to browser
DEBUG - 2011-02-28 09:17:04 --> Total execution time: 0.0378
DEBUG - 2011-02-28 09:17:34 --> Config Class Initialized
DEBUG - 2011-02-28 09:17:34 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:17:34 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:17:34 --> URI Class Initialized
DEBUG - 2011-02-28 09:17:34 --> Router Class Initialized
DEBUG - 2011-02-28 09:17:34 --> Output Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Input Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:17:35 --> Language Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Loader Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:17:35 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:17:35 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:17:35 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:17:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:17:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:17:35 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Session Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:17:35 --> Session routines successfully run
DEBUG - 2011-02-28 09:17:35 --> Controller Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:17:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:17:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:17:35 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:17:35 --> Final output sent to browser
DEBUG - 2011-02-28 09:17:35 --> Total execution time: 0.0476
DEBUG - 2011-02-28 09:17:36 --> Config Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:17:36 --> URI Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Router Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Output Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Input Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:17:36 --> Language Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Loader Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:17:36 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:17:36 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:17:36 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:17:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:17:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:17:36 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Session Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:17:36 --> Session routines successfully run
DEBUG - 2011-02-28 09:17:36 --> Controller Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:17:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:17:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:17:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:17:36 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:17:36 --> Final output sent to browser
DEBUG - 2011-02-28 09:17:36 --> Total execution time: 0.0343
DEBUG - 2011-02-28 09:18:48 --> Config Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:18:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:18:48 --> URI Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Router Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Output Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Input Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:18:48 --> Language Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Loader Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:18:48 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:18:48 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:18:48 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:18:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:18:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:18:48 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Session Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:18:48 --> Session routines successfully run
DEBUG - 2011-02-28 09:18:48 --> Controller Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:18:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:18:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:18:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:18:48 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:18:48 --> Final output sent to browser
DEBUG - 2011-02-28 09:18:48 --> Total execution time: 0.0361
DEBUG - 2011-02-28 09:19:19 --> Config Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:19:19 --> URI Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Router Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Output Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Input Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:19:19 --> Language Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Loader Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:19:19 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:19:19 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:19:19 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:19:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:19:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:19:19 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Session Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:19:19 --> Session routines successfully run
DEBUG - 2011-02-28 09:19:19 --> Controller Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:19:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:19:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:19:19 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:19:19 --> Final output sent to browser
DEBUG - 2011-02-28 09:19:19 --> Total execution time: 0.0554
DEBUG - 2011-02-28 09:19:36 --> Config Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:19:36 --> URI Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Router Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Output Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Input Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:19:36 --> Language Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Loader Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:19:36 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:19:36 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:19:36 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:19:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:19:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:19:36 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Session Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:19:36 --> Session routines successfully run
DEBUG - 2011-02-28 09:19:36 --> Controller Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:19:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:19:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:19:36 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:19:36 --> Final output sent to browser
DEBUG - 2011-02-28 09:19:36 --> Total execution time: 0.0549
DEBUG - 2011-02-28 09:19:52 --> Config Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:19:52 --> URI Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Router Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Output Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Input Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:19:52 --> Language Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Loader Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:19:52 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:19:52 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:19:52 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:19:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:19:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:19:52 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Session Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:19:52 --> Session routines successfully run
DEBUG - 2011-02-28 09:19:52 --> Controller Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:19:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:19:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:19:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:19:52 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:19:52 --> Final output sent to browser
DEBUG - 2011-02-28 09:19:52 --> Total execution time: 0.0395
DEBUG - 2011-02-28 09:20:12 --> Config Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:20:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:20:12 --> URI Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Router Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Output Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Input Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:20:12 --> Language Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Loader Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:20:12 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:20:12 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:20:12 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:20:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:20:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:20:12 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Session Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:20:12 --> Session routines successfully run
DEBUG - 2011-02-28 09:20:12 --> Controller Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:20:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:20:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:20:12 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:20:12 --> Final output sent to browser
DEBUG - 2011-02-28 09:20:12 --> Total execution time: 0.0360
DEBUG - 2011-02-28 09:20:33 --> Config Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:20:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:20:33 --> URI Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Router Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Output Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Input Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:20:33 --> Language Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Loader Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:20:33 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:20:33 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:20:33 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:20:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:20:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:20:33 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Session Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:20:33 --> Session routines successfully run
DEBUG - 2011-02-28 09:20:33 --> Controller Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:20:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:20:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:20:33 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:20:33 --> Final output sent to browser
DEBUG - 2011-02-28 09:20:33 --> Total execution time: 0.0340
DEBUG - 2011-02-28 09:20:58 --> Config Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:20:58 --> URI Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Router Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Output Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Input Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:20:58 --> Language Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Loader Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:20:58 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:20:58 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:20:58 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:20:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:20:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:20:58 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Session Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:20:58 --> Session routines successfully run
DEBUG - 2011-02-28 09:20:58 --> Controller Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:20:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:20:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:20:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:20:58 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:20:58 --> Final output sent to browser
DEBUG - 2011-02-28 09:20:58 --> Total execution time: 0.0944
DEBUG - 2011-02-28 09:21:05 --> Config Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:21:05 --> URI Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Router Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Output Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Input Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:21:05 --> Language Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Loader Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:21:05 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:21:05 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:21:05 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:21:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:21:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:21:05 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Session Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:21:05 --> Session routines successfully run
DEBUG - 2011-02-28 09:21:05 --> Controller Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:21:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:21:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:21:05 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:21:05 --> Final output sent to browser
DEBUG - 2011-02-28 09:21:05 --> Total execution time: 0.0383
DEBUG - 2011-02-28 09:21:50 --> Config Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:21:50 --> URI Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Router Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Output Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Input Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:21:50 --> Language Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Loader Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:21:50 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:21:50 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:21:50 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:21:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:21:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:21:50 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Session Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:21:50 --> Session routines successfully run
DEBUG - 2011-02-28 09:21:50 --> Controller Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:21:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:21:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:21:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:21:50 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:21:50 --> Final output sent to browser
DEBUG - 2011-02-28 09:21:50 --> Total execution time: 0.0348
DEBUG - 2011-02-28 09:22:03 --> Config Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:22:03 --> URI Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Router Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Output Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Input Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:22:03 --> Language Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Loader Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:22:03 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:22:03 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:22:03 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:22:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:22:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:22:03 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Session Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:22:03 --> Session routines successfully run
DEBUG - 2011-02-28 09:22:03 --> Controller Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:22:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:22:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:22:03 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:22:03 --> Final output sent to browser
DEBUG - 2011-02-28 09:22:03 --> Total execution time: 0.0344
DEBUG - 2011-02-28 09:22:37 --> Config Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:22:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:22:37 --> URI Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Router Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Output Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Input Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:22:37 --> Language Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Loader Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:22:37 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:22:37 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:22:37 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:22:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:22:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:22:37 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Session Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:22:37 --> Session routines successfully run
DEBUG - 2011-02-28 09:22:37 --> Controller Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:22:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:22:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:22:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:22:37 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:22:37 --> Final output sent to browser
DEBUG - 2011-02-28 09:22:37 --> Total execution time: 0.0331
DEBUG - 2011-02-28 09:23:38 --> Config Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:23:38 --> URI Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Router Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Output Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Input Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:23:38 --> Language Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Loader Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:23:38 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:23:38 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:23:38 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:23:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:23:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:23:38 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Session Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:23:38 --> Session routines successfully run
DEBUG - 2011-02-28 09:23:38 --> Controller Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> Model Class Initialized
DEBUG - 2011-02-28 09:23:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:23:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:23:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:23:38 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:23:38 --> Final output sent to browser
DEBUG - 2011-02-28 09:23:38 --> Total execution time: 0.0349
DEBUG - 2011-02-28 09:24:08 --> Config Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:24:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:24:08 --> URI Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Router Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Output Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Input Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:24:08 --> Language Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Loader Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:24:08 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:24:08 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:24:08 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:24:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:24:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:24:08 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Session Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:24:08 --> Session routines successfully run
DEBUG - 2011-02-28 09:24:08 --> Controller Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:24:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:24:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:24:08 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:24:08 --> Final output sent to browser
DEBUG - 2011-02-28 09:24:08 --> Total execution time: 0.0376
DEBUG - 2011-02-28 09:24:53 --> Config Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:24:53 --> URI Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Router Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Output Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Input Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:24:53 --> Language Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Loader Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:24:53 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:24:53 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:24:53 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:24:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:24:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:24:53 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Session Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:24:53 --> Session routines successfully run
DEBUG - 2011-02-28 09:24:53 --> Controller Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:24:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:24:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:24:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:24:53 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:24:53 --> Final output sent to browser
DEBUG - 2011-02-28 09:24:53 --> Total execution time: 0.0332
DEBUG - 2011-02-28 09:25:04 --> Config Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:25:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:25:04 --> URI Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Router Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Output Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Input Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:25:04 --> Language Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Loader Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:25:04 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:25:04 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:25:04 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:25:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:25:04 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:25:04 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Session Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:25:04 --> Session routines successfully run
DEBUG - 2011-02-28 09:25:04 --> Controller Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:25:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:25:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:25:04 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:25:04 --> Final output sent to browser
DEBUG - 2011-02-28 09:25:04 --> Total execution time: 0.0327
DEBUG - 2011-02-28 09:25:42 --> Config Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:25:42 --> URI Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Router Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Output Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Input Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:25:42 --> Language Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Loader Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:25:42 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:25:42 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:25:42 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:25:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:25:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:25:42 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Session Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:25:42 --> Session routines successfully run
DEBUG - 2011-02-28 09:25:42 --> Controller Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> Model Class Initialized
DEBUG - 2011-02-28 09:25:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:25:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:25:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:25:42 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:25:42 --> Final output sent to browser
DEBUG - 2011-02-28 09:25:42 --> Total execution time: 0.0360
DEBUG - 2011-02-28 09:27:12 --> Config Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:27:12 --> URI Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Router Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Output Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Input Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:27:12 --> Language Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Loader Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:27:12 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:27:12 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:27:12 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:27:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:27:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:27:12 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Session Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:27:12 --> Session routines successfully run
DEBUG - 2011-02-28 09:27:12 --> Controller Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> Model Class Initialized
DEBUG - 2011-02-28 09:27:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:27:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:27:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:27:12 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:27:12 --> Final output sent to browser
DEBUG - 2011-02-28 09:27:12 --> Total execution time: 0.0346
DEBUG - 2011-02-28 09:28:17 --> Config Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:28:17 --> URI Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Router Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Output Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Input Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:28:17 --> Language Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Loader Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:28:17 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:28:17 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:28:17 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:28:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:28:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:28:17 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Session Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:28:17 --> Session routines successfully run
DEBUG - 2011-02-28 09:28:17 --> Controller Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:28:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:28:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:28:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:28:17 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:28:17 --> Final output sent to browser
DEBUG - 2011-02-28 09:28:17 --> Total execution time: 0.0355
DEBUG - 2011-02-28 09:29:15 --> Config Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:29:15 --> URI Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Router Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Output Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Input Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:29:15 --> Language Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Loader Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:29:15 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:29:15 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:29:15 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:29:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:29:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:29:15 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Session Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:29:15 --> Session routines successfully run
DEBUG - 2011-02-28 09:29:15 --> Controller Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:29:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:29:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:29:15 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:29:15 --> Final output sent to browser
DEBUG - 2011-02-28 09:29:15 --> Total execution time: 0.0328
DEBUG - 2011-02-28 09:29:22 --> Config Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:29:22 --> URI Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Router Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Output Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Input Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:29:22 --> Language Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Loader Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:29:22 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:29:22 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:29:22 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:29:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:29:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:29:22 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Session Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:29:22 --> Session routines successfully run
DEBUG - 2011-02-28 09:29:22 --> Controller Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:29:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:29:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:29:22 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:29:22 --> Final output sent to browser
DEBUG - 2011-02-28 09:29:22 --> Total execution time: 0.0391
DEBUG - 2011-02-28 09:29:53 --> Config Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:29:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:29:53 --> URI Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Router Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Output Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Input Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:29:53 --> Language Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Loader Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:29:53 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:29:53 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:29:53 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:29:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:29:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:29:53 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Session Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:29:53 --> Session routines successfully run
DEBUG - 2011-02-28 09:29:53 --> Controller Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:29:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:29:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:29:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:29:53 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:29:53 --> Final output sent to browser
DEBUG - 2011-02-28 09:29:53 --> Total execution time: 0.0363
DEBUG - 2011-02-28 09:31:11 --> Config Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:31:11 --> URI Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Router Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Output Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Input Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:31:11 --> Language Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Loader Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:31:11 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:31:11 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:31:11 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:31:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:31:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:31:11 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Session Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:31:11 --> Session routines successfully run
DEBUG - 2011-02-28 09:31:11 --> Controller Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:11 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:31:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:31:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:31:11 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-28 09:31:11 --> Final output sent to browser
DEBUG - 2011-02-28 09:31:11 --> Total execution time: 0.0300
DEBUG - 2011-02-28 09:31:40 --> Config Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:31:40 --> URI Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Router Class Initialized
DEBUG - 2011-02-28 09:31:40 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:31:40 --> Output Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Input Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:31:40 --> Language Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Loader Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:31:40 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:31:40 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:31:40 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:31:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:31:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:31:40 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Session Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:31:40 --> Session routines successfully run
DEBUG - 2011-02-28 09:31:40 --> Controller Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:40 --> Model Class Initialized
DEBUG - 2011-02-28 09:31:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:31:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:31:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:31:40 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:31:40 --> Final output sent to browser
DEBUG - 2011-02-28 09:31:40 --> Total execution time: 0.0310
DEBUG - 2011-02-28 09:32:24 --> Config Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:32:24 --> URI Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Router Class Initialized
DEBUG - 2011-02-28 09:32:24 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:32:24 --> Output Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Input Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:32:24 --> Language Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Loader Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:32:24 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:32:24 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:32:24 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:32:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:32:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:32:24 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Session Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:32:24 --> Session routines successfully run
DEBUG - 2011-02-28 09:32:24 --> Controller Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:24 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:32:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:32:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:32:24 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:32:24 --> Final output sent to browser
DEBUG - 2011-02-28 09:32:24 --> Total execution time: 0.0322
DEBUG - 2011-02-28 09:32:53 --> Config Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:32:53 --> URI Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Router Class Initialized
DEBUG - 2011-02-28 09:32:53 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:32:53 --> Output Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Input Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:32:53 --> Language Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Loader Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:32:53 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:32:53 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:32:53 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:32:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:32:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:32:53 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Session Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:32:53 --> Session routines successfully run
DEBUG - 2011-02-28 09:32:53 --> Controller Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:32:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:32:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:32:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:32:53 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:32:53 --> Final output sent to browser
DEBUG - 2011-02-28 09:32:53 --> Total execution time: 0.0294
DEBUG - 2011-02-28 09:33:28 --> Config Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:33:28 --> URI Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Router Class Initialized
DEBUG - 2011-02-28 09:33:28 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:33:28 --> Output Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Input Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:33:28 --> Language Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Loader Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:33:28 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:33:28 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:33:28 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:33:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:33:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:33:28 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Session Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:33:28 --> Session routines successfully run
DEBUG - 2011-02-28 09:33:28 --> Controller Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Model Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Model Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Model Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Model Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Model Class Initialized
DEBUG - 2011-02-28 09:33:28 --> Model Class Initialized
DEBUG - 2011-02-28 09:33:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:33:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:33:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:33:28 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:33:28 --> Final output sent to browser
DEBUG - 2011-02-28 09:33:28 --> Total execution time: 0.0342
DEBUG - 2011-02-28 09:34:05 --> Config Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:34:05 --> URI Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Router Class Initialized
DEBUG - 2011-02-28 09:34:05 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:34:05 --> Output Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Input Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:34:05 --> Language Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Loader Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:34:05 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:34:05 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:34:05 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:34:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:34:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:34:05 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Session Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:34:05 --> Session routines successfully run
DEBUG - 2011-02-28 09:34:05 --> Controller Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:05 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:34:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:34:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:34:05 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:34:05 --> Final output sent to browser
DEBUG - 2011-02-28 09:34:05 --> Total execution time: 0.0304
DEBUG - 2011-02-28 09:34:36 --> Config Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:34:36 --> URI Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Router Class Initialized
DEBUG - 2011-02-28 09:34:36 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:34:36 --> Output Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Input Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:34:36 --> Language Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Loader Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:34:36 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:34:36 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:34:36 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:34:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:34:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:34:36 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Session Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:34:36 --> Session routines successfully run
DEBUG - 2011-02-28 09:34:36 --> Controller Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:36 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:34:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:34:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:34:36 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:34:36 --> Final output sent to browser
DEBUG - 2011-02-28 09:34:36 --> Total execution time: 0.0338
DEBUG - 2011-02-28 09:34:55 --> Config Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:34:55 --> URI Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Router Class Initialized
DEBUG - 2011-02-28 09:34:55 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:34:55 --> Output Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Input Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:34:55 --> Language Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Loader Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:34:55 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:34:55 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:34:55 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:34:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:34:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:34:55 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Session Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:34:55 --> Session routines successfully run
DEBUG - 2011-02-28 09:34:55 --> Controller Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:34:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:34:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:34:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:34:55 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:34:55 --> Final output sent to browser
DEBUG - 2011-02-28 09:34:55 --> Total execution time: 0.0331
DEBUG - 2011-02-28 09:35:17 --> Config Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:35:17 --> URI Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Router Class Initialized
DEBUG - 2011-02-28 09:35:17 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:35:17 --> Output Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Input Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:35:17 --> Language Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Loader Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:35:17 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:35:17 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:35:17 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:35:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:35:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:35:17 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Session Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:35:17 --> Session routines successfully run
DEBUG - 2011-02-28 09:35:17 --> Controller Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:35:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:35:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:35:17 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:35:17 --> Final output sent to browser
DEBUG - 2011-02-28 09:35:17 --> Total execution time: 0.0341
DEBUG - 2011-02-28 09:35:32 --> Config Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:35:32 --> URI Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Router Class Initialized
DEBUG - 2011-02-28 09:35:32 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:35:32 --> Output Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Input Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:35:32 --> Language Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Loader Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:35:32 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:35:32 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:35:32 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:35:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:35:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:35:32 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Session Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:35:32 --> Session routines successfully run
DEBUG - 2011-02-28 09:35:32 --> Controller Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:35:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:35:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:35:32 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:35:32 --> Final output sent to browser
DEBUG - 2011-02-28 09:35:32 --> Total execution time: 0.0343
DEBUG - 2011-02-28 09:35:59 --> Config Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:35:59 --> URI Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Router Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Output Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Input Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:35:59 --> Language Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Loader Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:35:59 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:35:59 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:35:59 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:35:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:35:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:35:59 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Session Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:35:59 --> Session routines successfully run
DEBUG - 2011-02-28 09:35:59 --> Controller Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:35:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:35:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:35:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:35:59 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-28 09:35:59 --> Final output sent to browser
DEBUG - 2011-02-28 09:35:59 --> Total execution time: 0.0302
DEBUG - 2011-02-28 09:36:10 --> Config Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:36:10 --> URI Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Router Class Initialized
DEBUG - 2011-02-28 09:36:10 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:36:10 --> Output Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Input Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:36:10 --> Language Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Loader Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:36:10 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:36:10 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:36:10 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:36:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:36:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:36:10 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Session Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:36:10 --> Session routines successfully run
DEBUG - 2011-02-28 09:36:10 --> Controller Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:10 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:36:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:36:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:36:10 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:36:10 --> Final output sent to browser
DEBUG - 2011-02-28 09:36:10 --> Total execution time: 0.0289
DEBUG - 2011-02-28 09:36:17 --> Config Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:36:17 --> URI Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Router Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Output Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Input Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:36:17 --> Language Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Loader Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:36:17 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:36:17 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:36:17 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:36:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:36:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:36:17 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Session Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:36:17 --> Session routines successfully run
DEBUG - 2011-02-28 09:36:17 --> Controller Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:17 --> Model Class Initialized
DEBUG - 2011-02-28 09:36:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:36:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:36:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:36:17 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-28 09:36:17 --> Final output sent to browser
DEBUG - 2011-02-28 09:36:17 --> Total execution time: 0.0293
DEBUG - 2011-02-28 09:37:45 --> Config Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:37:45 --> URI Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Router Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Output Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Input Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:37:45 --> Language Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Loader Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:37:45 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:37:45 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:37:45 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:37:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:37:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:37:45 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Session Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:37:45 --> Session routines successfully run
DEBUG - 2011-02-28 09:37:45 --> Controller Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:37:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:37:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:37:45 --> File loaded: application/views/home/about.php
DEBUG - 2011-02-28 09:37:45 --> Final output sent to browser
DEBUG - 2011-02-28 09:37:45 --> Total execution time: 0.0376
DEBUG - 2011-02-28 09:37:47 --> Config Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:37:47 --> URI Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Router Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Output Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Input Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:37:47 --> Language Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Loader Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:37:47 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:37:47 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:37:47 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:37:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:37:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:37:47 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Session Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:37:47 --> Session routines successfully run
DEBUG - 2011-02-28 09:37:47 --> Controller Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:37:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:37:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:37:47 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-28 09:37:47 --> Final output sent to browser
DEBUG - 2011-02-28 09:37:47 --> Total execution time: 0.0328
DEBUG - 2011-02-28 09:37:51 --> Config Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:37:51 --> URI Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Router Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Output Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Input Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:37:51 --> Language Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Loader Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:37:51 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:37:51 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:37:51 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:37:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:37:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:37:51 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Session Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:37:51 --> Session routines successfully run
DEBUG - 2011-02-28 09:37:51 --> Controller Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:37:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:37:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:37:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:37:51 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:37:51 --> Final output sent to browser
DEBUG - 2011-02-28 09:37:51 --> Total execution time: 0.0348
DEBUG - 2011-02-28 09:38:35 --> Config Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:38:35 --> URI Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Router Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Output Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Input Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:38:35 --> Language Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Loader Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:38:35 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:38:35 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:38:35 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:38:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:38:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:38:35 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Session Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:38:35 --> Session routines successfully run
DEBUG - 2011-02-28 09:38:35 --> Controller Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:38:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:38:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:38:35 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-28 09:38:35 --> Final output sent to browser
DEBUG - 2011-02-28 09:38:35 --> Total execution time: 0.0361
DEBUG - 2011-02-28 09:38:37 --> Config Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:38:37 --> URI Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Router Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Output Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Input Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:38:37 --> Language Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Loader Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:38:37 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:38:37 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:38:37 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:38:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:38:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:38:37 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Session Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:38:37 --> Session routines successfully run
DEBUG - 2011-02-28 09:38:37 --> Controller Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:38:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:38:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:38:37 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:38:37 --> Final output sent to browser
DEBUG - 2011-02-28 09:38:37 --> Total execution time: 0.0323
DEBUG - 2011-02-28 09:38:45 --> Config Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:38:45 --> URI Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Router Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Output Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Input Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:38:45 --> Language Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Loader Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:38:45 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:38:45 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:38:45 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:38:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:38:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:38:45 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Session Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:38:45 --> Session routines successfully run
DEBUG - 2011-02-28 09:38:45 --> Controller Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:38:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:38:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:38:45 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:38:45 --> Final output sent to browser
DEBUG - 2011-02-28 09:38:45 --> Total execution time: 0.0341
DEBUG - 2011-02-28 09:38:48 --> Config Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:38:48 --> URI Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Router Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Output Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Input Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:38:48 --> Language Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Loader Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:38:48 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:38:48 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:38:48 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:38:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:38:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:38:48 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Session Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:38:48 --> Session routines successfully run
DEBUG - 2011-02-28 09:38:48 --> Controller Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:38:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:38:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:38:48 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:38:48 --> Final output sent to browser
DEBUG - 2011-02-28 09:38:48 --> Total execution time: 0.0313
DEBUG - 2011-02-28 09:38:50 --> Config Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:38:50 --> URI Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Router Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Output Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Input Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:38:50 --> Language Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Loader Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:38:50 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:38:50 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:38:50 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:38:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:38:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:38:50 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Session Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:38:50 --> Session routines successfully run
DEBUG - 2011-02-28 09:38:50 --> Controller Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:38:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:38:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:38:50 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-28 09:38:50 --> Final output sent to browser
DEBUG - 2011-02-28 09:38:50 --> Total execution time: 0.0312
DEBUG - 2011-02-28 09:38:54 --> Config Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:38:54 --> URI Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Router Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Output Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Input Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:38:54 --> Language Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Loader Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:38:54 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:38:54 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:38:54 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:38:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:38:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:38:54 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Session Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:38:54 --> Session routines successfully run
DEBUG - 2011-02-28 09:38:54 --> Controller Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:38:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:38:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:38:54 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-28 09:38:54 --> Final output sent to browser
DEBUG - 2011-02-28 09:38:54 --> Total execution time: 0.0301
DEBUG - 2011-02-28 09:38:58 --> Config Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:38:58 --> URI Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Router Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Output Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Input Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:38:58 --> Language Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Loader Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:38:58 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:38:58 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:38:58 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:38:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:38:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:38:58 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Session Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:38:58 --> Session routines successfully run
DEBUG - 2011-02-28 09:38:58 --> Controller Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-02-28 09:38:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:38:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:38:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:38:58 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-28 09:38:58 --> Final output sent to browser
DEBUG - 2011-02-28 09:38:58 --> Total execution time: 0.0273
DEBUG - 2011-02-28 09:39:17 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:17 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:18 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:18 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:18 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:18 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:18 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:18 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:18 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:18 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:18 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-28 09:39:18 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:18 --> Total execution time: 0.0362
DEBUG - 2011-02-28 09:39:31 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:31 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:31 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:39:31 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:31 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:31 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:31 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:31 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:31 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:31 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:31 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:31 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:39:31 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:31 --> Total execution time: 0.0292
DEBUG - 2011-02-28 09:39:48 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:48 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:48 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:48 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:48 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:48 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:48 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:48 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:48 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:48 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-28 09:39:48 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:48 --> Total execution time: 0.0340
DEBUG - 2011-02-28 09:39:49 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:49 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:49 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:49 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:49 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:49 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:49 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:49 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:49 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:49 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-28 09:39:49 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:49 --> Total execution time: 0.0290
DEBUG - 2011-02-28 09:39:50 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:50 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:50 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:50 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:50 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:50 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:50 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:50 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:50 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:50 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-28 09:39:50 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:50 --> Total execution time: 0.0287
DEBUG - 2011-02-28 09:39:52 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:52 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:52 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:52 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:52 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:52 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:52 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:52 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:52 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:52 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:52 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-28 09:39:52 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:52 --> Total execution time: 0.0284
DEBUG - 2011-02-28 09:39:53 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:53 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:53 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:53 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:53 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:53 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:53 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:53 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:53 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:53 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-28 09:39:53 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:53 --> Total execution time: 0.0288
DEBUG - 2011-02-28 09:39:54 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:54 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:54 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:54 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:54 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:54 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:54 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:54 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:54 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:54 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-28 09:39:54 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:54 --> Total execution time: 0.0291
DEBUG - 2011-02-28 09:39:55 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:55 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:55 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:55 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:55 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:55 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:55 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:55 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:55 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:55 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-28 09:39:55 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:55 --> Total execution time: 0.0309
DEBUG - 2011-02-28 09:39:56 --> Config Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:39:56 --> URI Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Router Class Initialized
DEBUG - 2011-02-28 09:39:56 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:39:56 --> Output Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Input Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:39:56 --> Language Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Loader Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:39:56 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:39:56 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:39:56 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:39:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:39:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:39:56 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Session Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:39:56 --> Session routines successfully run
DEBUG - 2011-02-28 09:39:56 --> Controller Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:56 --> Model Class Initialized
DEBUG - 2011-02-28 09:39:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:39:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:39:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:39:56 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:39:56 --> Final output sent to browser
DEBUG - 2011-02-28 09:39:56 --> Total execution time: 0.0292
DEBUG - 2011-02-28 09:42:51 --> Config Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:42:51 --> URI Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Router Class Initialized
DEBUG - 2011-02-28 09:42:51 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:42:51 --> Output Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Input Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:42:51 --> Language Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Loader Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:42:51 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:42:51 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:42:51 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:42:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:42:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:42:51 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Session Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:42:51 --> Session routines successfully run
DEBUG - 2011-02-28 09:42:51 --> Controller Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:51 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:42:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:42:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:42:51 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:42:51 --> Final output sent to browser
DEBUG - 2011-02-28 09:42:51 --> Total execution time: 0.0327
DEBUG - 2011-02-28 09:42:55 --> Config Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:42:55 --> URI Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Router Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Output Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Input Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:42:55 --> Language Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Loader Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:42:55 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:42:55 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:42:55 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:42:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:42:55 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:42:55 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Session Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:42:55 --> Session routines successfully run
DEBUG - 2011-02-28 09:42:55 --> Controller Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:55 --> Model Class Initialized
DEBUG - 2011-02-28 09:42:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:42:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:42:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:42:55 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-28 09:42:55 --> Final output sent to browser
DEBUG - 2011-02-28 09:42:55 --> Total execution time: 0.0290
DEBUG - 2011-02-28 09:44:59 --> Config Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:44:59 --> URI Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Router Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Output Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Input Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:44:59 --> Language Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Loader Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:44:59 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:44:59 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:44:59 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:44:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:44:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:44:59 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Session Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:44:59 --> Session routines successfully run
DEBUG - 2011-02-28 09:44:59 --> Controller Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:44:59 --> Model Class Initialized
DEBUG - 2011-02-28 09:44:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:44:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:44:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:44:59 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-28 09:44:59 --> Final output sent to browser
DEBUG - 2011-02-28 09:44:59 --> Total execution time: 0.0268
DEBUG - 2011-02-28 09:45:31 --> Config Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:45:31 --> URI Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Router Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Output Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Input Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:45:31 --> Language Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Loader Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:45:31 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:45:31 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:45:31 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:45:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:45:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:45:31 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Session Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:45:31 --> Session routines successfully run
DEBUG - 2011-02-28 09:45:31 --> Controller Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:45:31 --> Model Class Initialized
DEBUG - 2011-02-28 09:45:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:45:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:45:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:45:31 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-28 09:45:31 --> Final output sent to browser
DEBUG - 2011-02-28 09:45:31 --> Total execution time: 0.0395
DEBUG - 2011-02-28 09:46:32 --> Config Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:46:32 --> URI Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Router Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Output Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Input Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:46:32 --> Language Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Loader Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:46:32 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:46:32 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:46:32 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:46:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:46:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:46:32 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Session Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:46:32 --> Session routines successfully run
DEBUG - 2011-02-28 09:46:32 --> Controller Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:46:32 --> Model Class Initialized
DEBUG - 2011-02-28 09:46:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:46:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:46:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:46:32 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-28 09:46:32 --> Final output sent to browser
DEBUG - 2011-02-28 09:46:32 --> Total execution time: 0.0298
DEBUG - 2011-02-28 09:47:23 --> Config Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:47:23 --> URI Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Router Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Output Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Input Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:47:23 --> Language Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Loader Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:47:23 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:47:23 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:47:23 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:47:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:47:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:47:23 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Session Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:47:23 --> Session routines successfully run
DEBUG - 2011-02-28 09:47:23 --> Controller Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:23 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:47:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:47:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:47:23 --> File loaded: application/views/home/contact.php
DEBUG - 2011-02-28 09:47:23 --> Final output sent to browser
DEBUG - 2011-02-28 09:47:23 --> Total execution time: 0.0323
DEBUG - 2011-02-28 09:47:43 --> Config Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:47:43 --> URI Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Router Class Initialized
DEBUG - 2011-02-28 09:47:43 --> No URI present. Default controller set.
DEBUG - 2011-02-28 09:47:43 --> Output Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Input Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:47:43 --> Language Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Loader Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:47:43 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:47:43 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:47:43 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:47:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:47:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:47:43 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Session Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:47:43 --> Session routines successfully run
DEBUG - 2011-02-28 09:47:43 --> Controller Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:43 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:47:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:47:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:47:43 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-28 09:47:43 --> Final output sent to browser
DEBUG - 2011-02-28 09:47:43 --> Total execution time: 0.0338
DEBUG - 2011-02-28 09:47:44 --> Config Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:47:44 --> URI Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Router Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Output Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Input Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:47:44 --> Language Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Loader Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:47:44 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:47:44 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:47:44 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:47:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:47:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:47:44 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Session Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:47:44 --> Session routines successfully run
DEBUG - 2011-02-28 09:47:44 --> Controller Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:47:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:47:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:47:44 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-02-28 09:47:44 --> Final output sent to browser
DEBUG - 2011-02-28 09:47:44 --> Total execution time: 0.0321
DEBUG - 2011-02-28 09:47:45 --> Config Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:47:45 --> URI Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Router Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Output Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Input Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:47:45 --> Language Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Loader Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:47:45 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:47:45 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:47:45 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:47:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:47:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:47:45 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Session Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:47:45 --> Session routines successfully run
DEBUG - 2011-02-28 09:47:45 --> Controller Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:45 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:47:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:47:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:47:45 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-28 09:47:45 --> Final output sent to browser
DEBUG - 2011-02-28 09:47:45 --> Total execution time: 0.0289
DEBUG - 2011-02-28 09:47:46 --> Config Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:47:46 --> URI Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Router Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Output Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Input Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:47:46 --> Language Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Loader Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:47:46 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:47:46 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:47:46 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:47:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:47:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:47:46 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Session Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:47:46 --> Session routines successfully run
DEBUG - 2011-02-28 09:47:46 --> Controller Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:46 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:47:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:47:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:47:46 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-28 09:47:46 --> Final output sent to browser
DEBUG - 2011-02-28 09:47:46 --> Total execution time: 0.0292
DEBUG - 2011-02-28 09:47:48 --> Config Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:47:48 --> URI Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Router Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Output Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Input Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:47:48 --> Language Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Loader Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:47:48 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:47:48 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:47:48 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:47:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:47:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:47:48 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Session Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:47:48 --> Session routines successfully run
DEBUG - 2011-02-28 09:47:48 --> Controller Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:48 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:47:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:47:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:47:48 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-28 09:47:48 --> Final output sent to browser
DEBUG - 2011-02-28 09:47:48 --> Total execution time: 0.0292
DEBUG - 2011-02-28 09:47:49 --> Config Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:47:49 --> URI Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Router Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Output Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Input Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:47:49 --> Language Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Loader Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:47:49 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Session Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:47:49 --> Session routines successfully run
DEBUG - 2011-02-28 09:47:49 --> Controller Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: robot_helper
DEBUG - 2011-02-28 09:47:49 --> Helper loaded: form_helper
DEBUG - 2011-02-28 09:47:49 --> Form Validation Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:49 --> Model Class Initialized
DEBUG - 2011-02-28 09:47:49 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:47:49 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:47:49 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:47:49 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-28 09:47:49 --> Final output sent to browser
DEBUG - 2011-02-28 09:47:49 --> Total execution time: 0.0360
DEBUG - 2011-02-28 09:49:54 --> Config Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Hooks Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Utf8 Class Initialized
DEBUG - 2011-02-28 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-28 09:49:54 --> URI Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Router Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Output Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Input Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-28 09:49:54 --> Language Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Loader Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: user_helper
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: url_helper
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: array_helper
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-28 09:49:54 --> Database Driver Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Session Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: string_helper
DEBUG - 2011-02-28 09:49:54 --> Session routines successfully run
DEBUG - 2011-02-28 09:49:54 --> Controller Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: robot_helper
DEBUG - 2011-02-28 09:49:54 --> Helper loaded: form_helper
DEBUG - 2011-02-28 09:49:54 --> Form Validation Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:49:54 --> Model Class Initialized
DEBUG - 2011-02-28 09:49:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-28 09:49:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-28 09:49:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-28 09:49:54 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-28 09:49:54 --> Final output sent to browser
DEBUG - 2011-02-28 09:49:54 --> Total execution time: 0.0355
