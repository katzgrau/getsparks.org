<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-21 09:47:23 --> Config Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:47:23 --> URI Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Router Class Initialized
DEBUG - 2011-03-21 09:47:23 --> No URI present. Default controller set.
DEBUG - 2011-03-21 09:47:23 --> Output Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Input Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:47:23 --> Language Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Loader Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:47:23 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Session Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:47:23 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Session routines successfully run
DEBUG - 2011-03-21 09:47:23 --> Controller Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: file_helper
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 09:47:23 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 09:47:23 --> CSSMin library initialized.
DEBUG - 2011-03-21 09:47:23 --> JSMin library initialized.
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
ERROR - 2011-03-21 09:47:23 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:23 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 09:47:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 09:47:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 09:47:23 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-21 09:47:23 --> Final output sent to browser
DEBUG - 2011-03-21 09:47:23 --> Total execution time: 0.0561
DEBUG - 2011-03-21 09:47:25 --> Config Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:47:25 --> URI Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Router Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Output Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Input Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:47:25 --> Language Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Loader Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:47:25 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:47:25 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:47:25 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:47:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:47:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:47:25 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Session Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:47:25 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:47:25 --> Session routines successfully run
DEBUG - 2011-03-21 09:47:25 --> Controller Class Initialized
DEBUG - 2011-03-21 09:47:25 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 09:47:25 --> Final output sent to browser
DEBUG - 2011-03-21 09:47:25 --> Total execution time: 0.0258
DEBUG - 2011-03-21 09:47:29 --> Config Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:47:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:47:29 --> URI Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Router Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Output Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Input Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:47:29 --> Language Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Loader Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:47:29 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Session Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:47:29 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Session routines successfully run
DEBUG - 2011-03-21 09:47:29 --> Controller Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: form_helper
DEBUG - 2011-03-21 09:47:29 --> Form Validation Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: file_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 09:47:29 --> CSSMin library initialized.
DEBUG - 2011-03-21 09:47:29 --> JSMin library initialized.
ERROR - 2011-03-21 09:47:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Model Class Initialized
DEBUG - 2011-03-21 09:47:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 09:47:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 09:47:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 09:47:29 --> File loaded: application/views/packages/add.php
DEBUG - 2011-03-21 09:47:29 --> Final output sent to browser
DEBUG - 2011-03-21 09:47:29 --> Total execution time: 0.0497
DEBUG - 2011-03-21 09:47:29 --> Config Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:47:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:47:29 --> URI Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Router Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Output Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Input Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:47:29 --> Language Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Loader Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:47:29 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Session Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:47:29 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:47:29 --> Session routines successfully run
DEBUG - 2011-03-21 09:47:29 --> Controller Class Initialized
DEBUG - 2011-03-21 09:47:29 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 09:47:29 --> Final output sent to browser
DEBUG - 2011-03-21 09:47:29 --> Total execution time: 0.0226
DEBUG - 2011-03-21 09:48:25 --> Config Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:48:25 --> URI Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Router Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Output Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Input Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:48:25 --> Language Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Loader Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:48:25 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Session Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:48:25 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Session routines successfully run
DEBUG - 2011-03-21 09:48:25 --> Controller Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: form_helper
DEBUG - 2011-03-21 09:48:25 --> Form Validation Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Config Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:48:25 --> URI Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Router Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Output Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Input Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:48:25 --> Language Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Loader Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:48:25 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Session Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:48:25 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Session routines successfully run
DEBUG - 2011-03-21 09:48:25 --> Controller Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: file_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 09:48:25 --> CSSMin library initialized.
DEBUG - 2011-03-21 09:48:25 --> JSMin library initialized.
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 09:48:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 09:48:25 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-21 09:48:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 09:48:25 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-21 09:48:25 --> Final output sent to browser
DEBUG - 2011-03-21 09:48:25 --> Total execution time: 0.0508
DEBUG - 2011-03-21 09:48:25 --> Config Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:48:25 --> URI Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Router Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Output Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Input Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:48:25 --> Language Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Loader Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:48:25 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Session Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:48:25 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:48:25 --> Session routines successfully run
DEBUG - 2011-03-21 09:48:25 --> Controller Class Initialized
DEBUG - 2011-03-21 09:48:25 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 09:48:25 --> Final output sent to browser
DEBUG - 2011-03-21 09:48:25 --> Total execution time: 0.0231
DEBUG - 2011-03-21 09:48:31 --> Config Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:48:31 --> URI Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Router Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Output Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Input Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:48:31 --> Language Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Loader Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:48:31 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Session Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:48:31 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Session routines successfully run
DEBUG - 2011-03-21 09:48:31 --> Controller Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: form_helper
DEBUG - 2011-03-21 09:48:31 --> Form Validation Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Config Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:48:31 --> URI Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Router Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Output Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Input Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:48:31 --> Language Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Loader Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:48:31 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Session Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:48:31 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Session routines successfully run
DEBUG - 2011-03-21 09:48:31 --> Controller Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: file_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 09:48:31 --> CSSMin library initialized.
DEBUG - 2011-03-21 09:48:31 --> JSMin library initialized.
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Model Class Initialized
DEBUG - 2011-03-21 09:48:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 09:48:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 09:48:31 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-21 09:48:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 09:48:31 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-21 09:48:31 --> Final output sent to browser
DEBUG - 2011-03-21 09:48:31 --> Total execution time: 0.0482
DEBUG - 2011-03-21 09:48:31 --> Config Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:48:31 --> URI Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Router Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Output Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Input Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:48:31 --> Language Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Loader Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:48:31 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Session Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:48:31 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:48:31 --> Session routines successfully run
DEBUG - 2011-03-21 09:48:31 --> Controller Class Initialized
DEBUG - 2011-03-21 09:48:31 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 09:48:31 --> Final output sent to browser
DEBUG - 2011-03-21 09:48:31 --> Total execution time: 0.0227
DEBUG - 2011-03-21 09:50:39 --> Config Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Hooks Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Utf8 Class Initialized
DEBUG - 2011-03-21 09:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 09:50:39 --> URI Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Router Class Initialized
DEBUG - 2011-03-21 09:50:39 --> No URI present. Default controller set.
DEBUG - 2011-03-21 09:50:39 --> Output Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Input Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 09:50:39 --> Language Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Loader Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 09:50:39 --> Helper loaded: user_helper
DEBUG - 2011-03-21 09:50:39 --> Helper loaded: url_helper
DEBUG - 2011-03-21 09:50:39 --> Helper loaded: array_helper
DEBUG - 2011-03-21 09:50:39 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 09:50:39 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 09:50:39 --> Database Driver Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Session Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Helper loaded: string_helper
DEBUG - 2011-03-21 09:50:39 --> Encrypt Class Initialized
DEBUG - 2011-03-21 09:50:39 --> A session cookie was not found.
DEBUG - 2011-03-21 09:50:39 --> Session routines successfully run
DEBUG - 2011-03-21 09:50:39 --> Controller Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Final output sent to browser
DEBUG - 2011-03-21 09:50:39 --> Total execution time: 0.0259
DEBUG - 2011-03-21 09:50:39 --> Model Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Model Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Model Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 09:50:39 --> Model Class Initialized
DEBUG - 2011-03-21 09:50:39 --> Model Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Config Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:28:57 --> URI Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Router Class Initialized
DEBUG - 2011-03-21 18:28:57 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:28:57 --> Output Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Input Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:28:57 --> Language Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Loader Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:28:57 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:28:57 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:28:57 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:28:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:28:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:28:57 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Session Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:28:57 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:28:57 --> A session cookie was not found.
DEBUG - 2011-03-21 18:28:57 --> Session routines successfully run
DEBUG - 2011-03-21 18:28:57 --> Controller Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Final output sent to browser
DEBUG - 2011-03-21 18:28:57 --> Total execution time: 0.0256
DEBUG - 2011-03-21 18:28:57 --> Model Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Model Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Model Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:28:57 --> Model Class Initialized
DEBUG - 2011-03-21 18:28:57 --> Model Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Config Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:31:30 --> URI Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Router Class Initialized
DEBUG - 2011-03-21 18:31:30 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:31:30 --> Output Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Input Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:31:30 --> Language Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Loader Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:31:30 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:31:30 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:31:30 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:31:30 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:31:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:31:30 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Session Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:31:30 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:31:30 --> A session cookie was not found.
DEBUG - 2011-03-21 18:31:30 --> Session routines successfully run
DEBUG - 2011-03-21 18:31:30 --> Controller Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Final output sent to browser
DEBUG - 2011-03-21 18:31:30 --> Total execution time: 0.0252
DEBUG - 2011-03-21 18:31:30 --> Model Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Model Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Model Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:31:30 --> Model Class Initialized
DEBUG - 2011-03-21 18:31:30 --> Model Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Config Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:32:36 --> URI Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Router Class Initialized
DEBUG - 2011-03-21 18:32:36 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:32:36 --> Output Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Input Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:32:36 --> Language Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Loader Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:32:36 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:32:36 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:32:36 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:32:36 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:32:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:32:36 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Session Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:32:36 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:32:36 --> A session cookie was not found.
DEBUG - 2011-03-21 18:32:36 --> Session routines successfully run
DEBUG - 2011-03-21 18:32:36 --> Controller Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Final output sent to browser
DEBUG - 2011-03-21 18:32:36 --> Total execution time: 0.0279
DEBUG - 2011-03-21 18:32:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:32:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:32:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Config Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:35:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:35:35 --> URI Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Router Class Initialized
DEBUG - 2011-03-21 18:35:35 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:35:35 --> Output Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Input Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:35:35 --> Language Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Loader Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:35:35 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:35:35 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:35:35 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:35:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:35:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:35:35 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Session Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:35:35 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:35:35 --> A session cookie was not found.
DEBUG - 2011-03-21 18:35:35 --> Session routines successfully run
DEBUG - 2011-03-21 18:35:35 --> Controller Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Final output sent to browser
DEBUG - 2011-03-21 18:35:35 --> Total execution time: 0.0255
DEBUG - 2011-03-21 18:35:35 --> Model Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Model Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Model Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:35:35 --> Model Class Initialized
DEBUG - 2011-03-21 18:35:35 --> Model Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Config Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:37:13 --> URI Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Router Class Initialized
DEBUG - 2011-03-21 18:37:13 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:37:13 --> Output Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Input Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:37:13 --> Language Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Loader Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:37:13 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:37:13 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:37:13 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:37:13 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:37:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:37:13 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Session Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:37:13 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:37:13 --> A session cookie was not found.
DEBUG - 2011-03-21 18:37:13 --> Session routines successfully run
DEBUG - 2011-03-21 18:37:13 --> Controller Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Final output sent to browser
DEBUG - 2011-03-21 18:37:13 --> Total execution time: 0.0261
DEBUG - 2011-03-21 18:37:13 --> Model Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Model Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Model Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:37:13 --> Model Class Initialized
DEBUG - 2011-03-21 18:37:13 --> Model Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Config Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:42:36 --> URI Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Router Class Initialized
DEBUG - 2011-03-21 18:42:36 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:42:36 --> Output Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Input Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:42:36 --> Language Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Loader Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:42:36 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:42:36 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:42:36 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:42:36 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:42:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:42:36 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Session Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:42:36 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:42:36 --> A session cookie was not found.
DEBUG - 2011-03-21 18:42:36 --> Session routines successfully run
DEBUG - 2011-03-21 18:42:36 --> Controller Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Final output sent to browser
DEBUG - 2011-03-21 18:42:36 --> Total execution time: 0.0253
DEBUG - 2011-03-21 18:42:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:42:36 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:42:36 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Config Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:53:46 --> URI Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Router Class Initialized
DEBUG - 2011-03-21 18:53:46 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:53:46 --> Output Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Input Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:53:46 --> Language Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Loader Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:53:46 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Session Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:53:46 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Session routines successfully run
DEBUG - 2011-03-21 18:53:46 --> Controller Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: file_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 18:53:46 --> CSSMin library initialized.
DEBUG - 2011-03-21 18:53:46 --> JSMin library initialized.
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
ERROR - 2011-03-21 18:53:46 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 18:53:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 18:53:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 18:53:46 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-21 18:53:46 --> Final output sent to browser
DEBUG - 2011-03-21 18:53:46 --> Total execution time: 0.0549
DEBUG - 2011-03-21 18:53:46 --> Config Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:53:46 --> URI Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Router Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Output Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Input Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:53:46 --> Language Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Loader Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:53:46 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Session Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:53:46 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:53:46 --> Session routines successfully run
DEBUG - 2011-03-21 18:53:46 --> Controller Class Initialized
DEBUG - 2011-03-21 18:53:46 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 18:53:46 --> Final output sent to browser
DEBUG - 2011-03-21 18:53:46 --> Total execution time: 0.0227
DEBUG - 2011-03-21 18:53:52 --> Config Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:53:52 --> URI Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Router Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Output Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Input Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:53:52 --> Language Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Loader Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:53:52 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Session Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:53:52 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Session routines successfully run
DEBUG - 2011-03-21 18:53:52 --> Controller Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: file_helper
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 18:53:52 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 18:53:52 --> CSSMin library initialized.
DEBUG - 2011-03-21 18:53:52 --> JSMin library initialized.
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 18:53:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 18:53:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 18:53:52 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-03-21 18:53:52 --> Final output sent to browser
DEBUG - 2011-03-21 18:53:52 --> Total execution time: 0.0475
DEBUG - 2011-03-21 18:53:53 --> Config Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:53:53 --> URI Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Router Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Output Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Input Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:53:53 --> Language Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Loader Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:53:53 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:53:53 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:53:53 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:53:53 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:53:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:53:53 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Session Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:53:53 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:53:53 --> Session routines successfully run
DEBUG - 2011-03-21 18:53:53 --> Controller Class Initialized
DEBUG - 2011-03-21 18:53:53 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 18:53:53 --> Final output sent to browser
DEBUG - 2011-03-21 18:53:53 --> Total execution time: 0.0229
DEBUG - 2011-03-21 18:53:56 --> Config Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:53:56 --> URI Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Router Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Output Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Input Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:53:56 --> Language Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Loader Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:53:56 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Session Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:53:56 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Session routines successfully run
DEBUG - 2011-03-21 18:53:56 --> Controller Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: file_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 18:53:56 --> CSSMin library initialized.
DEBUG - 2011-03-21 18:53:56 --> JSMin library initialized.
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Model Class Initialized
DEBUG - 2011-03-21 18:53:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 18:53:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 18:53:56 --> User Agent Class Initialized
DEBUG - 2011-03-21 18:53:56 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-03-21 18:53:56 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-21 18:53:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 18:53:56 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-21 18:53:56 --> Final output sent to browser
DEBUG - 2011-03-21 18:53:56 --> Total execution time: 0.0556
DEBUG - 2011-03-21 18:53:56 --> Config Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:53:56 --> URI Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Router Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Output Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Input Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:53:56 --> Language Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Loader Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:53:56 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Session Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:53:56 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:53:56 --> Session routines successfully run
DEBUG - 2011-03-21 18:53:56 --> Controller Class Initialized
DEBUG - 2011-03-21 18:53:56 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 18:53:56 --> Final output sent to browser
DEBUG - 2011-03-21 18:53:56 --> Total execution time: 0.0227
DEBUG - 2011-03-21 18:54:02 --> Config Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:54:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:54:02 --> URI Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Router Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Output Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Input Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:54:02 --> Language Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Loader Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:54:02 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Session Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:54:02 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Session routines successfully run
DEBUG - 2011-03-21 18:54:02 --> Controller Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: form_helper
DEBUG - 2011-03-21 18:54:02 --> Form Validation Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2011-03-21 18:54:02 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Config Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:54:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:54:02 --> URI Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Router Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Output Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Input Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:54:02 --> Language Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Loader Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:54:02 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Session Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:54:02 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Session routines successfully run
DEBUG - 2011-03-21 18:54:02 --> Controller Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: file_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 18:54:02 --> CSSMin library initialized.
DEBUG - 2011-03-21 18:54:02 --> JSMin library initialized.
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 18:54:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 18:54:02 --> User Agent Class Initialized
DEBUG - 2011-03-21 18:54:02 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-03-21 18:54:02 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-21 18:54:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 18:54:02 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-21 18:54:02 --> Final output sent to browser
DEBUG - 2011-03-21 18:54:02 --> Total execution time: 0.0500
DEBUG - 2011-03-21 18:54:02 --> Config Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:54:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:54:02 --> URI Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Router Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Output Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Input Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:54:02 --> Language Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Loader Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:54:02 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Session Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:54:02 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:54:02 --> Session routines successfully run
DEBUG - 2011-03-21 18:54:02 --> Controller Class Initialized
DEBUG - 2011-03-21 18:54:02 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 18:54:02 --> Final output sent to browser
DEBUG - 2011-03-21 18:54:02 --> Total execution time: 0.0229
DEBUG - 2011-03-21 18:54:25 --> Config Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:54:25 --> URI Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Router Class Initialized
DEBUG - 2011-03-21 18:54:25 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:54:25 --> Output Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Input Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:54:25 --> Language Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Loader Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:54:25 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:54:25 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:54:25 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:54:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:54:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:54:25 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Session Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:54:25 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:54:25 --> A session cookie was not found.
DEBUG - 2011-03-21 18:54:25 --> Session routines successfully run
DEBUG - 2011-03-21 18:54:25 --> Controller Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Final output sent to browser
DEBUG - 2011-03-21 18:54:25 --> Total execution time: 0.0254
DEBUG - 2011-03-21 18:54:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:54:25 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:54:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Config Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:56:25 --> URI Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Router Class Initialized
DEBUG - 2011-03-21 18:56:25 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:56:25 --> Output Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Input Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:56:25 --> Language Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Loader Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:56:25 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:56:25 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:56:25 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:56:25 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:56:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:56:25 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Session Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:56:25 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:56:25 --> A session cookie was not found.
DEBUG - 2011-03-21 18:56:25 --> Session routines successfully run
DEBUG - 2011-03-21 18:56:25 --> Controller Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Final output sent to browser
DEBUG - 2011-03-21 18:56:25 --> Total execution time: 0.0249
DEBUG - 2011-03-21 18:56:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:56:25 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:56:25 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Config Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:59:02 --> URI Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Router Class Initialized
DEBUG - 2011-03-21 18:59:02 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:59:02 --> Output Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Input Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:59:02 --> Language Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Loader Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:59:02 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:59:02 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:59:02 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:59:02 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:59:02 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:59:02 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Session Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:59:02 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:59:02 --> A session cookie was not found.
DEBUG - 2011-03-21 18:59:02 --> Session routines successfully run
DEBUG - 2011-03-21 18:59:02 --> Controller Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Final output sent to browser
DEBUG - 2011-03-21 18:59:02 --> Total execution time: 0.0255
DEBUG - 2011-03-21 18:59:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:02 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:59:02 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Config Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Hooks Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Utf8 Class Initialized
DEBUG - 2011-03-21 18:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 18:59:17 --> URI Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Router Class Initialized
DEBUG - 2011-03-21 18:59:17 --> No URI present. Default controller set.
DEBUG - 2011-03-21 18:59:17 --> Output Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Input Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 18:59:17 --> Language Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Loader Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 18:59:17 --> Helper loaded: user_helper
DEBUG - 2011-03-21 18:59:17 --> Helper loaded: url_helper
DEBUG - 2011-03-21 18:59:17 --> Helper loaded: array_helper
DEBUG - 2011-03-21 18:59:17 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 18:59:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 18:59:17 --> Database Driver Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Session Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Helper loaded: string_helper
DEBUG - 2011-03-21 18:59:17 --> Encrypt Class Initialized
DEBUG - 2011-03-21 18:59:17 --> A session cookie was not found.
DEBUG - 2011-03-21 18:59:17 --> Session routines successfully run
DEBUG - 2011-03-21 18:59:17 --> Controller Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Final output sent to browser
DEBUG - 2011-03-21 18:59:17 --> Total execution time: 0.0251
DEBUG - 2011-03-21 18:59:17 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Model Class Initialized
DEBUG - 2011-03-21 18:59:17 --> Helper loaded: markdown_helper
DEBUG - 2011-03-21 18:59:17 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Config Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:19:48 --> URI Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Router Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Output Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Input Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:19:48 --> Language Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Loader Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:19:48 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Session Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:19:48 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Session routines successfully run
DEBUG - 2011-03-21 19:19:48 --> Controller Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
ERROR - 2011-03-21 19:19:48 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: file_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 19:19:48 --> CSSMin library initialized.
DEBUG - 2011-03-21 19:19:48 --> JSMin library initialized.
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Model Class Initialized
DEBUG - 2011-03-21 19:19:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 19:19:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 19:19:48 --> User Agent Class Initialized
DEBUG - 2011-03-21 19:19:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-03-21 19:19:48 --> User_agent class already loaded. Second attempt ignored.
DEBUG - 2011-03-21 19:19:48 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-21 19:19:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 19:19:48 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-21 19:19:48 --> Final output sent to browser
DEBUG - 2011-03-21 19:19:48 --> Total execution time: 0.0605
DEBUG - 2011-03-21 19:19:48 --> Config Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:19:48 --> URI Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Router Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Output Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Input Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:19:48 --> Language Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Loader Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:19:48 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Session Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:19:48 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:19:48 --> Session routines successfully run
DEBUG - 2011-03-21 19:19:48 --> Controller Class Initialized
DEBUG - 2011-03-21 19:19:48 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 19:19:48 --> Final output sent to browser
DEBUG - 2011-03-21 19:19:48 --> Total execution time: 0.0227
DEBUG - 2011-03-21 19:21:35 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:35 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:35 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:35 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:35 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:35 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: file_helper
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 19:21:35 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 19:21:35 --> CSSMin library initialized.
DEBUG - 2011-03-21 19:21:35 --> JSMin library initialized.
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 19:21:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 19:21:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 19:21:35 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-21 19:21:35 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:35 --> Total execution time: 0.0435
DEBUG - 2011-03-21 19:21:36 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:36 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:36 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:36 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:36 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:36 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:36 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:36 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:36 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:36 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:36 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:36 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 19:21:36 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:36 --> Total execution time: 0.0279
DEBUG - 2011-03-21 19:21:37 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:37 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:37 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:37 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:37 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:37 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: file_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 19:21:37 --> CSSMin library initialized.
DEBUG - 2011-03-21 19:21:37 --> JSMin library initialized.
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 19:21:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: rating_helper
DEBUG - 2011-03-21 19:21:37 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 19:21:37 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-21 19:21:37 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:37 --> Total execution time: 0.0715
DEBUG - 2011-03-21 19:21:37 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:37 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:37 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:37 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:37 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:37 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:37 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:37 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 19:21:37 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:37 --> Total execution time: 0.0304
DEBUG - 2011-03-21 19:21:41 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:41 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:41 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:41 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:41 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:41 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:41 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:41 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:41 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:41 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:41 --> Helper loaded: rating_helper
DEBUG - 2011-03-21 19:21:41 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:41 --> Total execution time: 0.0265
DEBUG - 2011-03-21 19:21:46 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:46 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:46 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:46 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:46 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:46 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:46 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:46 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:46 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:46 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:46 --> Helper loaded: rating_helper
ERROR - 2011-03-21 19:21:46 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-21 19:21:46 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:46 --> Total execution time: 0.0291
DEBUG - 2011-03-21 19:21:49 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:49 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:49 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:49 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:49 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:49 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:49 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:49 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:49 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:49 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:49 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:49 --> Helper loaded: rating_helper
DEBUG - 2011-03-21 19:21:49 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:49 --> Total execution time: 0.0272
DEBUG - 2011-03-21 19:21:52 --> Config Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:21:52 --> URI Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Router Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Output Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Input Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:21:52 --> Language Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Loader Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:21:52 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:21:52 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:21:52 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:21:52 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:21:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:21:52 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Session Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:21:52 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Session routines successfully run
DEBUG - 2011-03-21 19:21:52 --> Controller Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Model Class Initialized
DEBUG - 2011-03-21 19:21:52 --> Helper loaded: rating_helper
DEBUG - 2011-03-21 19:21:52 --> Final output sent to browser
DEBUG - 2011-03-21 19:21:52 --> Total execution time: 0.0283
DEBUG - 2011-03-21 19:22:07 --> Config Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:22:07 --> URI Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Router Class Initialized
DEBUG - 2011-03-21 19:22:07 --> No URI present. Default controller set.
DEBUG - 2011-03-21 19:22:07 --> Output Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Input Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:22:07 --> Language Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Loader Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:22:07 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Session Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:22:07 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Session routines successfully run
DEBUG - 2011-03-21 19:22:07 --> Controller Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: file_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 19:22:07 --> CSSMin library initialized.
DEBUG - 2011-03-21 19:22:07 --> JSMin library initialized.
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Model Class Initialized
DEBUG - 2011-03-21 19:22:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 19:22:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 19:22:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 19:22:07 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-21 19:22:07 --> Final output sent to browser
DEBUG - 2011-03-21 19:22:07 --> Total execution time: 0.0445
DEBUG - 2011-03-21 19:22:07 --> Config Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:22:07 --> URI Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Router Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Output Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Input Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:22:07 --> Language Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Loader Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:22:07 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Session Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:22:07 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:22:07 --> Session routines successfully run
DEBUG - 2011-03-21 19:22:07 --> Controller Class Initialized
DEBUG - 2011-03-21 19:22:07 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 19:22:07 --> Final output sent to browser
DEBUG - 2011-03-21 19:22:07 --> Total execution time: 0.0229
DEBUG - 2011-03-21 19:23:56 --> Config Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:23:56 --> URI Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Router Class Initialized
DEBUG - 2011-03-21 19:23:56 --> No URI present. Default controller set.
DEBUG - 2011-03-21 19:23:56 --> Output Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Input Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:23:56 --> Language Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Loader Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:23:56 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Session Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:23:56 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Session routines successfully run
DEBUG - 2011-03-21 19:23:56 --> Controller Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: file_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 19:23:56 --> CSSMin library initialized.
DEBUG - 2011-03-21 19:23:56 --> JSMin library initialized.
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
ERROR - 2011-03-21 19:23:56 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Model Class Initialized
DEBUG - 2011-03-21 19:23:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 19:23:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 19:23:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 19:23:56 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-21 19:23:56 --> Final output sent to browser
DEBUG - 2011-03-21 19:23:56 --> Total execution time: 0.0458
DEBUG - 2011-03-21 19:23:56 --> Config Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:23:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:23:56 --> URI Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Router Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Output Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Input Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:23:56 --> Language Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Loader Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:23:56 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Session Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:23:56 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:23:56 --> Session routines successfully run
DEBUG - 2011-03-21 19:23:56 --> Controller Class Initialized
DEBUG - 2011-03-21 19:23:56 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 19:23:56 --> Final output sent to browser
DEBUG - 2011-03-21 19:23:56 --> Total execution time: 0.0229
DEBUG - 2011-03-21 19:24:13 --> Config Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:24:13 --> URI Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Router Class Initialized
DEBUG - 2011-03-21 19:24:13 --> No URI present. Default controller set.
DEBUG - 2011-03-21 19:24:13 --> Output Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Input Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:24:13 --> Language Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Loader Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:24:13 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Session Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:24:13 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Session routines successfully run
DEBUG - 2011-03-21 19:24:13 --> Controller Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: file_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: directory_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: assets_helper
DEBUG - 2011-03-21 19:24:13 --> CSSMin library initialized.
DEBUG - 2011-03-21 19:24:13 --> JSMin library initialized.
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Model Class Initialized
DEBUG - 2011-03-21 19:24:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-21 19:24:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-21 19:24:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-21 19:24:13 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-21 19:24:13 --> Final output sent to browser
DEBUG - 2011-03-21 19:24:13 --> Total execution time: 0.0489
DEBUG - 2011-03-21 19:24:13 --> Config Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Hooks Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Utf8 Class Initialized
DEBUG - 2011-03-21 19:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-21 19:24:13 --> URI Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Router Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Output Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Input Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-21 19:24:13 --> Language Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Loader Class Initialized
DEBUG - 2011-03-21 19:24:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: user_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: url_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: array_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: utility_helper
DEBUG - 2011-03-21 19:24:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-21 19:24:14 --> Database Driver Class Initialized
DEBUG - 2011-03-21 19:24:14 --> Session Class Initialized
DEBUG - 2011-03-21 19:24:14 --> Helper loaded: string_helper
DEBUG - 2011-03-21 19:24:14 --> Encrypt Class Initialized
DEBUG - 2011-03-21 19:24:14 --> Session routines successfully run
DEBUG - 2011-03-21 19:24:14 --> Controller Class Initialized
DEBUG - 2011-03-21 19:24:14 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-21 19:24:14 --> Final output sent to browser
DEBUG - 2011-03-21 19:24:14 --> Total execution time: 0.0231
