<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-11 22:01:09 --> Config Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Hooks Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Utf8 Class Initialized
DEBUG - 2011-03-11 22:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 22:01:09 --> URI Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Router Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Output Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Input Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 22:01:09 --> Language Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Loader Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 22:01:09 --> Helper loaded: user_helper
DEBUG - 2011-03-11 22:01:09 --> Helper loaded: url_helper
DEBUG - 2011-03-11 22:01:09 --> Helper loaded: array_helper
DEBUG - 2011-03-11 22:01:09 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 22:01:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 22:01:09 --> Database Driver Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Session Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Helper loaded: string_helper
DEBUG - 2011-03-11 22:01:09 --> Encrypt Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Session routines successfully run
DEBUG - 2011-03-11 22:01:09 --> Controller Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:09 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: file_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: directory_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: assets_helper
DEBUG - 2011-03-11 22:01:10 --> CSSMin library initialized.
DEBUG - 2011-03-11 22:01:10 --> JSMin library initialized.
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-11 22:01:10 --> Final output sent to browser
DEBUG - 2011-03-11 22:01:10 --> Total execution time: 0.0600
DEBUG - 2011-03-11 22:01:10 --> Config Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Hooks Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Utf8 Class Initialized
DEBUG - 2011-03-11 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 22:01:10 --> URI Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Router Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Output Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Input Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 22:01:10 --> Language Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Loader Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: user_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: url_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: array_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 22:01:10 --> Database Driver Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Session Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: string_helper
DEBUG - 2011-03-11 22:01:10 --> Encrypt Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Session routines successfully run
DEBUG - 2011-03-11 22:01:10 --> Controller Class Initialized
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-11 22:01:10 --> Final output sent to browser
DEBUG - 2011-03-11 22:01:10 --> Total execution time: 0.0258
DEBUG - 2011-03-11 22:01:10 --> Config Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Hooks Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Utf8 Class Initialized
DEBUG - 2011-03-11 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 22:01:10 --> URI Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Router Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Output Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Input Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 22:01:10 --> Language Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Loader Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: user_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: url_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: array_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 22:01:10 --> Database Driver Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Session Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: string_helper
DEBUG - 2011-03-11 22:01:10 --> Encrypt Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Session routines successfully run
DEBUG - 2011-03-11 22:01:10 --> Controller Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: file_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: directory_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: assets_helper
DEBUG - 2011-03-11 22:01:10 --> CSSMin library initialized.
DEBUG - 2011-03-11 22:01:10 --> JSMin library initialized.
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
ERROR - 2011-03-11 22:01:10 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-11 22:01:10 --> Final output sent to browser
DEBUG - 2011-03-11 22:01:10 --> Total execution time: 0.0498
DEBUG - 2011-03-11 22:01:10 --> Config Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Hooks Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Utf8 Class Initialized
DEBUG - 2011-03-11 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 22:01:10 --> URI Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Router Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Output Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Input Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 22:01:10 --> Language Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Loader Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: user_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: url_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: array_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 22:01:10 --> Database Driver Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Session Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Helper loaded: string_helper
DEBUG - 2011-03-11 22:01:10 --> Encrypt Class Initialized
DEBUG - 2011-03-11 22:01:10 --> Session routines successfully run
DEBUG - 2011-03-11 22:01:10 --> Controller Class Initialized
DEBUG - 2011-03-11 22:01:10 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-11 22:01:10 --> Final output sent to browser
DEBUG - 2011-03-11 22:01:10 --> Total execution time: 0.0247
DEBUG - 2011-03-11 22:01:11 --> Config Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Hooks Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Utf8 Class Initialized
DEBUG - 2011-03-11 22:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 22:01:11 --> URI Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Router Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Output Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Input Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 22:01:11 --> Language Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Loader Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: user_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: url_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: array_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 22:01:11 --> Database Driver Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Session Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: string_helper
DEBUG - 2011-03-11 22:01:11 --> Encrypt Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Session routines successfully run
DEBUG - 2011-03-11 22:01:11 --> Controller Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: file_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: directory_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: assets_helper
DEBUG - 2011-03-11 22:01:11 --> CSSMin library initialized.
DEBUG - 2011-03-11 22:01:11 --> JSMin library initialized.
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Model Class Initialized
DEBUG - 2011-03-11 22:01:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-11 22:01:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-11 22:01:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-11 22:01:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-03-11 22:01:11 --> Final output sent to browser
DEBUG - 2011-03-11 22:01:11 --> Total execution time: 0.0461
DEBUG - 2011-03-11 22:01:11 --> Config Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Hooks Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Utf8 Class Initialized
DEBUG - 2011-03-11 22:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 22:01:11 --> URI Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Router Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Output Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Input Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 22:01:11 --> Language Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Loader Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: user_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: url_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: array_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 22:01:11 --> Database Driver Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Session Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Helper loaded: string_helper
DEBUG - 2011-03-11 22:01:11 --> Encrypt Class Initialized
DEBUG - 2011-03-11 22:01:11 --> Session routines successfully run
DEBUG - 2011-03-11 22:01:11 --> Controller Class Initialized
DEBUG - 2011-03-11 22:01:11 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-11 22:01:11 --> Final output sent to browser
DEBUG - 2011-03-11 22:01:11 --> Total execution time: 0.0262
DEBUG - 2011-03-11 23:44:53 --> Config Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:44:53 --> URI Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Router Class Initialized
DEBUG - 2011-03-11 23:44:53 --> No URI present. Default controller set.
DEBUG - 2011-03-11 23:44:53 --> Output Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Input Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:44:53 --> Language Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Loader Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:44:53 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Session Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:44:53 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Session routines successfully run
DEBUG - 2011-03-11 23:44:53 --> Controller Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: file_helper
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: directory_helper
DEBUG - 2011-03-11 23:44:53 --> Helper loaded: assets_helper
DEBUG - 2011-03-11 23:44:53 --> CSSMin library initialized.
DEBUG - 2011-03-11 23:44:53 --> JSMin library initialized.
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> Model Class Initialized
DEBUG - 2011-03-11 23:44:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-11 23:44:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-11 23:44:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-11 23:44:53 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-11 23:44:53 --> Final output sent to browser
DEBUG - 2011-03-11 23:44:53 --> Total execution time: 0.0569
DEBUG - 2011-03-11 23:44:54 --> Config Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:44:54 --> URI Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Router Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Output Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Input Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:44:54 --> Language Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Loader Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:44:54 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:44:54 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:44:54 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:44:54 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:44:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:44:54 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Session Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:44:54 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:44:54 --> Session routines successfully run
DEBUG - 2011-03-11 23:44:54 --> Controller Class Initialized
DEBUG - 2011-03-11 23:44:54 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-11 23:44:54 --> Final output sent to browser
DEBUG - 2011-03-11 23:44:54 --> Total execution time: 0.0234
DEBUG - 2011-03-11 23:45:21 --> Config Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:45:21 --> URI Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Router Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Output Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Input Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:45:21 --> Language Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Loader Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:45:21 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Session Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:45:21 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Session routines successfully run
DEBUG - 2011-03-11 23:45:21 --> Controller Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: file_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: directory_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: assets_helper
DEBUG - 2011-03-11 23:45:21 --> CSSMin library initialized.
DEBUG - 2011-03-11 23:45:21 --> JSMin library initialized.
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-11 23:45:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-11 23:45:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-11 23:45:21 --> File loaded: application/views/home/contact.php
DEBUG - 2011-03-11 23:45:21 --> Final output sent to browser
DEBUG - 2011-03-11 23:45:21 --> Total execution time: 0.0508
DEBUG - 2011-03-11 23:45:21 --> Config Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:45:21 --> URI Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Router Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Output Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Input Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:45:21 --> Language Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Loader Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:45:21 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Session Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:45:21 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:45:21 --> Session routines successfully run
DEBUG - 2011-03-11 23:45:21 --> Controller Class Initialized
DEBUG - 2011-03-11 23:45:21 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-11 23:45:21 --> Final output sent to browser
DEBUG - 2011-03-11 23:45:21 --> Total execution time: 0.0275
DEBUG - 2011-03-11 23:45:47 --> Config Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:45:47 --> URI Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Router Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Output Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Input Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:45:47 --> Language Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Loader Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:45:47 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Session Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:45:47 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Session routines successfully run
DEBUG - 2011-03-11 23:45:47 --> Controller Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
ERROR - 2011-03-11 23:45:47 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: file_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: directory_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: assets_helper
DEBUG - 2011-03-11 23:45:47 --> CSSMin library initialized.
DEBUG - 2011-03-11 23:45:47 --> JSMin library initialized.
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Model Class Initialized
DEBUG - 2011-03-11 23:45:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-11 23:45:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-11 23:45:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-11 23:45:47 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-11 23:45:47 --> Final output sent to browser
DEBUG - 2011-03-11 23:45:47 --> Total execution time: 0.0547
DEBUG - 2011-03-11 23:45:47 --> Config Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:45:47 --> URI Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Router Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Output Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Input Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:45:47 --> Language Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Loader Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:45:47 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Session Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:45:47 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:45:47 --> Session routines successfully run
DEBUG - 2011-03-11 23:45:47 --> Controller Class Initialized
DEBUG - 2011-03-11 23:45:47 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-11 23:45:47 --> Final output sent to browser
DEBUG - 2011-03-11 23:45:47 --> Total execution time: 0.0260
DEBUG - 2011-03-11 23:46:10 --> Config Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:46:10 --> URI Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Router Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Output Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Input Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:46:10 --> Language Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Loader Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:46:10 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Session Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:46:10 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Session routines successfully run
DEBUG - 2011-03-11 23:46:10 --> Controller Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: file_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: directory_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: assets_helper
DEBUG - 2011-03-11 23:46:10 --> CSSMin library initialized.
DEBUG - 2011-03-11 23:46:10 --> JSMin library initialized.
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Model Class Initialized
DEBUG - 2011-03-11 23:46:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-11 23:46:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-11 23:46:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-11 23:46:10 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-03-11 23:46:10 --> Final output sent to browser
DEBUG - 2011-03-11 23:46:10 --> Total execution time: 0.0484
DEBUG - 2011-03-11 23:46:10 --> Config Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Hooks Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Utf8 Class Initialized
DEBUG - 2011-03-11 23:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-11 23:46:10 --> URI Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Router Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Output Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Input Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-11 23:46:10 --> Language Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Loader Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: user_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: url_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: array_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-11 23:46:10 --> Database Driver Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Session Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Helper loaded: string_helper
DEBUG - 2011-03-11 23:46:10 --> Encrypt Class Initialized
DEBUG - 2011-03-11 23:46:10 --> Session routines successfully run
DEBUG - 2011-03-11 23:46:10 --> Controller Class Initialized
DEBUG - 2011-03-11 23:46:10 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-11 23:46:10 --> Final output sent to browser
DEBUG - 2011-03-11 23:46:10 --> Total execution time: 0.0231
