<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-23 00:01:40 --> Config Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:01:40 --> URI Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Router Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Output Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Input Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:01:40 --> Language Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Loader Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:01:40 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:01:40 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:01:40 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:01:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:01:40 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Session Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:01:40 --> Session routines successfully run
DEBUG - 2011-02-23 00:01:40 --> Controller Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:40 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:01:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:01:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:01:40 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-23 00:01:40 --> Final output sent to browser
DEBUG - 2011-02-23 00:01:40 --> Total execution time: 0.0286
DEBUG - 2011-02-23 00:01:50 --> Config Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:01:50 --> URI Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Router Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Output Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Input Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:01:50 --> Language Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Loader Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:01:50 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:01:50 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:01:50 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:01:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:01:50 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Session Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:01:50 --> Session routines successfully run
DEBUG - 2011-02-23 00:01:50 --> Controller Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:01:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:01:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:01:50 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-23 00:01:50 --> Final output sent to browser
DEBUG - 2011-02-23 00:01:50 --> Total execution time: 0.0300
DEBUG - 2011-02-23 00:01:59 --> Config Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:01:59 --> URI Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Router Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Output Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Input Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:01:59 --> Language Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Loader Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:01:59 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:01:59 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:01:59 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:01:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:01:59 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Session Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:01:59 --> Session routines successfully run
DEBUG - 2011-02-23 00:01:59 --> Controller Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:59 --> Model Class Initialized
DEBUG - 2011-02-23 00:01:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:01:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:01:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:01:59 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 00:01:59 --> Final output sent to browser
DEBUG - 2011-02-23 00:01:59 --> Total execution time: 0.0283
DEBUG - 2011-02-23 00:02:05 --> Config Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:02:05 --> URI Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Router Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Output Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Input Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:02:05 --> Language Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Loader Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:02:05 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:02:05 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:02:05 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:02:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:02:05 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Session Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:02:05 --> Session routines successfully run
DEBUG - 2011-02-23 00:02:05 --> Controller Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Model Class Initialized
DEBUG - 2011-02-23 00:02:05 --> Model Class Initialized
DEBUG - 2011-02-23 00:02:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:02:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:02:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:02:05 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 00:02:05 --> Final output sent to browser
DEBUG - 2011-02-23 00:02:05 --> Total execution time: 0.0234
DEBUG - 2011-02-23 00:04:02 --> Config Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:04:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:04:02 --> URI Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Router Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Output Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Input Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:04:02 --> Language Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Loader Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:04:02 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:04:02 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:04:02 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:04:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:04:02 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Session Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:04:02 --> Session routines successfully run
DEBUG - 2011-02-23 00:04:02 --> Controller Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Model Class Initialized
DEBUG - 2011-02-23 00:04:02 --> Model Class Initialized
DEBUG - 2011-02-23 00:04:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:04:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:04:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:04:02 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-23 00:04:02 --> Final output sent to browser
DEBUG - 2011-02-23 00:04:02 --> Total execution time: 0.0246
DEBUG - 2011-02-23 00:05:03 --> Config Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:05:03 --> URI Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Router Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Output Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Input Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:05:03 --> Language Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Loader Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:05:03 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:05:03 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:05:03 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:05:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:05:03 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Session Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:05:03 --> Session routines successfully run
DEBUG - 2011-02-23 00:05:03 --> Controller Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Model Class Initialized
DEBUG - 2011-02-23 00:05:03 --> Model Class Initialized
DEBUG - 2011-02-23 00:05:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:05:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:05:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:05:03 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-23 00:05:03 --> Final output sent to browser
DEBUG - 2011-02-23 00:05:03 --> Total execution time: 0.0250
DEBUG - 2011-02-23 00:05:09 --> Config Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:05:09 --> URI Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Router Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Output Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Input Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:05:09 --> Language Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Loader Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:05:09 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:05:09 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:05:09 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:05:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:05:09 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Session Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:05:09 --> Session routines successfully run
DEBUG - 2011-02-23 00:05:09 --> Controller Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Model Class Initialized
DEBUG - 2011-02-23 00:05:09 --> Model Class Initialized
DEBUG - 2011-02-23 00:05:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:05:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:05:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:05:09 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 00:05:09 --> Final output sent to browser
DEBUG - 2011-02-23 00:05:09 --> Total execution time: 0.0242
DEBUG - 2011-02-23 00:05:22 --> Config Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:05:22 --> URI Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Router Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Output Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Input Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:05:22 --> Language Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Loader Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:05:22 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:05:22 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:05:22 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:05:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:05:22 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Session Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:05:22 --> Session routines successfully run
DEBUG - 2011-02-23 00:05:22 --> Controller Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Model Class Initialized
DEBUG - 2011-02-23 00:05:22 --> Model Class Initialized
DEBUG - 2011-02-23 00:05:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:05:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:05:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:05:22 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 00:05:22 --> Final output sent to browser
DEBUG - 2011-02-23 00:05:22 --> Total execution time: 0.0247
DEBUG - 2011-02-23 00:06:52 --> Config Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:06:52 --> URI Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Router Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Output Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Input Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:06:52 --> Language Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Loader Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:06:52 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:06:52 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:06:52 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:06:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:06:52 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Session Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:06:52 --> Session routines successfully run
DEBUG - 2011-02-23 00:06:52 --> Controller Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Model Class Initialized
DEBUG - 2011-02-23 00:06:52 --> Model Class Initialized
DEBUG - 2011-02-23 00:06:52 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 00:06:52 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 00:06:52 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-23 00:06:52 --> Final output sent to browser
DEBUG - 2011-02-23 00:06:52 --> Total execution time: 0.0266
DEBUG - 2011-02-23 00:07:01 --> Config Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:07:01 --> URI Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Router Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Output Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Input Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:07:01 --> Language Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Loader Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:07:01 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:07:01 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:07:01 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:07:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:07:01 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Session Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:07:01 --> Session routines successfully run
DEBUG - 2011-02-23 00:07:01 --> Controller Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Model Class Initialized
DEBUG - 2011-02-23 00:07:01 --> Model Class Initialized
DEBUG - 2011-02-23 00:07:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:07:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:07:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:07:01 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:07:01 --> Final output sent to browser
DEBUG - 2011-02-23 00:07:01 --> Total execution time: 0.0246
DEBUG - 2011-02-23 00:08:07 --> Config Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:08:07 --> URI Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Router Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Output Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Input Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:08:07 --> Language Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Loader Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:08:07 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:08:07 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:08:07 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:08:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:08:07 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Session Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:08:07 --> Session routines successfully run
DEBUG - 2011-02-23 00:08:07 --> Controller Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Model Class Initialized
DEBUG - 2011-02-23 00:08:07 --> Model Class Initialized
DEBUG - 2011-02-23 00:08:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:08:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:08:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:08:07 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:08:07 --> Final output sent to browser
DEBUG - 2011-02-23 00:08:07 --> Total execution time: 0.0235
DEBUG - 2011-02-23 00:11:37 --> Config Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:11:37 --> URI Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Router Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Output Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Input Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:11:37 --> Language Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Loader Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:11:37 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:11:37 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:11:37 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:11:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:11:37 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Session Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:11:37 --> Session routines successfully run
DEBUG - 2011-02-23 00:11:37 --> Controller Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:37 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:11:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:11:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:11:37 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:11:37 --> Final output sent to browser
DEBUG - 2011-02-23 00:11:37 --> Total execution time: 0.0241
DEBUG - 2011-02-23 00:11:38 --> Config Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:11:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:11:38 --> URI Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Router Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Output Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Input Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:11:38 --> Language Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Loader Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:11:38 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:11:38 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:11:38 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:11:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:11:38 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Session Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:11:38 --> Session routines successfully run
DEBUG - 2011-02-23 00:11:38 --> Controller Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:38 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:11:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:11:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:11:38 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:11:38 --> Final output sent to browser
DEBUG - 2011-02-23 00:11:38 --> Total execution time: 0.0236
DEBUG - 2011-02-23 00:11:39 --> Config Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:11:39 --> URI Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Router Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Output Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Input Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:11:39 --> Language Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Loader Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:11:39 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:11:39 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:11:39 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:11:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:11:39 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Session Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:11:39 --> Session routines successfully run
DEBUG - 2011-02-23 00:11:39 --> Controller Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:39 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:11:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:11:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:11:39 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:11:39 --> Final output sent to browser
DEBUG - 2011-02-23 00:11:39 --> Total execution time: 0.0241
DEBUG - 2011-02-23 00:11:48 --> Config Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:11:48 --> URI Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Router Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Output Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Input Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:11:48 --> Language Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Loader Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:11:48 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:11:48 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:11:48 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:11:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:11:48 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Session Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:11:48 --> Session routines successfully run
DEBUG - 2011-02-23 00:11:48 --> Controller Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:48 --> Model Class Initialized
DEBUG - 2011-02-23 00:11:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:11:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:11:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:11:48 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:11:48 --> Final output sent to browser
DEBUG - 2011-02-23 00:11:48 --> Total execution time: 0.0243
DEBUG - 2011-02-23 00:12:02 --> Config Class Initialized
DEBUG - 2011-02-23 00:12:02 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:12:02 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:12:02 --> URI Class Initialized
DEBUG - 2011-02-23 00:12:02 --> Router Class Initialized
ERROR - 2011-02-23 00:12:02 --> 404 Page Not Found --> static
DEBUG - 2011-02-23 00:13:50 --> Config Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:13:50 --> URI Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Router Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Output Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Input Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:13:50 --> Language Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Loader Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:13:50 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:13:50 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:13:50 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:13:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:13:50 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Session Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:13:50 --> Session routines successfully run
DEBUG - 2011-02-23 00:13:50 --> Controller Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:13:50 --> Model Class Initialized
DEBUG - 2011-02-23 00:13:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:13:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:13:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:13:50 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:13:50 --> Final output sent to browser
DEBUG - 2011-02-23 00:13:50 --> Total execution time: 0.0216
DEBUG - 2011-02-23 00:14:41 --> Config Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:14:41 --> URI Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Router Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Output Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Input Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:14:41 --> Language Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Loader Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:14:41 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:14:41 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:14:41 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:14:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:14:41 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Session Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:14:41 --> Session routines successfully run
DEBUG - 2011-02-23 00:14:41 --> Controller Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Model Class Initialized
DEBUG - 2011-02-23 00:14:41 --> Model Class Initialized
DEBUG - 2011-02-23 00:14:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 00:14:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 00:14:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 00:14:41 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 00:14:41 --> Final output sent to browser
DEBUG - 2011-02-23 00:14:41 --> Total execution time: 0.0234
DEBUG - 2011-02-23 00:14:45 --> Config Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:14:45 --> URI Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Router Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Output Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Input Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:14:45 --> Language Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Loader Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:14:45 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:14:45 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:14:45 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:14:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:14:45 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Session Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:14:45 --> Session routines successfully run
DEBUG - 2011-02-23 00:14:45 --> Controller Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Model Class Initialized
DEBUG - 2011-02-23 00:14:45 --> Model Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Config Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Hooks Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Utf8 Class Initialized
DEBUG - 2011-02-23 00:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 00:15:14 --> URI Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Router Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Output Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Input Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 00:15:14 --> Language Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Loader Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 00:15:14 --> Helper loaded: user_helper
DEBUG - 2011-02-23 00:15:14 --> Helper loaded: url_helper
DEBUG - 2011-02-23 00:15:14 --> Helper loaded: array_helper
DEBUG - 2011-02-23 00:15:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 00:15:14 --> Database Driver Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Session Class Initialized
DEBUG - 2011-02-23 00:15:14 --> Helper loaded: string_helper
DEBUG - 2011-02-23 00:15:14 --> Session routines successfully run
DEBUG - 2011-02-23 00:15:14 --> Controller Class Initialized
DEBUG - 2011-02-23 00:15:14 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-23 00:15:14 --> Final output sent to browser
DEBUG - 2011-02-23 00:15:14 --> Total execution time: 0.0229
DEBUG - 2011-02-23 08:46:05 --> Config Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:46:05 --> URI Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Router Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Output Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Input Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:46:05 --> Language Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Loader Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:46:05 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Session Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:46:05 --> A session cookie was not found.
DEBUG - 2011-02-23 08:46:05 --> Session routines successfully run
DEBUG - 2011-02-23 08:46:05 --> Controller Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Config Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:46:05 --> URI Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Router Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Output Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Input Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:46:05 --> Language Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Loader Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:46:05 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Session Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:46:05 --> Session routines successfully run
DEBUG - 2011-02-23 08:46:05 --> Controller Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:05 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:05 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 08:46:05 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 08:46:05 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-23 08:46:05 --> Final output sent to browser
DEBUG - 2011-02-23 08:46:05 --> Total execution time: 0.0221
DEBUG - 2011-02-23 08:46:11 --> Config Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:46:11 --> URI Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Router Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Output Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Input Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:46:11 --> Language Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Loader Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:46:11 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Session Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:46:11 --> Session routines successfully run
DEBUG - 2011-02-23 08:46:11 --> Controller Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Config Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:46:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:46:11 --> URI Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Router Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Output Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Input Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:46:11 --> Language Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Loader Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:46:11 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Session Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:46:11 --> Session routines successfully run
DEBUG - 2011-02-23 08:46:11 --> Controller Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: form_helper
DEBUG - 2011-02-23 08:46:11 --> Form Validation Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 08:46:11 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:11 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:11 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 08:46:11 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 08:46:11 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-23 08:46:11 --> Final output sent to browser
DEBUG - 2011-02-23 08:46:11 --> Total execution time: 0.0315
DEBUG - 2011-02-23 08:46:26 --> Config Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:46:26 --> URI Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Router Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Output Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Input Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:46:26 --> Language Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Loader Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:46:26 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:46:26 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:46:26 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:46:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:46:26 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Session Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:46:26 --> Session routines successfully run
DEBUG - 2011-02-23 08:46:26 --> Controller Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Helper loaded: form_helper
DEBUG - 2011-02-23 08:46:26 --> Form Validation Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 08:46:26 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:26 --> Model Class Initialized
DEBUG - 2011-02-23 08:46:26 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 08:46:26 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 08:46:26 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-23 08:46:26 --> Final output sent to browser
DEBUG - 2011-02-23 08:46:26 --> Total execution time: 0.0260
DEBUG - 2011-02-23 08:48:23 --> Config Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:48:23 --> URI Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Router Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Output Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Input Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:48:23 --> Language Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Loader Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:48:23 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:48:23 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:48:23 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:48:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:48:23 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Session Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:48:23 --> Session routines successfully run
DEBUG - 2011-02-23 08:48:23 --> Controller Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Helper loaded: form_helper
DEBUG - 2011-02-23 08:48:23 --> Form Validation Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 08:48:23 --> Model Class Initialized
DEBUG - 2011-02-23 08:48:23 --> Model Class Initialized
DEBUG - 2011-02-23 08:48:23 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 08:48:23 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 08:48:23 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-23 08:48:23 --> Final output sent to browser
DEBUG - 2011-02-23 08:48:23 --> Total execution time: 0.0271
DEBUG - 2011-02-23 08:48:24 --> Config Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:48:24 --> URI Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Router Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Output Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Input Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:48:24 --> Language Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Loader Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:48:24 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:48:24 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:48:24 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:48:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:48:24 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Session Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:48:24 --> Session routines successfully run
DEBUG - 2011-02-23 08:48:24 --> Controller Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Helper loaded: form_helper
DEBUG - 2011-02-23 08:48:24 --> Form Validation Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 08:48:24 --> Model Class Initialized
DEBUG - 2011-02-23 08:48:24 --> Model Class Initialized
DEBUG - 2011-02-23 08:48:24 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 08:48:24 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 08:48:24 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-23 08:48:24 --> Final output sent to browser
DEBUG - 2011-02-23 08:48:24 --> Total execution time: 0.0282
DEBUG - 2011-02-23 08:49:13 --> Config Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:49:13 --> URI Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Router Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Output Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Input Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:49:13 --> Language Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Loader Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:49:13 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:49:13 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:49:13 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:49:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:49:13 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Session Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:49:13 --> Session routines successfully run
DEBUG - 2011-02-23 08:49:13 --> Controller Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Model Class Initialized
DEBUG - 2011-02-23 08:49:13 --> Model Class Initialized
DEBUG - 2011-02-23 08:49:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 08:49:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 08:49:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 08:49:13 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 08:49:13 --> Final output sent to browser
DEBUG - 2011-02-23 08:49:13 --> Total execution time: 0.0276
DEBUG - 2011-02-23 08:49:41 --> Config Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:49:41 --> URI Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Router Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Output Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Input Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:49:41 --> Language Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Loader Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:49:41 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:49:41 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:49:41 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:49:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:49:41 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Session Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:49:41 --> Session routines successfully run
DEBUG - 2011-02-23 08:49:41 --> Controller Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Helper loaded: form_helper
DEBUG - 2011-02-23 08:49:41 --> Form Validation Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 08:49:41 --> Model Class Initialized
DEBUG - 2011-02-23 08:49:41 --> Model Class Initialized
DEBUG - 2011-02-23 08:49:41 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 08:49:41 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 08:49:41 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-23 08:49:41 --> Final output sent to browser
DEBUG - 2011-02-23 08:49:41 --> Total execution time: 0.0356
DEBUG - 2011-02-23 08:58:25 --> Config Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:58:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:58:25 --> URI Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Router Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Output Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Input Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:58:25 --> Language Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Loader Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:58:25 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:58:25 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:58:25 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:58:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:58:25 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Session Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:58:25 --> Session routines successfully run
DEBUG - 2011-02-23 08:58:25 --> Controller Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Model Class Initialized
DEBUG - 2011-02-23 08:58:25 --> Model Class Initialized
DEBUG - 2011-02-23 08:58:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 08:58:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 08:58:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 08:58:25 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 08:58:25 --> Final output sent to browser
DEBUG - 2011-02-23 08:58:25 --> Total execution time: 0.0238
DEBUG - 2011-02-23 08:59:37 --> Config Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Hooks Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Utf8 Class Initialized
DEBUG - 2011-02-23 08:59:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 08:59:37 --> URI Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Router Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Output Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Input Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 08:59:37 --> Language Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Loader Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 08:59:37 --> Helper loaded: user_helper
DEBUG - 2011-02-23 08:59:37 --> Helper loaded: url_helper
DEBUG - 2011-02-23 08:59:37 --> Helper loaded: array_helper
DEBUG - 2011-02-23 08:59:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 08:59:37 --> Database Driver Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Session Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Helper loaded: string_helper
DEBUG - 2011-02-23 08:59:37 --> Session routines successfully run
DEBUG - 2011-02-23 08:59:37 --> Controller Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Model Class Initialized
DEBUG - 2011-02-23 08:59:37 --> Model Class Initialized
DEBUG - 2011-02-23 08:59:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 08:59:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 08:59:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 08:59:37 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 08:59:37 --> Final output sent to browser
DEBUG - 2011-02-23 08:59:37 --> Total execution time: 0.0240
DEBUG - 2011-02-23 09:06:04 --> Config Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:06:04 --> URI Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Router Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Output Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Input Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:06:04 --> Language Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Loader Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:06:04 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:06:04 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:06:04 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:06:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:06:04 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Session Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:06:04 --> Session routines successfully run
DEBUG - 2011-02-23 09:06:04 --> Controller Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Model Class Initialized
DEBUG - 2011-02-23 09:06:04 --> Model Class Initialized
DEBUG - 2011-02-23 09:06:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:06:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:06:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:06:04 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:06:04 --> Final output sent to browser
DEBUG - 2011-02-23 09:06:04 --> Total execution time: 0.0246
DEBUG - 2011-02-23 09:13:04 --> Config Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:13:04 --> URI Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Router Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Output Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Input Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:13:04 --> Language Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Loader Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:13:04 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:13:04 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:13:04 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:13:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:13:04 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Session Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:13:04 --> Session routines successfully run
DEBUG - 2011-02-23 09:13:04 --> Controller Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Model Class Initialized
DEBUG - 2011-02-23 09:13:04 --> Model Class Initialized
DEBUG - 2011-02-23 09:13:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:13:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:13:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:13:04 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:13:04 --> Final output sent to browser
DEBUG - 2011-02-23 09:13:04 --> Total execution time: 0.0240
DEBUG - 2011-02-23 09:15:32 --> Config Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:15:32 --> URI Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Router Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Output Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Input Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:15:32 --> Language Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Loader Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:15:32 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:15:32 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:15:32 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:15:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:15:32 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Session Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:15:32 --> Session routines successfully run
DEBUG - 2011-02-23 09:15:32 --> Controller Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Model Class Initialized
DEBUG - 2011-02-23 09:15:32 --> Model Class Initialized
DEBUG - 2011-02-23 09:15:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:15:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:15:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:15:32 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:15:32 --> Final output sent to browser
DEBUG - 2011-02-23 09:15:32 --> Total execution time: 0.0220
DEBUG - 2011-02-23 09:15:42 --> Config Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:15:42 --> URI Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Router Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Output Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Input Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:15:42 --> Language Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Loader Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:15:42 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:15:42 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:15:42 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:15:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:15:42 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Session Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:15:42 --> Session routines successfully run
DEBUG - 2011-02-23 09:15:42 --> Controller Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:15:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:15:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:15:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:15:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:15:42 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:15:42 --> Final output sent to browser
DEBUG - 2011-02-23 09:15:42 --> Total execution time: 0.0256
DEBUG - 2011-02-23 09:16:17 --> Config Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:16:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:16:17 --> URI Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Router Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Output Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Input Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:16:17 --> Language Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Loader Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:16:17 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:16:17 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:16:17 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:16:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:16:17 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Session Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:16:17 --> Session routines successfully run
DEBUG - 2011-02-23 09:16:17 --> Controller Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Model Class Initialized
DEBUG - 2011-02-23 09:16:17 --> Model Class Initialized
DEBUG - 2011-02-23 09:16:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:16:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:16:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:16:17 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:16:17 --> Final output sent to browser
DEBUG - 2011-02-23 09:16:17 --> Total execution time: 0.0242
DEBUG - 2011-02-23 09:17:16 --> Config Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:17:16 --> URI Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Router Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Output Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Input Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:17:16 --> Language Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Loader Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:17:16 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:17:16 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:17:16 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:17:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:17:16 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Session Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:17:16 --> Session routines successfully run
DEBUG - 2011-02-23 09:17:16 --> Controller Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Model Class Initialized
DEBUG - 2011-02-23 09:17:16 --> Model Class Initialized
DEBUG - 2011-02-23 09:17:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:17:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:17:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:17:16 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:17:16 --> Final output sent to browser
DEBUG - 2011-02-23 09:17:16 --> Total execution time: 0.0227
DEBUG - 2011-02-23 09:17:54 --> Config Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:17:54 --> URI Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Router Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Output Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Input Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:17:54 --> Language Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Loader Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:17:54 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:17:54 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:17:54 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:17:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:17:54 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Session Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:17:54 --> Session routines successfully run
DEBUG - 2011-02-23 09:17:54 --> Controller Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Model Class Initialized
DEBUG - 2011-02-23 09:17:54 --> Model Class Initialized
DEBUG - 2011-02-23 09:17:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:17:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:17:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:17:54 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:17:54 --> Final output sent to browser
DEBUG - 2011-02-23 09:17:54 --> Total execution time: 0.0218
DEBUG - 2011-02-23 09:18:01 --> Config Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:18:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:18:01 --> URI Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Router Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Output Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Input Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:18:01 --> Language Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Loader Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:18:01 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:18:01 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:18:01 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:18:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:18:01 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Session Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:18:01 --> Session routines successfully run
DEBUG - 2011-02-23 09:18:01 --> Controller Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:01 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:18:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:18:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:18:01 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 09:18:01 --> Final output sent to browser
DEBUG - 2011-02-23 09:18:01 --> Total execution time: 0.0299
DEBUG - 2011-02-23 09:18:15 --> Config Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:18:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:18:15 --> URI Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Router Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Output Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Input Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:18:15 --> Language Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Loader Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:18:15 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:18:15 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:18:15 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:18:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:18:15 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Session Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:18:15 --> Session routines successfully run
DEBUG - 2011-02-23 09:18:15 --> Controller Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:15 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:18:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:18:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:18:15 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-23 09:18:15 --> Final output sent to browser
DEBUG - 2011-02-23 09:18:15 --> Total execution time: 0.0304
DEBUG - 2011-02-23 09:18:30 --> Config Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:18:30 --> URI Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Router Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Output Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Input Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:18:30 --> Language Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Loader Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:18:30 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:18:30 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:18:30 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:18:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:18:30 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Session Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:18:30 --> Session routines successfully run
DEBUG - 2011-02-23 09:18:30 --> Controller Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:30 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:18:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:18:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:18:30 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:18:30 --> Final output sent to browser
DEBUG - 2011-02-23 09:18:30 --> Total execution time: 0.0344
DEBUG - 2011-02-23 09:18:42 --> Config Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:18:42 --> URI Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Router Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Output Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Input Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:18:42 --> Language Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Loader Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:18:42 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:18:42 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:18:42 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:18:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:18:42 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Session Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:18:42 --> Session routines successfully run
DEBUG - 2011-02-23 09:18:42 --> Controller Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:18:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:18:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:18:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:18:42 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 09:18:42 --> Final output sent to browser
DEBUG - 2011-02-23 09:18:42 --> Total execution time: 0.0252
DEBUG - 2011-02-23 09:21:42 --> Config Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:21:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:21:42 --> URI Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Router Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Output Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Input Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:21:42 --> Language Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Loader Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:21:42 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:21:42 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:21:42 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:21:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:21:42 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Session Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:21:42 --> Session routines successfully run
DEBUG - 2011-02-23 09:21:42 --> Controller Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:21:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:21:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:21:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:21:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:21:42 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:21:42 --> Final output sent to browser
DEBUG - 2011-02-23 09:21:42 --> Total execution time: 0.0234
DEBUG - 2011-02-23 09:28:22 --> Config Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:28:22 --> URI Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Router Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Output Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Input Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:28:22 --> Language Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Loader Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:28:22 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:28:22 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:28:22 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:28:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:28:22 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Session Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:28:22 --> Session routines successfully run
DEBUG - 2011-02-23 09:28:22 --> Controller Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Model Class Initialized
DEBUG - 2011-02-23 09:28:22 --> Model Class Initialized
DEBUG - 2011-02-23 09:28:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:28:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:28:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:28:22 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:28:22 --> Final output sent to browser
DEBUG - 2011-02-23 09:28:22 --> Total execution time: 0.0231
DEBUG - 2011-02-23 09:32:57 --> Config Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:32:57 --> URI Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Router Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Output Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Input Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:32:57 --> Language Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Loader Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:32:57 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:32:57 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:32:57 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:32:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:32:57 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Session Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:32:57 --> Session routines successfully run
DEBUG - 2011-02-23 09:32:57 --> Controller Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Model Class Initialized
DEBUG - 2011-02-23 09:32:57 --> Model Class Initialized
DEBUG - 2011-02-23 09:32:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:32:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:32:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:32:57 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:32:57 --> Final output sent to browser
DEBUG - 2011-02-23 09:32:57 --> Total execution time: 0.0244
DEBUG - 2011-02-23 09:33:13 --> Config Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:33:13 --> URI Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Router Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Output Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Input Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:33:13 --> Language Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Loader Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:33:13 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:33:13 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:33:13 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:33:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:33:13 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Session Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:33:13 --> Session routines successfully run
DEBUG - 2011-02-23 09:33:13 --> Controller Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:13 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:33:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:33:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:33:13 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:33:13 --> Final output sent to browser
DEBUG - 2011-02-23 09:33:13 --> Total execution time: 0.0228
DEBUG - 2011-02-23 09:33:31 --> Config Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:33:31 --> URI Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Router Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Output Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Input Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:33:31 --> Language Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Loader Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:33:31 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:33:31 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:33:31 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:33:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:33:31 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Session Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:33:31 --> Session routines successfully run
DEBUG - 2011-02-23 09:33:31 --> Controller Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:31 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:33:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:33:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:33:31 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:33:31 --> Final output sent to browser
DEBUG - 2011-02-23 09:33:31 --> Total execution time: 0.0224
DEBUG - 2011-02-23 09:33:43 --> Config Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:33:43 --> URI Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Router Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Output Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Input Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:33:43 --> Language Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Loader Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:33:43 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:33:43 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:33:43 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:33:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:33:43 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Session Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:33:43 --> Session routines successfully run
DEBUG - 2011-02-23 09:33:43 --> Controller Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:43 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:33:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:33:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:33:43 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:33:43 --> Final output sent to browser
DEBUG - 2011-02-23 09:33:43 --> Total execution time: 0.0215
DEBUG - 2011-02-23 09:33:52 --> Config Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:33:52 --> URI Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Router Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Output Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Input Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:33:52 --> Language Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Loader Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:33:52 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:33:52 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:33:52 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:33:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:33:52 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Session Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:33:52 --> Session routines successfully run
DEBUG - 2011-02-23 09:33:52 --> Controller Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:52 --> Model Class Initialized
DEBUG - 2011-02-23 09:33:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:33:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:33:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:33:52 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:33:52 --> Final output sent to browser
DEBUG - 2011-02-23 09:33:52 --> Total execution time: 0.0226
DEBUG - 2011-02-23 09:34:11 --> Config Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:34:11 --> URI Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Router Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Output Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Input Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:34:11 --> Language Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Loader Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:34:11 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:34:11 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:34:11 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:34:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:34:11 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Session Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:34:11 --> Session routines successfully run
DEBUG - 2011-02-23 09:34:11 --> Controller Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Model Class Initialized
DEBUG - 2011-02-23 09:34:11 --> Model Class Initialized
DEBUG - 2011-02-23 09:34:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:34:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:34:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:34:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:34:11 --> Final output sent to browser
DEBUG - 2011-02-23 09:34:11 --> Total execution time: 0.0219
DEBUG - 2011-02-23 09:34:25 --> Config Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:34:25 --> URI Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Router Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Output Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Input Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:34:25 --> Language Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Loader Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:34:25 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:34:25 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:34:25 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:34:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:34:25 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Session Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:34:25 --> Session routines successfully run
DEBUG - 2011-02-23 09:34:25 --> Controller Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Model Class Initialized
DEBUG - 2011-02-23 09:34:25 --> Model Class Initialized
DEBUG - 2011-02-23 09:34:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:34:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:34:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:34:25 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:34:25 --> Final output sent to browser
DEBUG - 2011-02-23 09:34:25 --> Total execution time: 0.0223
DEBUG - 2011-02-23 09:35:26 --> Config Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:35:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:35:26 --> URI Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Router Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Output Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Input Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:35:26 --> Language Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Loader Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:35:26 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:35:26 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:35:26 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:35:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:35:26 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Session Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:35:26 --> Session routines successfully run
DEBUG - 2011-02-23 09:35:26 --> Controller Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Model Class Initialized
DEBUG - 2011-02-23 09:35:26 --> Model Class Initialized
DEBUG - 2011-02-23 09:35:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:35:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:35:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:35:26 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:35:26 --> Final output sent to browser
DEBUG - 2011-02-23 09:35:26 --> Total execution time: 0.0248
DEBUG - 2011-02-23 09:36:16 --> Config Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:36:16 --> URI Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Router Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Output Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Input Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:36:16 --> Language Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Loader Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:36:16 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:36:16 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:36:16 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:36:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:36:16 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Session Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:36:16 --> Session routines successfully run
DEBUG - 2011-02-23 09:36:16 --> Controller Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Model Class Initialized
DEBUG - 2011-02-23 09:36:16 --> Model Class Initialized
DEBUG - 2011-02-23 09:36:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:36:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:36:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:36:16 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:36:16 --> Final output sent to browser
DEBUG - 2011-02-23 09:36:16 --> Total execution time: 0.0239
DEBUG - 2011-02-23 09:37:08 --> Config Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:37:08 --> URI Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Router Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Output Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Input Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:37:08 --> Language Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Loader Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:37:08 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:37:08 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:37:08 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:37:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:37:08 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Session Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:37:08 --> Session routines successfully run
DEBUG - 2011-02-23 09:37:08 --> Controller Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Model Class Initialized
DEBUG - 2011-02-23 09:37:08 --> Model Class Initialized
DEBUG - 2011-02-23 09:37:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:37:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:37:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:37:08 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:37:08 --> Final output sent to browser
DEBUG - 2011-02-23 09:37:08 --> Total execution time: 0.0265
DEBUG - 2011-02-23 09:37:36 --> Config Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:37:36 --> URI Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Router Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Output Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Input Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:37:36 --> Language Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Loader Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:37:36 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:37:36 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:37:36 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:37:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:37:36 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Session Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:37:36 --> Session routines successfully run
DEBUG - 2011-02-23 09:37:36 --> Controller Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Model Class Initialized
DEBUG - 2011-02-23 09:37:36 --> Model Class Initialized
DEBUG - 2011-02-23 09:37:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:37:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:37:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:37:36 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:37:36 --> Final output sent to browser
DEBUG - 2011-02-23 09:37:36 --> Total execution time: 0.0216
DEBUG - 2011-02-23 09:38:11 --> Config Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:38:11 --> URI Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Router Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Output Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Input Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:38:11 --> Language Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Loader Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:38:11 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:38:11 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:38:11 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:38:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:38:11 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Session Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:38:11 --> Session routines successfully run
DEBUG - 2011-02-23 09:38:11 --> Controller Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Model Class Initialized
DEBUG - 2011-02-23 09:38:11 --> Model Class Initialized
DEBUG - 2011-02-23 09:38:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:38:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:38:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:38:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:38:11 --> Final output sent to browser
DEBUG - 2011-02-23 09:38:11 --> Total execution time: 0.0290
DEBUG - 2011-02-23 09:38:27 --> Config Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:38:27 --> URI Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Router Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Output Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Input Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:38:27 --> Language Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Loader Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:38:27 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:38:27 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:38:27 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:38:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:38:27 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Session Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:38:27 --> Session routines successfully run
DEBUG - 2011-02-23 09:38:27 --> Controller Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Model Class Initialized
DEBUG - 2011-02-23 09:38:27 --> Model Class Initialized
DEBUG - 2011-02-23 09:38:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:38:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:38:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:38:27 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:38:27 --> Final output sent to browser
DEBUG - 2011-02-23 09:38:27 --> Total execution time: 0.0234
DEBUG - 2011-02-23 09:38:56 --> Config Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:38:56 --> URI Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Router Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Output Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Input Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:38:56 --> Language Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Loader Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:38:56 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:38:56 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:38:56 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:38:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:38:56 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Session Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:38:56 --> Session routines successfully run
DEBUG - 2011-02-23 09:38:56 --> Controller Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Model Class Initialized
DEBUG - 2011-02-23 09:38:56 --> Model Class Initialized
DEBUG - 2011-02-23 09:38:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:38:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:38:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:38:56 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:38:56 --> Final output sent to browser
DEBUG - 2011-02-23 09:38:56 --> Total execution time: 0.0260
DEBUG - 2011-02-23 09:39:26 --> Config Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:39:26 --> URI Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Router Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Output Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Input Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:39:26 --> Language Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Loader Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:39:26 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:39:26 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:39:26 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:39:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:39:26 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Session Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:39:26 --> Session routines successfully run
DEBUG - 2011-02-23 09:39:26 --> Controller Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Model Class Initialized
DEBUG - 2011-02-23 09:39:26 --> Model Class Initialized
DEBUG - 2011-02-23 09:39:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:39:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:39:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:39:26 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:39:26 --> Final output sent to browser
DEBUG - 2011-02-23 09:39:26 --> Total execution time: 0.0233
DEBUG - 2011-02-23 09:40:05 --> Config Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:40:05 --> URI Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Router Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Output Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Input Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:40:05 --> Language Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Loader Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:40:05 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:40:05 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:40:05 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:40:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:40:05 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Session Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:40:05 --> Session routines successfully run
DEBUG - 2011-02-23 09:40:05 --> Controller Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Model Class Initialized
DEBUG - 2011-02-23 09:40:05 --> Model Class Initialized
DEBUG - 2011-02-23 09:40:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:40:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:40:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:40:05 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:40:05 --> Final output sent to browser
DEBUG - 2011-02-23 09:40:05 --> Total execution time: 0.0235
DEBUG - 2011-02-23 09:40:38 --> Config Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:40:38 --> URI Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Router Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Output Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Input Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:40:38 --> Language Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Loader Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:40:38 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:40:38 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:40:38 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:40:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:40:38 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Session Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:40:38 --> Session routines successfully run
DEBUG - 2011-02-23 09:40:38 --> Controller Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Model Class Initialized
DEBUG - 2011-02-23 09:40:38 --> Model Class Initialized
DEBUG - 2011-02-23 09:40:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:40:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:40:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:40:38 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:40:38 --> Final output sent to browser
DEBUG - 2011-02-23 09:40:38 --> Total execution time: 0.0223
DEBUG - 2011-02-23 09:40:52 --> Config Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:40:52 --> URI Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Router Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Output Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Input Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:40:52 --> Language Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Loader Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:40:52 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:40:52 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:40:52 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:40:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:40:52 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Session Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:40:52 --> Session routines successfully run
DEBUG - 2011-02-23 09:40:52 --> Controller Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Model Class Initialized
DEBUG - 2011-02-23 09:40:52 --> Model Class Initialized
DEBUG - 2011-02-23 09:40:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:40:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:40:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:40:52 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:40:52 --> Final output sent to browser
DEBUG - 2011-02-23 09:40:52 --> Total execution time: 0.0250
DEBUG - 2011-02-23 09:41:08 --> Config Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:41:08 --> URI Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Router Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Output Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Input Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:41:08 --> Language Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Loader Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:41:08 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:41:08 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:41:08 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:41:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:41:08 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Session Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:41:08 --> Session routines successfully run
DEBUG - 2011-02-23 09:41:08 --> Controller Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Model Class Initialized
DEBUG - 2011-02-23 09:41:08 --> Model Class Initialized
DEBUG - 2011-02-23 09:41:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:41:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:41:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:41:08 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:41:08 --> Final output sent to browser
DEBUG - 2011-02-23 09:41:08 --> Total execution time: 0.0299
DEBUG - 2011-02-23 09:42:38 --> Config Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:42:38 --> URI Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Router Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Output Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Input Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:42:38 --> Language Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Loader Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:42:38 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:42:38 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:42:38 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:42:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:42:38 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Session Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:42:38 --> Session routines successfully run
DEBUG - 2011-02-23 09:42:38 --> Controller Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Model Class Initialized
DEBUG - 2011-02-23 09:42:38 --> Model Class Initialized
DEBUG - 2011-02-23 09:42:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:42:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:42:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:42:38 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:42:38 --> Final output sent to browser
DEBUG - 2011-02-23 09:42:38 --> Total execution time: 0.0217
DEBUG - 2011-02-23 09:44:43 --> Config Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:44:43 --> URI Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Router Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Output Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Input Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:44:43 --> Language Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Loader Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:44:43 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:44:43 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:44:43 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:44:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:44:43 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Session Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:44:43 --> Session routines successfully run
DEBUG - 2011-02-23 09:44:43 --> Controller Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Model Class Initialized
DEBUG - 2011-02-23 09:44:43 --> Model Class Initialized
DEBUG - 2011-02-23 09:44:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:44:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:44:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:44:43 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:44:43 --> Final output sent to browser
DEBUG - 2011-02-23 09:44:43 --> Total execution time: 0.0242
DEBUG - 2011-02-23 09:46:22 --> Config Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:46:22 --> URI Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Router Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Output Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Input Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:46:22 --> Language Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Loader Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:46:22 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:46:22 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:46:22 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:46:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:46:22 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Session Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:46:22 --> Session routines successfully run
DEBUG - 2011-02-23 09:46:22 --> Controller Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Model Class Initialized
DEBUG - 2011-02-23 09:46:22 --> Model Class Initialized
DEBUG - 2011-02-23 09:46:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:46:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:46:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:46:22 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:46:22 --> Final output sent to browser
DEBUG - 2011-02-23 09:46:22 --> Total execution time: 0.0233
DEBUG - 2011-02-23 09:49:36 --> Config Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:49:36 --> URI Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Router Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Output Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Input Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:49:36 --> Language Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Loader Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:49:36 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:49:36 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:49:36 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:49:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:49:36 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Session Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:49:36 --> Session routines successfully run
DEBUG - 2011-02-23 09:49:36 --> Controller Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Model Class Initialized
DEBUG - 2011-02-23 09:49:36 --> Model Class Initialized
DEBUG - 2011-02-23 09:49:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:49:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:49:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:49:36 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:49:36 --> Final output sent to browser
DEBUG - 2011-02-23 09:49:36 --> Total execution time: 0.0245
DEBUG - 2011-02-23 09:50:12 --> Config Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:50:12 --> URI Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Router Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Output Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Input Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:50:12 --> Language Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Loader Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:50:12 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:50:12 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:50:12 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:50:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:50:12 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Session Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:50:12 --> Session routines successfully run
DEBUG - 2011-02-23 09:50:12 --> Controller Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Model Class Initialized
DEBUG - 2011-02-23 09:50:12 --> Model Class Initialized
DEBUG - 2011-02-23 09:50:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:50:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:50:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:50:12 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:50:12 --> Final output sent to browser
DEBUG - 2011-02-23 09:50:12 --> Total execution time: 0.0246
DEBUG - 2011-02-23 09:52:05 --> Config Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:52:05 --> URI Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Router Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Output Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Input Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:52:05 --> Language Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Loader Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:52:05 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:52:05 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:52:05 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:52:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:52:05 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Session Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:52:05 --> Session routines successfully run
DEBUG - 2011-02-23 09:52:05 --> Controller Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Model Class Initialized
DEBUG - 2011-02-23 09:52:05 --> Model Class Initialized
DEBUG - 2011-02-23 09:52:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:52:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:52:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:52:05 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:52:05 --> Final output sent to browser
DEBUG - 2011-02-23 09:52:05 --> Total execution time: 0.0224
DEBUG - 2011-02-23 09:52:19 --> Config Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:52:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:52:19 --> URI Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Router Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Output Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Input Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:52:19 --> Language Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Loader Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:52:19 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:52:19 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:52:19 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:52:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:52:19 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Session Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:52:19 --> Session routines successfully run
DEBUG - 2011-02-23 09:52:19 --> Controller Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Model Class Initialized
DEBUG - 2011-02-23 09:52:19 --> Model Class Initialized
DEBUG - 2011-02-23 09:52:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:52:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:52:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:52:19 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:52:19 --> Final output sent to browser
DEBUG - 2011-02-23 09:52:19 --> Total execution time: 0.0230
DEBUG - 2011-02-23 09:54:17 --> Config Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:54:17 --> URI Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Router Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Output Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Input Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:54:17 --> Language Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Loader Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:54:17 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:54:17 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:54:17 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:54:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:54:17 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Session Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:54:17 --> Session routines successfully run
DEBUG - 2011-02-23 09:54:17 --> Controller Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Model Class Initialized
DEBUG - 2011-02-23 09:54:17 --> Model Class Initialized
DEBUG - 2011-02-23 09:54:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:54:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:54:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:54:17 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:54:17 --> Final output sent to browser
DEBUG - 2011-02-23 09:54:17 --> Total execution time: 0.0241
DEBUG - 2011-02-23 09:54:42 --> Config Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:54:42 --> URI Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Router Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Output Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Input Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:54:42 --> Language Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Loader Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:54:42 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:54:42 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:54:42 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:54:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:54:42 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Session Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:54:42 --> Session routines successfully run
DEBUG - 2011-02-23 09:54:42 --> Controller Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:54:42 --> Model Class Initialized
DEBUG - 2011-02-23 09:54:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:54:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:54:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:54:42 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:54:42 --> Final output sent to browser
DEBUG - 2011-02-23 09:54:42 --> Total execution time: 0.0236
DEBUG - 2011-02-23 09:54:51 --> Config Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:54:51 --> URI Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Router Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Output Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Input Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:54:51 --> Language Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Loader Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:54:51 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:54:51 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:54:51 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:54:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:54:51 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Session Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:54:51 --> Session routines successfully run
DEBUG - 2011-02-23 09:54:51 --> Controller Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Model Class Initialized
DEBUG - 2011-02-23 09:54:51 --> Model Class Initialized
DEBUG - 2011-02-23 09:54:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:54:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:54:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:54:51 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 09:54:51 --> Final output sent to browser
DEBUG - 2011-02-23 09:54:51 --> Total execution time: 0.0227
DEBUG - 2011-02-23 09:55:25 --> Config Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:55:25 --> URI Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Router Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Output Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Input Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:55:25 --> Language Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Loader Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:55:25 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:55:25 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:55:25 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:55:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:55:25 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Session Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:55:25 --> Session routines successfully run
DEBUG - 2011-02-23 09:55:25 --> Controller Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Model Class Initialized
DEBUG - 2011-02-23 09:55:25 --> Model Class Initialized
DEBUG - 2011-02-23 09:55:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:55:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:55:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:55:25 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 09:55:25 --> Final output sent to browser
DEBUG - 2011-02-23 09:55:25 --> Total execution time: 0.0249
DEBUG - 2011-02-23 09:55:29 --> Config Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:55:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:55:29 --> URI Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Router Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Output Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Input Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:55:29 --> Language Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Loader Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:55:29 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:55:29 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:55:29 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:55:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:55:29 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Session Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:55:29 --> Session routines successfully run
DEBUG - 2011-02-23 09:55:29 --> Controller Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Model Class Initialized
DEBUG - 2011-02-23 09:55:29 --> Model Class Initialized
DEBUG - 2011-02-23 09:55:29 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:55:29 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:55:29 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:55:29 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-23 09:55:29 --> Final output sent to browser
DEBUG - 2011-02-23 09:55:29 --> Total execution time: 0.0261
DEBUG - 2011-02-23 09:55:31 --> Config Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:55:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:55:31 --> URI Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Router Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Output Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Input Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:55:31 --> Language Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Loader Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:55:31 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:55:31 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:55:31 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:55:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:55:31 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Session Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:55:31 --> Session routines successfully run
DEBUG - 2011-02-23 09:55:31 --> Controller Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Model Class Initialized
DEBUG - 2011-02-23 09:55:31 --> Model Class Initialized
DEBUG - 2011-02-23 09:55:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:55:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:55:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:55:31 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:55:31 --> Final output sent to browser
DEBUG - 2011-02-23 09:55:31 --> Total execution time: 0.0260
DEBUG - 2011-02-23 09:58:11 --> Config Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:58:11 --> URI Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Router Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Output Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Input Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:58:11 --> Language Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Loader Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:58:11 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:58:11 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:58:11 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:58:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:58:11 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Session Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:58:11 --> Session routines successfully run
DEBUG - 2011-02-23 09:58:11 --> Controller Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Model Class Initialized
DEBUG - 2011-02-23 09:58:11 --> Model Class Initialized
DEBUG - 2011-02-23 09:58:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:58:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:58:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:58:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:58:11 --> Final output sent to browser
DEBUG - 2011-02-23 09:58:11 --> Total execution time: 0.0227
DEBUG - 2011-02-23 09:58:19 --> Config Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:58:19 --> URI Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Router Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Output Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Input Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:58:19 --> Language Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Loader Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:58:19 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:58:19 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:58:19 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:58:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:58:19 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Session Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:58:19 --> Session routines successfully run
DEBUG - 2011-02-23 09:58:19 --> Controller Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Model Class Initialized
DEBUG - 2011-02-23 09:58:19 --> Model Class Initialized
DEBUG - 2011-02-23 09:58:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:58:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:58:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:58:19 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:58:19 --> Final output sent to browser
DEBUG - 2011-02-23 09:58:19 --> Total execution time: 0.0233
DEBUG - 2011-02-23 09:58:37 --> Config Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:58:37 --> URI Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Router Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Output Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Input Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:58:37 --> Language Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Loader Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:58:37 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:58:37 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:58:37 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:58:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:58:37 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Session Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:58:37 --> Session routines successfully run
DEBUG - 2011-02-23 09:58:37 --> Controller Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Model Class Initialized
DEBUG - 2011-02-23 09:58:37 --> Model Class Initialized
DEBUG - 2011-02-23 09:58:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:58:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:58:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:58:37 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:58:37 --> Final output sent to browser
DEBUG - 2011-02-23 09:58:37 --> Total execution time: 0.0231
DEBUG - 2011-02-23 09:59:28 --> Config Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Hooks Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Utf8 Class Initialized
DEBUG - 2011-02-23 09:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 09:59:28 --> URI Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Router Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Output Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Input Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 09:59:28 --> Language Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Loader Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 09:59:28 --> Helper loaded: user_helper
DEBUG - 2011-02-23 09:59:28 --> Helper loaded: url_helper
DEBUG - 2011-02-23 09:59:28 --> Helper loaded: array_helper
DEBUG - 2011-02-23 09:59:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 09:59:28 --> Database Driver Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Session Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Helper loaded: string_helper
DEBUG - 2011-02-23 09:59:28 --> Session routines successfully run
DEBUG - 2011-02-23 09:59:28 --> Controller Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Model Class Initialized
DEBUG - 2011-02-23 09:59:28 --> Model Class Initialized
DEBUG - 2011-02-23 09:59:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 09:59:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 09:59:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 09:59:28 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 09:59:28 --> Final output sent to browser
DEBUG - 2011-02-23 09:59:28 --> Total execution time: 0.0219
DEBUG - 2011-02-23 18:34:33 --> Config Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:34:33 --> URI Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Router Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Output Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Input Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:34:33 --> Language Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Loader Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:34:33 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:34:33 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:34:33 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:34:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:34:33 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Session Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:34:33 --> A session cookie was not found.
DEBUG - 2011-02-23 18:34:33 --> Session routines successfully run
DEBUG - 2011-02-23 18:34:33 --> Controller Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Model Class Initialized
DEBUG - 2011-02-23 18:34:33 --> Model Class Initialized
DEBUG - 2011-02-23 18:34:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:34:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:34:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:34:33 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:34:33 --> Final output sent to browser
DEBUG - 2011-02-23 18:34:33 --> Total execution time: 0.0254
DEBUG - 2011-02-23 18:34:35 --> Config Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:34:35 --> URI Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Router Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Output Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Input Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:34:35 --> Language Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Loader Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:34:35 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:34:35 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:34:35 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:34:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:34:35 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Session Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:34:35 --> Session routines successfully run
DEBUG - 2011-02-23 18:34:35 --> Controller Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Model Class Initialized
DEBUG - 2011-02-23 18:34:35 --> Model Class Initialized
DEBUG - 2011-02-23 18:34:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:34:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:34:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:34:35 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:34:35 --> Final output sent to browser
DEBUG - 2011-02-23 18:34:35 --> Total execution time: 0.0234
DEBUG - 2011-02-23 18:44:17 --> Config Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:44:17 --> URI Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Router Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Output Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Input Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:44:17 --> Language Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Loader Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:44:17 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:44:17 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:44:17 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:44:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:44:17 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Session Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:44:17 --> Session routines successfully run
DEBUG - 2011-02-23 18:44:17 --> Controller Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Model Class Initialized
DEBUG - 2011-02-23 18:44:17 --> Model Class Initialized
DEBUG - 2011-02-23 18:44:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:44:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:44:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:44:17 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:44:17 --> Final output sent to browser
DEBUG - 2011-02-23 18:44:17 --> Total execution time: 0.0228
DEBUG - 2011-02-23 18:44:47 --> Config Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:44:47 --> URI Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Router Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Output Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Input Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:44:47 --> Language Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Loader Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:44:47 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:44:47 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:44:47 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:44:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:44:47 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Session Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:44:47 --> Session routines successfully run
DEBUG - 2011-02-23 18:44:47 --> Controller Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Model Class Initialized
DEBUG - 2011-02-23 18:44:47 --> Model Class Initialized
DEBUG - 2011-02-23 18:44:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:44:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:44:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:44:47 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:44:47 --> Final output sent to browser
DEBUG - 2011-02-23 18:44:47 --> Total execution time: 0.0240
DEBUG - 2011-02-23 18:45:27 --> Config Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:45:27 --> URI Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Router Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Output Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Input Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:45:27 --> Language Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Loader Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:45:27 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:45:27 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:45:27 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:45:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:45:27 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Session Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:45:27 --> Session routines successfully run
DEBUG - 2011-02-23 18:45:27 --> Controller Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Model Class Initialized
DEBUG - 2011-02-23 18:45:27 --> Model Class Initialized
DEBUG - 2011-02-23 18:45:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:45:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:45:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:45:27 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:45:27 --> Final output sent to browser
DEBUG - 2011-02-23 18:45:27 --> Total execution time: 0.0231
DEBUG - 2011-02-23 18:50:13 --> Config Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:50:13 --> URI Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Router Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Output Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Input Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:50:13 --> Language Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Loader Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:50:13 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:50:13 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:50:13 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:50:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:50:13 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Session Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:50:13 --> Session routines successfully run
DEBUG - 2011-02-23 18:50:13 --> Controller Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Model Class Initialized
DEBUG - 2011-02-23 18:50:13 --> Model Class Initialized
DEBUG - 2011-02-23 18:50:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:50:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:50:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:50:13 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:50:13 --> Final output sent to browser
DEBUG - 2011-02-23 18:50:13 --> Total execution time: 0.0224
DEBUG - 2011-02-23 18:56:11 --> Config Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:56:11 --> URI Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Router Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Output Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Input Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:56:11 --> Language Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Loader Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:56:11 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:56:11 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:56:11 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:56:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:56:11 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Session Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:56:11 --> Session routines successfully run
DEBUG - 2011-02-23 18:56:11 --> Controller Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Model Class Initialized
DEBUG - 2011-02-23 18:56:11 --> Model Class Initialized
DEBUG - 2011-02-23 18:56:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:56:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:56:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:56:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:56:11 --> Final output sent to browser
DEBUG - 2011-02-23 18:56:11 --> Total execution time: 0.0235
DEBUG - 2011-02-23 18:56:38 --> Config Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:56:38 --> URI Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Router Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Output Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Input Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:56:38 --> Language Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Loader Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:56:38 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:56:38 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:56:38 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:56:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:56:38 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Session Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:56:38 --> Session routines successfully run
DEBUG - 2011-02-23 18:56:38 --> Controller Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Model Class Initialized
DEBUG - 2011-02-23 18:56:38 --> Model Class Initialized
DEBUG - 2011-02-23 18:56:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:56:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:56:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:56:38 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:56:38 --> Final output sent to browser
DEBUG - 2011-02-23 18:56:38 --> Total execution time: 0.0218
DEBUG - 2011-02-23 18:59:39 --> Config Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Hooks Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Utf8 Class Initialized
DEBUG - 2011-02-23 18:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 18:59:39 --> URI Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Router Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Output Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Input Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 18:59:39 --> Language Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Loader Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 18:59:39 --> Helper loaded: user_helper
DEBUG - 2011-02-23 18:59:39 --> Helper loaded: url_helper
DEBUG - 2011-02-23 18:59:39 --> Helper loaded: array_helper
DEBUG - 2011-02-23 18:59:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 18:59:39 --> Database Driver Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Session Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Helper loaded: string_helper
DEBUG - 2011-02-23 18:59:39 --> Session routines successfully run
DEBUG - 2011-02-23 18:59:39 --> Controller Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Model Class Initialized
DEBUG - 2011-02-23 18:59:39 --> Model Class Initialized
DEBUG - 2011-02-23 18:59:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 18:59:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 18:59:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 18:59:39 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 18:59:39 --> Final output sent to browser
DEBUG - 2011-02-23 18:59:39 --> Total execution time: 0.0217
DEBUG - 2011-02-23 19:00:06 --> Config Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:00:06 --> URI Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Router Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Output Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Input Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:00:06 --> Language Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Loader Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:00:06 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:00:06 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:00:06 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:00:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:00:06 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Session Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:00:06 --> Session routines successfully run
DEBUG - 2011-02-23 19:00:06 --> Controller Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:00:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:00:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:00:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:00:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:00:06 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:00:06 --> Final output sent to browser
DEBUG - 2011-02-23 19:00:06 --> Total execution time: 0.0223
DEBUG - 2011-02-23 19:01:05 --> Config Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:01:05 --> URI Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Router Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Output Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Input Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:01:05 --> Language Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Loader Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:01:05 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:01:05 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:01:05 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:01:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:01:05 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Session Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:01:05 --> Session routines successfully run
DEBUG - 2011-02-23 19:01:05 --> Controller Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Model Class Initialized
DEBUG - 2011-02-23 19:01:05 --> Model Class Initialized
DEBUG - 2011-02-23 19:01:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:01:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:01:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:01:05 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:01:05 --> Final output sent to browser
DEBUG - 2011-02-23 19:01:05 --> Total execution time: 0.0260
DEBUG - 2011-02-23 19:07:54 --> Config Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:07:54 --> URI Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Router Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Output Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Input Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:07:54 --> Language Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Loader Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:07:54 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:07:54 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:07:54 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:07:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:07:54 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Session Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:07:54 --> Session routines successfully run
DEBUG - 2011-02-23 19:07:54 --> Controller Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Model Class Initialized
DEBUG - 2011-02-23 19:07:54 --> Model Class Initialized
DEBUG - 2011-02-23 19:07:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:07:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:07:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:07:54 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:07:54 --> Final output sent to browser
DEBUG - 2011-02-23 19:07:54 --> Total execution time: 0.0227
DEBUG - 2011-02-23 19:08:48 --> Config Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:08:48 --> URI Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Router Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Output Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Input Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:08:48 --> Language Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Loader Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:08:48 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:08:48 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:08:48 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:08:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:08:48 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Session Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:08:48 --> Session routines successfully run
DEBUG - 2011-02-23 19:08:48 --> Controller Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Model Class Initialized
DEBUG - 2011-02-23 19:08:48 --> Model Class Initialized
DEBUG - 2011-02-23 19:08:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:08:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:08:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:08:48 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:08:48 --> Final output sent to browser
DEBUG - 2011-02-23 19:08:48 --> Total execution time: 0.0224
DEBUG - 2011-02-23 19:08:56 --> Config Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:08:56 --> URI Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Router Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Output Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Input Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:08:56 --> Language Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Loader Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:08:56 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:08:56 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:08:56 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:08:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:08:56 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Session Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:08:56 --> Session routines successfully run
DEBUG - 2011-02-23 19:08:56 --> Controller Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Model Class Initialized
DEBUG - 2011-02-23 19:08:56 --> Model Class Initialized
DEBUG - 2011-02-23 19:08:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:08:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:08:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:08:56 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:08:56 --> Final output sent to browser
DEBUG - 2011-02-23 19:08:56 --> Total execution time: 0.0265
DEBUG - 2011-02-23 19:09:11 --> Config Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:09:11 --> URI Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Router Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Output Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Input Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:09:11 --> Language Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Loader Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:09:11 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:09:11 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:09:11 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:09:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:09:11 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Session Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:09:11 --> Session routines successfully run
DEBUG - 2011-02-23 19:09:11 --> Controller Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Model Class Initialized
DEBUG - 2011-02-23 19:09:11 --> Model Class Initialized
DEBUG - 2011-02-23 19:09:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:09:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:09:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:09:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:09:11 --> Final output sent to browser
DEBUG - 2011-02-23 19:09:11 --> Total execution time: 0.0231
DEBUG - 2011-02-23 19:09:22 --> Config Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:09:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:09:22 --> URI Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Router Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Output Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Input Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:09:22 --> Language Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Loader Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:09:22 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:09:22 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:09:22 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:09:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:09:22 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Session Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:09:22 --> Session routines successfully run
DEBUG - 2011-02-23 19:09:22 --> Controller Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Model Class Initialized
DEBUG - 2011-02-23 19:09:22 --> Model Class Initialized
DEBUG - 2011-02-23 19:09:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:09:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:09:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:09:22 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:09:22 --> Final output sent to browser
DEBUG - 2011-02-23 19:09:22 --> Total execution time: 0.0253
DEBUG - 2011-02-23 19:13:30 --> Config Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:13:30 --> URI Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Router Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Output Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Input Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:13:30 --> Language Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Loader Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:13:30 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:13:30 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:13:30 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:13:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:13:30 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Session Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:13:30 --> Session routines successfully run
DEBUG - 2011-02-23 19:13:30 --> Controller Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:13:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:13:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:13:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:13:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:13:30 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:13:30 --> Final output sent to browser
DEBUG - 2011-02-23 19:13:30 --> Total execution time: 0.0220
DEBUG - 2011-02-23 19:14:09 --> Config Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:14:09 --> URI Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Router Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Output Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Input Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:14:09 --> Language Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Loader Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:14:09 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:14:09 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:14:09 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:14:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:14:09 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Session Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:14:09 --> Session routines successfully run
DEBUG - 2011-02-23 19:14:09 --> Controller Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Model Class Initialized
DEBUG - 2011-02-23 19:14:09 --> Model Class Initialized
DEBUG - 2011-02-23 19:14:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:14:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:14:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:14:09 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:14:09 --> Final output sent to browser
DEBUG - 2011-02-23 19:14:09 --> Total execution time: 0.0235
DEBUG - 2011-02-23 19:14:32 --> Config Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:14:32 --> URI Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Router Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Output Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Input Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:14:32 --> Language Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Loader Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:14:32 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:14:32 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:14:32 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:14:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:14:32 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Session Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:14:32 --> Session routines successfully run
DEBUG - 2011-02-23 19:14:32 --> Controller Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Model Class Initialized
DEBUG - 2011-02-23 19:14:32 --> Model Class Initialized
DEBUG - 2011-02-23 19:14:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:14:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:14:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:14:32 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:14:32 --> Final output sent to browser
DEBUG - 2011-02-23 19:14:32 --> Total execution time: 0.0238
DEBUG - 2011-02-23 19:15:47 --> Config Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:15:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:15:47 --> URI Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Router Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Output Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Input Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:15:47 --> Language Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Loader Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:15:47 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:15:47 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:15:47 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:15:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:15:47 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Session Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:15:47 --> Session routines successfully run
DEBUG - 2011-02-23 19:15:47 --> Controller Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Model Class Initialized
DEBUG - 2011-02-23 19:15:47 --> Model Class Initialized
DEBUG - 2011-02-23 19:15:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:15:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:15:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:15:47 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:15:47 --> Final output sent to browser
DEBUG - 2011-02-23 19:15:47 --> Total execution time: 0.0219
DEBUG - 2011-02-23 19:15:50 --> Config Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:15:50 --> URI Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Router Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Output Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Input Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:15:50 --> Language Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Loader Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:15:50 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:15:50 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:15:50 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:15:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:15:50 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Session Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:15:50 --> Session routines successfully run
DEBUG - 2011-02-23 19:15:50 --> Controller Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Helper loaded: robot_helper
DEBUG - 2011-02-23 19:15:50 --> Helper loaded: form_helper
DEBUG - 2011-02-23 19:15:50 --> Form Validation Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Model Class Initialized
DEBUG - 2011-02-23 19:15:50 --> Model Class Initialized
DEBUG - 2011-02-23 19:15:50 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 19:15:50 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 19:15:50 --> File loaded: application/views/contributors/register.php
DEBUG - 2011-02-23 19:15:50 --> Final output sent to browser
DEBUG - 2011-02-23 19:15:50 --> Total execution time: 0.0287
DEBUG - 2011-02-23 19:17:52 --> Config Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:17:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:17:52 --> URI Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Router Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Output Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Input Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:17:52 --> Language Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Loader Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:17:52 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:17:52 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:17:52 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:17:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:17:52 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Session Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:17:52 --> Session routines successfully run
DEBUG - 2011-02-23 19:17:52 --> Controller Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Model Class Initialized
DEBUG - 2011-02-23 19:17:52 --> Model Class Initialized
DEBUG - 2011-02-23 19:17:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:17:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:17:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:17:52 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:17:52 --> Final output sent to browser
DEBUG - 2011-02-23 19:17:52 --> Total execution time: 0.0221
DEBUG - 2011-02-23 19:18:08 --> Config Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:18:08 --> URI Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Router Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Output Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Input Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:18:08 --> Language Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Loader Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:18:08 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:18:08 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:18:08 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:18:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:18:08 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Session Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:18:08 --> Session routines successfully run
DEBUG - 2011-02-23 19:18:08 --> Controller Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Model Class Initialized
DEBUG - 2011-02-23 19:18:08 --> Model Class Initialized
DEBUG - 2011-02-23 19:18:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:18:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:18:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:18:08 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:18:08 --> Final output sent to browser
DEBUG - 2011-02-23 19:18:08 --> Total execution time: 0.0232
DEBUG - 2011-02-23 19:18:37 --> Config Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:18:37 --> URI Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Router Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Output Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Input Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:18:37 --> Language Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Loader Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:18:37 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:18:37 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:18:37 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:18:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:18:37 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Session Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:18:37 --> Session routines successfully run
DEBUG - 2011-02-23 19:18:37 --> Controller Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Model Class Initialized
DEBUG - 2011-02-23 19:18:37 --> Model Class Initialized
DEBUG - 2011-02-23 19:18:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:18:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:18:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:18:37 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:18:37 --> Final output sent to browser
DEBUG - 2011-02-23 19:18:37 --> Total execution time: 0.0237
DEBUG - 2011-02-23 19:19:56 --> Config Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:19:56 --> URI Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Router Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Output Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Input Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:19:56 --> Language Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Loader Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:19:56 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:19:56 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:19:56 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:19:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:19:56 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Session Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:19:56 --> Session routines successfully run
DEBUG - 2011-02-23 19:19:56 --> Controller Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Model Class Initialized
DEBUG - 2011-02-23 19:19:56 --> Model Class Initialized
DEBUG - 2011-02-23 19:19:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:19:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:19:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:19:56 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:19:56 --> Final output sent to browser
DEBUG - 2011-02-23 19:19:56 --> Total execution time: 0.0271
DEBUG - 2011-02-23 19:19:58 --> Config Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:19:58 --> URI Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Router Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Output Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Input Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:19:58 --> Language Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Loader Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:19:58 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Session Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:19:58 --> Session routines successfully run
DEBUG - 2011-02-23 19:19:58 --> Controller Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Config Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:19:58 --> URI Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Router Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Output Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Input Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:19:58 --> Language Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Loader Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:19:58 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Session Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:19:58 --> Session routines successfully run
DEBUG - 2011-02-23 19:19:58 --> Controller Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Model Class Initialized
DEBUG - 2011-02-23 19:19:58 --> Model Class Initialized
DEBUG - 2011-02-23 19:19:58 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 19:19:58 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 19:19:58 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-23 19:19:58 --> Final output sent to browser
DEBUG - 2011-02-23 19:19:58 --> Total execution time: 0.0217
DEBUG - 2011-02-23 19:20:02 --> Config Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:20:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:20:02 --> URI Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Router Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Output Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Input Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:20:02 --> Language Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Loader Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:20:02 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Session Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:20:02 --> Session routines successfully run
DEBUG - 2011-02-23 19:20:02 --> Controller Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Config Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:20:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:20:02 --> URI Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Router Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Output Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Input Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:20:02 --> Language Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Loader Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:20:02 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Session Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:20:02 --> Session routines successfully run
DEBUG - 2011-02-23 19:20:02 --> Controller Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:02 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:02 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 19:20:02 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 19:20:02 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-23 19:20:02 --> Final output sent to browser
DEBUG - 2011-02-23 19:20:02 --> Total execution time: 0.0218
DEBUG - 2011-02-23 19:20:25 --> Config Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:20:25 --> URI Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Router Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Output Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Input Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:20:25 --> Language Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Loader Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:20:25 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Session Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:20:25 --> Session routines successfully run
DEBUG - 2011-02-23 19:20:25 --> Controller Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Config Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:20:25 --> URI Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Router Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Output Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Input Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:20:25 --> Language Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Loader Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:20:25 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Session Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:20:25 --> Session routines successfully run
DEBUG - 2011-02-23 19:20:25 --> Controller Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:25 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:25 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 19:20:25 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 19:20:25 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-23 19:20:25 --> Final output sent to browser
DEBUG - 2011-02-23 19:20:25 --> Total execution time: 0.0215
DEBUG - 2011-02-23 19:20:29 --> Config Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:20:29 --> URI Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Router Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Output Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Input Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:20:29 --> Language Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Loader Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:20:29 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Session Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:20:29 --> Session routines successfully run
DEBUG - 2011-02-23 19:20:29 --> Controller Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Config Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:20:29 --> URI Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Router Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Output Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Input Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:20:29 --> Language Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Loader Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:20:29 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Session Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:20:29 --> Session routines successfully run
DEBUG - 2011-02-23 19:20:29 --> Controller Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: form_helper
DEBUG - 2011-02-23 19:20:29 --> Form Validation Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 19:20:29 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:29 --> Model Class Initialized
DEBUG - 2011-02-23 19:20:29 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-23 19:20:29 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-23 19:20:29 --> File loaded: application/views/packages/add.php
DEBUG - 2011-02-23 19:20:29 --> Final output sent to browser
DEBUG - 2011-02-23 19:20:29 --> Total execution time: 0.0295
DEBUG - 2011-02-23 19:22:06 --> Config Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:22:06 --> URI Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Router Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Output Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Input Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:22:06 --> Language Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Loader Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:22:06 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Session Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:22:06 --> Session routines successfully run
DEBUG - 2011-02-23 19:22:06 --> Controller Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: form_helper
DEBUG - 2011-02-23 19:22:06 --> Form Validation Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Config Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:22:06 --> URI Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Router Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Output Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Input Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:22:06 --> Language Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Loader Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:22:06 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Session Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:22:06 --> Session routines successfully run
DEBUG - 2011-02-23 19:22:06 --> Controller Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> Model Class Initialized
DEBUG - 2011-02-23 19:22:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:22:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:22:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:22:06 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-23 19:22:06 --> Final output sent to browser
DEBUG - 2011-02-23 19:22:06 --> Total execution time: 0.0260
DEBUG - 2011-02-23 19:27:30 --> Config Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:27:30 --> URI Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Router Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Output Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Input Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:27:30 --> Language Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Loader Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:27:30 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:27:30 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:27:30 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:27:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:27:30 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Session Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:27:30 --> Session routines successfully run
DEBUG - 2011-02-23 19:27:30 --> Controller Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:30 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:27:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:27:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:27:30 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-23 19:27:30 --> Final output sent to browser
DEBUG - 2011-02-23 19:27:30 --> Total execution time: 0.0284
DEBUG - 2011-02-23 19:27:42 --> Config Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:27:42 --> URI Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Router Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Output Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Input Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:27:42 --> Language Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Loader Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:27:42 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:27:42 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:27:42 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:27:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:27:42 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Session Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:27:42 --> Session routines successfully run
DEBUG - 2011-02-23 19:27:42 --> Controller Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:42 --> Model Class Initialized
DEBUG - 2011-02-23 19:27:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:27:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:27:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:27:42 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:27:42 --> Final output sent to browser
DEBUG - 2011-02-23 19:27:42 --> Total execution time: 0.0222
DEBUG - 2011-02-23 19:28:05 --> Config Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:28:05 --> URI Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Router Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Output Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Input Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:28:05 --> Language Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Loader Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:28:05 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:28:05 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:28:05 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:28:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:28:05 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Session Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:28:05 --> Session routines successfully run
DEBUG - 2011-02-23 19:28:05 --> Controller Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Model Class Initialized
DEBUG - 2011-02-23 19:28:05 --> Model Class Initialized
DEBUG - 2011-02-23 19:28:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:28:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:28:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:28:05 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:28:05 --> Final output sent to browser
DEBUG - 2011-02-23 19:28:05 --> Total execution time: 0.0238
DEBUG - 2011-02-23 19:30:39 --> Config Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:30:39 --> URI Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Router Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Output Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Input Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:30:39 --> Language Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Loader Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:30:39 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:30:39 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:30:39 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:30:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:30:39 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Session Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:30:39 --> Session routines successfully run
DEBUG - 2011-02-23 19:30:39 --> Controller Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Model Class Initialized
DEBUG - 2011-02-23 19:30:39 --> Model Class Initialized
DEBUG - 2011-02-23 19:30:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:30:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:30:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:30:39 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:30:39 --> Final output sent to browser
DEBUG - 2011-02-23 19:30:39 --> Total execution time: 0.0219
DEBUG - 2011-02-23 19:36:09 --> Config Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:36:09 --> URI Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Router Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Output Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Input Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:36:09 --> Language Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Loader Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:36:09 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:36:09 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:36:09 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:36:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:36:09 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Session Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:36:09 --> Session routines successfully run
DEBUG - 2011-02-23 19:36:09 --> Controller Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Model Class Initialized
DEBUG - 2011-02-23 19:36:09 --> Model Class Initialized
DEBUG - 2011-02-23 19:36:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:36:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:36:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:36:09 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:36:09 --> Final output sent to browser
DEBUG - 2011-02-23 19:36:09 --> Total execution time: 0.0225
DEBUG - 2011-02-23 19:36:23 --> Config Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:36:23 --> URI Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Router Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Output Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Input Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:36:23 --> Language Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Loader Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:36:23 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:36:23 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:36:23 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:36:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:36:23 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Session Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:36:23 --> Session routines successfully run
DEBUG - 2011-02-23 19:36:23 --> Controller Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Model Class Initialized
DEBUG - 2011-02-23 19:36:23 --> Model Class Initialized
DEBUG - 2011-02-23 19:36:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:36:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:36:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:36:23 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:36:23 --> Final output sent to browser
DEBUG - 2011-02-23 19:36:23 --> Total execution time: 0.0234
DEBUG - 2011-02-23 19:37:04 --> Config Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Hooks Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Utf8 Class Initialized
DEBUG - 2011-02-23 19:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 19:37:04 --> URI Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Router Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Output Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Input Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 19:37:04 --> Language Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Loader Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 19:37:04 --> Helper loaded: user_helper
DEBUG - 2011-02-23 19:37:04 --> Helper loaded: url_helper
DEBUG - 2011-02-23 19:37:04 --> Helper loaded: array_helper
DEBUG - 2011-02-23 19:37:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 19:37:04 --> Database Driver Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Session Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Helper loaded: string_helper
DEBUG - 2011-02-23 19:37:04 --> Session routines successfully run
DEBUG - 2011-02-23 19:37:04 --> Controller Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Model Class Initialized
DEBUG - 2011-02-23 19:37:04 --> Model Class Initialized
DEBUG - 2011-02-23 19:37:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 19:37:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 19:37:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 19:37:04 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 19:37:04 --> Final output sent to browser
DEBUG - 2011-02-23 19:37:04 --> Total execution time: 0.0239
DEBUG - 2011-02-23 20:05:33 --> Config Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Hooks Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Utf8 Class Initialized
DEBUG - 2011-02-23 20:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 20:05:33 --> URI Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Router Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Output Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Input Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 20:05:33 --> Language Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Loader Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 20:05:33 --> Helper loaded: user_helper
DEBUG - 2011-02-23 20:05:33 --> Helper loaded: url_helper
DEBUG - 2011-02-23 20:05:33 --> Helper loaded: array_helper
DEBUG - 2011-02-23 20:05:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 20:05:33 --> Database Driver Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Session Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Helper loaded: string_helper
DEBUG - 2011-02-23 20:05:33 --> Session routines successfully run
DEBUG - 2011-02-23 20:05:33 --> Controller Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Model Class Initialized
DEBUG - 2011-02-23 20:05:33 --> Model Class Initialized
DEBUG - 2011-02-23 20:05:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 20:05:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 20:05:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 20:05:33 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 20:05:33 --> Final output sent to browser
DEBUG - 2011-02-23 20:05:33 --> Total execution time: 0.0237
DEBUG - 2011-02-23 20:08:14 --> Config Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Hooks Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Utf8 Class Initialized
DEBUG - 2011-02-23 20:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 20:08:14 --> URI Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Router Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Output Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Input Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 20:08:14 --> Language Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Loader Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 20:08:14 --> Helper loaded: user_helper
DEBUG - 2011-02-23 20:08:14 --> Helper loaded: url_helper
DEBUG - 2011-02-23 20:08:14 --> Helper loaded: array_helper
DEBUG - 2011-02-23 20:08:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 20:08:14 --> Database Driver Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Session Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Helper loaded: string_helper
DEBUG - 2011-02-23 20:08:14 --> Session routines successfully run
DEBUG - 2011-02-23 20:08:14 --> Controller Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Model Class Initialized
DEBUG - 2011-02-23 20:08:14 --> Model Class Initialized
DEBUG - 2011-02-23 20:08:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 20:08:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 20:08:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 20:08:14 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-23 20:08:14 --> Final output sent to browser
DEBUG - 2011-02-23 20:08:14 --> Total execution time: 0.0230
DEBUG - 2011-02-23 22:24:05 --> Config Class Initialized
DEBUG - 2011-02-23 22:24:05 --> Hooks Class Initialized
DEBUG - 2011-02-23 22:24:05 --> Utf8 Class Initialized
DEBUG - 2011-02-23 22:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 22:24:05 --> URI Class Initialized
DEBUG - 2011-02-23 22:24:05 --> Router Class Initialized
ERROR - 2011-02-23 22:24:05 --> 404 Page Not Found --> project
DEBUG - 2011-02-23 22:24:46 --> Config Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Hooks Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Utf8 Class Initialized
DEBUG - 2011-02-23 22:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 22:24:46 --> URI Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Router Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Output Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Input Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 22:24:46 --> Language Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Loader Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 22:24:46 --> Helper loaded: user_helper
DEBUG - 2011-02-23 22:24:46 --> Helper loaded: url_helper
DEBUG - 2011-02-23 22:24:46 --> Helper loaded: array_helper
DEBUG - 2011-02-23 22:24:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 22:24:46 --> Database Driver Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Session Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Helper loaded: string_helper
DEBUG - 2011-02-23 22:24:46 --> A session cookie was not found.
DEBUG - 2011-02-23 22:24:46 --> Session routines successfully run
DEBUG - 2011-02-23 22:24:46 --> Controller Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 22:24:46 --> Model Class Initialized
DEBUG - 2011-02-23 22:24:46 --> Model Class Initialized
DEBUG - 2011-02-23 22:24:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 22:24:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 22:24:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 22:24:46 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-23 22:24:46 --> Final output sent to browser
DEBUG - 2011-02-23 22:24:46 --> Total execution time: 0.0264
DEBUG - 2011-02-23 22:25:13 --> Config Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Hooks Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Utf8 Class Initialized
DEBUG - 2011-02-23 22:25:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 22:25:13 --> URI Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Router Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Output Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Input Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 22:25:13 --> Language Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Loader Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 22:25:13 --> Helper loaded: user_helper
DEBUG - 2011-02-23 22:25:13 --> Helper loaded: url_helper
DEBUG - 2011-02-23 22:25:13 --> Helper loaded: array_helper
DEBUG - 2011-02-23 22:25:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 22:25:13 --> Database Driver Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Session Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Helper loaded: string_helper
DEBUG - 2011-02-23 22:25:13 --> Session routines successfully run
DEBUG - 2011-02-23 22:25:13 --> Controller Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 22:25:13 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:13 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 22:25:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 22:25:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 22:25:13 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-23 22:25:13 --> Final output sent to browser
DEBUG - 2011-02-23 22:25:13 --> Total execution time: 0.0242
DEBUG - 2011-02-23 22:25:14 --> Config Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Hooks Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Utf8 Class Initialized
DEBUG - 2011-02-23 22:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 22:25:14 --> URI Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Router Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Output Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Input Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 22:25:14 --> Language Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Loader Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 22:25:14 --> Helper loaded: user_helper
DEBUG - 2011-02-23 22:25:14 --> Helper loaded: url_helper
DEBUG - 2011-02-23 22:25:14 --> Helper loaded: array_helper
DEBUG - 2011-02-23 22:25:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 22:25:14 --> Database Driver Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Session Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Helper loaded: string_helper
DEBUG - 2011-02-23 22:25:14 --> Session routines successfully run
DEBUG - 2011-02-23 22:25:14 --> Controller Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 22:25:14 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:14 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 22:25:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 22:25:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 22:25:14 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-23 22:25:14 --> Final output sent to browser
DEBUG - 2011-02-23 22:25:14 --> Total execution time: 0.0236
DEBUG - 2011-02-23 22:25:15 --> Config Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Hooks Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Utf8 Class Initialized
DEBUG - 2011-02-23 22:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 22:25:15 --> URI Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Router Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Output Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Input Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 22:25:15 --> Language Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Loader Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 22:25:15 --> Helper loaded: user_helper
DEBUG - 2011-02-23 22:25:15 --> Helper loaded: url_helper
DEBUG - 2011-02-23 22:25:15 --> Helper loaded: array_helper
DEBUG - 2011-02-23 22:25:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 22:25:15 --> Database Driver Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Session Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Helper loaded: string_helper
DEBUG - 2011-02-23 22:25:15 --> Session routines successfully run
DEBUG - 2011-02-23 22:25:15 --> Controller Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 22:25:15 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:15 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 22:25:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 22:25:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 22:25:15 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-23 22:25:15 --> Final output sent to browser
DEBUG - 2011-02-23 22:25:15 --> Total execution time: 0.0235
DEBUG - 2011-02-23 22:25:19 --> Config Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Hooks Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Utf8 Class Initialized
DEBUG - 2011-02-23 22:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 22:25:19 --> URI Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Router Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Output Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Input Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 22:25:19 --> Language Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Loader Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 22:25:19 --> Helper loaded: user_helper
DEBUG - 2011-02-23 22:25:19 --> Helper loaded: url_helper
DEBUG - 2011-02-23 22:25:19 --> Helper loaded: array_helper
DEBUG - 2011-02-23 22:25:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 22:25:19 --> Database Driver Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Session Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Helper loaded: string_helper
DEBUG - 2011-02-23 22:25:19 --> Session routines successfully run
DEBUG - 2011-02-23 22:25:19 --> Controller Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:19 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 22:25:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 22:25:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 22:25:19 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-23 22:25:19 --> Final output sent to browser
DEBUG - 2011-02-23 22:25:19 --> Total execution time: 0.0238
DEBUG - 2011-02-23 22:25:26 --> Config Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Hooks Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Utf8 Class Initialized
DEBUG - 2011-02-23 22:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 22:25:26 --> URI Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Router Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Output Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Input Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 22:25:26 --> Language Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Loader Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 22:25:26 --> Helper loaded: user_helper
DEBUG - 2011-02-23 22:25:26 --> Helper loaded: url_helper
DEBUG - 2011-02-23 22:25:26 --> Helper loaded: array_helper
DEBUG - 2011-02-23 22:25:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 22:25:26 --> Database Driver Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Session Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Helper loaded: string_helper
DEBUG - 2011-02-23 22:25:26 --> Session routines successfully run
DEBUG - 2011-02-23 22:25:26 --> Controller Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 22:25:26 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:26 --> Model Class Initialized
DEBUG - 2011-02-23 22:25:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 22:25:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 22:25:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 22:25:26 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-23 22:25:26 --> Final output sent to browser
DEBUG - 2011-02-23 22:25:26 --> Total execution time: 0.0295
DEBUG - 2011-02-23 23:26:09 --> Config Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Hooks Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Utf8 Class Initialized
DEBUG - 2011-02-23 23:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 23:26:09 --> URI Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Router Class Initialized
DEBUG - 2011-02-23 23:26:09 --> No URI present. Default controller set.
DEBUG - 2011-02-23 23:26:09 --> Output Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Input Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 23:26:09 --> Language Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Loader Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 23:26:09 --> Helper loaded: user_helper
DEBUG - 2011-02-23 23:26:09 --> Helper loaded: url_helper
DEBUG - 2011-02-23 23:26:09 --> Helper loaded: array_helper
DEBUG - 2011-02-23 23:26:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 23:26:09 --> Database Driver Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Session Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Helper loaded: string_helper
DEBUG - 2011-02-23 23:26:09 --> Session routines successfully run
DEBUG - 2011-02-23 23:26:09 --> Controller Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> Model Class Initialized
DEBUG - 2011-02-23 23:26:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 23:26:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 23:26:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 23:26:09 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-23 23:26:09 --> Final output sent to browser
DEBUG - 2011-02-23 23:26:09 --> Total execution time: 0.0429
DEBUG - 2011-02-23 23:27:44 --> Config Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Hooks Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Utf8 Class Initialized
DEBUG - 2011-02-23 23:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-23 23:27:44 --> URI Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Router Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Output Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Input Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-23 23:27:44 --> Language Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Loader Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-23 23:27:44 --> Helper loaded: user_helper
DEBUG - 2011-02-23 23:27:44 --> Helper loaded: url_helper
DEBUG - 2011-02-23 23:27:44 --> Helper loaded: array_helper
DEBUG - 2011-02-23 23:27:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-23 23:27:44 --> Database Driver Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Session Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Helper loaded: string_helper
DEBUG - 2011-02-23 23:27:44 --> Session routines successfully run
DEBUG - 2011-02-23 23:27:44 --> Controller Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-23 23:27:44 --> Model Class Initialized
DEBUG - 2011-02-23 23:27:44 --> Model Class Initialized
DEBUG - 2011-02-23 23:27:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-23 23:27:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-23 23:27:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-23 23:27:44 --> File loaded: application/views/home/project.php
DEBUG - 2011-02-23 23:27:44 --> Final output sent to browser
DEBUG - 2011-02-23 23:27:44 --> Total execution time: 0.0334
