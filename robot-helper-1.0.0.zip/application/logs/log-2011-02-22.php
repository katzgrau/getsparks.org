<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-22 08:43:48 --> Config Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:43:48 --> URI Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Router Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Output Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Input Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:43:48 --> Language Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Loader Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:43:48 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:43:48 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:43:48 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:43:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:43:48 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Session Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:43:48 --> A session cookie was not found.
DEBUG - 2011-02-22 08:43:48 --> Session routines successfully run
DEBUG - 2011-02-22 08:43:48 --> Controller Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:48 --> Model Class Initialized
ERROR - 2011-02-22 08:43:48 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-22 08:43:48 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 08:43:48 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 08:43:48 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 08:43:48 --> Final output sent to browser
DEBUG - 2011-02-22 08:43:48 --> Total execution time: 0.0322
DEBUG - 2011-02-22 08:43:53 --> Config Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:43:53 --> URI Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Router Class Initialized
DEBUG - 2011-02-22 08:43:53 --> No URI present. Default controller set.
DEBUG - 2011-02-22 08:43:53 --> Output Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Input Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:43:53 --> Language Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Loader Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:43:53 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:43:53 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:43:53 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:43:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:43:53 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Session Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:43:53 --> Session routines successfully run
DEBUG - 2011-02-22 08:43:53 --> Controller Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Model Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Config Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:43:53 --> URI Class Initialized
DEBUG - 2011-02-22 08:43:53 --> Router Class Initialized
ERROR - 2011-02-22 08:43:53 --> 404 Page Not Found --> %3Cbr
DEBUG - 2011-02-22 08:46:12 --> Config Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:46:12 --> URI Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Router Class Initialized
DEBUG - 2011-02-22 08:46:12 --> No URI present. Default controller set.
DEBUG - 2011-02-22 08:46:12 --> Output Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Input Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:46:12 --> Language Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Loader Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:46:12 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:46:12 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:46:12 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:46:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:46:12 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Session Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:46:12 --> Session routines successfully run
DEBUG - 2011-02-22 08:46:12 --> Controller Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Model Class Initialized
DEBUG - 2011-02-22 08:46:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 08:46:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 08:46:12 --> Config Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:46:12 --> URI Class Initialized
DEBUG - 2011-02-22 08:46:12 --> Router Class Initialized
ERROR - 2011-02-22 08:46:12 --> 404 Page Not Found --> %3Cbr
DEBUG - 2011-02-22 08:47:11 --> Config Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:47:11 --> URI Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Router Class Initialized
DEBUG - 2011-02-22 08:47:11 --> No URI present. Default controller set.
DEBUG - 2011-02-22 08:47:11 --> Output Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Input Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:47:11 --> Language Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Loader Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:47:11 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:47:11 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:47:11 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:47:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:47:11 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Session Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:47:11 --> Session routines successfully run
DEBUG - 2011-02-22 08:47:11 --> Controller Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 08:47:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 08:47:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 08:47:11 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 08:47:11 --> Final output sent to browser
DEBUG - 2011-02-22 08:47:11 --> Total execution time: 0.0431
DEBUG - 2011-02-22 08:47:38 --> Config Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:47:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:47:38 --> URI Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Router Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Output Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Input Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:47:38 --> Language Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Loader Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:47:38 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:47:38 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:47:38 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:47:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:47:38 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Session Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:47:38 --> Session routines successfully run
DEBUG - 2011-02-22 08:47:38 --> Controller Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
ERROR - 2011-02-22 08:47:38 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:38 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:38 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 08:47:38 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 08:47:38 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 08:47:38 --> Final output sent to browser
DEBUG - 2011-02-22 08:47:38 --> Total execution time: 0.0315
DEBUG - 2011-02-22 08:47:50 --> Config Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:47:50 --> URI Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Router Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Output Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Input Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:47:50 --> Language Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Loader Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:47:50 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:47:50 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:47:50 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:47:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:47:50 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Session Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:47:50 --> Session routines successfully run
DEBUG - 2011-02-22 08:47:50 --> Controller Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 08:47:50 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 08:47:50 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 08:47:50 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 08:47:50 --> Final output sent to browser
DEBUG - 2011-02-22 08:47:50 --> Total execution time: 0.0309
DEBUG - 2011-02-22 08:55:59 --> Config Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:55:59 --> URI Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Router Class Initialized
DEBUG - 2011-02-22 08:55:59 --> No URI present. Default controller set.
DEBUG - 2011-02-22 08:55:59 --> Output Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Input Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:55:59 --> Language Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Loader Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:55:59 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:55:59 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:55:59 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:55:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:55:59 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Session Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:55:59 --> Session routines successfully run
DEBUG - 2011-02-22 08:55:59 --> Controller Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> Model Class Initialized
DEBUG - 2011-02-22 08:55:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 08:55:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 08:55:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 08:55:59 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 08:55:59 --> Final output sent to browser
DEBUG - 2011-02-22 08:55:59 --> Total execution time: 0.0365
DEBUG - 2011-02-22 08:56:09 --> Config Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:56:09 --> URI Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Router Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Output Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Input Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:56:09 --> Language Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Loader Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:56:09 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:56:09 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:56:09 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:56:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:56:09 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Session Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:56:09 --> Session routines successfully run
DEBUG - 2011-02-22 08:56:09 --> Controller Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:09 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:09 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 08:56:09 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 08:56:09 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-22 08:56:09 --> Final output sent to browser
DEBUG - 2011-02-22 08:56:09 --> Total execution time: 0.0275
DEBUG - 2011-02-22 08:56:19 --> Config Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:56:19 --> URI Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Router Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Output Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Input Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:56:19 --> Language Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Loader Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:56:19 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:56:19 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:56:19 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:56:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:56:19 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Session Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:56:19 --> Session routines successfully run
DEBUG - 2011-02-22 08:56:19 --> Controller Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:19 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:19 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 08:56:19 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 08:56:19 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-02-22 08:56:19 --> Final output sent to browser
DEBUG - 2011-02-22 08:56:19 --> Total execution time: 0.0251
DEBUG - 2011-02-22 08:56:25 --> Config Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:56:25 --> URI Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Router Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Output Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Input Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:56:25 --> Language Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Loader Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:56:25 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Session Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:56:25 --> Session routines successfully run
DEBUG - 2011-02-22 08:56:25 --> Controller Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Config Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:56:25 --> URI Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Router Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Output Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Input Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:56:25 --> Language Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Loader Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:56:25 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Session Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:56:25 --> Session routines successfully run
DEBUG - 2011-02-22 08:56:25 --> Controller Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 08:56:25 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 08:56:25 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 08:56:25 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-22 08:56:25 --> Final output sent to browser
DEBUG - 2011-02-22 08:56:25 --> Total execution time: 0.0347
DEBUG - 2011-02-22 08:56:27 --> Config Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:56:27 --> URI Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Router Class Initialized
DEBUG - 2011-02-22 08:56:27 --> No URI present. Default controller set.
DEBUG - 2011-02-22 08:56:27 --> Output Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Input Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:56:27 --> Language Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Loader Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:56:27 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:56:27 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:56:27 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:56:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:56:27 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Session Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:56:27 --> Session routines successfully run
DEBUG - 2011-02-22 08:56:27 --> Controller Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 08:56:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 08:56:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 08:56:27 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 08:56:27 --> Final output sent to browser
DEBUG - 2011-02-22 08:56:27 --> Total execution time: 0.0339
DEBUG - 2011-02-22 08:56:41 --> Config Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Hooks Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Utf8 Class Initialized
DEBUG - 2011-02-22 08:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 08:56:41 --> URI Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Router Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Output Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Input Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 08:56:41 --> Language Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Loader Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 08:56:41 --> Helper loaded: user_helper
DEBUG - 2011-02-22 08:56:41 --> Helper loaded: url_helper
DEBUG - 2011-02-22 08:56:41 --> Helper loaded: array_helper
DEBUG - 2011-02-22 08:56:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 08:56:41 --> Database Driver Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Session Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Helper loaded: string_helper
DEBUG - 2011-02-22 08:56:41 --> Session routines successfully run
DEBUG - 2011-02-22 08:56:41 --> Controller Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Model Class Initialized
DEBUG - 2011-02-22 08:56:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 08:56:41 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 08:56:41 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 08:56:41 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-02-22 08:56:41 --> Final output sent to browser
DEBUG - 2011-02-22 08:56:41 --> Total execution time: 0.0303
DEBUG - 2011-02-22 09:06:33 --> Config Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:06:33 --> URI Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Router Class Initialized
DEBUG - 2011-02-22 09:06:33 --> No URI present. Default controller set.
DEBUG - 2011-02-22 09:06:33 --> Output Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Input Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:06:33 --> Language Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Loader Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:06:33 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:06:33 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:06:33 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:06:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:06:33 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Session Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:06:33 --> Session routines successfully run
DEBUG - 2011-02-22 09:06:33 --> Controller Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:06:33 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:06:33 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:06:33 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:06:33 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 09:06:33 --> Final output sent to browser
DEBUG - 2011-02-22 09:06:33 --> Total execution time: 0.0327
DEBUG - 2011-02-22 09:07:27 --> Config Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:07:27 --> URI Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Router Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Output Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Input Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:07:27 --> Language Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Loader Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:07:27 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:07:27 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:07:27 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:07:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:07:27 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Session Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:07:27 --> Session routines successfully run
DEBUG - 2011-02-22 09:07:27 --> Controller Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:07:27 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:27 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:27 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:07:27 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:07:27 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:07:27 --> Final output sent to browser
DEBUG - 2011-02-22 09:07:27 --> Total execution time: 0.0309
DEBUG - 2011-02-22 09:07:32 --> Config Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:07:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:07:32 --> URI Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Router Class Initialized
DEBUG - 2011-02-22 09:07:32 --> No URI present. Default controller set.
DEBUG - 2011-02-22 09:07:32 --> Output Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Input Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:07:32 --> Language Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Loader Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:07:32 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:07:32 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:07:32 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:07:32 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:07:32 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Session Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:07:32 --> Session routines successfully run
DEBUG - 2011-02-22 09:07:32 --> Controller Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:07:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:07:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:07:32 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 09:07:32 --> Final output sent to browser
DEBUG - 2011-02-22 09:07:32 --> Total execution time: 0.0322
DEBUG - 2011-02-22 09:07:34 --> Config Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:07:34 --> URI Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Router Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Output Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Input Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:07:34 --> Language Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Loader Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:07:34 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:07:34 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:07:34 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:07:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:07:34 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Session Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:07:34 --> Session routines successfully run
DEBUG - 2011-02-22 09:07:34 --> Controller Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:07:34 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:07:34 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:07:34 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:07:34 --> Final output sent to browser
DEBUG - 2011-02-22 09:07:34 --> Total execution time: 0.0289
DEBUG - 2011-02-22 09:07:44 --> Config Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:07:44 --> URI Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Router Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Output Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Input Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:07:44 --> Language Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Loader Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:07:44 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:07:44 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:07:44 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:07:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:07:44 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Session Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:07:44 --> Session routines successfully run
DEBUG - 2011-02-22 09:07:44 --> Controller Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:07:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:07:44 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:07:44 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:07:44 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:07:44 --> Final output sent to browser
DEBUG - 2011-02-22 09:07:44 --> Total execution time: 0.0361
DEBUG - 2011-02-22 09:09:13 --> Config Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:09:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:09:13 --> URI Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Router Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Output Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Input Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:09:13 --> Language Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Loader Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:09:13 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:09:13 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:09:13 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:09:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:09:13 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Session Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:09:13 --> Session routines successfully run
DEBUG - 2011-02-22 09:09:13 --> Controller Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:09:13 --> Model Class Initialized
DEBUG - 2011-02-22 09:09:13 --> Model Class Initialized
DEBUG - 2011-02-22 09:09:13 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:09:13 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:09:13 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:09:13 --> Final output sent to browser
DEBUG - 2011-02-22 09:09:13 --> Total execution time: 0.0289
DEBUG - 2011-02-22 09:09:30 --> Config Class Initialized
DEBUG - 2011-02-22 09:09:30 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:09:30 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:09:30 --> URI Class Initialized
DEBUG - 2011-02-22 09:09:30 --> Router Class Initialized
ERROR - 2011-02-22 09:09:30 --> 404 Page Not Found --> set-up
DEBUG - 2011-02-22 09:09:37 --> Config Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:09:37 --> URI Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Router Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Output Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Input Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:09:37 --> Language Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Loader Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:09:37 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:09:37 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:09:37 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:09:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:09:37 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Session Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:09:37 --> Session routines successfully run
DEBUG - 2011-02-22 09:09:37 --> Controller Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:09:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:09:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:09:37 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:09:37 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:09:37 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 09:09:37 --> Final output sent to browser
DEBUG - 2011-02-22 09:09:37 --> Total execution time: 0.0258
DEBUG - 2011-02-22 09:09:39 --> Config Class Initialized
DEBUG - 2011-02-22 09:09:39 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:09:39 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:09:39 --> URI Class Initialized
DEBUG - 2011-02-22 09:09:39 --> Router Class Initialized
ERROR - 2011-02-22 09:09:39 --> 404 Page Not Found --> set-up
DEBUG - 2011-02-22 09:11:48 --> Config Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:11:48 --> URI Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Router Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Output Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Input Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:11:48 --> Language Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Loader Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:11:48 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:11:48 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:11:48 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:11:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:11:48 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Session Class Initialized
DEBUG - 2011-02-22 09:11:48 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:11:48 --> Session routines successfully run
DEBUG - 2011-02-22 09:11:48 --> Controller Class Initialized
ERROR - 2011-02-22 09:11:48 --> 404 Page Not Found --> home/set_up
DEBUG - 2011-02-22 09:11:49 --> Config Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:11:49 --> URI Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Router Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Output Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Input Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:11:49 --> Language Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Loader Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:11:49 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:11:49 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:11:49 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:11:49 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:11:49 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Session Class Initialized
DEBUG - 2011-02-22 09:11:49 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:11:49 --> Session routines successfully run
DEBUG - 2011-02-22 09:11:49 --> Controller Class Initialized
ERROR - 2011-02-22 09:11:49 --> 404 Page Not Found --> home/set_up
DEBUG - 2011-02-22 09:13:03 --> Config Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:13:03 --> URI Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Router Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Output Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Input Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:13:03 --> Language Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Loader Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:13:03 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:13:03 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:13:03 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:13:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:13:03 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Session Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:13:03 --> Session routines successfully run
DEBUG - 2011-02-22 09:13:03 --> Controller Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:13:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:13:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:13:03 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:13:03 --> Final output sent to browser
DEBUG - 2011-02-22 09:13:03 --> Total execution time: 0.0227
DEBUG - 2011-02-22 09:13:19 --> Config Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:13:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:13:19 --> URI Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Router Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Output Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Input Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:13:19 --> Language Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Loader Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:13:19 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:13:19 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:13:19 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:13:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:13:19 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Session Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:13:19 --> Session routines successfully run
DEBUG - 2011-02-22 09:13:19 --> Controller Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:19 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:13:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:13:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:13:19 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:13:19 --> Final output sent to browser
DEBUG - 2011-02-22 09:13:19 --> Total execution time: 0.0262
DEBUG - 2011-02-22 09:13:20 --> Config Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:13:20 --> URI Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Router Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Output Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Input Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:13:20 --> Language Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Loader Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:13:20 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:13:20 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:13:20 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:13:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:13:20 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Session Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:13:20 --> Session routines successfully run
DEBUG - 2011-02-22 09:13:20 --> Controller Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:20 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:13:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:13:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:13:20 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:13:20 --> Final output sent to browser
DEBUG - 2011-02-22 09:13:20 --> Total execution time: 0.0266
DEBUG - 2011-02-22 09:13:33 --> Config Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:13:33 --> URI Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Router Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Output Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Input Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:13:33 --> Language Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Loader Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:13:33 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:13:33 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:13:33 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:13:33 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:13:33 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Session Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:13:33 --> Session routines successfully run
DEBUG - 2011-02-22 09:13:33 --> Controller Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:13:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:33 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:33 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:13:33 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:13:33 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:13:33 --> Final output sent to browser
DEBUG - 2011-02-22 09:13:33 --> Total execution time: 0.0279
DEBUG - 2011-02-22 09:13:36 --> Config Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:13:36 --> URI Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Router Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Output Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Input Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:13:36 --> Language Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Loader Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:13:36 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:13:36 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:13:36 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:13:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:13:36 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Session Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:13:36 --> Session routines successfully run
DEBUG - 2011-02-22 09:13:36 --> Controller Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:13:36 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:36 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:36 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:13:36 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:13:36 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:13:36 --> Final output sent to browser
DEBUG - 2011-02-22 09:13:36 --> Total execution time: 0.0245
DEBUG - 2011-02-22 09:13:38 --> Config Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:13:38 --> URI Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Router Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Output Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Input Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:13:38 --> Language Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Loader Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:13:38 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:13:38 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:13:38 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:13:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:13:38 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Session Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:13:38 --> Session routines successfully run
DEBUG - 2011-02-22 09:13:38 --> Controller Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:13:38 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:38 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:38 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:13:38 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:13:38 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 09:13:38 --> Final output sent to browser
DEBUG - 2011-02-22 09:13:38 --> Total execution time: 0.0300
DEBUG - 2011-02-22 09:13:39 --> Config Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:13:39 --> URI Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Router Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Output Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Input Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:13:39 --> Language Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Loader Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:13:39 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:13:39 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:13:39 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:13:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:13:39 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Session Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:13:39 --> Session routines successfully run
DEBUG - 2011-02-22 09:13:39 --> Controller Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:13:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:13:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:13:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:13:39 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:13:39 --> Final output sent to browser
DEBUG - 2011-02-22 09:13:39 --> Total execution time: 0.0229
DEBUG - 2011-02-22 09:16:05 --> Config Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:16:05 --> URI Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Router Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Output Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Input Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:16:05 --> Language Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Loader Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:16:05 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:16:05 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:16:05 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:16:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:16:05 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Session Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:16:05 --> Session routines successfully run
DEBUG - 2011-02-22 09:16:05 --> Controller Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Model Class Initialized
DEBUG - 2011-02-22 09:16:05 --> Model Class Initialized
DEBUG - 2011-02-22 09:16:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:16:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:16:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:16:05 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:16:05 --> Final output sent to browser
DEBUG - 2011-02-22 09:16:05 --> Total execution time: 0.0247
DEBUG - 2011-02-22 09:16:51 --> Config Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:16:51 --> URI Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Router Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Output Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Input Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:16:51 --> Language Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Loader Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:16:51 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:16:51 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:16:51 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:16:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:16:51 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Session Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:16:51 --> Session routines successfully run
DEBUG - 2011-02-22 09:16:51 --> Controller Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Model Class Initialized
DEBUG - 2011-02-22 09:16:51 --> Model Class Initialized
DEBUG - 2011-02-22 09:16:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:16:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:16:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:16:51 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:16:51 --> Final output sent to browser
DEBUG - 2011-02-22 09:16:51 --> Total execution time: 0.0250
DEBUG - 2011-02-22 09:16:59 --> Config Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:16:59 --> URI Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Router Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Output Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Input Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:16:59 --> Language Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Loader Class Initialized
DEBUG - 2011-02-22 09:16:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:16:59 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:16:59 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:16:59 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:16:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:17:00 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:17:00 --> Session Class Initialized
DEBUG - 2011-02-22 09:17:00 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:17:00 --> Session routines successfully run
DEBUG - 2011-02-22 09:17:00 --> Controller Class Initialized
DEBUG - 2011-02-22 09:17:00 --> Model Class Initialized
DEBUG - 2011-02-22 09:17:00 --> Model Class Initialized
DEBUG - 2011-02-22 09:17:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:17:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:17:00 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:17:00 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:17:00 --> Final output sent to browser
DEBUG - 2011-02-22 09:17:00 --> Total execution time: 0.0269
DEBUG - 2011-02-22 09:17:11 --> Config Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:17:11 --> URI Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Router Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Output Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Input Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:17:11 --> Language Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Loader Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:17:11 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:17:11 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:17:11 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:17:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:17:11 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Session Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:17:11 --> Session routines successfully run
DEBUG - 2011-02-22 09:17:11 --> Controller Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Model Class Initialized
DEBUG - 2011-02-22 09:17:11 --> Model Class Initialized
DEBUG - 2011-02-22 09:17:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:17:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:17:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:17:11 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:17:11 --> Final output sent to browser
DEBUG - 2011-02-22 09:17:11 --> Total execution time: 0.0247
DEBUG - 2011-02-22 09:18:14 --> Config Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:18:14 --> URI Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Router Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Output Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Input Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:18:14 --> Language Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Loader Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:18:14 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:18:14 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:18:14 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:18:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:18:14 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Session Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:18:14 --> Session routines successfully run
DEBUG - 2011-02-22 09:18:14 --> Controller Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Model Class Initialized
DEBUG - 2011-02-22 09:18:14 --> Model Class Initialized
DEBUG - 2011-02-22 09:18:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:18:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:18:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:18:14 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:18:14 --> Final output sent to browser
DEBUG - 2011-02-22 09:18:14 --> Total execution time: 0.0243
DEBUG - 2011-02-22 09:21:23 --> Config Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:21:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:21:23 --> URI Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Router Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Output Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Input Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:21:23 --> Language Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Loader Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:21:23 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:21:23 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:21:23 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:21:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:21:23 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Session Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:21:23 --> Session routines successfully run
DEBUG - 2011-02-22 09:21:23 --> Controller Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Model Class Initialized
DEBUG - 2011-02-22 09:21:23 --> Model Class Initialized
DEBUG - 2011-02-22 09:21:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:21:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:21:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:21:23 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:21:23 --> Final output sent to browser
DEBUG - 2011-02-22 09:21:23 --> Total execution time: 0.0235
DEBUG - 2011-02-22 09:21:24 --> Config Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:21:24 --> URI Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Router Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Output Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Input Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:21:24 --> Language Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Loader Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:21:24 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:21:24 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:21:24 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:21:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:21:24 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Session Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:21:24 --> Session routines successfully run
DEBUG - 2011-02-22 09:21:24 --> Controller Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Model Class Initialized
DEBUG - 2011-02-22 09:21:24 --> Model Class Initialized
DEBUG - 2011-02-22 09:21:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:21:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:21:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:21:24 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:21:24 --> Final output sent to browser
DEBUG - 2011-02-22 09:21:24 --> Total execution time: 0.0239
DEBUG - 2011-02-22 09:22:03 --> Config Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:22:03 --> URI Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Router Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Output Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Input Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:22:03 --> Language Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Loader Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:22:03 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:22:03 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:22:03 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:22:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:22:03 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Session Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:22:03 --> Session routines successfully run
DEBUG - 2011-02-22 09:22:03 --> Controller Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:22:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:22:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:22:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:22:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:22:03 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:22:03 --> Final output sent to browser
DEBUG - 2011-02-22 09:22:03 --> Total execution time: 0.0233
DEBUG - 2011-02-22 09:22:08 --> Config Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:22:08 --> URI Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Router Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Output Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Input Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:22:08 --> Language Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Loader Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:22:08 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:22:08 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:22:08 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:22:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:22:08 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Session Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:22:08 --> Session routines successfully run
DEBUG - 2011-02-22 09:22:08 --> Controller Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:22:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:22:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:22:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:22:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:22:08 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:22:08 --> Final output sent to browser
DEBUG - 2011-02-22 09:22:08 --> Total execution time: 0.0553
DEBUG - 2011-02-22 09:23:08 --> Config Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:23:08 --> URI Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Router Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Output Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Input Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:23:08 --> Language Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Loader Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:23:08 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:23:08 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:23:08 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:23:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:23:08 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Session Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:23:08 --> Session routines successfully run
DEBUG - 2011-02-22 09:23:08 --> Controller Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:23:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:23:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:23:08 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:23:08 --> Final output sent to browser
DEBUG - 2011-02-22 09:23:08 --> Total execution time: 0.0231
DEBUG - 2011-02-22 09:23:35 --> Config Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:23:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:23:35 --> URI Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Router Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Output Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Input Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:23:35 --> Language Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Loader Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:23:35 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:23:35 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:23:35 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:23:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:23:35 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Session Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:23:35 --> Session routines successfully run
DEBUG - 2011-02-22 09:23:35 --> Controller Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:35 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:23:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:23:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:23:35 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:23:35 --> Final output sent to browser
DEBUG - 2011-02-22 09:23:35 --> Total execution time: 0.0224
DEBUG - 2011-02-22 09:23:48 --> Config Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:23:48 --> URI Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Router Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Output Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Input Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:23:48 --> Language Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Loader Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:23:48 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:23:48 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:23:48 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:23:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:23:48 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Session Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:23:48 --> Session routines successfully run
DEBUG - 2011-02-22 09:23:48 --> Controller Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:48 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:23:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:23:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:23:48 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:23:48 --> Final output sent to browser
DEBUG - 2011-02-22 09:23:48 --> Total execution time: 0.0427
DEBUG - 2011-02-22 09:23:57 --> Config Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:23:57 --> URI Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Router Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Output Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Input Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:23:57 --> Language Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Loader Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:23:57 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:23:57 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:23:57 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:23:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:23:57 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Session Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:23:57 --> Session routines successfully run
DEBUG - 2011-02-22 09:23:57 --> Controller Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:57 --> Model Class Initialized
DEBUG - 2011-02-22 09:23:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:23:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:23:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:23:57 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:23:57 --> Final output sent to browser
DEBUG - 2011-02-22 09:23:57 --> Total execution time: 0.0362
DEBUG - 2011-02-22 09:24:12 --> Config Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:24:12 --> URI Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Router Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Output Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Input Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:24:12 --> Language Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Loader Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:24:12 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Session Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:24:12 --> Session routines successfully run
DEBUG - 2011-02-22 09:24:12 --> Controller Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:24:12 --> Final output sent to browser
DEBUG - 2011-02-22 09:24:12 --> Total execution time: 0.0230
DEBUG - 2011-02-22 09:24:12 --> Config Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:24:12 --> URI Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Router Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Output Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Input Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:24:12 --> Language Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Loader Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:24:12 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Session Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:24:12 --> Session routines successfully run
DEBUG - 2011-02-22 09:24:12 --> Controller Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:12 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:24:12 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:24:12 --> Final output sent to browser
DEBUG - 2011-02-22 09:24:12 --> Total execution time: 0.0237
DEBUG - 2011-02-22 09:24:22 --> Config Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:24:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:24:22 --> URI Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Router Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Output Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Input Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:24:22 --> Language Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Loader Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:24:22 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:24:22 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:24:22 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:24:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:24:22 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Session Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:24:22 --> Session routines successfully run
DEBUG - 2011-02-22 09:24:22 --> Controller Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Model Class Initialized
DEBUG - 2011-02-22 09:24:22 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:24:22 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:24:22 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:24:22 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:24:22 --> Final output sent to browser
DEBUG - 2011-02-22 09:24:22 --> Total execution time: 0.0347
DEBUG - 2011-02-22 09:25:28 --> Config Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:25:28 --> URI Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Router Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Output Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Input Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:25:28 --> Language Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Loader Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:25:28 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:25:28 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:25:28 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:25:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:25:28 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Session Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:25:28 --> Session routines successfully run
DEBUG - 2011-02-22 09:25:28 --> Controller Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Model Class Initialized
DEBUG - 2011-02-22 09:25:28 --> Model Class Initialized
DEBUG - 2011-02-22 09:25:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:25:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:25:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:25:28 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:25:28 --> Final output sent to browser
DEBUG - 2011-02-22 09:25:28 --> Total execution time: 0.0280
DEBUG - 2011-02-22 09:25:37 --> Config Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:25:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:25:37 --> URI Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Router Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Output Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Input Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:25:37 --> Language Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Loader Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:25:37 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:25:37 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:25:37 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:25:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:25:37 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Session Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:25:37 --> Session routines successfully run
DEBUG - 2011-02-22 09:25:37 --> Controller Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:25:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:25:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:25:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:25:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:25:37 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 09:25:37 --> Final output sent to browser
DEBUG - 2011-02-22 09:25:37 --> Total execution time: 0.0251
DEBUG - 2011-02-22 09:25:51 --> Config Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:25:51 --> URI Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Router Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Output Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Input Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:25:51 --> Language Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Loader Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:25:51 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:25:51 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:25:51 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:25:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:25:51 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Session Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:25:51 --> Session routines successfully run
DEBUG - 2011-02-22 09:25:51 --> Controller Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Model Class Initialized
DEBUG - 2011-02-22 09:25:51 --> Model Class Initialized
DEBUG - 2011-02-22 09:25:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:25:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:25:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:25:51 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:25:51 --> Final output sent to browser
DEBUG - 2011-02-22 09:25:51 --> Total execution time: 0.0246
DEBUG - 2011-02-22 09:27:38 --> Config Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:27:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:27:38 --> URI Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Router Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Output Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Input Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:27:38 --> Language Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Loader Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:27:38 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:27:38 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:27:38 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:27:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:27:38 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Session Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:27:38 --> Session routines successfully run
DEBUG - 2011-02-22 09:27:38 --> Controller Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:38 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:27:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:27:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:27:38 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:27:38 --> Final output sent to browser
DEBUG - 2011-02-22 09:27:38 --> Total execution time: 0.0248
DEBUG - 2011-02-22 09:27:39 --> Config Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:27:39 --> URI Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Router Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Output Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Input Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:27:39 --> Language Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Loader Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:27:39 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:27:39 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:27:39 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:27:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:27:39 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Session Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:27:39 --> Session routines successfully run
DEBUG - 2011-02-22 09:27:39 --> Controller Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:27:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:27:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:27:39 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:27:39 --> Final output sent to browser
DEBUG - 2011-02-22 09:27:39 --> Total execution time: 0.0240
DEBUG - 2011-02-22 09:27:41 --> Config Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:27:41 --> URI Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Router Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Output Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Input Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:27:41 --> Language Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Loader Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:27:41 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:27:41 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:27:41 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:27:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:27:41 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Session Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:27:41 --> Session routines successfully run
DEBUG - 2011-02-22 09:27:41 --> Controller Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:41 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:27:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:27:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:27:41 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:27:41 --> Final output sent to browser
DEBUG - 2011-02-22 09:27:41 --> Total execution time: 0.0244
DEBUG - 2011-02-22 09:27:49 --> Config Class Initialized
DEBUG - 2011-02-22 09:27:49 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:27:49 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:27:49 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:27:49 --> URI Class Initialized
DEBUG - 2011-02-22 09:27:49 --> Router Class Initialized
ERROR - 2011-02-22 09:27:49 --> 404 Page Not Found --> %5C
DEBUG - 2011-02-22 09:27:52 --> Config Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:27:52 --> URI Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Router Class Initialized
DEBUG - 2011-02-22 09:27:52 --> No URI present. Default controller set.
DEBUG - 2011-02-22 09:27:52 --> Output Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Input Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:27:52 --> Language Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Loader Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:27:52 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:27:52 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:27:52 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:27:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:27:52 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Session Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:27:52 --> Session routines successfully run
DEBUG - 2011-02-22 09:27:52 --> Controller Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:27:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:27:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:27:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:27:52 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 09:27:52 --> Final output sent to browser
DEBUG - 2011-02-22 09:27:52 --> Total execution time: 0.0386
DEBUG - 2011-02-22 09:28:03 --> Config Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:28:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:28:03 --> URI Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Router Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Output Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Input Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:28:03 --> Language Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Loader Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:28:03 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:28:03 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:28:03 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:28:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:28:03 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Session Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:28:03 --> Session routines successfully run
DEBUG - 2011-02-22 09:28:03 --> Controller Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:28:03 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:28:03 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:28:03 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:28:03 --> Final output sent to browser
DEBUG - 2011-02-22 09:28:03 --> Total execution time: 0.0279
DEBUG - 2011-02-22 09:28:10 --> Config Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:28:10 --> URI Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Router Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Output Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Input Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:28:10 --> Language Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Loader Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:28:10 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:28:10 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:28:10 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:28:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:28:10 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Session Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:28:10 --> Session routines successfully run
DEBUG - 2011-02-22 09:28:10 --> Controller Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:10 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:28:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:28:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:28:10 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:28:10 --> Final output sent to browser
DEBUG - 2011-02-22 09:28:10 --> Total execution time: 0.0236
DEBUG - 2011-02-22 09:28:16 --> Config Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:28:16 --> URI Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Router Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Output Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Input Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:28:16 --> Language Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Loader Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:28:16 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:28:16 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:28:16 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:28:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:28:16 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Session Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:28:16 --> Session routines successfully run
DEBUG - 2011-02-22 09:28:16 --> Controller Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Model Class Initialized
DEBUG - 2011-02-22 09:28:16 --> Model Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Config Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:29:28 --> URI Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Router Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Output Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Input Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:29:28 --> Language Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Loader Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:29:28 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:29:28 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:29:28 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:29:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:29:28 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Session Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:29:28 --> Session routines successfully run
DEBUG - 2011-02-22 09:29:28 --> Controller Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Model Class Initialized
DEBUG - 2011-02-22 09:29:28 --> Model Class Initialized
DEBUG - 2011-02-22 09:29:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:29:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:29:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:29:28 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:29:28 --> Final output sent to browser
DEBUG - 2011-02-22 09:29:28 --> Total execution time: 0.0242
DEBUG - 2011-02-22 09:29:30 --> Config Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:29:30 --> URI Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Router Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Output Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Input Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:29:30 --> Language Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Loader Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:29:30 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:29:30 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:29:30 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:29:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:29:30 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Session Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:29:30 --> Session routines successfully run
DEBUG - 2011-02-22 09:29:30 --> Controller Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Model Class Initialized
DEBUG - 2011-02-22 09:29:30 --> Model Class Initialized
DEBUG - 2011-02-22 09:29:34 --> Config Class Initialized
DEBUG - 2011-02-22 09:29:34 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:29:34 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:29:34 --> URI Class Initialized
DEBUG - 2011-02-22 09:29:34 --> Router Class Initialized
ERROR - 2011-02-22 09:29:34 --> 404 Page Not Found --> static
DEBUG - 2011-02-22 09:31:00 --> Config Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:31:00 --> URI Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Router Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Output Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Input Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:31:00 --> Language Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Loader Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:31:00 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:31:00 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:31:00 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:31:00 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:31:00 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Session Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:31:00 --> Session routines successfully run
DEBUG - 2011-02-22 09:31:00 --> Controller Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Model Class Initialized
DEBUG - 2011-02-22 09:31:00 --> Model Class Initialized
DEBUG - 2011-02-22 09:31:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:31:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:31:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:31:00 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:31:00 --> Final output sent to browser
DEBUG - 2011-02-22 09:31:00 --> Total execution time: 0.0241
DEBUG - 2011-02-22 09:31:19 --> Config Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:31:19 --> URI Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Router Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Output Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Input Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:31:19 --> Language Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Loader Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:31:19 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:31:19 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:31:19 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:31:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:31:19 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Session Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:31:19 --> Session routines successfully run
DEBUG - 2011-02-22 09:31:19 --> Controller Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Model Class Initialized
DEBUG - 2011-02-22 09:31:19 --> Model Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Config Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:34:31 --> URI Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Router Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Output Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Input Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:34:31 --> Language Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Loader Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:34:31 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:34:31 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:34:31 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:34:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:34:31 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Session Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:34:31 --> Session routines successfully run
DEBUG - 2011-02-22 09:34:31 --> Controller Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Model Class Initialized
DEBUG - 2011-02-22 09:34:31 --> Model Class Initialized
DEBUG - 2011-02-22 09:34:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:34:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:34:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:34:31 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:34:31 --> Final output sent to browser
DEBUG - 2011-02-22 09:34:31 --> Total execution time: 0.0241
DEBUG - 2011-02-22 09:34:48 --> Config Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:34:48 --> URI Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Router Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Output Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Input Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:34:48 --> Language Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Loader Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:34:48 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:34:48 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:34:48 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:34:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:34:48 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Session Class Initialized
DEBUG - 2011-02-22 09:34:48 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:34:48 --> Session routines successfully run
DEBUG - 2011-02-22 09:34:48 --> Controller Class Initialized
DEBUG - 2011-02-22 09:34:48 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-22 09:34:48 --> Final output sent to browser
DEBUG - 2011-02-22 09:34:48 --> Total execution time: 0.0203
DEBUG - 2011-02-22 09:35:51 --> Config Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:35:51 --> URI Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Router Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Output Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Input Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:35:51 --> Language Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Loader Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:35:51 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:35:51 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:35:51 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:35:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:35:51 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Session Class Initialized
DEBUG - 2011-02-22 09:35:51 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:35:51 --> Session routines successfully run
DEBUG - 2011-02-22 09:35:51 --> Controller Class Initialized
DEBUG - 2011-02-22 09:35:51 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-22 09:35:51 --> Final output sent to browser
DEBUG - 2011-02-22 09:35:51 --> Total execution time: 0.0205
DEBUG - 2011-02-22 09:35:53 --> Config Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:35:53 --> URI Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Router Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Output Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Input Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:35:53 --> Language Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Loader Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:35:53 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Session Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:35:53 --> Session routines successfully run
DEBUG - 2011-02-22 09:35:53 --> Controller Class Initialized
DEBUG - 2011-02-22 09:35:53 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-22 09:35:53 --> Final output sent to browser
DEBUG - 2011-02-22 09:35:53 --> Total execution time: 0.0198
DEBUG - 2011-02-22 09:35:53 --> Config Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:35:53 --> URI Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Router Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Output Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Input Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:35:53 --> Language Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Loader Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:35:53 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Session Class Initialized
DEBUG - 2011-02-22 09:35:53 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:35:53 --> Session routines successfully run
DEBUG - 2011-02-22 09:35:53 --> Controller Class Initialized
DEBUG - 2011-02-22 09:35:53 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-22 09:35:53 --> Final output sent to browser
DEBUG - 2011-02-22 09:35:53 --> Total execution time: 0.0221
DEBUG - 2011-02-22 09:35:58 --> Config Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:35:58 --> URI Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Router Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Output Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Input Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:35:58 --> Language Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Loader Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:35:58 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:35:58 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:35:58 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:35:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:35:58 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Session Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:35:58 --> Session routines successfully run
DEBUG - 2011-02-22 09:35:58 --> Controller Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Model Class Initialized
DEBUG - 2011-02-22 09:35:58 --> Model Class Initialized
DEBUG - 2011-02-22 09:35:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:35:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:35:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:35:58 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:35:58 --> Final output sent to browser
DEBUG - 2011-02-22 09:35:58 --> Total execution time: 0.0292
DEBUG - 2011-02-22 09:36:06 --> Config Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:36:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:36:06 --> URI Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Router Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Output Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Input Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:36:06 --> Language Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Loader Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:36:06 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:36:06 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:36:06 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:36:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:36:06 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Session Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:36:06 --> Session routines successfully run
DEBUG - 2011-02-22 09:36:06 --> Controller Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Model Class Initialized
DEBUG - 2011-02-22 09:36:06 --> Model Class Initialized
DEBUG - 2011-02-22 09:36:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:36:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:36:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:36:06 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:36:06 --> Final output sent to browser
DEBUG - 2011-02-22 09:36:06 --> Total execution time: 0.0299
DEBUG - 2011-02-22 09:36:37 --> Config Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:36:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:36:37 --> URI Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Router Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Output Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Input Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:36:37 --> Language Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Loader Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:36:37 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:36:37 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:36:37 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:36:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:36:37 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Session Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:36:37 --> Session routines successfully run
DEBUG - 2011-02-22 09:36:37 --> Controller Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:36:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:36:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:36:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:36:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:36:37 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:36:37 --> Final output sent to browser
DEBUG - 2011-02-22 09:36:37 --> Total execution time: 0.0242
DEBUG - 2011-02-22 09:37:07 --> Config Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:37:07 --> URI Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Router Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Output Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Input Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:37:07 --> Language Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Loader Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:37:07 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:37:07 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:37:07 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:37:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:37:07 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Session Class Initialized
DEBUG - 2011-02-22 09:37:07 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:37:07 --> A session cookie was not found.
DEBUG - 2011-02-22 09:37:07 --> Session routines successfully run
DEBUG - 2011-02-22 09:37:07 --> Controller Class Initialized
DEBUG - 2011-02-22 09:37:07 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-22 09:37:07 --> Final output sent to browser
DEBUG - 2011-02-22 09:37:07 --> Total execution time: 0.0195
DEBUG - 2011-02-22 09:37:14 --> Config Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:37:14 --> URI Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Router Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Output Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Input Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:37:14 --> Language Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Loader Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:37:14 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:37:14 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:37:14 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:37:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:37:14 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Session Class Initialized
DEBUG - 2011-02-22 09:37:14 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:37:14 --> A session cookie was not found.
DEBUG - 2011-02-22 09:37:14 --> Session routines successfully run
DEBUG - 2011-02-22 09:37:14 --> Controller Class Initialized
DEBUG - 2011-02-22 09:37:14 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-22 09:37:14 --> Final output sent to browser
DEBUG - 2011-02-22 09:37:14 --> Total execution time: 0.0199
DEBUG - 2011-02-22 09:37:48 --> Config Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:37:48 --> URI Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Router Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Output Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Input Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:37:48 --> Language Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Loader Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:37:48 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:37:48 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:37:48 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:37:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:37:48 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Session Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:37:48 --> Session routines successfully run
DEBUG - 2011-02-22 09:37:48 --> Controller Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Model Class Initialized
DEBUG - 2011-02-22 09:37:48 --> Model Class Initialized
DEBUG - 2011-02-22 09:37:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:37:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:37:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:37:48 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:37:48 --> Final output sent to browser
DEBUG - 2011-02-22 09:37:48 --> Total execution time: 0.0270
DEBUG - 2011-02-22 09:38:21 --> Config Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:38:21 --> URI Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Router Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Output Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Input Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:38:21 --> Language Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Loader Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:38:21 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:38:21 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:38:21 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:38:21 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:38:21 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Session Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:38:21 --> Session routines successfully run
DEBUG - 2011-02-22 09:38:21 --> Controller Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Model Class Initialized
DEBUG - 2011-02-22 09:38:21 --> Model Class Initialized
DEBUG - 2011-02-22 09:38:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:38:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:38:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:38:21 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:38:21 --> Final output sent to browser
DEBUG - 2011-02-22 09:38:21 --> Total execution time: 0.0232
DEBUG - 2011-02-22 09:38:31 --> Config Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:38:31 --> URI Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Router Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Output Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Input Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:38:31 --> Language Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Loader Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:38:31 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:38:31 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:38:31 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:38:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:38:31 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Session Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:38:31 --> Session routines successfully run
DEBUG - 2011-02-22 09:38:31 --> Controller Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Model Class Initialized
DEBUG - 2011-02-22 09:38:31 --> Model Class Initialized
DEBUG - 2011-02-22 09:38:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:38:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:38:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:38:31 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:38:31 --> Final output sent to browser
DEBUG - 2011-02-22 09:38:31 --> Total execution time: 0.0238
DEBUG - 2011-02-22 09:39:07 --> Config Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:39:07 --> URI Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Router Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Output Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Input Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:39:07 --> Language Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Loader Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:39:07 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:39:07 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:39:07 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:39:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:39:07 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Session Class Initialized
DEBUG - 2011-02-22 09:39:07 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:39:07 --> Session routines successfully run
DEBUG - 2011-02-22 09:39:07 --> Controller Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Config Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:39:13 --> URI Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Router Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Output Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Input Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:39:13 --> Language Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Loader Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:39:13 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:39:13 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:39:13 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:39:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:39:13 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Session Class Initialized
DEBUG - 2011-02-22 09:39:13 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:39:13 --> Session routines successfully run
DEBUG - 2011-02-22 09:39:13 --> Controller Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Config Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:39:23 --> URI Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Router Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Output Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Input Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:39:23 --> Language Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Loader Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:39:23 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:39:23 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:39:23 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:39:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:39:23 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Session Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:39:23 --> Session routines successfully run
DEBUG - 2011-02-22 09:39:23 --> Controller Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:23 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:39:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:39:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:39:23 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:39:23 --> Final output sent to browser
DEBUG - 2011-02-22 09:39:23 --> Total execution time: 0.0218
DEBUG - 2011-02-22 09:39:50 --> Config Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:39:50 --> URI Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Router Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Output Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Input Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:39:50 --> Language Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Loader Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:39:50 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:39:50 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:39:50 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:39:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:39:50 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Session Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:39:50 --> Session routines successfully run
DEBUG - 2011-02-22 09:39:50 --> Controller Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:50 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:39:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:39:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:39:50 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:39:50 --> Final output sent to browser
DEBUG - 2011-02-22 09:39:50 --> Total execution time: 0.0283
DEBUG - 2011-02-22 09:39:53 --> Config Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:39:53 --> URI Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Router Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Output Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Input Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:39:53 --> Language Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Loader Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:39:53 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:39:53 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:39:53 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:39:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:39:53 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Session Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:39:53 --> Session routines successfully run
DEBUG - 2011-02-22 09:39:53 --> Controller Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:53 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:39:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:39:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:39:53 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:39:53 --> Final output sent to browser
DEBUG - 2011-02-22 09:39:53 --> Total execution time: 0.0277
DEBUG - 2011-02-22 09:39:54 --> Config Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:39:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:39:54 --> URI Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Router Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Output Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Input Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:39:54 --> Language Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Loader Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:39:54 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:39:54 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:39:54 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:39:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:39:54 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Session Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:39:54 --> Session routines successfully run
DEBUG - 2011-02-22 09:39:54 --> Controller Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:54 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:39:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:39:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:39:54 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:39:54 --> Final output sent to browser
DEBUG - 2011-02-22 09:39:54 --> Total execution time: 0.0255
DEBUG - 2011-02-22 09:39:55 --> Config Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:39:55 --> URI Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Router Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Output Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Input Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:39:55 --> Language Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Loader Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:39:55 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:39:55 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:39:55 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:39:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:39:55 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Session Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:39:55 --> Session routines successfully run
DEBUG - 2011-02-22 09:39:55 --> Controller Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:55 --> Model Class Initialized
DEBUG - 2011-02-22 09:39:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:39:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:39:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:39:55 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:39:55 --> Final output sent to browser
DEBUG - 2011-02-22 09:39:55 --> Total execution time: 0.0225
DEBUG - 2011-02-22 09:40:01 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:01 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:01 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:01 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:01 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:01 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:01 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:01 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:01 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:01 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:01 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:01 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:01 --> Total execution time: 0.0294
DEBUG - 2011-02-22 09:40:02 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:02 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:02 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:02 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:02 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:02 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:02 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:02 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:02 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:02 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:02 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:02 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:02 --> Total execution time: 0.0238
DEBUG - 2011-02-22 09:40:05 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:05 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:05 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:05 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:05 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:05 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:05 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:05 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:05 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:05 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:05 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:05 --> Total execution time: 0.0280
DEBUG - 2011-02-22 09:40:05 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:05 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:05 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:06 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:06 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:06 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:06 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:06 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:06 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:06 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:06 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:06 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:06 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:06 --> Total execution time: 0.0230
DEBUG - 2011-02-22 09:40:09 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:09 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:09 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:09 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:09 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:09 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:09 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:09 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:09 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:09 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:09 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:09 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:09 --> Total execution time: 0.0265
DEBUG - 2011-02-22 09:40:20 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:20 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:20 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:20 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:20 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:20 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:20 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:20 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:20 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:20 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:20 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:20 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:20 --> Total execution time: 0.0225
DEBUG - 2011-02-22 09:40:39 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:39 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:39 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:39 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:39 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:39 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:39 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:39 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:39 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:39 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:39 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:39 --> Total execution time: 0.0221
DEBUG - 2011-02-22 09:40:56 --> Config Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:40:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:40:56 --> URI Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Router Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Output Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Input Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:40:56 --> Language Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Loader Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:40:56 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:40:56 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:40:56 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:40:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:40:56 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Session Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:40:56 --> Session routines successfully run
DEBUG - 2011-02-22 09:40:56 --> Controller Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:56 --> Model Class Initialized
DEBUG - 2011-02-22 09:40:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:40:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:40:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:40:56 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:40:56 --> Final output sent to browser
DEBUG - 2011-02-22 09:40:56 --> Total execution time: 0.0278
DEBUG - 2011-02-22 09:41:12 --> Config Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:41:12 --> URI Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Router Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Output Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Input Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:41:12 --> Language Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Loader Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:41:12 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:41:12 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:41:12 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:41:12 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:41:12 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Session Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:41:12 --> Session routines successfully run
DEBUG - 2011-02-22 09:41:12 --> Controller Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:12 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:41:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:41:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:41:12 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:41:12 --> Final output sent to browser
DEBUG - 2011-02-22 09:41:12 --> Total execution time: 0.0218
DEBUG - 2011-02-22 09:41:17 --> Config Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:41:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:41:17 --> URI Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Router Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Output Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Input Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:41:17 --> Language Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Loader Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:41:17 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:41:17 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:41:17 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:41:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:41:17 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Session Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:41:17 --> Session routines successfully run
DEBUG - 2011-02-22 09:41:17 --> Controller Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:41:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:41:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:41:17 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:41:17 --> Final output sent to browser
DEBUG - 2011-02-22 09:41:17 --> Total execution time: 0.0254
DEBUG - 2011-02-22 09:41:37 --> Config Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:41:37 --> URI Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Router Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Output Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Input Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:41:37 --> Language Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Loader Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:41:37 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:41:37 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:41:37 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:41:37 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:41:37 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Session Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:41:37 --> Session routines successfully run
DEBUG - 2011-02-22 09:41:37 --> Controller Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:37 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:41:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:41:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:41:37 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 09:41:37 --> Final output sent to browser
DEBUG - 2011-02-22 09:41:37 --> Total execution time: 0.0258
DEBUG - 2011-02-22 09:41:44 --> Config Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:41:44 --> URI Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Router Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Output Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Input Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:41:44 --> Language Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Loader Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:41:44 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:41:44 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:41:44 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:41:44 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:41:44 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Session Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:41:44 --> Session routines successfully run
DEBUG - 2011-02-22 09:41:44 --> Controller Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:44 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:41:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:41:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:41:44 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 09:41:44 --> Final output sent to browser
DEBUG - 2011-02-22 09:41:44 --> Total execution time: 0.0278
DEBUG - 2011-02-22 09:41:52 --> Config Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:41:52 --> URI Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Router Class Initialized
DEBUG - 2011-02-22 09:41:52 --> No URI present. Default controller set.
DEBUG - 2011-02-22 09:41:52 --> Output Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Input Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:41:52 --> Language Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Loader Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:41:52 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:41:52 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:41:52 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:41:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:41:52 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Session Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:41:52 --> Session routines successfully run
DEBUG - 2011-02-22 09:41:52 --> Controller Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> Model Class Initialized
DEBUG - 2011-02-22 09:41:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:41:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:41:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:41:52 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 09:41:52 --> Final output sent to browser
DEBUG - 2011-02-22 09:41:52 --> Total execution time: 0.0341
DEBUG - 2011-02-22 09:42:08 --> Config Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:42:08 --> URI Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Router Class Initialized
DEBUG - 2011-02-22 09:42:08 --> No URI present. Default controller set.
DEBUG - 2011-02-22 09:42:08 --> Output Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Input Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:42:08 --> Language Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Loader Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:42:08 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:42:08 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:42:08 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:42:08 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:42:08 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Session Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:42:08 --> Session routines successfully run
DEBUG - 2011-02-22 09:42:08 --> Controller Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:42:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:42:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:42:08 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 09:42:08 --> Final output sent to browser
DEBUG - 2011-02-22 09:42:08 --> Total execution time: 0.0331
DEBUG - 2011-02-22 09:42:17 --> Config Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:42:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:42:17 --> URI Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Router Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Output Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Input Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:42:17 --> Language Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Loader Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:42:17 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:42:17 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:42:17 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:42:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:42:17 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Session Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:42:17 --> Session routines successfully run
DEBUG - 2011-02-22 09:42:17 --> Controller Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Model Class Initialized
DEBUG - 2011-02-22 09:42:17 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 09:42:17 --> File loaded: application/views/global/_header.php
DEBUG - 2011-02-22 09:42:17 --> File loaded: application/views/global/_footer.php
DEBUG - 2011-02-22 09:42:17 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:42:17 --> Final output sent to browser
DEBUG - 2011-02-22 09:42:17 --> Total execution time: 0.0353
DEBUG - 2011-02-22 09:43:15 --> Config Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:43:15 --> URI Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Router Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Output Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Input Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:43:15 --> Language Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Loader Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:43:15 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:43:15 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:43:15 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:43:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:43:15 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Session Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:43:15 --> Session routines successfully run
DEBUG - 2011-02-22 09:43:15 --> Controller Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:15 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:43:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:43:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:43:15 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:43:15 --> Final output sent to browser
DEBUG - 2011-02-22 09:43:15 --> Total execution time: 0.0283
DEBUG - 2011-02-22 09:43:31 --> Config Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:43:31 --> URI Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Router Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Output Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Input Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:43:31 --> Language Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Loader Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:43:31 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:43:31 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:43:31 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:43:31 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:43:31 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Session Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:43:31 --> Session routines successfully run
DEBUG - 2011-02-22 09:43:31 --> Controller Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:31 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:31 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:43:31 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:43:31 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:43:31 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:43:31 --> Final output sent to browser
DEBUG - 2011-02-22 09:43:31 --> Total execution time: 0.0263
DEBUG - 2011-02-22 09:43:45 --> Config Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:43:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:43:45 --> URI Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Router Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Output Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Input Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:43:45 --> Language Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Loader Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:43:45 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:43:45 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:43:45 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:43:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:43:45 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Session Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:43:45 --> Session routines successfully run
DEBUG - 2011-02-22 09:43:45 --> Controller Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:45 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:43:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:43:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:43:45 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:43:45 --> Final output sent to browser
DEBUG - 2011-02-22 09:43:45 --> Total execution time: 0.0288
DEBUG - 2011-02-22 09:43:46 --> Config Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:43:46 --> URI Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Router Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Output Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Input Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:43:46 --> Language Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Loader Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:43:46 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:43:46 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:43:46 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:43:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:43:46 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Session Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:43:46 --> Session routines successfully run
DEBUG - 2011-02-22 09:43:46 --> Controller Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:46 --> Model Class Initialized
DEBUG - 2011-02-22 09:43:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:43:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:43:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:43:46 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 09:43:46 --> Final output sent to browser
DEBUG - 2011-02-22 09:43:46 --> Total execution time: 0.0285
DEBUG - 2011-02-22 09:45:39 --> Config Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Hooks Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Utf8 Class Initialized
DEBUG - 2011-02-22 09:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 09:45:39 --> URI Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Router Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Output Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Input Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 09:45:39 --> Language Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Loader Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 09:45:39 --> Helper loaded: user_helper
DEBUG - 2011-02-22 09:45:39 --> Helper loaded: url_helper
DEBUG - 2011-02-22 09:45:39 --> Helper loaded: array_helper
DEBUG - 2011-02-22 09:45:39 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 09:45:39 --> Database Driver Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Session Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Helper loaded: string_helper
DEBUG - 2011-02-22 09:45:39 --> Session routines successfully run
DEBUG - 2011-02-22 09:45:39 --> Controller Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:45:39 --> Model Class Initialized
DEBUG - 2011-02-22 09:45:39 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 09:45:39 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 09:45:39 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 09:45:39 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 09:45:39 --> Final output sent to browser
DEBUG - 2011-02-22 09:45:39 --> Total execution time: 0.0255
DEBUG - 2011-02-22 21:47:13 --> Config Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Hooks Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Utf8 Class Initialized
DEBUG - 2011-02-22 21:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 21:47:13 --> URI Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Router Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Output Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Input Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 21:47:13 --> Language Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Loader Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 21:47:13 --> Helper loaded: user_helper
DEBUG - 2011-02-22 21:47:13 --> Helper loaded: url_helper
DEBUG - 2011-02-22 21:47:13 --> Helper loaded: array_helper
DEBUG - 2011-02-22 21:47:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 21:47:13 --> Database Driver Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Session Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Helper loaded: string_helper
DEBUG - 2011-02-22 21:47:13 --> A session cookie was not found.
DEBUG - 2011-02-22 21:47:13 --> Session routines successfully run
DEBUG - 2011-02-22 21:47:13 --> Controller Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Model Class Initialized
DEBUG - 2011-02-22 21:47:13 --> Model Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Config Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Hooks Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Utf8 Class Initialized
DEBUG - 2011-02-22 21:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 21:47:25 --> URI Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Router Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Output Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Input Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 21:47:25 --> Language Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Loader Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 21:47:25 --> Helper loaded: user_helper
DEBUG - 2011-02-22 21:47:25 --> Helper loaded: url_helper
DEBUG - 2011-02-22 21:47:25 --> Helper loaded: array_helper
DEBUG - 2011-02-22 21:47:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 21:47:25 --> Database Driver Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Session Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Helper loaded: string_helper
DEBUG - 2011-02-22 21:47:25 --> Session routines successfully run
DEBUG - 2011-02-22 21:47:25 --> Controller Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Model Class Initialized
DEBUG - 2011-02-22 21:47:25 --> Model Class Initialized
DEBUG - 2011-02-22 21:47:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 21:47:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 21:47:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 21:47:25 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 21:47:25 --> Final output sent to browser
DEBUG - 2011-02-22 21:47:25 --> Total execution time: 0.0314
DEBUG - 2011-02-22 22:10:24 --> Config Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:10:24 --> URI Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Router Class Initialized
DEBUG - 2011-02-22 22:10:24 --> No URI present. Default controller set.
DEBUG - 2011-02-22 22:10:24 --> Output Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Input Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:10:24 --> Language Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Loader Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:10:24 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:10:24 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:10:24 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:10:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:10:24 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Session Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:10:24 --> Session routines successfully run
DEBUG - 2011-02-22 22:10:24 --> Controller Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:10:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:10:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:10:24 --> File loaded: application/views/home/index.php
DEBUG - 2011-02-22 22:10:24 --> Final output sent to browser
DEBUG - 2011-02-22 22:10:24 --> Total execution time: 0.0353
DEBUG - 2011-02-22 22:10:58 --> Config Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:10:58 --> URI Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Router Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Output Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Input Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:10:58 --> Language Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Loader Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:10:58 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:10:58 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:10:58 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:10:58 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:10:58 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Session Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:10:58 --> Session routines successfully run
DEBUG - 2011-02-22 22:10:58 --> Controller Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> Model Class Initialized
DEBUG - 2011-02-22 22:10:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:10:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:10:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:10:58 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 22:10:58 --> Final output sent to browser
DEBUG - 2011-02-22 22:10:58 --> Total execution time: 0.0314
DEBUG - 2011-02-22 22:11:02 --> Config Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:11:02 --> URI Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Router Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Output Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Input Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:11:02 --> Language Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Loader Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:11:02 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:11:02 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:11:02 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:11:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:11:02 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Session Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:11:02 --> Session routines successfully run
DEBUG - 2011-02-22 22:11:02 --> Controller Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:11:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:11:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:11:02 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 22:11:02 --> Final output sent to browser
DEBUG - 2011-02-22 22:11:02 --> Total execution time: 0.0283
DEBUG - 2011-02-22 22:11:18 --> Config Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:11:18 --> URI Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Router Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Output Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Input Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:11:18 --> Language Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Loader Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:11:18 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:11:18 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:11:18 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:11:18 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:11:18 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Session Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:11:18 --> Session routines successfully run
DEBUG - 2011-02-22 22:11:18 --> Controller Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:18 --> Model Class Initialized
DEBUG - 2011-02-22 22:11:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:11:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:11:18 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:11:18 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:11:18 --> Final output sent to browser
DEBUG - 2011-02-22 22:11:18 --> Total execution time: 0.0284
DEBUG - 2011-02-22 22:20:34 --> Config Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:20:34 --> URI Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Router Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Output Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Input Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:20:34 --> Language Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Loader Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:20:34 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:20:34 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:20:34 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:20:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:20:34 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Session Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:20:34 --> Session routines successfully run
DEBUG - 2011-02-22 22:20:34 --> Controller Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:20:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:20:34 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:20:34 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:20:34 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:20:34 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:20:34 --> Final output sent to browser
DEBUG - 2011-02-22 22:20:34 --> Total execution time: 0.0284
DEBUG - 2011-02-22 22:21:16 --> Config Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:21:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:21:16 --> URI Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Router Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Output Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Input Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:21:16 --> Language Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Loader Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:21:16 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:21:16 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:21:16 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:21:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:21:16 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Session Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:21:16 --> Session routines successfully run
DEBUG - 2011-02-22 22:21:16 --> Controller Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Model Class Initialized
DEBUG - 2011-02-22 22:21:16 --> Model Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Config Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:22:38 --> URI Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Router Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Output Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Input Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:22:38 --> Language Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Loader Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:22:38 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:22:38 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:22:38 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:22:38 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:22:38 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Session Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:22:38 --> Session routines successfully run
DEBUG - 2011-02-22 22:22:38 --> Controller Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Model Class Initialized
DEBUG - 2011-02-22 22:22:38 --> Model Class Initialized
DEBUG - 2011-02-22 22:22:38 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:22:38 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:22:38 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:22:38 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:22:38 --> Final output sent to browser
DEBUG - 2011-02-22 22:22:38 --> Total execution time: 0.0266
DEBUG - 2011-02-22 22:25:52 --> Config Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:25:52 --> URI Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Router Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Output Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Input Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:25:52 --> Language Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Loader Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:25:52 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:25:52 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:25:52 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:25:52 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:25:52 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Session Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:25:52 --> Session routines successfully run
DEBUG - 2011-02-22 22:25:52 --> Controller Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Model Class Initialized
DEBUG - 2011-02-22 22:25:52 --> Model Class Initialized
DEBUG - 2011-02-22 22:25:52 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:25:52 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:25:52 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:25:52 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:25:52 --> Final output sent to browser
DEBUG - 2011-02-22 22:25:52 --> Total execution time: 0.0238
DEBUG - 2011-02-22 22:25:55 --> Config Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:25:55 --> URI Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Router Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Output Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Input Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:25:55 --> Language Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Loader Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:25:55 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:25:55 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:25:55 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:25:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:25:55 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Session Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:25:55 --> Session routines successfully run
DEBUG - 2011-02-22 22:25:55 --> Controller Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Model Class Initialized
DEBUG - 2011-02-22 22:25:55 --> Model Class Initialized
DEBUG - 2011-02-22 22:25:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:25:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:25:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:25:55 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:25:55 --> Final output sent to browser
DEBUG - 2011-02-22 22:25:55 --> Total execution time: 0.0234
DEBUG - 2011-02-22 22:26:01 --> Config Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:26:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:26:01 --> URI Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Router Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Output Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Input Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:26:01 --> Language Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Loader Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:26:01 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:26:01 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:26:01 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:26:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:26:01 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Session Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:26:01 --> Session routines successfully run
DEBUG - 2011-02-22 22:26:01 --> Controller Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:01 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:26:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:26:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:26:01 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:26:01 --> Final output sent to browser
DEBUG - 2011-02-22 22:26:01 --> Total execution time: 0.0240
DEBUG - 2011-02-22 22:26:25 --> Config Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:26:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:26:25 --> URI Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Router Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Output Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Input Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:26:25 --> Language Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Loader Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:26:25 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:26:25 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:26:25 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:26:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:26:25 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Session Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:26:25 --> Session routines successfully run
DEBUG - 2011-02-22 22:26:25 --> Controller Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:25 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:26:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:26:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:26:25 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:26:25 --> Final output sent to browser
DEBUG - 2011-02-22 22:26:25 --> Total execution time: 0.0245
DEBUG - 2011-02-22 22:26:26 --> Config Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:26:26 --> URI Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Router Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Output Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Input Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:26:26 --> Language Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Loader Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:26:26 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:26:26 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:26:26 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:26:26 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:26:26 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Session Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:26:26 --> Session routines successfully run
DEBUG - 2011-02-22 22:26:26 --> Controller Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:26 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:26:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:26:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:26:26 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:26:26 --> Final output sent to browser
DEBUG - 2011-02-22 22:26:26 --> Total execution time: 0.0248
DEBUG - 2011-02-22 22:26:40 --> Config Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:26:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:26:40 --> URI Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Router Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Output Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Input Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:26:40 --> Language Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Loader Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:26:40 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:26:40 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:26:40 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:26:40 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:26:40 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Session Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:26:40 --> Session routines successfully run
DEBUG - 2011-02-22 22:26:40 --> Controller Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:40 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:26:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:26:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:26:40 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:26:40 --> Final output sent to browser
DEBUG - 2011-02-22 22:26:40 --> Total execution time: 0.0218
DEBUG - 2011-02-22 22:26:42 --> Config Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:26:42 --> URI Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Router Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Output Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Input Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:26:42 --> Language Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Loader Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:26:42 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:26:42 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:26:42 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:26:42 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:26:42 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Session Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:26:42 --> Session routines successfully run
DEBUG - 2011-02-22 22:26:42 --> Controller Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:42 --> Model Class Initialized
DEBUG - 2011-02-22 22:26:42 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:26:42 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:26:42 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:26:42 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:26:42 --> Final output sent to browser
DEBUG - 2011-02-22 22:26:42 --> Total execution time: 0.0236
DEBUG - 2011-02-22 22:27:09 --> Config Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:27:09 --> URI Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Router Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Output Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Input Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:27:09 --> Language Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Loader Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:27:09 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:27:09 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:27:09 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:27:09 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:27:09 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Session Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:27:09 --> Session routines successfully run
DEBUG - 2011-02-22 22:27:09 --> Controller Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Model Class Initialized
DEBUG - 2011-02-22 22:27:09 --> Model Class Initialized
DEBUG - 2011-02-22 22:27:09 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:27:09 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:27:09 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:27:09 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 22:27:09 --> Final output sent to browser
DEBUG - 2011-02-22 22:27:09 --> Total execution time: 0.0267
DEBUG - 2011-02-22 22:27:22 --> Config Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:27:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:27:22 --> URI Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Router Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Output Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Input Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:27:22 --> Language Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Loader Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:27:22 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:27:22 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:27:22 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:27:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:27:22 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Session Class Initialized
DEBUG - 2011-02-22 22:27:22 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:27:22 --> Session routines successfully run
DEBUG - 2011-02-22 22:27:22 --> Controller Class Initialized
DEBUG - 2011-02-22 22:27:22 --> File loaded: application/views/home/go_sparks.php
DEBUG - 2011-02-22 22:27:22 --> Final output sent to browser
DEBUG - 2011-02-22 22:27:22 --> Total execution time: 0.0265
DEBUG - 2011-02-22 22:27:53 --> Config Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:27:53 --> URI Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Router Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Output Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Input Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:27:53 --> Language Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Loader Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:27:53 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:27:53 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:27:53 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:27:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:27:53 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Session Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:27:53 --> Session routines successfully run
DEBUG - 2011-02-22 22:27:53 --> Controller Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Model Class Initialized
DEBUG - 2011-02-22 22:27:53 --> Model Class Initialized
DEBUG - 2011-02-22 22:27:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:27:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:27:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:27:53 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:27:53 --> Final output sent to browser
DEBUG - 2011-02-22 22:27:53 --> Total execution time: 0.0248
DEBUG - 2011-02-22 22:29:20 --> Config Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:29:20 --> URI Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Router Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Output Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Input Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:29:20 --> Language Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Loader Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:29:20 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:29:20 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:29:20 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:29:20 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:29:20 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Session Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:29:20 --> Session routines successfully run
DEBUG - 2011-02-22 22:29:20 --> Controller Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Model Class Initialized
DEBUG - 2011-02-22 22:29:20 --> Model Class Initialized
DEBUG - 2011-02-22 22:29:20 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:29:20 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:29:20 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:29:20 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:29:20 --> Final output sent to browser
DEBUG - 2011-02-22 22:29:20 --> Total execution time: 0.0236
DEBUG - 2011-02-22 22:30:23 --> Config Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:30:23 --> URI Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Router Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Output Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Input Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:30:23 --> Language Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Loader Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:30:23 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:30:23 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:30:23 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:30:23 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:30:23 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Session Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:30:23 --> Session routines successfully run
DEBUG - 2011-02-22 22:30:23 --> Controller Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Model Class Initialized
DEBUG - 2011-02-22 22:30:23 --> Model Class Initialized
DEBUG - 2011-02-22 22:30:23 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:30:23 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:30:23 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:30:23 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:30:23 --> Final output sent to browser
DEBUG - 2011-02-22 22:30:23 --> Total execution time: 0.0218
DEBUG - 2011-02-22 22:31:17 --> Config Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:31:17 --> URI Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Router Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Output Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Input Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:31:17 --> Language Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Loader Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:31:17 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:31:17 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:31:17 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:31:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:31:17 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Session Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:31:17 --> Session routines successfully run
DEBUG - 2011-02-22 22:31:17 --> Controller Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Model Class Initialized
DEBUG - 2011-02-22 22:31:17 --> Model Class Initialized
DEBUG - 2011-02-22 22:31:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:31:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:31:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:31:17 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:31:17 --> Final output sent to browser
DEBUG - 2011-02-22 22:31:17 --> Total execution time: 0.0239
DEBUG - 2011-02-22 22:31:19 --> Config Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:31:19 --> URI Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Router Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Output Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Input Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:31:19 --> Language Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Loader Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:31:19 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:31:19 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:31:19 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:31:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:31:19 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Session Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:31:19 --> Session routines successfully run
DEBUG - 2011-02-22 22:31:19 --> Controller Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Model Class Initialized
DEBUG - 2011-02-22 22:31:19 --> Model Class Initialized
DEBUG - 2011-02-22 22:31:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:31:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:31:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:31:19 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:31:19 --> Final output sent to browser
DEBUG - 2011-02-22 22:31:19 --> Total execution time: 0.0250
DEBUG - 2011-02-22 22:31:57 --> Config Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:31:57 --> URI Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Router Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Output Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Input Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:31:57 --> Language Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Loader Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:31:57 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:31:57 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:31:57 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:31:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:31:57 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Session Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:31:57 --> Session routines successfully run
DEBUG - 2011-02-22 22:31:57 --> Controller Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Model Class Initialized
DEBUG - 2011-02-22 22:31:57 --> Model Class Initialized
DEBUG - 2011-02-22 22:31:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:31:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:31:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:31:57 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:31:57 --> Final output sent to browser
DEBUG - 2011-02-22 22:31:57 --> Total execution time: 0.0277
DEBUG - 2011-02-22 22:32:28 --> Config Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:32:28 --> URI Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Router Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Output Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Input Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:32:28 --> Language Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Loader Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:32:28 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:32:28 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:32:28 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:32:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:32:28 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Session Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:32:28 --> Session routines successfully run
DEBUG - 2011-02-22 22:32:28 --> Controller Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Model Class Initialized
DEBUG - 2011-02-22 22:32:28 --> Model Class Initialized
DEBUG - 2011-02-22 22:32:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:32:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:32:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:32:28 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:32:28 --> Final output sent to browser
DEBUG - 2011-02-22 22:32:28 --> Total execution time: 0.0228
DEBUG - 2011-02-22 22:33:47 --> Config Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:33:47 --> URI Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Router Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Output Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Input Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:33:47 --> Language Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Loader Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:33:47 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:33:47 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:33:47 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:33:47 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:33:47 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Session Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:33:47 --> Session routines successfully run
DEBUG - 2011-02-22 22:33:47 --> Controller Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Model Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Model Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Model Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Model Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Model Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Model Class Initialized
DEBUG - 2011-02-22 22:33:47 --> Model Class Initialized
DEBUG - 2011-02-22 22:33:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:33:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:33:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:33:47 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 22:33:47 --> Final output sent to browser
DEBUG - 2011-02-22 22:33:47 --> Total execution time: 0.0354
DEBUG - 2011-02-22 22:34:34 --> Config Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:34:34 --> URI Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Router Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Output Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Input Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:34:34 --> Language Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Loader Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:34:34 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:34:34 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:34:34 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:34:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:34:34 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Session Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:34:34 --> Session routines successfully run
DEBUG - 2011-02-22 22:34:34 --> Controller Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:34 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:34:34 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:34:34 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:34:34 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 22:34:34 --> Final output sent to browser
DEBUG - 2011-02-22 22:34:34 --> Total execution time: 0.0328
DEBUG - 2011-02-22 22:34:59 --> Config Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:34:59 --> URI Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Router Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Output Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Input Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:34:59 --> Language Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Loader Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:34:59 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:34:59 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:34:59 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:34:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:34:59 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Session Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:34:59 --> Session routines successfully run
DEBUG - 2011-02-22 22:34:59 --> Controller Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:34:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:34:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:34:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:34:59 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 22:34:59 --> Final output sent to browser
DEBUG - 2011-02-22 22:34:59 --> Total execution time: 0.0296
DEBUG - 2011-02-22 22:35:03 --> Config Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:35:03 --> URI Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Router Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Output Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Input Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:35:03 --> Language Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Loader Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:35:03 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:35:03 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:35:03 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:35:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:35:03 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Session Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:35:03 --> Session routines successfully run
DEBUG - 2011-02-22 22:35:03 --> Controller Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:03 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:35:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:35:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:35:03 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:35:03 --> Final output sent to browser
DEBUG - 2011-02-22 22:35:03 --> Total execution time: 0.0244
DEBUG - 2011-02-22 22:35:48 --> Config Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:35:48 --> URI Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Router Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Output Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Input Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:35:48 --> Language Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Loader Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:35:48 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:35:48 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:35:48 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:35:48 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:35:48 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Session Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:35:48 --> Session routines successfully run
DEBUG - 2011-02-22 22:35:48 --> Controller Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:48 --> Model Class Initialized
DEBUG - 2011-02-22 22:35:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:35:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:35:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:35:48 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 22:35:48 --> Final output sent to browser
DEBUG - 2011-02-22 22:35:48 --> Total execution time: 0.0349
DEBUG - 2011-02-22 22:43:17 --> Config Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:43:17 --> URI Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Router Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Output Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Input Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:43:17 --> Language Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Loader Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:43:17 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:43:17 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:43:17 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:43:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:43:17 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Session Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:43:17 --> Session routines successfully run
DEBUG - 2011-02-22 22:43:17 --> Controller Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Model Class Initialized
DEBUG - 2011-02-22 22:43:17 --> Model Class Initialized
DEBUG - 2011-02-22 22:43:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:43:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:43:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:43:17 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:43:17 --> Final output sent to browser
DEBUG - 2011-02-22 22:43:17 --> Total execution time: 0.0231
DEBUG - 2011-02-22 22:47:07 --> Config Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:47:07 --> URI Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Router Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Output Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Input Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:47:07 --> Language Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Loader Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:47:07 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:47:07 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:47:07 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:47:07 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:47:07 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Session Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:47:07 --> Session routines successfully run
DEBUG - 2011-02-22 22:47:07 --> Controller Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:07 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:07 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:47:07 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:47:07 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:47:07 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:47:07 --> Final output sent to browser
DEBUG - 2011-02-22 22:47:07 --> Total execution time: 0.0225
DEBUG - 2011-02-22 22:47:27 --> Config Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:47:27 --> URI Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Router Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Output Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Input Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:47:27 --> Language Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Loader Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:47:27 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:47:27 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:47:27 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:47:27 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:47:27 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Session Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:47:27 --> Session routines successfully run
DEBUG - 2011-02-22 22:47:27 --> Controller Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:27 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:27 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:47:27 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:47:27 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:47:27 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:47:27 --> Final output sent to browser
DEBUG - 2011-02-22 22:47:27 --> Total execution time: 0.0231
DEBUG - 2011-02-22 22:47:35 --> Config Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:47:35 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:47:35 --> URI Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Router Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Output Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Input Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:47:35 --> Language Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Loader Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:47:35 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:47:35 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:47:35 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:47:35 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:47:35 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Session Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:47:35 --> Session routines successfully run
DEBUG - 2011-02-22 22:47:35 --> Controller Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:35 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:35 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:47:35 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:47:35 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:47:35 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:47:35 --> Final output sent to browser
DEBUG - 2011-02-22 22:47:35 --> Total execution time: 0.0236
DEBUG - 2011-02-22 22:47:41 --> Config Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:47:41 --> URI Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Router Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Output Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Input Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:47:41 --> Language Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Loader Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:47:41 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:47:41 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:47:41 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:47:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:47:41 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Session Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:47:41 --> Session routines successfully run
DEBUG - 2011-02-22 22:47:41 --> Controller Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:41 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:47:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:47:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:47:41 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:47:41 --> Final output sent to browser
DEBUG - 2011-02-22 22:47:41 --> Total execution time: 0.0226
DEBUG - 2011-02-22 22:47:50 --> Config Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:47:50 --> URI Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Router Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Output Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Input Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:47:50 --> Language Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Loader Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:47:50 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:47:50 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:47:50 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:47:50 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:47:50 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Session Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:47:50 --> Session routines successfully run
DEBUG - 2011-02-22 22:47:50 --> Controller Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:50 --> Model Class Initialized
DEBUG - 2011-02-22 22:47:50 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:47:50 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:47:50 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:47:50 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:47:50 --> Final output sent to browser
DEBUG - 2011-02-22 22:47:50 --> Total execution time: 0.0231
DEBUG - 2011-02-22 22:48:15 --> Config Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:48:15 --> URI Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Router Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Output Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Input Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:48:15 --> Language Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Loader Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:48:15 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:48:15 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:48:15 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:48:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:48:15 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Session Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:48:15 --> Session routines successfully run
DEBUG - 2011-02-22 22:48:15 --> Controller Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Model Class Initialized
DEBUG - 2011-02-22 22:48:15 --> Model Class Initialized
DEBUG - 2011-02-22 22:48:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:48:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:48:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:48:15 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:48:15 --> Final output sent to browser
DEBUG - 2011-02-22 22:48:15 --> Total execution time: 0.0248
DEBUG - 2011-02-22 22:48:43 --> Config Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:48:43 --> URI Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Router Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Output Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Input Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:48:43 --> Language Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Loader Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:48:43 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:48:43 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:48:43 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:48:43 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:48:43 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Session Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:48:43 --> Session routines successfully run
DEBUG - 2011-02-22 22:48:43 --> Controller Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Model Class Initialized
DEBUG - 2011-02-22 22:48:43 --> Model Class Initialized
DEBUG - 2011-02-22 22:48:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:48:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:48:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:48:43 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:48:43 --> Final output sent to browser
DEBUG - 2011-02-22 22:48:43 --> Total execution time: 0.0233
DEBUG - 2011-02-22 22:48:54 --> Config Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:48:54 --> URI Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Router Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Output Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Input Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:48:54 --> Language Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Loader Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:48:54 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:48:54 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:48:54 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:48:54 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:48:54 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Session Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:48:54 --> Session routines successfully run
DEBUG - 2011-02-22 22:48:54 --> Controller Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Model Class Initialized
DEBUG - 2011-02-22 22:48:54 --> Model Class Initialized
DEBUG - 2011-02-22 22:48:54 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:48:54 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:48:54 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:48:54 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:48:54 --> Final output sent to browser
DEBUG - 2011-02-22 22:48:54 --> Total execution time: 0.0230
DEBUG - 2011-02-22 22:49:41 --> Config Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:49:41 --> URI Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Router Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Output Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Input Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:49:41 --> Language Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Loader Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:49:41 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:49:41 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:49:41 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:49:41 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:49:41 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Session Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:49:41 --> Session routines successfully run
DEBUG - 2011-02-22 22:49:41 --> Controller Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Model Class Initialized
DEBUG - 2011-02-22 22:49:41 --> Model Class Initialized
DEBUG - 2011-02-22 22:49:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:49:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:49:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:49:41 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:49:41 --> Final output sent to browser
DEBUG - 2011-02-22 22:49:41 --> Total execution time: 0.0219
DEBUG - 2011-02-22 22:49:53 --> Config Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:49:53 --> URI Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Router Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Output Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Input Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:49:53 --> Language Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Loader Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:49:53 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:49:53 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:49:53 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:49:53 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:49:53 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Session Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:49:53 --> Session routines successfully run
DEBUG - 2011-02-22 22:49:53 --> Controller Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Model Class Initialized
DEBUG - 2011-02-22 22:49:53 --> Model Class Initialized
DEBUG - 2011-02-22 22:49:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:49:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:49:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:49:53 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:49:53 --> Final output sent to browser
DEBUG - 2011-02-22 22:49:53 --> Total execution time: 0.0234
DEBUG - 2011-02-22 22:50:10 --> Config Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:50:10 --> URI Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Router Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Output Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Input Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:50:10 --> Language Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Loader Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:50:10 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:50:10 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:50:10 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:50:10 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:50:10 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Session Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:50:10 --> Session routines successfully run
DEBUG - 2011-02-22 22:50:10 --> Controller Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Model Class Initialized
DEBUG - 2011-02-22 22:50:10 --> Model Class Initialized
DEBUG - 2011-02-22 22:50:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:50:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:50:10 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:50:10 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:50:10 --> Final output sent to browser
DEBUG - 2011-02-22 22:50:10 --> Total execution time: 0.0231
DEBUG - 2011-02-22 22:50:19 --> Config Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:50:19 --> URI Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Router Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Output Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Input Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:50:19 --> Language Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Loader Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:50:19 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:50:19 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:50:19 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:50:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:50:19 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Session Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:50:19 --> Session routines successfully run
DEBUG - 2011-02-22 22:50:19 --> Controller Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Model Class Initialized
DEBUG - 2011-02-22 22:50:19 --> Model Class Initialized
DEBUG - 2011-02-22 22:50:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:50:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:50:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:50:19 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:50:19 --> Final output sent to browser
DEBUG - 2011-02-22 22:50:19 --> Total execution time: 0.0257
DEBUG - 2011-02-22 22:52:13 --> Config Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:52:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:52:13 --> URI Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Router Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Output Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Input Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:52:13 --> Language Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Loader Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:52:13 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:52:13 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:52:13 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:52:13 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:52:13 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Session Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:52:13 --> Session routines successfully run
DEBUG - 2011-02-22 22:52:13 --> Controller Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Model Class Initialized
DEBUG - 2011-02-22 22:52:13 --> Model Class Initialized
DEBUG - 2011-02-22 22:52:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:52:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:52:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:52:13 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:52:13 --> Final output sent to browser
DEBUG - 2011-02-22 22:52:13 --> Total execution time: 0.0266
DEBUG - 2011-02-22 22:52:36 --> Config Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:52:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:52:36 --> URI Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Router Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Output Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Input Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:52:36 --> Language Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Loader Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:52:36 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:52:36 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:52:36 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:52:36 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:52:36 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Session Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:52:36 --> Session routines successfully run
DEBUG - 2011-02-22 22:52:36 --> Controller Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Model Class Initialized
DEBUG - 2011-02-22 22:52:36 --> Model Class Initialized
DEBUG - 2011-02-22 22:52:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:52:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:52:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:52:36 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:52:36 --> Final output sent to browser
DEBUG - 2011-02-22 22:52:36 --> Total execution time: 0.0232
DEBUG - 2011-02-22 22:52:55 --> Config Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:52:55 --> URI Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Router Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Output Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Input Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:52:55 --> Language Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Loader Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:52:55 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:52:55 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:52:55 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:52:55 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:52:55 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Session Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:52:55 --> Session routines successfully run
DEBUG - 2011-02-22 22:52:55 --> Controller Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Model Class Initialized
DEBUG - 2011-02-22 22:52:55 --> Model Class Initialized
DEBUG - 2011-02-22 22:52:55 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:52:55 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:52:55 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:52:55 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:52:55 --> Final output sent to browser
DEBUG - 2011-02-22 22:52:55 --> Total execution time: 0.0242
DEBUG - 2011-02-22 22:54:14 --> Config Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:54:14 --> URI Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Router Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Output Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Input Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:54:14 --> Language Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Loader Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:54:14 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:54:14 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:54:14 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:54:14 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:54:14 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Session Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:54:14 --> Session routines successfully run
DEBUG - 2011-02-22 22:54:14 --> Controller Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Model Class Initialized
DEBUG - 2011-02-22 22:54:14 --> Model Class Initialized
DEBUG - 2011-02-22 22:54:14 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:54:14 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:54:14 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:54:14 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:54:14 --> Final output sent to browser
DEBUG - 2011-02-22 22:54:14 --> Total execution time: 0.0275
DEBUG - 2011-02-22 22:54:22 --> Config Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:54:22 --> URI Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Router Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Output Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Input Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:54:22 --> Language Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Loader Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:54:22 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:54:22 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:54:22 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:54:22 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:54:22 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Session Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:54:22 --> Session routines successfully run
DEBUG - 2011-02-22 22:54:22 --> Controller Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Model Class Initialized
DEBUG - 2011-02-22 22:54:22 --> Model Class Initialized
DEBUG - 2011-02-22 22:54:22 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:54:22 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:54:22 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:54:22 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:54:22 --> Final output sent to browser
DEBUG - 2011-02-22 22:54:22 --> Total execution time: 0.0218
DEBUG - 2011-02-22 22:54:45 --> Config Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:54:45 --> URI Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Router Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Output Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Input Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:54:45 --> Language Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Loader Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:54:45 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:54:45 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:54:45 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:54:45 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:54:45 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Session Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:54:45 --> Session routines successfully run
DEBUG - 2011-02-22 22:54:45 --> Controller Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Model Class Initialized
DEBUG - 2011-02-22 22:54:45 --> Model Class Initialized
DEBUG - 2011-02-22 22:54:45 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:54:45 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:54:45 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:54:45 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:54:45 --> Final output sent to browser
DEBUG - 2011-02-22 22:54:45 --> Total execution time: 0.0418
DEBUG - 2011-02-22 22:56:15 --> Config Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:56:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:56:15 --> URI Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Router Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Output Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Input Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:56:15 --> Language Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Loader Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:56:15 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:56:15 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:56:15 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:56:15 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:56:15 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Session Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:56:15 --> Session routines successfully run
DEBUG - 2011-02-22 22:56:15 --> Controller Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:15 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:15 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:56:15 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:56:15 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:56:15 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:56:15 --> Final output sent to browser
DEBUG - 2011-02-22 22:56:15 --> Total execution time: 0.0235
DEBUG - 2011-02-22 22:56:30 --> Config Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:56:30 --> URI Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Router Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Output Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Input Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:56:30 --> Language Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Loader Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:56:30 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:56:30 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:56:30 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:56:30 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:56:30 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Session Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:56:30 --> Session routines successfully run
DEBUG - 2011-02-22 22:56:30 --> Controller Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:30 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:56:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:56:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:56:30 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:56:30 --> Final output sent to browser
DEBUG - 2011-02-22 22:56:30 --> Total execution time: 0.0222
DEBUG - 2011-02-22 22:56:34 --> Config Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:56:34 --> URI Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Router Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Output Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Input Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:56:34 --> Language Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Loader Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:56:34 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:56:34 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:56:34 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:56:34 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:56:34 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Session Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:56:34 --> Session routines successfully run
DEBUG - 2011-02-22 22:56:34 --> Controller Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:34 --> Model Class Initialized
DEBUG - 2011-02-22 22:56:34 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:56:34 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:56:34 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:56:34 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 22:56:34 --> Final output sent to browser
DEBUG - 2011-02-22 22:56:34 --> Total execution time: 0.0373
DEBUG - 2011-02-22 22:57:59 --> Config Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:57:59 --> URI Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Router Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Output Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Input Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:57:59 --> Language Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Loader Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:57:59 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:57:59 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:57:59 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:57:59 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:57:59 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Session Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:57:59 --> Session routines successfully run
DEBUG - 2011-02-22 22:57:59 --> Controller Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:57:59 --> Model Class Initialized
DEBUG - 2011-02-22 22:57:59 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:57:59 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:57:59 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:57:59 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 22:57:59 --> Final output sent to browser
DEBUG - 2011-02-22 22:57:59 --> Total execution time: 0.0244
DEBUG - 2011-02-22 22:58:11 --> Config Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:58:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:58:11 --> URI Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Router Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Output Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Input Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:58:11 --> Language Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Loader Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:58:11 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:58:11 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:58:11 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:58:11 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:58:11 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Session Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:58:11 --> Session routines successfully run
DEBUG - 2011-02-22 22:58:11 --> Controller Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Model Class Initialized
DEBUG - 2011-02-22 22:58:11 --> Model Class Initialized
DEBUG - 2011-02-22 22:58:11 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:58:11 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:58:11 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:58:11 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 22:58:11 --> Final output sent to browser
DEBUG - 2011-02-22 22:58:11 --> Total execution time: 0.0278
DEBUG - 2011-02-22 22:58:57 --> Config Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Hooks Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Utf8 Class Initialized
DEBUG - 2011-02-22 22:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 22:58:57 --> URI Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Router Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Output Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Input Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 22:58:57 --> Language Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Loader Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 22:58:57 --> Helper loaded: user_helper
DEBUG - 2011-02-22 22:58:57 --> Helper loaded: url_helper
DEBUG - 2011-02-22 22:58:57 --> Helper loaded: array_helper
DEBUG - 2011-02-22 22:58:57 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 22:58:57 --> Database Driver Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Session Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Helper loaded: string_helper
DEBUG - 2011-02-22 22:58:57 --> Session routines successfully run
DEBUG - 2011-02-22 22:58:57 --> Controller Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Model Class Initialized
DEBUG - 2011-02-22 22:58:57 --> Model Class Initialized
DEBUG - 2011-02-22 22:58:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 22:58:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 22:58:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 22:58:57 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 22:58:57 --> Final output sent to browser
DEBUG - 2011-02-22 22:58:57 --> Total execution time: 0.0228
DEBUG - 2011-02-22 23:42:02 --> Config Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:42:02 --> URI Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Router Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Output Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Input Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:42:02 --> Language Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Loader Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:42:02 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:42:02 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:42:02 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:42:02 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:42:02 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Session Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:42:02 --> Session routines successfully run
DEBUG - 2011-02-22 23:42:02 --> Controller Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Model Class Initialized
DEBUG - 2011-02-22 23:42:02 --> Model Class Initialized
DEBUG - 2011-02-22 23:42:02 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:42:02 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:42:02 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:42:02 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:42:02 --> Final output sent to browser
DEBUG - 2011-02-22 23:42:02 --> Total execution time: 0.0268
DEBUG - 2011-02-22 23:48:05 --> Config Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:48:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:48:05 --> URI Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Router Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Output Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Input Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:48:05 --> Language Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Loader Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:48:05 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:48:05 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:48:05 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:48:05 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:48:05 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Session Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:48:05 --> Session routines successfully run
DEBUG - 2011-02-22 23:48:05 --> Controller Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Model Class Initialized
DEBUG - 2011-02-22 23:48:05 --> Model Class Initialized
DEBUG - 2011-02-22 23:48:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:48:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:48:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:48:05 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:48:05 --> Final output sent to browser
DEBUG - 2011-02-22 23:48:05 --> Total execution time: 0.0220
DEBUG - 2011-02-22 23:50:19 --> Config Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:50:19 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:50:19 --> URI Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Router Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Output Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Input Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:50:19 --> Language Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Loader Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:50:19 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:50:19 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:50:19 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:50:19 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:50:19 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Session Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:50:19 --> Session routines successfully run
DEBUG - 2011-02-22 23:50:19 --> Controller Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Model Class Initialized
DEBUG - 2011-02-22 23:50:19 --> Model Class Initialized
DEBUG - 2011-02-22 23:50:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:50:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:50:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:50:19 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:50:19 --> Final output sent to browser
DEBUG - 2011-02-22 23:50:19 --> Total execution time: 0.0219
DEBUG - 2011-02-22 23:51:51 --> Config Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:51:51 --> URI Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Router Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Output Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Input Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:51:51 --> Language Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Loader Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:51:51 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:51:51 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:51:51 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:51:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:51:51 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Session Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:51:51 --> Session routines successfully run
DEBUG - 2011-02-22 23:51:51 --> Controller Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Model Class Initialized
DEBUG - 2011-02-22 23:51:51 --> Model Class Initialized
DEBUG - 2011-02-22 23:51:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:51:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:51:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:51:51 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:51:51 --> Final output sent to browser
DEBUG - 2011-02-22 23:51:51 --> Total execution time: 0.0228
DEBUG - 2011-02-22 23:52:04 --> Config Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:52:04 --> URI Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Router Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Output Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Input Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:52:04 --> Language Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Loader Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:52:04 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:52:04 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:52:04 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:52:04 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:52:04 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Session Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:52:04 --> Session routines successfully run
DEBUG - 2011-02-22 23:52:04 --> Controller Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Model Class Initialized
DEBUG - 2011-02-22 23:52:04 --> Model Class Initialized
DEBUG - 2011-02-22 23:52:04 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:52:04 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:52:04 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:52:04 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:52:04 --> Final output sent to browser
DEBUG - 2011-02-22 23:52:04 --> Total execution time: 0.0221
DEBUG - 2011-02-22 23:52:16 --> Config Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:52:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:52:16 --> URI Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Router Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Output Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Input Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:52:16 --> Language Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Loader Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:52:16 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:52:16 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:52:16 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:52:16 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:52:16 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Session Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:52:16 --> Session routines successfully run
DEBUG - 2011-02-22 23:52:16 --> Controller Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Model Class Initialized
DEBUG - 2011-02-22 23:52:16 --> Model Class Initialized
DEBUG - 2011-02-22 23:52:16 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:52:16 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:52:16 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:52:16 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:52:16 --> Final output sent to browser
DEBUG - 2011-02-22 23:52:16 --> Total execution time: 0.0229
DEBUG - 2011-02-22 23:53:25 --> Config Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:53:25 --> URI Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Router Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Output Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Input Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:53:25 --> Language Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Loader Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:53:25 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:53:25 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:53:25 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:53:25 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:53:25 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Session Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:53:25 --> Session routines successfully run
DEBUG - 2011-02-22 23:53:25 --> Controller Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:25 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:25 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:53:25 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:53:25 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:53:25 --> File loaded: application/views/packages/show.php
DEBUG - 2011-02-22 23:53:25 --> Final output sent to browser
DEBUG - 2011-02-22 23:53:25 --> Total execution time: 0.0278
DEBUG - 2011-02-22 23:53:28 --> Config Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:53:28 --> URI Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Router Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Output Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Input Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:53:28 --> Language Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Loader Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:53:28 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:53:28 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:53:28 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:53:28 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:53:28 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Session Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:53:28 --> Session routines successfully run
DEBUG - 2011-02-22 23:53:28 --> Controller Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:28 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:53:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:53:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:53:28 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:53:28 --> Final output sent to browser
DEBUG - 2011-02-22 23:53:28 --> Total execution time: 0.0243
DEBUG - 2011-02-22 23:53:46 --> Config Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:53:46 --> URI Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Router Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Output Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Input Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:53:46 --> Language Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Loader Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:53:46 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:53:46 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:53:46 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:53:46 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:53:46 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Session Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:53:46 --> Session routines successfully run
DEBUG - 2011-02-22 23:53:46 --> Controller Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:46 --> Model Class Initialized
DEBUG - 2011-02-22 23:53:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:53:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:53:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:53:46 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:53:46 --> Final output sent to browser
DEBUG - 2011-02-22 23:53:46 --> Total execution time: 0.0220
DEBUG - 2011-02-22 23:54:03 --> Config Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:54:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:54:03 --> URI Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Router Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Output Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Input Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:54:03 --> Language Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Loader Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:54:03 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:54:03 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:54:03 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:54:03 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:54:03 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Session Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:54:03 --> Session routines successfully run
DEBUG - 2011-02-22 23:54:03 --> Controller Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Model Class Initialized
DEBUG - 2011-02-22 23:54:03 --> Model Class Initialized
DEBUG - 2011-02-22 23:54:03 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:54:03 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:54:03 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:54:03 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:54:03 --> Final output sent to browser
DEBUG - 2011-02-22 23:54:03 --> Total execution time: 0.0229
DEBUG - 2011-02-22 23:55:06 --> Config Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:55:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:55:06 --> URI Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Router Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Output Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Input Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:55:06 --> Language Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Loader Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:55:06 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:55:06 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:55:06 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:55:06 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:55:06 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Session Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:55:06 --> Session routines successfully run
DEBUG - 2011-02-22 23:55:06 --> Controller Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Model Class Initialized
DEBUG - 2011-02-22 23:55:06 --> Model Class Initialized
DEBUG - 2011-02-22 23:55:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:55:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:55:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:55:06 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:55:06 --> Final output sent to browser
DEBUG - 2011-02-22 23:55:06 --> Total execution time: 0.0234
DEBUG - 2011-02-22 23:55:56 --> Config Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:55:56 --> URI Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Router Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Output Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Input Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:55:56 --> Language Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Loader Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:55:56 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:55:56 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:55:56 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:55:56 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:55:56 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Session Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:55:56 --> Session routines successfully run
DEBUG - 2011-02-22 23:55:56 --> Controller Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Model Class Initialized
DEBUG - 2011-02-22 23:55:56 --> Model Class Initialized
DEBUG - 2011-02-22 23:55:56 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:55:56 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:55:56 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:55:56 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:55:56 --> Final output sent to browser
DEBUG - 2011-02-22 23:55:56 --> Total execution time: 0.0222
DEBUG - 2011-02-22 23:57:01 --> Config Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:57:01 --> URI Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Router Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Output Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Input Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:57:01 --> Language Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Loader Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:57:01 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:57:01 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:57:01 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:57:01 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:57:01 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Session Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:57:01 --> Session routines successfully run
DEBUG - 2011-02-22 23:57:01 --> Controller Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:01 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:57:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:57:01 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:57:01 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:57:01 --> Final output sent to browser
DEBUG - 2011-02-22 23:57:01 --> Total execution time: 0.0251
DEBUG - 2011-02-22 23:57:17 --> Config Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:57:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:57:17 --> URI Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Router Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Output Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Input Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:57:17 --> Language Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Loader Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:57:17 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:57:17 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:57:17 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:57:17 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:57:17 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Session Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:57:17 --> Session routines successfully run
DEBUG - 2011-02-22 23:57:17 --> Controller Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:17 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:17 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:57:17 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:57:17 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:57:17 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:57:17 --> Final output sent to browser
DEBUG - 2011-02-22 23:57:17 --> Total execution time: 0.0265
DEBUG - 2011-02-22 23:57:21 --> Config Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:57:21 --> URI Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Router Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Output Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Input Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:57:21 --> Language Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Loader Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:57:21 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:57:21 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:57:21 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:57:21 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:57:21 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Session Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:57:21 --> Session routines successfully run
DEBUG - 2011-02-22 23:57:21 --> Controller Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:21 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:21 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:57:21 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:57:21 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:57:21 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-02-22 23:57:21 --> Final output sent to browser
DEBUG - 2011-02-22 23:57:21 --> Total execution time: 0.0328
DEBUG - 2011-02-22 23:57:24 --> Config Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:57:24 --> URI Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Router Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Output Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Input Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:57:24 --> Language Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Loader Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:57:24 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:57:24 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:57:24 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:57:24 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:57:24 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Session Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:57:24 --> Session routines successfully run
DEBUG - 2011-02-22 23:57:24 --> Controller Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:24 --> Model Class Initialized
DEBUG - 2011-02-22 23:57:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:57:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:57:24 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:57:24 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-02-22 23:57:24 --> Final output sent to browser
DEBUG - 2011-02-22 23:57:24 --> Total execution time: 0.0246
DEBUG - 2011-02-22 23:58:51 --> Config Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Hooks Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Utf8 Class Initialized
DEBUG - 2011-02-22 23:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-02-22 23:58:51 --> URI Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Router Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Output Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Input Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-22 23:58:51 --> Language Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Loader Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-02-22 23:58:51 --> Helper loaded: user_helper
DEBUG - 2011-02-22 23:58:51 --> Helper loaded: url_helper
DEBUG - 2011-02-22 23:58:51 --> Helper loaded: array_helper
DEBUG - 2011-02-22 23:58:51 --> Helper loaded: utility_helper
DEBUG - 2011-02-22 23:58:51 --> Database Driver Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Session Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Helper loaded: string_helper
DEBUG - 2011-02-22 23:58:51 --> Session routines successfully run
DEBUG - 2011-02-22 23:58:51 --> Controller Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Model Class Initialized
DEBUG - 2011-02-22 23:58:51 --> Model Class Initialized
DEBUG - 2011-02-22 23:58:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-02-22 23:58:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-02-22 23:58:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-02-22 23:58:51 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-02-22 23:58:51 --> Final output sent to browser
DEBUG - 2011-02-22 23:58:51 --> Total execution time: 0.0322
