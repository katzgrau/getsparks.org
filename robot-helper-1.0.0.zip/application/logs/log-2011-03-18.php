<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-18 18:07:58 --> Config Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:07:58 --> URI Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Router Class Initialized
DEBUG - 2011-03-18 18:07:58 --> No URI present. Default controller set.
DEBUG - 2011-03-18 18:07:58 --> Output Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Input Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:07:58 --> Language Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Loader Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:07:58 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Session Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:07:58 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Session routines successfully run
DEBUG - 2011-03-18 18:07:58 --> Controller Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: file_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: directory_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: assets_helper
DEBUG - 2011-03-18 18:07:58 --> CSSMin library initialized.
DEBUG - 2011-03-18 18:07:58 --> JSMin library initialized.
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
ERROR - 2011-03-18 18:07:58 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Model Class Initialized
DEBUG - 2011-03-18 18:07:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-18 18:07:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-18 18:07:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-18 18:07:58 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-18 18:07:58 --> Final output sent to browser
DEBUG - 2011-03-18 18:07:58 --> Total execution time: 0.0544
DEBUG - 2011-03-18 18:07:58 --> Config Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:07:58 --> URI Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Router Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Output Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Input Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:07:58 --> Language Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Loader Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:07:58 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Session Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:07:58 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:07:58 --> Session routines successfully run
DEBUG - 2011-03-18 18:07:58 --> Controller Class Initialized
DEBUG - 2011-03-18 18:07:58 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-18 18:07:58 --> Final output sent to browser
DEBUG - 2011-03-18 18:07:58 --> Total execution time: 0.0227
DEBUG - 2011-03-18 18:08:01 --> Config Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:08:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:08:01 --> URI Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Router Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Output Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Input Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:08:01 --> Language Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Loader Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:08:01 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Session Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:08:01 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Session routines successfully run
DEBUG - 2011-03-18 18:08:01 --> Controller Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: file_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: directory_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: assets_helper
DEBUG - 2011-03-18 18:08:01 --> CSSMin library initialized.
DEBUG - 2011-03-18 18:08:01 --> JSMin library initialized.
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-18 18:08:01 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: rating_helper
DEBUG - 2011-03-18 18:08:01 --> Model Class Initialized
DEBUG - 2011-03-18 18:08:01 --> DB Transaction Failure
ERROR - 2011-03-18 18:08:01 --> Query error: Table 'sparks.rating_names' doesn't exist
DEBUG - 2011-03-18 18:08:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-03-18 18:08:01 --> Config Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:08:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:08:01 --> URI Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Router Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Output Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Input Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:08:01 --> Language Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Loader Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:08:01 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Session Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:08:01 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:08:01 --> Session routines successfully run
DEBUG - 2011-03-18 18:08:01 --> Controller Class Initialized
DEBUG - 2011-03-18 18:08:01 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-18 18:08:01 --> Final output sent to browser
DEBUG - 2011-03-18 18:08:01 --> Total execution time: 0.0230
DEBUG - 2011-03-18 18:25:24 --> Config Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:25:24 --> URI Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Router Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Output Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Input Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:25:24 --> Language Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Loader Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:25:24 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Session Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:25:24 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Session routines successfully run
DEBUG - 2011-03-18 18:25:24 --> Controller Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
ERROR - 2011-03-18 18:25:24 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: file_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: directory_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: assets_helper
DEBUG - 2011-03-18 18:25:24 --> CSSMin library initialized.
DEBUG - 2011-03-18 18:25:24 --> JSMin library initialized.
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-18 18:25:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: rating_helper
DEBUG - 2011-03-18 18:25:24 --> Model Class Initialized
DEBUG - 2011-03-18 18:25:24 --> DB Transaction Failure
ERROR - 2011-03-18 18:25:24 --> Query error: Table 'sparks.rating_names' doesn't exist
DEBUG - 2011-03-18 18:25:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-03-18 18:25:24 --> Config Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:25:24 --> URI Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Router Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Output Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Input Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:25:24 --> Language Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Loader Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:25:24 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Session Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:25:24 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:25:24 --> Session routines successfully run
DEBUG - 2011-03-18 18:25:24 --> Controller Class Initialized
DEBUG - 2011-03-18 18:25:24 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-18 18:25:24 --> Final output sent to browser
DEBUG - 2011-03-18 18:25:24 --> Total execution time: 0.0233
DEBUG - 2011-03-18 18:27:40 --> Config Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:27:40 --> URI Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Router Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Output Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Input Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:27:40 --> Language Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Loader Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:27:40 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Session Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:27:40 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Session routines successfully run
DEBUG - 2011-03-18 18:27:40 --> Controller Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
ERROR - 2011-03-18 18:27:40 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: file_helper
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: directory_helper
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: assets_helper
DEBUG - 2011-03-18 18:27:40 --> CSSMin library initialized.
DEBUG - 2011-03-18 18:27:40 --> JSMin library initialized.
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-18 18:27:40 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-18 18:27:40 --> Helper loaded: rating_helper
DEBUG - 2011-03-18 18:27:40 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:40 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-18 18:27:40 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-03-18 18:27:40 --> Final output sent to browser
DEBUG - 2011-03-18 18:27:40 --> Total execution time: 0.0731
DEBUG - 2011-03-18 18:27:43 --> Config Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:27:43 --> URI Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Router Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Output Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Input Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:27:43 --> Language Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Loader Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:27:43 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Session Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:27:43 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Session routines successfully run
DEBUG - 2011-03-18 18:27:43 --> Controller Class Initialized
DEBUG - 2011-03-18 18:27:43 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-18 18:27:43 --> Final output sent to browser
DEBUG - 2011-03-18 18:27:43 --> Total execution time: 0.0248
DEBUG - 2011-03-18 18:27:43 --> Config Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Hooks Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Utf8 Class Initialized
DEBUG - 2011-03-18 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-18 18:27:43 --> URI Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Router Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Output Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Input Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-18 18:27:43 --> Language Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Loader Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: user_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: url_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: array_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: utility_helper
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-18 18:27:43 --> Database Driver Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Session Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: string_helper
DEBUG - 2011-03-18 18:27:43 --> Encrypt Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Session routines successfully run
DEBUG - 2011-03-18 18:27:43 --> Controller Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Model Class Initialized
DEBUG - 2011-03-18 18:27:43 --> Helper loaded: rating_helper
DEBUG - 2011-03-18 18:27:43 --> Final output sent to browser
DEBUG - 2011-03-18 18:27:43 --> Total execution time: 0.0256
