<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-01 08:56:57 --> Config Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Hooks Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Utf8 Class Initialized
DEBUG - 2011-03-01 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-01 08:56:57 --> URI Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Router Class Initialized
DEBUG - 2011-03-01 08:56:57 --> No URI present. Default controller set.
DEBUG - 2011-03-01 08:56:57 --> Output Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Input Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-01 08:56:57 --> Language Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Loader Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-01 08:56:57 --> Helper loaded: user_helper
DEBUG - 2011-03-01 08:56:57 --> Helper loaded: url_helper
DEBUG - 2011-03-01 08:56:57 --> Helper loaded: array_helper
DEBUG - 2011-03-01 08:56:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-01 08:56:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-01 08:56:57 --> Database Driver Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Session Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Helper loaded: string_helper
DEBUG - 2011-03-01 08:56:57 --> A session cookie was not found.
DEBUG - 2011-03-01 08:56:57 --> Session routines successfully run
DEBUG - 2011-03-01 08:56:57 --> Controller Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Model Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Model Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Model Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Model Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Model Class Initialized
DEBUG - 2011-03-01 08:56:57 --> Model Class Initialized
DEBUG - 2011-03-01 08:56:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-01 08:56:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-01 08:56:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-01 08:56:57 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-01 08:56:57 --> Final output sent to browser
DEBUG - 2011-03-01 08:56:57 --> Total execution time: 0.0296
