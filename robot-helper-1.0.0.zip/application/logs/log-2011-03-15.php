<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-15 08:44:36 --> Config Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Hooks Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Utf8 Class Initialized
DEBUG - 2011-03-15 08:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 08:44:36 --> URI Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Router Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Output Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Input Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 08:44:36 --> Language Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Loader Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: user_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: url_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: array_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 08:44:36 --> Database Driver Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Session Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: string_helper
DEBUG - 2011-03-15 08:44:36 --> Encrypt Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Session routines successfully run
DEBUG - 2011-03-15 08:44:36 --> Controller Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: file_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: directory_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: assets_helper
DEBUG - 2011-03-15 08:44:36 --> CSSMin library initialized.
DEBUG - 2011-03-15 08:44:36 --> JSMin library initialized.
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
ERROR - 2011-03-15 08:44:36 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:36 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-15 08:44:36 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-15 08:44:36 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-15 08:44:36 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-03-15 08:44:36 --> Final output sent to browser
DEBUG - 2011-03-15 08:44:36 --> Total execution time: 0.0534
DEBUG - 2011-03-15 08:44:36 --> Config Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Hooks Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Utf8 Class Initialized
DEBUG - 2011-03-15 08:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 08:44:36 --> URI Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Router Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Output Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Input Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 08:44:36 --> Language Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Loader Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: user_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: url_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: array_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 08:44:36 --> Database Driver Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Session Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Helper loaded: string_helper
DEBUG - 2011-03-15 08:44:36 --> Encrypt Class Initialized
DEBUG - 2011-03-15 08:44:36 --> Session routines successfully run
DEBUG - 2011-03-15 08:44:36 --> Controller Class Initialized
DEBUG - 2011-03-15 08:44:36 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-15 08:44:36 --> Final output sent to browser
DEBUG - 2011-03-15 08:44:36 --> Total execution time: 0.0222
DEBUG - 2011-03-15 08:44:43 --> Config Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Hooks Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Utf8 Class Initialized
DEBUG - 2011-03-15 08:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 08:44:43 --> URI Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Router Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Output Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Input Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 08:44:43 --> Language Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Loader Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: user_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: url_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: array_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 08:44:43 --> Database Driver Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Session Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: string_helper
DEBUG - 2011-03-15 08:44:43 --> Encrypt Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Session routines successfully run
DEBUG - 2011-03-15 08:44:43 --> Controller Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: file_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: directory_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: assets_helper
DEBUG - 2011-03-15 08:44:43 --> CSSMin library initialized.
DEBUG - 2011-03-15 08:44:43 --> JSMin library initialized.
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
ERROR - 2011-03-15 08:44:43 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-15 08:44:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-15 08:44:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-15 08:44:43 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-03-15 08:44:43 --> Final output sent to browser
DEBUG - 2011-03-15 08:44:43 --> Total execution time: 0.0439
DEBUG - 2011-03-15 08:44:43 --> Config Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Hooks Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Utf8 Class Initialized
DEBUG - 2011-03-15 08:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 08:44:43 --> URI Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Router Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Output Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Input Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 08:44:43 --> Language Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Loader Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: user_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: url_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: array_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 08:44:43 --> Database Driver Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Session Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Helper loaded: string_helper
DEBUG - 2011-03-15 08:44:43 --> Encrypt Class Initialized
DEBUG - 2011-03-15 08:44:43 --> Session routines successfully run
DEBUG - 2011-03-15 08:44:43 --> Controller Class Initialized
DEBUG - 2011-03-15 08:44:43 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-15 08:44:43 --> Final output sent to browser
DEBUG - 2011-03-15 08:44:43 --> Total execution time: 0.0222
DEBUG - 2011-03-15 08:44:53 --> Config Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Hooks Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Utf8 Class Initialized
DEBUG - 2011-03-15 08:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 08:44:53 --> URI Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Router Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Output Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Input Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 08:44:53 --> Language Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Loader Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: user_helper
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: url_helper
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: array_helper
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 08:44:53 --> Database Driver Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Session Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: string_helper
DEBUG - 2011-03-15 08:44:53 --> Encrypt Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Session routines successfully run
DEBUG - 2011-03-15 08:44:53 --> Controller Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: file_helper
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: directory_helper
DEBUG - 2011-03-15 08:44:53 --> Helper loaded: assets_helper
DEBUG - 2011-03-15 08:44:53 --> CSSMin library initialized.
DEBUG - 2011-03-15 08:44:53 --> JSMin library initialized.
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> Model Class Initialized
DEBUG - 2011-03-15 08:44:53 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-15 08:44:53 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-15 08:44:53 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-15 08:44:53 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-03-15 08:44:53 --> Final output sent to browser
DEBUG - 2011-03-15 08:44:53 --> Total execution time: 0.0463
DEBUG - 2011-03-15 08:44:54 --> Config Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Hooks Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Utf8 Class Initialized
DEBUG - 2011-03-15 08:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 08:44:54 --> URI Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Router Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Output Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Input Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 08:44:54 --> Language Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Loader Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 08:44:54 --> Helper loaded: user_helper
DEBUG - 2011-03-15 08:44:54 --> Helper loaded: url_helper
DEBUG - 2011-03-15 08:44:54 --> Helper loaded: array_helper
DEBUG - 2011-03-15 08:44:54 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 08:44:54 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 08:44:54 --> Database Driver Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Session Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Helper loaded: string_helper
DEBUG - 2011-03-15 08:44:54 --> Encrypt Class Initialized
DEBUG - 2011-03-15 08:44:54 --> Session routines successfully run
DEBUG - 2011-03-15 08:44:54 --> Controller Class Initialized
DEBUG - 2011-03-15 08:44:54 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-15 08:44:54 --> Final output sent to browser
DEBUG - 2011-03-15 08:44:54 --> Total execution time: 0.0236
DEBUG - 2011-03-15 18:34:32 --> Config Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:34:32 --> URI Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Router Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Output Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Input Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:34:32 --> Language Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Loader Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:34:32 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Session Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:34:32 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Session routines successfully run
DEBUG - 2011-03-15 18:34:32 --> Controller Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: file_helper
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: directory_helper
DEBUG - 2011-03-15 18:34:32 --> Helper loaded: assets_helper
DEBUG - 2011-03-15 18:34:32 --> CSSMin library initialized.
DEBUG - 2011-03-15 18:34:32 --> JSMin library initialized.
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
ERROR - 2011-03-15 18:34:32 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
DEBUG - 2011-03-15 18:34:32 --> Model Class Initialized
DEBUG - 2011-03-15 18:34:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-15 18:34:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-15 18:34:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-15 18:34:32 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-03-15 18:34:32 --> Final output sent to browser
DEBUG - 2011-03-15 18:34:32 --> Total execution time: 0.0486
DEBUG - 2011-03-15 18:34:34 --> Config Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:34:34 --> URI Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Router Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Output Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Input Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:34:34 --> Language Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Loader Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:34:34 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:34:34 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:34:34 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:34:34 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:34:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:34:34 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Session Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:34:34 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:34:34 --> Session routines successfully run
DEBUG - 2011-03-15 18:34:34 --> Controller Class Initialized
DEBUG - 2011-03-15 18:34:34 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-15 18:34:34 --> Final output sent to browser
DEBUG - 2011-03-15 18:34:34 --> Total execution time: 0.0243
DEBUG - 2011-03-15 18:35:10 --> Config Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:35:10 --> URI Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Router Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Output Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Input Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:35:10 --> Language Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Loader Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:35:10 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Session Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:35:10 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Session routines successfully run
DEBUG - 2011-03-15 18:35:10 --> Controller Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
ERROR - 2011-03-15 18:35:10 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: file_helper
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: directory_helper
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: assets_helper
DEBUG - 2011-03-15 18:35:10 --> CSSMin library initialized.
DEBUG - 2011-03-15 18:35:10 --> JSMin library initialized.
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-15 18:35:10 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-15 18:35:10 --> Helper loaded: rating_helper
DEBUG - 2011-03-15 18:35:10 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:10 --> DB Transaction Failure
ERROR - 2011-03-15 18:35:10 --> Query error: Table 'sparks.rating_names' doesn't exist
DEBUG - 2011-03-15 18:35:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-03-15 18:35:11 --> Config Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:35:11 --> URI Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Router Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Output Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Input Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:35:11 --> Language Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Loader Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:35:11 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:35:11 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:35:11 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:35:11 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:35:11 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:35:11 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Session Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:35:11 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:35:11 --> Session routines successfully run
DEBUG - 2011-03-15 18:35:11 --> Controller Class Initialized
DEBUG - 2011-03-15 18:35:11 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-15 18:35:11 --> Final output sent to browser
DEBUG - 2011-03-15 18:35:11 --> Total execution time: 0.0232
DEBUG - 2011-03-15 18:35:24 --> Config Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:35:24 --> URI Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Router Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Output Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Input Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:35:24 --> Language Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Loader Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:35:24 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Session Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:35:24 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Session routines successfully run
DEBUG - 2011-03-15 18:35:24 --> Controller Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: file_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: directory_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: assets_helper
DEBUG - 2011-03-15 18:35:24 --> CSSMin library initialized.
DEBUG - 2011-03-15 18:35:24 --> JSMin library initialized.
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-15 18:35:24 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: rating_helper
DEBUG - 2011-03-15 18:35:24 --> Model Class Initialized
DEBUG - 2011-03-15 18:35:24 --> DB Transaction Failure
ERROR - 2011-03-15 18:35:24 --> Query error: Table 'sparks.rating_names' doesn't exist
DEBUG - 2011-03-15 18:35:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-03-15 18:35:24 --> Config Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:35:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:35:24 --> URI Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Router Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Output Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Input Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:35:24 --> Language Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Loader Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:35:24 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Session Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:35:24 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:35:24 --> Session routines successfully run
DEBUG - 2011-03-15 18:35:24 --> Controller Class Initialized
DEBUG - 2011-03-15 18:35:24 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-15 18:35:24 --> Final output sent to browser
DEBUG - 2011-03-15 18:35:24 --> Total execution time: 0.0227
DEBUG - 2011-03-15 18:36:18 --> Config Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:36:18 --> URI Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Router Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Output Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Input Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:36:18 --> Language Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Loader Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:36:18 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Session Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:36:18 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Session routines successfully run
DEBUG - 2011-03-15 18:36:18 --> Controller Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
ERROR - 2011-03-15 18:36:18 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: file_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: directory_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: assets_helper
DEBUG - 2011-03-15 18:36:18 --> CSSMin library initialized.
DEBUG - 2011-03-15 18:36:18 --> JSMin library initialized.
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-15 18:36:18 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: rating_helper
DEBUG - 2011-03-15 18:36:18 --> Model Class Initialized
DEBUG - 2011-03-15 18:36:18 --> DB Transaction Failure
ERROR - 2011-03-15 18:36:18 --> Query error: Table 'sparks.rating_names' doesn't exist
DEBUG - 2011-03-15 18:36:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-03-15 18:36:18 --> Config Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Hooks Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Utf8 Class Initialized
DEBUG - 2011-03-15 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 18:36:18 --> URI Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Router Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Output Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Input Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 18:36:18 --> Language Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Loader Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: user_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: url_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: array_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 18:36:18 --> Database Driver Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Session Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Helper loaded: string_helper
DEBUG - 2011-03-15 18:36:18 --> Encrypt Class Initialized
DEBUG - 2011-03-15 18:36:18 --> Session routines successfully run
DEBUG - 2011-03-15 18:36:18 --> Controller Class Initialized
DEBUG - 2011-03-15 18:36:18 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-15 18:36:18 --> Final output sent to browser
DEBUG - 2011-03-15 18:36:18 --> Total execution time: 0.0222
DEBUG - 2011-03-15 19:02:46 --> Config Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Hooks Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Utf8 Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> UTF-8 Support Enabled
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> URI Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Router Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> No URI present. Default controller set.
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Output Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Input Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Global POST and COOKIE data sanitized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Language Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Loader Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Config file loaded: application/config/application.php
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: user_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: url_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: array_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: utility_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: gravatar_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Database Driver Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Session Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: string_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Encrypt Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> A session cookie was not found.
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Session routines successfully run
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Controller Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Config file loaded: sparks/assets/v0.4/config/assets.php
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: file_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: directory_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Helper loaded: assets_helper
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> CSSMin library initialized.
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> JSMin library initialized.
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Model Class Initialized
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> File loaded: application/views/global/_left_column.php
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> File loaded: application/views/global/_new_header.php
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> File loaded: application/views/global/_new_footer.php
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> File loaded: application/views/home/index.php
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Final output sent to browser
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:46 --> Total execution time: 0.0599
ERROR - 2011-03-15 19:02:46 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:51 --> Config Class Initialized
ERROR - 2011-03-15 19:02:51 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:51 --> Hooks Class Initialized
ERROR - 2011-03-15 19:02:51 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:51 --> Utf8 Class Initialized
ERROR - 2011-03-15 19:02:51 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:51 --> UTF-8 Support Enabled
ERROR - 2011-03-15 19:02:51 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:51 --> URI Class Initialized
ERROR - 2011-03-15 19:02:51 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 19:02:51 --> Router Class Initialized
ERROR - 2011-03-15 19:02:51 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
ERROR - 2011-03-15 19:02:51 --> 404 Page Not Found --> cli
ERROR - 2011-03-15 19:02:51 --> Severity: Warning  --> chmod(): Operation not permitted /Users/katzgrau/Dev/ci-sparks-repo/system/libraries/Log.php 106
DEBUG - 2011-03-15 21:03:52 --> Config Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:03:52 --> URI Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Router Class Initialized
DEBUG - 2011-03-15 21:03:52 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:03:52 --> Output Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Input Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:03:52 --> Language Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Loader Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:03:52 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:03:52 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:03:52 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:03:52 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:03:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:03:52 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Session Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:03:52 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:03:52 --> A session cookie was not found.
DEBUG - 2011-03-15 21:03:52 --> Session routines successfully run
DEBUG - 2011-03-15 21:03:52 --> Controller Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Final output sent to browser
DEBUG - 2011-03-15 21:03:52 --> Total execution time: 0.0247
DEBUG - 2011-03-15 21:03:52 --> Model Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Model Class Initialized
DEBUG - 2011-03-15 21:03:52 --> Model Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Config Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:06:48 --> URI Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Router Class Initialized
DEBUG - 2011-03-15 21:06:48 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:06:48 --> Output Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Input Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:06:48 --> Language Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Loader Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:06:48 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:06:48 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:06:48 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:06:48 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:06:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:06:48 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Session Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:06:48 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:06:48 --> A session cookie was not found.
DEBUG - 2011-03-15 21:06:48 --> Session routines successfully run
DEBUG - 2011-03-15 21:06:48 --> Controller Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Final output sent to browser
DEBUG - 2011-03-15 21:06:48 --> Total execution time: 0.0245
DEBUG - 2011-03-15 21:06:48 --> Model Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Model Class Initialized
DEBUG - 2011-03-15 21:06:48 --> Model Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Config Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:07:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:07:34 --> URI Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Router Class Initialized
DEBUG - 2011-03-15 21:07:34 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:07:34 --> Output Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Input Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:07:34 --> Language Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Loader Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:07:34 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:07:34 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:07:34 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:07:34 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:07:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:07:34 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Session Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:07:34 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:07:34 --> A session cookie was not found.
DEBUG - 2011-03-15 21:07:34 --> Session routines successfully run
DEBUG - 2011-03-15 21:07:34 --> Controller Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Final output sent to browser
DEBUG - 2011-03-15 21:07:34 --> Total execution time: 0.0242
DEBUG - 2011-03-15 21:07:34 --> Model Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Model Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Model Class Initialized
DEBUG - 2011-03-15 21:07:34 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:07:34 --> Model Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Config Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:08:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:08:37 --> URI Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Router Class Initialized
DEBUG - 2011-03-15 21:08:37 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:08:37 --> Output Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Input Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:08:37 --> Language Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Loader Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:08:37 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:08:37 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:08:37 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:08:37 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:08:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:08:37 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Session Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:08:37 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:08:37 --> A session cookie was not found.
DEBUG - 2011-03-15 21:08:37 --> Session routines successfully run
DEBUG - 2011-03-15 21:08:37 --> Controller Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Final output sent to browser
DEBUG - 2011-03-15 21:08:37 --> Total execution time: 0.0234
DEBUG - 2011-03-15 21:08:37 --> Model Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Model Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Model Class Initialized
DEBUG - 2011-03-15 21:08:37 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:08:57 --> Config Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:08:57 --> URI Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Router Class Initialized
DEBUG - 2011-03-15 21:08:57 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:08:57 --> Output Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Input Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:08:57 --> Language Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Loader Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:08:57 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:08:57 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:08:57 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:08:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:08:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:08:57 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Session Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:08:57 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:08:57 --> A session cookie was not found.
DEBUG - 2011-03-15 21:08:57 --> Session routines successfully run
DEBUG - 2011-03-15 21:08:57 --> Controller Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Final output sent to browser
DEBUG - 2011-03-15 21:08:57 --> Total execution time: 0.0235
DEBUG - 2011-03-15 21:08:57 --> Model Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Model Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Model Class Initialized
DEBUG - 2011-03-15 21:08:57 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:08:57 --> Model Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Config Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:10:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:10:35 --> URI Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Router Class Initialized
DEBUG - 2011-03-15 21:10:35 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:10:35 --> Output Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Input Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:10:35 --> Language Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Loader Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:10:35 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:10:35 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:10:35 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:10:35 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:10:35 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:10:35 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Session Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:10:35 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:10:35 --> A session cookie was not found.
DEBUG - 2011-03-15 21:10:35 --> Session routines successfully run
DEBUG - 2011-03-15 21:10:35 --> Controller Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Final output sent to browser
DEBUG - 2011-03-15 21:10:35 --> Total execution time: 0.0242
DEBUG - 2011-03-15 21:10:35 --> Model Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Model Class Initialized
DEBUG - 2011-03-15 21:10:35 --> Model Class Initialized
DEBUG - 2011-03-15 21:10:36 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:10:45 --> Config Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:10:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:10:45 --> URI Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Router Class Initialized
DEBUG - 2011-03-15 21:10:45 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:10:45 --> Output Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Input Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:10:45 --> Language Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Loader Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:10:45 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:10:45 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:10:45 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:10:45 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:10:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:10:45 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Session Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:10:45 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:10:45 --> A session cookie was not found.
DEBUG - 2011-03-15 21:10:45 --> Session routines successfully run
DEBUG - 2011-03-15 21:10:45 --> Controller Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Final output sent to browser
DEBUG - 2011-03-15 21:10:45 --> Total execution time: 0.0243
DEBUG - 2011-03-15 21:10:45 --> Model Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Model Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Model Class Initialized
DEBUG - 2011-03-15 21:10:45 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:11:21 --> Config Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:11:21 --> URI Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Router Class Initialized
DEBUG - 2011-03-15 21:11:21 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:11:21 --> Output Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Input Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:11:21 --> Language Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Loader Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:11:21 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:11:21 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:11:21 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:11:21 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:11:21 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:11:21 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Session Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:11:21 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:11:21 --> A session cookie was not found.
DEBUG - 2011-03-15 21:11:21 --> Session routines successfully run
DEBUG - 2011-03-15 21:11:21 --> Controller Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Final output sent to browser
DEBUG - 2011-03-15 21:11:21 --> Total execution time: 0.0233
DEBUG - 2011-03-15 21:11:21 --> Model Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Model Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Model Class Initialized
DEBUG - 2011-03-15 21:11:21 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:11:21 --> Model Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Config Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:12:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:12:43 --> URI Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Router Class Initialized
DEBUG - 2011-03-15 21:12:43 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:12:43 --> Output Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Input Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:12:43 --> Language Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Loader Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:12:43 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:12:43 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:12:43 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:12:43 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:12:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:12:43 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Session Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:12:43 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:12:43 --> A session cookie was not found.
DEBUG - 2011-03-15 21:12:43 --> Session routines successfully run
DEBUG - 2011-03-15 21:12:43 --> Controller Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Final output sent to browser
DEBUG - 2011-03-15 21:12:43 --> Total execution time: 0.0243
DEBUG - 2011-03-15 21:12:43 --> Model Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Model Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Model Class Initialized
DEBUG - 2011-03-15 21:12:43 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:12:43 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Config Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:13:03 --> URI Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Router Class Initialized
DEBUG - 2011-03-15 21:13:03 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:13:03 --> Output Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Input Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:13:03 --> Language Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Loader Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:13:03 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:13:03 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:13:03 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:13:03 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:13:03 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:13:03 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Session Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:13:03 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:13:03 --> A session cookie was not found.
DEBUG - 2011-03-15 21:13:03 --> Session routines successfully run
DEBUG - 2011-03-15 21:13:03 --> Controller Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Final output sent to browser
DEBUG - 2011-03-15 21:13:03 --> Total execution time: 0.0286
DEBUG - 2011-03-15 21:13:03 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:03 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:13:03 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Config Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:13:42 --> URI Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Router Class Initialized
DEBUG - 2011-03-15 21:13:42 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:13:42 --> Output Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Input Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:13:42 --> Language Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Loader Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:13:42 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:13:42 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:13:42 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:13:42 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:13:42 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:13:42 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Session Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:13:42 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:13:42 --> A session cookie was not found.
DEBUG - 2011-03-15 21:13:42 --> Session routines successfully run
DEBUG - 2011-03-15 21:13:42 --> Controller Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Final output sent to browser
DEBUG - 2011-03-15 21:13:42 --> Total execution time: 0.0250
DEBUG - 2011-03-15 21:13:42 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Model Class Initialized
DEBUG - 2011-03-15 21:13:42 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:13:42 --> Model Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Config Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Hooks Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Utf8 Class Initialized
DEBUG - 2011-03-15 21:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-15 21:14:10 --> URI Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Router Class Initialized
DEBUG - 2011-03-15 21:14:10 --> No URI present. Default controller set.
DEBUG - 2011-03-15 21:14:10 --> Output Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Input Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-15 21:14:10 --> Language Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Loader Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-15 21:14:10 --> Helper loaded: user_helper
DEBUG - 2011-03-15 21:14:10 --> Helper loaded: url_helper
DEBUG - 2011-03-15 21:14:10 --> Helper loaded: array_helper
DEBUG - 2011-03-15 21:14:10 --> Helper loaded: utility_helper
DEBUG - 2011-03-15 21:14:10 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-15 21:14:10 --> Database Driver Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Session Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Helper loaded: string_helper
DEBUG - 2011-03-15 21:14:10 --> Encrypt Class Initialized
DEBUG - 2011-03-15 21:14:10 --> A session cookie was not found.
DEBUG - 2011-03-15 21:14:10 --> Session routines successfully run
DEBUG - 2011-03-15 21:14:10 --> Controller Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Final output sent to browser
DEBUG - 2011-03-15 21:14:10 --> Total execution time: 0.0231
DEBUG - 2011-03-15 21:14:10 --> Model Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Model Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Model Class Initialized
DEBUG - 2011-03-15 21:14:10 --> Helper loaded: markdown_helper
DEBUG - 2011-03-15 21:14:10 --> Model Class Initialized
