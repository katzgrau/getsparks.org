<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-28 09:00:48 --> Config Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:00:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:00:48 --> URI Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Router Class Initialized
DEBUG - 2011-03-28 09:00:48 --> No URI present. Default controller set.
DEBUG - 2011-03-28 09:00:48 --> Output Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Input Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:00:48 --> Language Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Loader Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:00:48 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Session Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:00:48 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Session routines successfully run
DEBUG - 2011-03-28 09:00:48 --> Controller Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: file_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: directory_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: assets_helper
DEBUG - 2011-03-28 09:00:48 --> CSSMin library initialized.
DEBUG - 2011-03-28 09:00:48 --> JSMin library initialized.
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
ERROR - 2011-03-28 09:00:48 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Model Class Initialized
DEBUG - 2011-03-28 09:00:48 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-28 09:00:48 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-28 09:00:48 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-28 09:00:48 --> File loaded: application/views/home/index.php
DEBUG - 2011-03-28 09:00:48 --> Final output sent to browser
DEBUG - 2011-03-28 09:00:48 --> Total execution time: 0.2051
DEBUG - 2011-03-28 09:00:48 --> Config Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:00:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:00:48 --> URI Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Router Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Output Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Input Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:00:48 --> Language Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Loader Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:00:48 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Session Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:00:48 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:00:48 --> Session routines successfully run
DEBUG - 2011-03-28 09:00:48 --> Controller Class Initialized
DEBUG - 2011-03-28 09:00:48 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-28 09:00:48 --> Final output sent to browser
DEBUG - 2011-03-28 09:00:48 --> Total execution time: 0.0287
DEBUG - 2011-03-28 09:38:58 --> Config Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:38:58 --> URI Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Router Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Output Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Input Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:38:58 --> Language Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Loader Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:38:58 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:38:58 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:38:58 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:38:58 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:38:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:38:58 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Session Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:38:58 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Session routines successfully run
DEBUG - 2011-03-28 09:38:58 --> Controller Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
ERROR - 2011-03-28 09:38:58 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> Model Class Initialized
DEBUG - 2011-03-28 09:38:58 --> File loaded: application/views/rss/sparks.php
DEBUG - 2011-03-28 09:38:58 --> Final output sent to browser
DEBUG - 2011-03-28 09:38:58 --> Total execution time: 0.0383
DEBUG - 2011-03-28 09:41:24 --> Config Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:41:24 --> URI Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Router Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Output Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Input Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:41:24 --> Language Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Loader Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:41:24 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:41:24 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:41:24 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:41:24 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:41:24 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:41:24 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Session Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:41:24 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Session routines successfully run
DEBUG - 2011-03-28 09:41:24 --> Controller Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
ERROR - 2011-03-28 09:41:24 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> Model Class Initialized
DEBUG - 2011-03-28 09:41:24 --> File loaded: application/views/rss/sparks.php
DEBUG - 2011-03-28 09:41:24 --> Final output sent to browser
DEBUG - 2011-03-28 09:41:24 --> Total execution time: 0.0329
DEBUG - 2011-03-28 09:42:19 --> Config Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:42:19 --> URI Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Router Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Output Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Input Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:42:19 --> Language Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Loader Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:42:19 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:42:19 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:42:19 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:42:19 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:42:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:42:19 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Session Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:42:19 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Session routines successfully run
DEBUG - 2011-03-28 09:42:19 --> Controller Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
ERROR - 2011-03-28 09:42:19 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:19 --> File loaded: application/views/rss/sparks.php
DEBUG - 2011-03-28 09:42:19 --> Final output sent to browser
DEBUG - 2011-03-28 09:42:19 --> Total execution time: 0.0314
DEBUG - 2011-03-28 09:42:28 --> Config Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:42:28 --> URI Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Router Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Output Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Input Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:42:28 --> Language Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Loader Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:42:28 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Session Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:42:28 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Session routines successfully run
DEBUG - 2011-03-28 09:42:28 --> Controller Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
ERROR - 2011-03-28 09:42:28 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: file_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: directory_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: assets_helper
DEBUG - 2011-03-28 09:42:28 --> CSSMin library initialized.
DEBUG - 2011-03-28 09:42:28 --> JSMin library initialized.
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:28 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-28 09:42:28 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-28 09:42:28 --> User Agent Class Initialized
DEBUG - 2011-03-28 09:42:28 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-28 09:42:28 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-28 09:42:28 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-28 09:42:28 --> Final output sent to browser
DEBUG - 2011-03-28 09:42:28 --> Total execution time: 0.0566
DEBUG - 2011-03-28 09:42:28 --> Config Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:42:28 --> URI Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Router Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Output Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Input Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:42:28 --> Language Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Loader Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:42:28 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Session Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:42:28 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:42:28 --> Session routines successfully run
DEBUG - 2011-03-28 09:42:28 --> Controller Class Initialized
DEBUG - 2011-03-28 09:42:28 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-28 09:42:28 --> Final output sent to browser
DEBUG - 2011-03-28 09:42:28 --> Total execution time: 0.0253
DEBUG - 2011-03-28 09:42:32 --> Config Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:42:32 --> URI Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Router Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Output Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Input Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:42:32 --> Language Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Loader Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:42:32 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Session Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:42:32 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Session routines successfully run
DEBUG - 2011-03-28 09:42:32 --> Controller Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: file_helper
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: directory_helper
DEBUG - 2011-03-28 09:42:32 --> Helper loaded: assets_helper
DEBUG - 2011-03-28 09:42:32 --> CSSMin library initialized.
DEBUG - 2011-03-28 09:42:32 --> JSMin library initialized.
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:32 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-28 09:42:32 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-28 09:42:32 --> User Agent Class Initialized
DEBUG - 2011-03-28 09:42:32 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-28 09:42:32 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-28 09:42:32 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-28 09:42:32 --> Final output sent to browser
DEBUG - 2011-03-28 09:42:32 --> Total execution time: 0.0530
DEBUG - 2011-03-28 09:42:33 --> Config Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:42:33 --> URI Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Router Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Output Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Input Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:42:33 --> Language Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Loader Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:42:33 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:42:33 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:42:33 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:42:33 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:42:33 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:42:33 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Session Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:42:33 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:42:33 --> Session routines successfully run
DEBUG - 2011-03-28 09:42:33 --> Controller Class Initialized
DEBUG - 2011-03-28 09:42:33 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-28 09:42:33 --> Final output sent to browser
DEBUG - 2011-03-28 09:42:33 --> Total execution time: 0.0234
DEBUG - 2011-03-28 09:42:43 --> Config Class Initialized
DEBUG - 2011-03-28 09:42:43 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:42:43 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:42:43 --> URI Class Initialized
DEBUG - 2011-03-28 09:42:43 --> Router Class Initialized
DEBUG - 2011-03-28 09:42:43 --> Output Class Initialized
DEBUG - 2011-03-28 09:42:43 --> Input Class Initialized
DEBUG - 2011-03-28 09:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:42:43 --> Language Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Loader Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:42:44 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Session Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:42:44 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Session routines successfully run
DEBUG - 2011-03-28 09:42:44 --> Controller Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
ERROR - 2011-03-28 09:42:44 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: file_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: directory_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: assets_helper
DEBUG - 2011-03-28 09:42:44 --> CSSMin library initialized.
DEBUG - 2011-03-28 09:42:44 --> JSMin library initialized.
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Model Class Initialized
DEBUG - 2011-03-28 09:42:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-03-28 09:42:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-03-28 09:42:44 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-03-28 09:42:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-03-28 09:42:44 --> File loaded: application/views/packages/show.php
DEBUG - 2011-03-28 09:42:44 --> Final output sent to browser
DEBUG - 2011-03-28 09:42:44 --> Total execution time: 0.0516
DEBUG - 2011-03-28 09:42:44 --> Config Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:42:44 --> URI Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Router Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Output Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Input Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:42:44 --> Language Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Loader Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:42:44 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Session Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:42:44 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:42:44 --> Session routines successfully run
DEBUG - 2011-03-28 09:42:44 --> Controller Class Initialized
DEBUG - 2011-03-28 09:42:44 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-03-28 09:42:44 --> Final output sent to browser
DEBUG - 2011-03-28 09:42:44 --> Total execution time: 0.0236
DEBUG - 2011-03-28 09:48:47 --> Config Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:48:47 --> URI Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Router Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Output Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Input Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:48:47 --> Language Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Loader Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:48:47 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:48:47 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:48:47 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:48:47 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:48:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:48:47 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Session Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:48:47 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Session routines successfully run
DEBUG - 2011-03-28 09:48:47 --> Controller Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
ERROR - 2011-03-28 09:48:47 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:47 --> File loaded: application/views/rss/sparks.php
DEBUG - 2011-03-28 09:48:47 --> Final output sent to browser
DEBUG - 2011-03-28 09:48:47 --> Total execution time: 0.0438
DEBUG - 2011-03-28 09:48:50 --> Config Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:48:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:48:50 --> URI Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Router Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Output Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Input Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:48:50 --> Language Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Loader Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:48:50 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:48:50 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:48:50 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:48:50 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:48:50 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:48:50 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Session Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:48:50 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Session routines successfully run
DEBUG - 2011-03-28 09:48:50 --> Controller Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:50 --> File loaded: application/views/rss/sparks.php
DEBUG - 2011-03-28 09:48:50 --> Final output sent to browser
DEBUG - 2011-03-28 09:48:50 --> Total execution time: 0.0347
DEBUG - 2011-03-28 09:48:56 --> Config Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:48:56 --> URI Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Router Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Output Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Input Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:48:56 --> Language Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Loader Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:48:56 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:48:56 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:48:56 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:48:56 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:48:56 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:48:56 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Session Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:48:56 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Session routines successfully run
DEBUG - 2011-03-28 09:48:56 --> Controller Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:56 --> File loaded: application/views/rss/sparks.php
DEBUG - 2011-03-28 09:48:56 --> Final output sent to browser
DEBUG - 2011-03-28 09:48:56 --> Total execution time: 0.0292
DEBUG - 2011-03-28 09:48:57 --> Config Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:48:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:48:57 --> URI Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Router Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Output Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Input Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:48:57 --> Language Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Loader Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:48:57 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:48:57 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:48:57 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:48:57 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:48:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:48:57 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Session Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:48:57 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Session routines successfully run
DEBUG - 2011-03-28 09:48:57 --> Controller Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> Model Class Initialized
DEBUG - 2011-03-28 09:48:57 --> File loaded: application/views/rss/sparks.php
DEBUG - 2011-03-28 09:48:57 --> Final output sent to browser
DEBUG - 2011-03-28 09:48:57 --> Total execution time: 0.0341
DEBUG - 2011-03-28 09:49:07 --> Config Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Hooks Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Utf8 Class Initialized
DEBUG - 2011-03-28 09:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-28 09:49:07 --> URI Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Router Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Output Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Input Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-28 09:49:07 --> Language Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Loader Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-03-28 09:49:07 --> Helper loaded: user_helper
DEBUG - 2011-03-28 09:49:07 --> Helper loaded: url_helper
DEBUG - 2011-03-28 09:49:07 --> Helper loaded: array_helper
DEBUG - 2011-03-28 09:49:07 --> Helper loaded: utility_helper
DEBUG - 2011-03-28 09:49:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-03-28 09:49:07 --> Database Driver Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Session Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Helper loaded: string_helper
DEBUG - 2011-03-28 09:49:07 --> Encrypt Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Session routines successfully run
DEBUG - 2011-03-28 09:49:07 --> Controller Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Model Class Initialized
DEBUG - 2011-03-28 09:49:07 --> Model Class Initialized
ERROR - 2011-03-28 09:49:07 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away /Users/katzgrau/Dev/ci-sparks-repo/system/database/drivers/mysql/mysql_driver.php 88
DEBUG - 2011-03-28 09:49:07 --> Model Class Initialized
ERROR - 2011-03-28 09:49:07 --> Severity: Notice  --> Undefined variable: sparks /Users/katzgrau/Dev/ci-sparks-repo/application/controllers/api/rss.php 23
ERROR - 2011-03-28 09:49:07 --> 404 Page Not Found --> 
