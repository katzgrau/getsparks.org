<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-01 01:38:47 --> Config Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:38:47 --> URI Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Router Class Initialized
DEBUG - 2011-05-01 01:38:47 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:38:47 --> Output Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Input Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:38:47 --> Language Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Loader Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:38:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Session Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:38:47 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Session routines successfully run
DEBUG - 2011-05-01 01:38:47 --> Controller Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:38:47 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:38:47 --> JSMin library initialized.
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Model Class Initialized
DEBUG - 2011-05-01 01:38:47 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:38:47 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:38:47 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:38:47 --> File loaded: application/views/home/index.php
DEBUG - 2011-05-01 01:38:47 --> Final output sent to browser
DEBUG - 2011-05-01 01:38:47 --> Total execution time: 0.0430
DEBUG - 2011-05-01 01:38:47 --> Config Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:38:47 --> URI Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Router Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Output Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Input Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:38:47 --> Language Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Loader Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:38:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Session Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:38:47 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:38:47 --> Session routines successfully run
DEBUG - 2011-05-01 01:38:47 --> Controller Class Initialized
DEBUG - 2011-05-01 01:38:47 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:38:47 --> Final output sent to browser
DEBUG - 2011-05-01 01:38:47 --> Total execution time: 0.0218
DEBUG - 2011-05-01 01:39:08 --> Config Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:39:08 --> URI Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Router Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Output Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Input Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:39:08 --> Language Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Loader Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:39:08 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Session Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:39:08 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Session routines successfully run
DEBUG - 2011-05-01 01:39:08 --> Controller Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:39:08 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:39:08 --> JSMin library initialized.
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:39:08 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 01:39:08 --> Model Class Initialized
DEBUG - 2011-05-01 01:39:08 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-05-01 01:39:08 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:39:08 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-05-01 01:39:08 --> Final output sent to browser
DEBUG - 2011-05-01 01:39:08 --> Total execution time: 0.0730
DEBUG - 2011-05-01 01:39:08 --> Config Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:39:08 --> URI Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Router Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Output Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Input Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:39:08 --> Language Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Loader Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:39:08 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Session Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:39:08 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:39:08 --> Session routines successfully run
DEBUG - 2011-05-01 01:39:08 --> Controller Class Initialized
DEBUG - 2011-05-01 01:39:08 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:39:08 --> Final output sent to browser
DEBUG - 2011-05-01 01:39:08 --> Total execution time: 0.0205
DEBUG - 2011-05-01 01:40:43 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:43 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:43 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:43 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:43 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:40:43 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:40:43 --> JSMin library initialized.
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:40:43 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 01:40:43 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:43 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-05-01 01:40:43 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:40:43 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-05-01 01:40:43 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:43 --> Total execution time: 0.0737
DEBUG - 2011-05-01 01:40:43 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:43 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:43 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:43 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:43 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:43 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:43 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:40:43 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:43 --> Total execution time: 0.0199
DEBUG - 2011-05-01 01:40:44 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:44 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:44 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:44 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:44 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:40:44 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:40:44 --> JSMin library initialized.
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:44 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:40:44 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:40:44 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:40:44 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-05-01 01:40:44 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:44 --> Total execution time: 0.0385
DEBUG - 2011-05-01 01:40:44 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:44 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:44 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:44 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:44 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:44 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:44 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:44 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:40:44 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:44 --> Total execution time: 0.0251
DEBUG - 2011-05-01 01:40:46 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:46 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:46 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:40:46 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:46 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:46 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:46 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:46 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:40:46 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:40:46 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:40:46 --> JSMin library initialized.
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:46 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:40:46 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:40:46 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:40:46 --> File loaded: application/views/home/index.php
DEBUG - 2011-05-01 01:40:46 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:46 --> Total execution time: 0.0393
DEBUG - 2011-05-01 01:40:47 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:47 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:47 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:47 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:47 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:47 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:47 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:47 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:47 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:47 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:47 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:47 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:47 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:40:47 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:47 --> Total execution time: 0.0197
DEBUG - 2011-05-01 01:40:51 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:51 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:51 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:51 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:51 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:51 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:40:51 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:40:51 --> JSMin library initialized.
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:40:51 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:40:51 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 01:40:51 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:51 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-05-01 01:40:51 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:40:51 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-05-01 01:40:51 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:51 --> Total execution time: 0.0702
DEBUG - 2011-05-01 01:40:52 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:52 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:52 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:52 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:52 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:52 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:52 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:52 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:52 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:52 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:52 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:52 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:52 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:40:52 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:52 --> Total execution time: 0.0204
DEBUG - 2011-05-01 01:40:57 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:57 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:57 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:57 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:57 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:40:57 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:40:57 --> JSMin library initialized.
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:57 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:40:57 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:40:57 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:40:57 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-05-01 01:40:57 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:57 --> Total execution time: 0.0403
DEBUG - 2011-05-01 01:40:57 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:57 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:57 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:57 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:57 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:57 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:57 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:57 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:40:57 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:57 --> Total execution time: 0.0470
DEBUG - 2011-05-01 01:40:58 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:58 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:58 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:58 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:58 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:40:58 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:40:58 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:40:58 --> JSMin library initialized.
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:40:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:40:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:40:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:40:58 --> File loaded: application/views/home/get_sparks.php
DEBUG - 2011-05-01 01:40:58 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:58 --> Total execution time: 0.0401
DEBUG - 2011-05-01 01:40:59 --> Config Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:40:59 --> URI Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Router Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Output Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Input Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:40:59 --> Language Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Loader Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:40:59 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:40:59 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:40:59 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:40:59 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:40:59 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:40:59 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Session Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:40:59 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:40:59 --> Session routines successfully run
DEBUG - 2011-05-01 01:40:59 --> Controller Class Initialized
DEBUG - 2011-05-01 01:40:59 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:40:59 --> Final output sent to browser
DEBUG - 2011-05-01 01:40:59 --> Total execution time: 0.0263
DEBUG - 2011-05-01 01:41:00 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:00 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:00 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:00 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:00 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:41:00 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:41:00 --> JSMin library initialized.
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:41:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:41:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:41:00 --> File loaded: application/views/home/make_sparks.php
DEBUG - 2011-05-01 01:41:00 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:00 --> Total execution time: 0.0391
DEBUG - 2011-05-01 01:41:00 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:00 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:00 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:00 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:00 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:00 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:00 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:41:00 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:00 --> Total execution time: 0.0200
DEBUG - 2011-05-01 01:41:05 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:05 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:05 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:05 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:05 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:05 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:41:05 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:41:05 --> JSMin library initialized.
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:05 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:41:05 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:41:05 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:41:05 --> File loaded: application/views/home/contact.php
DEBUG - 2011-05-01 01:41:05 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:05 --> Total execution time: 0.0398
DEBUG - 2011-05-01 01:41:05 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:05 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:05 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:05 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:05 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:05 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:05 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:05 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:41:05 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:05 --> Total execution time: 0.0205
DEBUG - 2011-05-01 01:41:19 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:19 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:19 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:41:19 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:19 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:19 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:19 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:41:19 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:41:19 --> JSMin library initialized.
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:19 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:41:19 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:41:19 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:41:19 --> File loaded: application/views/home/index.php
DEBUG - 2011-05-01 01:41:19 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:19 --> Total execution time: 0.0386
DEBUG - 2011-05-01 01:41:19 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:19 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:19 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:19 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:19 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:19 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:19 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:41:19 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:19 --> Total execution time: 0.0199
DEBUG - 2011-05-01 01:41:30 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:30 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:30 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:41:30 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:30 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:30 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:30 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:30 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:41:30 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:41:30 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:41:30 --> JSMin library initialized.
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:30 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:41:30 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:41:30 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:41:30 --> File loaded: application/views/home/index.php
DEBUG - 2011-05-01 01:41:30 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:30 --> Total execution time: 0.0402
DEBUG - 2011-05-01 01:41:31 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:31 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:31 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:31 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:31 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:31 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:31 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:31 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:31 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:31 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:31 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:31 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:31 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:41:31 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:31 --> Total execution time: 0.0276
DEBUG - 2011-05-01 01:41:37 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:37 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:37 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:37 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:37 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:41:37 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:41:37 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:41:37 --> JSMin library initialized.
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:37 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:41:37 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:41:37 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:41:37 --> File loaded: application/views/contributors/login.php
DEBUG - 2011-05-01 01:41:37 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:37 --> Total execution time: 0.0530
DEBUG - 2011-05-01 01:41:38 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:38 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:38 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:38 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:38 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:38 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:38 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:38 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:38 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:38 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:38 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:38 --> File loaded: application/views/global/_login_form.php
DEBUG - 2011-05-01 01:41:38 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:38 --> Total execution time: 0.0200
DEBUG - 2011-05-01 01:41:41 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:41 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:41 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:41 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:41 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:41 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:41 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:41 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:41 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:41:41 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:41:41 --> JSMin library initialized.
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 01:41:41 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/contributors/profile.php
DEBUG - 2011-05-01 01:41:41 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:41 --> Total execution time: 0.0602
DEBUG - 2011-05-01 01:41:41 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:41 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:41 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:41 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:41 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:41 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:41 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:41 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-05-01 01:41:41 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:41 --> Total execution time: 0.0272
DEBUG - 2011-05-01 01:41:58 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:58 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:58 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:58 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:58 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:41:58 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:41:58 --> JSMin library initialized.
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:41:58 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:41:58 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:41:58 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:41:58 --> File loaded: application/views/home/set_up.php
DEBUG - 2011-05-01 01:41:58 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:58 --> Total execution time: 0.0495
DEBUG - 2011-05-01 01:41:58 --> Config Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:41:58 --> URI Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Router Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Output Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Input Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:41:58 --> Language Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Loader Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:41:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Session Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:41:58 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:41:58 --> Session routines successfully run
DEBUG - 2011-05-01 01:41:58 --> Controller Class Initialized
DEBUG - 2011-05-01 01:41:58 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-05-01 01:41:58 --> Final output sent to browser
DEBUG - 2011-05-01 01:41:58 --> Total execution time: 0.0278
DEBUG - 2011-05-01 01:42:00 --> Config Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:42:00 --> URI Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Router Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Output Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Input Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:42:00 --> Language Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Loader Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:42:00 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Session Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:42:00 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Session routines successfully run
DEBUG - 2011-05-01 01:42:00 --> Controller Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:42:00 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:42:00 --> JSMin library initialized.
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:42:00 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 01:42:00 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:42:00 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-05-01 01:42:00 --> Final output sent to browser
DEBUG - 2011-05-01 01:42:00 --> Total execution time: 0.1052
DEBUG - 2011-05-01 01:42:01 --> Config Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:42:01 --> URI Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Router Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Output Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Input Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:42:01 --> Language Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Loader Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:42:01 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:42:01 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:42:01 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:42:01 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:42:01 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:42:01 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Session Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:42:01 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:42:01 --> Session routines successfully run
DEBUG - 2011-05-01 01:42:01 --> Controller Class Initialized
DEBUG - 2011-05-01 01:42:01 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-05-01 01:42:01 --> Final output sent to browser
DEBUG - 2011-05-01 01:42:01 --> Total execution time: 0.0290
DEBUG - 2011-05-01 01:42:06 --> Config Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:42:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:42:06 --> URI Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Router Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Output Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Input Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:42:06 --> Language Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Loader Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:42:06 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Session Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:42:06 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Session routines successfully run
DEBUG - 2011-05-01 01:42:06 --> Controller Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:42:06 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:42:06 --> JSMin library initialized.
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:42:06 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:42:06 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 01:42:06 --> Model Class Initialized
DEBUG - 2011-05-01 01:42:06 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:42:06 --> User Agent Class Initialized
DEBUG - 2011-05-01 01:42:06 --> File loaded: application/views/global/_disqus.php
DEBUG - 2011-05-01 01:42:06 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:42:06 --> File loaded: application/views/packages/show.php
DEBUG - 2011-05-01 01:42:06 --> Final output sent to browser
DEBUG - 2011-05-01 01:42:06 --> Total execution time: 0.0537
DEBUG - 2011-05-01 01:42:07 --> Config Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:42:07 --> URI Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Router Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Output Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Input Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:42:07 --> Language Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Loader Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:42:07 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:42:07 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:42:07 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:42:07 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:42:07 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:42:07 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Session Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:42:07 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:42:07 --> Session routines successfully run
DEBUG - 2011-05-01 01:42:07 --> Controller Class Initialized
DEBUG - 2011-05-01 01:42:07 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-05-01 01:42:07 --> Final output sent to browser
DEBUG - 2011-05-01 01:42:07 --> Total execution time: 0.0219
DEBUG - 2011-05-01 01:58:38 --> Config Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:58:38 --> URI Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Router Class Initialized
DEBUG - 2011-05-01 01:58:38 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:58:38 --> Output Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Input Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:58:38 --> Language Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Loader Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:58:38 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:58:38 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:58:38 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:58:38 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:58:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:58:38 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:58:38 --> Session Class Initialized
DEBUG - 2011-05-01 01:58:39 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:58:39 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:58:39 --> A session cookie was not found.
DEBUG - 2011-05-01 01:58:39 --> Session routines successfully run
DEBUG - 2011-05-01 01:58:39 --> Controller Class Initialized
DEBUG - 2011-05-01 01:58:39 --> Final output sent to browser
DEBUG - 2011-05-01 01:58:39 --> Total execution time: 0.0243
DEBUG - 2011-05-01 01:58:39 --> Model Class Initialized
DEBUG - 2011-05-01 01:58:39 --> Model Class Initialized
DEBUG - 2011-05-01 01:58:39 --> Model Class Initialized
DEBUG - 2011-05-01 01:58:39 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 01:58:39 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Config Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:59:12 --> URI Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Router Class Initialized
DEBUG - 2011-05-01 01:59:12 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:59:12 --> Output Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Input Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:59:12 --> Language Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Loader Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:59:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Session Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:59:12 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Session routines successfully run
DEBUG - 2011-05-01 01:59:12 --> Controller Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:59:12 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:59:12 --> JSMin library initialized.
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:12 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:59:12 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:59:12 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:59:12 --> File loaded: application/views/home/index.php
DEBUG - 2011-05-01 01:59:12 --> Final output sent to browser
DEBUG - 2011-05-01 01:59:12 --> Total execution time: 0.0530
DEBUG - 2011-05-01 01:59:12 --> Config Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:59:12 --> URI Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Router Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Output Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Input Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:59:12 --> Language Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Loader Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:59:12 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Session Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:59:12 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:59:12 --> Session routines successfully run
DEBUG - 2011-05-01 01:59:12 --> Controller Class Initialized
DEBUG - 2011-05-01 01:59:12 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-05-01 01:59:12 --> Final output sent to browser
DEBUG - 2011-05-01 01:59:12 --> Total execution time: 0.0249
DEBUG - 2011-05-01 01:59:13 --> Config Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:59:13 --> URI Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Router Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Output Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Input Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:59:13 --> Language Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Loader Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:59:13 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Session Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:59:13 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Session routines successfully run
DEBUG - 2011-05-01 01:59:13 --> Controller Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: file_helper
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 01:59:13 --> CSSMin library initialized.
DEBUG - 2011-05-01 01:59:13 --> JSMin library initialized.
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 01:59:13 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 01:59:13 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 01:59:13 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-05-01 01:59:13 --> Final output sent to browser
DEBUG - 2011-05-01 01:59:13 --> Total execution time: 0.0876
DEBUG - 2011-05-01 01:59:14 --> Config Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:59:14 --> URI Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Router Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Output Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Input Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:59:14 --> Language Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Loader Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:59:14 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:59:14 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:59:14 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:59:14 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:59:14 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:59:14 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Session Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:59:14 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:59:14 --> Session routines successfully run
DEBUG - 2011-05-01 01:59:14 --> Controller Class Initialized
DEBUG - 2011-05-01 01:59:14 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-05-01 01:59:14 --> Final output sent to browser
DEBUG - 2011-05-01 01:59:14 --> Total execution time: 0.0222
DEBUG - 2011-05-01 01:59:19 --> Config Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:59:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:59:19 --> URI Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Router Class Initialized
DEBUG - 2011-05-01 01:59:19 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:59:19 --> Output Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Input Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:59:19 --> Language Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Loader Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:59:19 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:59:19 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:59:19 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:59:19 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:59:19 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:59:19 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Session Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:59:19 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:59:19 --> A session cookie was not found.
DEBUG - 2011-05-01 01:59:19 --> Session routines successfully run
DEBUG - 2011-05-01 01:59:19 --> Controller Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Final output sent to browser
DEBUG - 2011-05-01 01:59:19 --> Total execution time: 0.0233
DEBUG - 2011-05-01 01:59:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:19 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 01:59:19 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Config Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:59:34 --> URI Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Router Class Initialized
DEBUG - 2011-05-01 01:59:34 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:59:34 --> Output Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Input Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:59:34 --> Language Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Loader Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:59:34 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:59:34 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:59:34 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:59:34 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:59:34 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:59:34 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Session Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:59:34 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:59:34 --> A session cookie was not found.
DEBUG - 2011-05-01 01:59:34 --> Session routines successfully run
DEBUG - 2011-05-01 01:59:34 --> Controller Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Final output sent to browser
DEBUG - 2011-05-01 01:59:34 --> Total execution time: 0.0244
DEBUG - 2011-05-01 01:59:34 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:34 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 01:59:34 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Config Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Hooks Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Utf8 Class Initialized
DEBUG - 2011-05-01 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 01:59:58 --> URI Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Router Class Initialized
DEBUG - 2011-05-01 01:59:58 --> No URI present. Default controller set.
DEBUG - 2011-05-01 01:59:58 --> Output Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Input Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 01:59:58 --> Language Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Loader Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 01:59:58 --> Helper loaded: user_helper
DEBUG - 2011-05-01 01:59:58 --> Helper loaded: url_helper
DEBUG - 2011-05-01 01:59:58 --> Helper loaded: array_helper
DEBUG - 2011-05-01 01:59:58 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 01:59:58 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 01:59:58 --> Database Driver Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Session Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Helper loaded: string_helper
DEBUG - 2011-05-01 01:59:58 --> Encrypt Class Initialized
DEBUG - 2011-05-01 01:59:58 --> A session cookie was not found.
DEBUG - 2011-05-01 01:59:58 --> Session routines successfully run
DEBUG - 2011-05-01 01:59:58 --> Controller Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Final output sent to browser
DEBUG - 2011-05-01 01:59:58 --> Total execution time: 0.0249
DEBUG - 2011-05-01 01:59:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Model Class Initialized
DEBUG - 2011-05-01 01:59:58 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 01:59:58 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Config Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:01:26 --> URI Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Router Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Output Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Input Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:01:26 --> Language Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Loader Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:01:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Session Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:01:26 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Session routines successfully run
DEBUG - 2011-05-01 02:01:26 --> Controller Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Config file loaded: sparks/assets/v0.4/config/assets.php
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: file_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: directory_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: assets_helper
DEBUG - 2011-05-01 02:01:26 --> CSSMin library initialized.
DEBUG - 2011-05-01 02:01:26 --> JSMin library initialized.
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/global/_left_column.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/global/_new_header.php
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: rating_helper
DEBUG - 2011-05-01 02:01:26 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/ratings/_rating.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/packages/_list.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/global/_new_footer.php
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/packages/listing.php
DEBUG - 2011-05-01 02:01:26 --> Final output sent to browser
DEBUG - 2011-05-01 02:01:26 --> Total execution time: 0.1104
DEBUG - 2011-05-01 02:01:26 --> Config Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:01:26 --> URI Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Router Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Output Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Input Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:01:26 --> Language Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Loader Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:01:26 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Session Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:01:26 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:01:26 --> Session routines successfully run
DEBUG - 2011-05-01 02:01:26 --> Controller Class Initialized
DEBUG - 2011-05-01 02:01:26 --> File loaded: application/views/global/_profile_box.php
DEBUG - 2011-05-01 02:01:26 --> Final output sent to browser
DEBUG - 2011-05-01 02:01:26 --> Total execution time: 0.0224
DEBUG - 2011-05-01 02:01:38 --> Config Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:01:38 --> URI Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Router Class Initialized
DEBUG - 2011-05-01 02:01:38 --> No URI present. Default controller set.
DEBUG - 2011-05-01 02:01:38 --> Output Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Input Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:01:38 --> Language Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Loader Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:01:38 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:01:38 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:01:38 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:01:38 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:01:38 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:01:38 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Session Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:01:38 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:01:38 --> A session cookie was not found.
DEBUG - 2011-05-01 02:01:38 --> Session routines successfully run
DEBUG - 2011-05-01 02:01:38 --> Controller Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Final output sent to browser
DEBUG - 2011-05-01 02:01:38 --> Total execution time: 0.0236
DEBUG - 2011-05-01 02:01:38 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:38 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 02:01:38 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Config Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:01:43 --> URI Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Router Class Initialized
DEBUG - 2011-05-01 02:01:43 --> No URI present. Default controller set.
DEBUG - 2011-05-01 02:01:43 --> Output Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Input Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:01:43 --> Language Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Loader Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:01:43 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:01:43 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:01:43 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:01:43 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:01:43 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:01:43 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Session Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:01:43 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:01:43 --> A session cookie was not found.
DEBUG - 2011-05-01 02:01:43 --> Session routines successfully run
DEBUG - 2011-05-01 02:01:43 --> Controller Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Final output sent to browser
DEBUG - 2011-05-01 02:01:43 --> Total execution time: 0.0248
DEBUG - 2011-05-01 02:01:43 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Model Class Initialized
DEBUG - 2011-05-01 02:01:43 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 02:01:43 --> Model Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Config Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:04:46 --> URI Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Router Class Initialized
DEBUG - 2011-05-01 02:04:46 --> No URI present. Default controller set.
DEBUG - 2011-05-01 02:04:46 --> Output Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Input Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:04:46 --> Language Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Loader Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:04:46 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:04:46 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:04:46 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:04:46 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:04:46 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:04:46 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Session Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:04:46 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:04:46 --> A session cookie was not found.
DEBUG - 2011-05-01 02:04:46 --> Session routines successfully run
DEBUG - 2011-05-01 02:04:46 --> Controller Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Final output sent to browser
DEBUG - 2011-05-01 02:04:46 --> Total execution time: 0.0265
DEBUG - 2011-05-01 02:04:46 --> Model Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Model Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Model Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 02:04:46 --> Model Class Initialized
DEBUG - 2011-05-01 02:04:46 --> Model Class Initialized
DEBUG - 2011-05-01 02:04:46 --> DB Transaction Failure
ERROR - 2011-05-01 02:04:46 --> Query error: Duplicate entry '86-85' for key 'uniq_version_dep'
DEBUG - 2011-05-01 02:04:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-05-01 02:05:37 --> Config Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:05:37 --> URI Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Router Class Initialized
DEBUG - 2011-05-01 02:05:37 --> No URI present. Default controller set.
DEBUG - 2011-05-01 02:05:37 --> Output Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Input Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:05:37 --> Language Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Loader Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:05:37 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:05:37 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:05:37 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:05:37 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:05:37 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:05:37 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Session Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:05:37 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:05:37 --> A session cookie was not found.
DEBUG - 2011-05-01 02:05:37 --> Session routines successfully run
DEBUG - 2011-05-01 02:05:37 --> Controller Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Final output sent to browser
DEBUG - 2011-05-01 02:05:37 --> Total execution time: 0.0257
DEBUG - 2011-05-01 02:05:37 --> Model Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Model Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Model Class Initialized
DEBUG - 2011-05-01 02:05:37 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 02:05:37 --> Model Class Initialized
DEBUG - 2011-05-01 02:05:38 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Config Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:06:25 --> URI Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Router Class Initialized
DEBUG - 2011-05-01 02:06:25 --> No URI present. Default controller set.
DEBUG - 2011-05-01 02:06:25 --> Output Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Input Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:06:25 --> Language Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Loader Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:06:25 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:06:25 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:06:25 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:06:25 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:06:25 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:06:25 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Session Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:06:25 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:06:25 --> A session cookie was not found.
DEBUG - 2011-05-01 02:06:25 --> Session routines successfully run
DEBUG - 2011-05-01 02:06:25 --> Controller Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Final output sent to browser
DEBUG - 2011-05-01 02:06:25 --> Total execution time: 0.0233
DEBUG - 2011-05-01 02:06:25 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:25 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 02:06:45 --> Config Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Hooks Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Utf8 Class Initialized
DEBUG - 2011-05-01 02:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-01 02:06:45 --> URI Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Router Class Initialized
DEBUG - 2011-05-01 02:06:45 --> No URI present. Default controller set.
DEBUG - 2011-05-01 02:06:45 --> Output Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Input Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-01 02:06:45 --> Language Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Loader Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Config file loaded: application/config/application.php
DEBUG - 2011-05-01 02:06:45 --> Helper loaded: user_helper
DEBUG - 2011-05-01 02:06:45 --> Helper loaded: url_helper
DEBUG - 2011-05-01 02:06:45 --> Helper loaded: array_helper
DEBUG - 2011-05-01 02:06:45 --> Helper loaded: utility_helper
DEBUG - 2011-05-01 02:06:45 --> Helper loaded: gravatar_helper
DEBUG - 2011-05-01 02:06:45 --> Database Driver Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Session Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Helper loaded: string_helper
DEBUG - 2011-05-01 02:06:45 --> Encrypt Class Initialized
DEBUG - 2011-05-01 02:06:45 --> A session cookie was not found.
DEBUG - 2011-05-01 02:06:45 --> Session routines successfully run
DEBUG - 2011-05-01 02:06:45 --> Controller Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Final output sent to browser
DEBUG - 2011-05-01 02:06:45 --> Total execution time: 0.0242
DEBUG - 2011-05-01 02:06:45 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Helper loaded: markdown_helper
DEBUG - 2011-05-01 02:06:45 --> Model Class Initialized
DEBUG - 2011-05-01 02:06:45 --> Model Class Initialized
