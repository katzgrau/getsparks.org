<?php

class PaypalHelper
{
    public static function getTestString()
    {
        return "Foooooooooo";
    }
}