<?php

class SparkException extends Exception {

}
